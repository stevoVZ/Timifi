// app/admin/dashboard/page.tsx
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

const KPI = [
  { label:'Active contractors', value:'12',    sub:'3 pending onboarding', col:B.accent },
  { label:'Timesheets due',     value:'8',     sub:'This month',           col:B.amber  },
  { label:'Invoices outstanding',value:'$42,800', sub:'Aged 30+ days: $12,400', col:B.red },
  { label:'Next pay run',       value:'31 Mar', sub:'4 contractors',       col:B.green  },
]

export default function DashboardPage() {
  return (
    <>
      <TopBar title="Dashboard" subtitle="March 2026"/>
      <main style={{flex:1,padding:'28px 32px',background:'#f4f5f7'}}>

        {/* KPI strip */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:16,marginBottom:28}}>
          {KPI.map(k=>(
            <div key={k.label} style={{
              background:'#fff',border:'1px solid #e5e7eb',borderRadius:12,
              padding:'20px 22px',boxShadow:'0 1px 2px rgba(0,0,0,.04)',
            }}>
              <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:'#6b7280',marginBottom:10}}>{k.label}</div>
              <div style={{fontSize:26,fontWeight:700,color:k.col,fontFamily:"'DM Mono',monospace",marginBottom:4}}>{k.value}</div>
              <div style={{fontSize:12,color:'#9ca3af'}}>{k.sub}</div>
            </div>
          ))}
        </div>

        {/* Quick links */}
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
          {[
            {title:'Upload timesheets',  desc:'Drop PDFs for one or more contractors',  href:'/admin/timesheets', icon:'📄'},
            {title:'Process pay run',    desc:'Review and file this month\'s payroll',  href:'/admin/payroll',    icon:'💳'},
            {title:'Review contractors', desc:'Onboarding, profiles, contract hours',   href:'/admin/contractors',icon:'👤'},
            {title:'Send invoices',      desc:'Create and email invoices via Xero',     href:'/admin/invoicing',  icon:'🧾'},
          ].map(q=>(
            <a key={q.href} href={q.href} style={{
              display:'flex',alignItems:'center',gap:14,
              background:'#fff',border:'1px solid #e5e7eb',borderRadius:12,
              padding:'18px 20px',textDecoration:'none',
              transition:'border-color .15s,box-shadow .15s',
            }}
            onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.borderColor='#2563eb';(e.currentTarget as HTMLElement).style.boxShadow='0 0 0 3px #eff6ff'}}
            onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.borderColor='#e5e7eb';(e.currentTarget as HTMLElement).style.boxShadow='none'}}
            >
              <div style={{
                width:44,height:44,borderRadius:11,background:'#f4f5f7',
                display:'flex',alignItems:'center',justifyContent:'center',
                fontSize:22,flexShrink:0,
              }}>{q.icon}</div>
              <div>
                <div style={{fontSize:14,fontWeight:600,color:'#111827'}}>{q.title}</div>
                <div style={{fontSize:13,color:'#6b7280',marginTop:2}}>{q.desc}</div>
              </div>
            </a>
          ))}
        </div>
      </main>
    </>
  )
}
