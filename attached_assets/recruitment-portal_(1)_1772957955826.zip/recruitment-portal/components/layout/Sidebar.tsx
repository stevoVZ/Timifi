'use client'
// components/layout/Sidebar.tsx
import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { B } from '@/lib/design'

const NAV = [
  { label:'Dashboard',     href:'/admin/dashboard',    icon:'▦' },
  { label:'Contractors',   href:'/admin/contractors',  icon:'👤' },
  { label:'Timesheets',    href:'/admin/timesheets',   icon:'📄' },
  { label:'Pay Runs',      href:'/admin/payroll',      icon:'💳' },
  { label:'Invoicing',     href:'/admin/invoicing',    icon:'🧾' },
  { label:'Notifications', href:'/admin/notifications',icon:'🔔' },
  { label:'Settings',      href:'/admin/settings',     icon:'⚙️' },
]

export default function Sidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside style={{
      width: collapsed ? 58 : 220,
      minHeight: '100vh',
      background: B.surface,
      borderRight: `1px solid ${B.border}`,
      display: 'flex',
      flexDirection: 'column',
      transition: 'width .2s cubic-bezier(.22,.68,0,1.2)',
      flexShrink: 0,
      position: 'sticky',
      top: 0,
    }}>
      {/* Logo */}
      <div style={{
        padding: collapsed ? '18px 0' : '18px 16px',
        borderBottom: `1px solid ${B.faint}`,
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        justifyContent: collapsed ? 'center' : 'flex-start',
      }}>
        <div style={{
          width:32,height:32,borderRadius:9,background:B.accent,
          display:'flex',alignItems:'center',justifyContent:'center',
          fontSize:16,flexShrink:0,
        }}>🏢</div>
        {!collapsed && (
          <span style={{fontSize:14,fontWeight:700,color:B.text,whiteSpace:'nowrap'}}>
            Recruitment
          </span>
        )}
      </div>

      {/* Nav */}
      <nav style={{flex:1,padding:'12px 0',overflowY:'auto'}}>
        {NAV.map(item=>{
          const active = pathname.startsWith(item.href)
          return (
            <Link key={item.href} href={item.href} style={{
              display:'flex',alignItems:'center',gap:10,
              padding: collapsed ? '10px 0' : '10px 14px',
              justifyContent: collapsed ? 'center' : 'flex-start',
              margin:'2px 8px',
              borderRadius:8,
              textDecoration:'none',
              background: active ? B.aP : 'transparent',
              color: active ? B.accent : B.dim,
              fontWeight: active ? 600 : 400,
              fontSize:14,
              transition:'all .12s',
            }}
            onMouseEnter={e=>{if(!active)(e.currentTarget as HTMLElement).style.background=B.faint}}
            onMouseLeave={e=>{if(!active)(e.currentTarget as HTMLElement).style.background='transparent'}}
            >
              <span style={{fontSize:16,flexShrink:0}}>{item.icon}</span>
              {!collapsed && <span style={{whiteSpace:'nowrap'}}>{item.label}</span>}
            </Link>
          )
        })}
      </nav>

      {/* Collapse toggle */}
      <div style={{padding:'12px 8px',borderTop:`1px solid ${B.faint}`}}>
        <button
          onClick={()=>setCollapsed(c=>!c)}
          style={{
            width:'100%',padding:'9px',borderRadius:8,border:'none',
            background:'transparent',cursor:'pointer',
            fontSize:14,color:B.dim,display:'flex',alignItems:'center',
            justifyContent: collapsed ? 'center' : 'flex-start',
            gap:8,fontFamily:"'DM Sans',sans-serif",transition:'all .12s',
          }}
          onMouseEnter={e=>(e.currentTarget.style.background=B.faint)}
          onMouseLeave={e=>(e.currentTarget.style.background='transparent')}
        >
          <span style={{fontSize:16}}>{collapsed ? '→' : '←'}</span>
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </aside>
  )
}
