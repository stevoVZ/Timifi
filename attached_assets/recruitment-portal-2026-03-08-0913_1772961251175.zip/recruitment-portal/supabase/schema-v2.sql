-- =============================================================================
-- Schema additions v2 — run AFTER schema.sql and schema-additions.sql
-- Adds: messages, organisations (multi-tenant), contractor_documents view,
--       onboarding_status column, ABA payment records, webhook_events index
-- =============================================================================

-- =============================================================================
-- 1. MESSAGES (in-app messaging between agency staff and contractors)
-- =============================================================================

CREATE TYPE message_status AS ENUM ('SENT', 'DELIVERED', 'READ', 'ARCHIVED');

CREATE TABLE messages (
  id              UUID           PRIMARY KEY DEFAULT uuid_generate_v4(),
  -- Thread grouping (all replies share the same thread_id = first message id)
  thread_id       UUID           NOT NULL,
  -- Participants
  from_profile_id UUID           NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  to_profile_id   UUID           NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  contractor_id   UUID           REFERENCES contractors(id) ON DELETE CASCADE,
  -- Content
  subject         TEXT,
  body            TEXT           NOT NULL,
  status          message_status NOT NULL DEFAULT 'SENT',
  is_read         BOOLEAN        NOT NULL DEFAULT FALSE,
  read_at         TIMESTAMPTZ,
  -- Attachments (stored in documents bucket, referenced by id)
  attachment_ids  UUID[]         DEFAULT '{}',
  -- Meta
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Admins and consultants see all messages
CREATE POLICY "messages: staff all"
  ON messages FOR ALL
  USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));

-- Contractors can read messages where they are sender or recipient
CREATE POLICY "messages: contractor read own"
  ON messages FOR SELECT
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'contractor'
    AND (from_profile_id = auth.uid() OR to_profile_id = auth.uid())
  );

-- Contractors can send messages (insert)
CREATE POLICY "messages: contractor send"
  ON messages FOR INSERT
  WITH CHECK (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'contractor'
    AND from_profile_id = auth.uid()
  );

-- Contractors can mark their own messages read (update is_read)
CREATE POLICY "messages: contractor mark read"
  ON messages FOR UPDATE
  USING (
    (SELECT role FROM profiles WHERE id = auth.uid()) = 'contractor'
    AND to_profile_id = auth.uid()
  );

CREATE INDEX idx_messages_thread    ON messages(thread_id);
CREATE INDEX idx_messages_to        ON messages(to_profile_id);
CREATE INDEX idx_messages_from      ON messages(from_profile_id);
CREATE INDEX idx_messages_contractor ON messages(contractor_id);
CREATE INDEX idx_messages_unread    ON messages(to_profile_id) WHERE is_read = FALSE;

-- Auto-set thread_id to own id if not provided (first message in thread)
CREATE OR REPLACE FUNCTION set_thread_id()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.thread_id IS NULL OR NEW.thread_id = '00000000-0000-0000-0000-000000000000' THEN
    NEW.thread_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_set_thread_id
  BEFORE INSERT ON messages
  FOR EACH ROW EXECUTE FUNCTION set_thread_id();

CREATE TRIGGER trg_updated_at_messages
  BEFORE UPDATE ON messages
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- =============================================================================
-- 2. ORGANISATIONS (multi-tenant support)
-- Each organisation = one portal instance (one agency brand)
-- =============================================================================

CREATE TABLE organisations (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug            TEXT        NOT NULL UNIQUE,   -- URL slug, e.g. "acme-recruitment"
  name            TEXT        NOT NULL,
  abn             TEXT,
  plan            TEXT        NOT NULL DEFAULT 'starter',  -- starter | professional | enterprise
  is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
  -- Branding
  accent_color    TEXT        NOT NULL DEFAULT '#2563eb',
  logo_url        TEXT,
  -- Billing
  billing_email   TEXT,
  stripe_customer_id TEXT,
  trial_ends_at   TIMESTAMPTZ,
  -- Limits
  max_contractors SMALLINT    NOT NULL DEFAULT 10,
  -- Meta
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE organisations ENABLE ROW LEVEL SECURITY;

-- Organisation members junction table
CREATE TABLE org_members (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  org_id          UUID        NOT NULL REFERENCES organisations(id) ON DELETE CASCADE,
  profile_id      UUID        NOT NULL REFERENCES profiles(id)      ON DELETE CASCADE,
  org_role        TEXT        NOT NULL DEFAULT 'member',  -- owner | admin | member
  is_active       BOOLEAN     NOT NULL DEFAULT TRUE,
  joined_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (org_id, profile_id)
);

ALTER TABLE org_members ENABLE ROW LEVEL SECURITY;

-- Members can see their own org
CREATE POLICY "org_members: read own"
  ON org_members FOR SELECT
  USING (profile_id = auth.uid());

-- Org owners/admins can manage membership
CREATE POLICY "org_members: owner manage"
  ON org_members FOR ALL
  USING (
    (SELECT org_role FROM org_members WHERE org_id = org_members.org_id AND profile_id = auth.uid())
    IN ('owner','admin')
  );

-- Add org_id to contractors (nullable for backward compat)
ALTER TABLE contractors ADD COLUMN IF NOT EXISTS org_id UUID REFERENCES organisations(id);
CREATE INDEX IF NOT EXISTS idx_contractors_org ON contractors(org_id);

-- Add org_id to portal_settings
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS org_id UUID REFERENCES organisations(id);

CREATE TRIGGER trg_updated_at_organisations BEFORE UPDATE ON organisations FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- =============================================================================
-- 3. ONBOARDING STATUS — track wizard progress per contractor
-- =============================================================================

ALTER TABLE contractors
  ADD COLUMN IF NOT EXISTS onboarding_complete     BOOLEAN     NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS onboarding_completed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS onboarding_step         SMALLINT    NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS date_of_birth           DATE,
  ADD COLUMN IF NOT EXISTS gender                  CHAR(1),
  ADD COLUMN IF NOT EXISTS super_stapled           BOOLEAN     NOT NULL DEFAULT FALSE;

-- =============================================================================
-- 4. ABA PAYMENT RECORDS (Australian Banking Association direct entry files)
-- =============================================================================

CREATE TABLE aba_payments (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  pay_run_id      UUID        NOT NULL REFERENCES pay_runs(id) ON DELETE CASCADE,
  -- File details
  file_name       TEXT        NOT NULL,
  file_content    TEXT,             -- ABA file content (stored for audit)
  file_url        TEXT,             -- Supabase Storage URL
  total_amount    NUMERIC(12,2) NOT NULL,
  entry_count     SMALLINT    NOT NULL,
  -- Processing bank details
  bsb             TEXT        NOT NULL,   -- Agency's BSB (debit account)
  account_number  TEXT        NOT NULL,   -- Agency's account number
  account_name    TEXT        NOT NULL,
  description     TEXT,
  -- Status
  status          TEXT        NOT NULL DEFAULT 'GENERATED',  -- GENERATED | SUBMITTED | PROCESSED
  submitted_at    TIMESTAMPTZ,
  processed_at    TIMESTAMPTZ,
  -- Meta
  generated_by    UUID        REFERENCES profiles(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE aba_payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "aba: admin all" ON aba_payments FOR ALL USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');

CREATE INDEX idx_aba_pay_run ON aba_payments(pay_run_id);

-- =============================================================================
-- 5. SEED: Default organisation record
-- =============================================================================

INSERT INTO organisations (id, slug, name, plan, max_contractors)
VALUES ('00000000-0000-0000-0000-000000000001', 'default', 'Default Agency', 'professional', 50)
ON CONFLICT (slug) DO NOTHING;

-- =============================================================================
-- 6. Seed messages for demo contractors
-- (Run after profiles are created — update UUIDs to match your actual profile IDs)
-- =============================================================================

-- Example:
-- INSERT INTO messages (thread_id, from_profile_id, to_profile_id, contractor_id, subject, body, is_read)
-- VALUES (
--   gen_random_uuid(),
--   '<admin-profile-id>',
--   '<contractor-profile-id>',
--   '<contractor-id>',
--   'Timesheet for March',
--   'Hi Alex, please submit your March timesheet by EOD Friday.',
--   FALSE
-- );
