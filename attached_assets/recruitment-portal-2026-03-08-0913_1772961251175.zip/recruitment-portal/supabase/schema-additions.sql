-- =============================================================================
-- Schema additions — run AFTER schema.sql
-- Adds: leave_requests, pay_items, portal_settings, contractor_pay_items
-- =============================================================================

-- New enums
CREATE TYPE leave_type   AS ENUM ('ANNUAL','SICK','LONG_SERVICE','PERSONAL','COMPASSIONATE','UNPAID','PUBLIC_HOLIDAY');
CREATE TYPE leave_status AS ENUM ('PENDING','APPROVED','REJECTED','CANCELLED');

-- =============================================================================
-- PORTAL SETTINGS (single row per portal instance — upsert on id=1)
-- =============================================================================

CREATE TABLE portal_settings (
  id                     INTEGER     PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  -- Branding
  agency_name            TEXT        NOT NULL DEFAULT 'Recruitment Portal',
  accent_color           TEXT        NOT NULL DEFAULT '#2563eb',
  logo_url               TEXT,
  primary_email          TEXT,
  -- Company
  abn                    TEXT,
  acn                    TEXT,
  registered_name        TEXT,
  street_address         TEXT,
  suburb                 TEXT,
  state                  CHAR(3),
  postcode               TEXT,
  phone                  TEXT,
  -- Payroll
  super_rate             NUMERIC(5,4) NOT NULL DEFAULT 0.1150,
  payment_terms_days     SMALLINT    NOT NULL DEFAULT 14,
  default_pay_calendar   pay_calendar NOT NULL DEFAULT 'MONTHLY',
  stp_enabled            BOOLEAN     NOT NULL DEFAULT TRUE,
  auto_super_calc        BOOLEAN     NOT NULL DEFAULT TRUE,
  -- Portal access
  contractor_portal      BOOLEAN     NOT NULL DEFAULT TRUE,
  contractor_upload      BOOLEAN     NOT NULL DEFAULT FALSE,
  mfa_required           BOOLEAN     NOT NULL DEFAULT FALSE,
  session_timeout_mins   SMALLINT    NOT NULL DEFAULT 60,
  -- Meta
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by             UUID        REFERENCES profiles(id)
);

ALTER TABLE portal_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings: admin write" ON portal_settings FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "settings: staff read"  ON portal_settings FOR SELECT USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));

-- Insert default row
INSERT INTO portal_settings (id) VALUES (1) ON CONFLICT DO NOTHING;

-- =============================================================================
-- PAY ITEMS (pay codes / earnings types)
-- =============================================================================

CREATE TABLE pay_items (
  id                UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  code              TEXT        NOT NULL UNIQUE,       -- e.g. "ORDINARY", "OVERTIME_1_5"
  name              TEXT        NOT NULL,
  description       TEXT,
  item_type         TEXT        NOT NULL DEFAULT 'EARNINGS', -- EARNINGS | DEDUCTION | ALLOWANCE | LEAVE
  rate_multiplier   NUMERIC(5,3) NOT NULL DEFAULT 1.000,     -- 1.0 = ordinary, 1.5 = OT, 2.0 = double
  is_active         BOOLEAN     NOT NULL DEFAULT TRUE,
  is_system         BOOLEAN     NOT NULL DEFAULT FALSE,      -- system items cannot be deleted
  xero_payroll_id   TEXT,
  ato_category      TEXT,                                     -- ATO STP2 category code
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE pay_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pay_items: admin write"  ON pay_items FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "pay_items: staff read"   ON pay_items FOR SELECT USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));

-- Default system pay items
INSERT INTO pay_items (code, name, description, item_type, rate_multiplier, is_system, ato_category) VALUES
  ('ORDINARY',       'Ordinary time earnings',    'Standard hourly rate',                      'EARNINGS',  1.000, TRUE,  'OrdinaryTimeEarnings'),
  ('OVERTIME_1_5',   'Overtime 1.5×',             'Time and a half',                           'EARNINGS',  1.500, TRUE,  'OvertimeEarnings'),
  ('OVERTIME_2_0',   'Overtime 2.0×',             'Double time',                               'EARNINGS',  2.000, TRUE,  'OvertimeEarnings'),
  ('ALLOWANCE_CAR',  'Car allowance',             'Per km or flat rate car allowance',         'ALLOWANCE', 1.000, FALSE, 'AllowanceTypeOther'),
  ('ALLOWANCE_PHONE','Phone allowance',           'Mobile phone allowance',                    'ALLOWANCE', 1.000, FALSE, 'AllowanceTypeOther'),
  ('ALLOWANCE_MEAL', 'Meal allowance',            'Meal/entertainment allowance',              'ALLOWANCE', 1.000, FALSE, 'AllowanceTypeMeals'),
  ('LEAVE_ANNUAL',   'Annual leave payout',       'Payout of accrued annual leave',            'LEAVE',     1.000, TRUE,  'AnnualLeaveLoading'),
  ('LEAVE_SICK',     'Sick leave',                'Personal/carer leave',                      'LEAVE',     1.000, TRUE,  'PersonalLeaveEarnings'),
  ('PAYG',           'PAYG withholding',          'Income tax withheld',                       'DEDUCTION', 1.000, TRUE,  NULL),
  ('SUPER_SGC',      'Superannuation SGC',        'Superannuation guarantee contribution',     'DEDUCTION', 1.000, TRUE,  NULL)
ON CONFLICT (code) DO NOTHING;

-- =============================================================================
-- LEAVE REQUESTS
-- =============================================================================

CREATE TABLE leave_requests (
  id              UUID           PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id   UUID           NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  leave_type      leave_type     NOT NULL,
  status          leave_status   NOT NULL DEFAULT 'PENDING',
  -- Dates
  start_date      DATE           NOT NULL,
  end_date        DATE           NOT NULL,
  total_days      NUMERIC(4,1)   NOT NULL,
  total_hours     NUMERIC(6,2),
  -- Notes
  reason          TEXT,
  admin_notes     TEXT,
  -- Approval
  reviewed_by     UUID           REFERENCES profiles(id),
  reviewed_at     TIMESTAMPTZ,
  rejection_reason TEXT,
  -- Accrual (for annual leave)
  is_paid         BOOLEAN        NOT NULL DEFAULT TRUE,
  leave_balance_before NUMERIC(6,2),
  leave_balance_after  NUMERIC(6,2),
  -- Xero
  xero_leave_id   TEXT,
  -- Meta
  submitted_by    UUID           REFERENCES profiles(id),
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "leave: admin_consultant all" ON leave_requests FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "leave: contractor own"       ON leave_requests FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());
CREATE POLICY "leave: contractor request"   ON leave_requests FOR INSERT WITH CHECK ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- =============================================================================
-- LEAVE BALANCES (per contractor per leave type — updated by triggers/API)
-- =============================================================================

CREATE TABLE leave_balances (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id   UUID        NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  leave_type      leave_type  NOT NULL,
  accrued_hours   NUMERIC(7,2) NOT NULL DEFAULT 0,
  taken_hours     NUMERIC(7,2) NOT NULL DEFAULT 0,
  balance_hours   NUMERIC(7,2) GENERATED ALWAYS AS (accrued_hours - taken_hours) STORED,
  balance_days    NUMERIC(5,1) GENERATED ALWAYS AS (ROUND((accrued_hours - taken_hours) / 7.6, 1)) STORED,
  financial_year  TEXT        NOT NULL,  -- e.g. "2025-26"
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (contractor_id, leave_type, financial_year)
);

ALTER TABLE leave_balances ENABLE ROW LEVEL SECURITY;
CREATE POLICY "lb: admin_consultant" ON leave_balances FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "lb: contractor own"   ON leave_balances FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- Seed balances for FY2025-26
INSERT INTO leave_balances (contractor_id, leave_type, accrued_hours, taken_hours, financial_year)
SELECT c.id, 'ANNUAL'::leave_type, 152.0, 0, '2025-26'
FROM contractors c WHERE c.status = 'ACTIVE'
ON CONFLICT DO NOTHING;

-- =============================================================================
-- TRIGGERS — leave + pay items updated_at
-- =============================================================================

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['pay_items','leave_requests','leave_balances','portal_settings'] LOOP
    EXECUTE format(
      'CREATE TRIGGER trg_updated_at_%1$s BEFORE UPDATE ON %1$I FOR EACH ROW EXECUTE FUNCTION update_updated_at()',
      t
    );
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- INDEXES
-- =============================================================================

CREATE INDEX idx_leave_contractor   ON leave_requests(contractor_id);
CREATE INDEX idx_leave_status       ON leave_requests(status);
CREATE INDEX idx_leave_dates        ON leave_requests(start_date, end_date);
CREATE INDEX idx_leave_bal_contractor ON leave_balances(contractor_id);

-- =============================================================================
-- Messages and Message Threads (added round 3)
-- =============================================================================

CREATE TABLE IF NOT EXISTS message_threads (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  participant_a uuid REFERENCES profiles(id) ON DELETE SET NULL,
  participant_b uuid REFERENCES profiles(id) ON DELETE SET NULL,
  contractor_id uuid REFERENCES contractors(id) ON DELETE SET NULL,
  subject       text NOT NULL DEFAULT 'Message',
  created_at    timestamptz DEFAULT now(),
  updated_at    timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS messages (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id       uuid REFERENCES message_threads(id) ON DELETE CASCADE,
  contractor_id   uuid REFERENCES contractors(id) ON DELETE SET NULL,
  from_profile_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  to_profile_id   uuid REFERENCES profiles(id) ON DELETE SET NULL,
  subject         text,
  body            text NOT NULL,
  status          text NOT NULL DEFAULT 'SENT',
  is_read         boolean NOT NULL DEFAULT false,
  read_at         timestamptz,
  attachments     jsonb,
  created_at      timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS messages_thread_id_idx   ON messages(thread_id);
CREATE INDEX IF NOT EXISTS messages_to_profile_idx  ON messages(to_profile_id, is_read);
CREATE INDEX IF NOT EXISTS threads_participants_idx  ON message_threads(participant_a, participant_b);
CREATE INDEX IF NOT EXISTS threads_updated_idx       ON message_threads(updated_at DESC);

ALTER TABLE message_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages        ENABLE ROW LEVEL SECURITY;

-- Participants can read/write their own threads
CREATE POLICY "threads: participants only" ON message_threads
  FOR ALL USING (participant_a = auth.uid() OR participant_b = auth.uid()
                 OR (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));

CREATE POLICY "messages: participants only" ON messages
  FOR ALL USING (from_profile_id = auth.uid() OR to_profile_id = auth.uid()
                 OR (SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));

-- =============================================================================
-- Contractors: extra columns added in round 3
-- (safe to re-run — uses IF NOT EXISTS / DO NOTHING)
-- =============================================================================
ALTER TABLE contractors ADD COLUMN IF NOT EXISTS address_line1     text;
ALTER TABLE contractors ADD COLUMN IF NOT EXISTS gender            char(1);
ALTER TABLE contractors ADD COLUMN IF NOT EXISTS date_of_birth     date;
ALTER TABLE contractors ADD COLUMN IF NOT EXISTS super_stapled     boolean DEFAULT false;
ALTER TABLE contractors ADD COLUMN IF NOT EXISTS onboarding_complete boolean DEFAULT false;
ALTER TABLE contractors ADD COLUMN IF NOT EXISTS notes             text;
ALTER TABLE contractors ADD COLUMN IF NOT EXISTS end_date          date;
ALTER TABLE contractors ADD COLUMN IF NOT EXISTS contract_hours_pa integer DEFAULT 2000;

-- portal_settings: extra columns
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS portal_domain    text DEFAULT 'http://localhost:3000';
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS contractor_upload boolean DEFAULT false;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS mfa_required     boolean DEFAULT false;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS session_timeout_mins integer DEFAULT 60;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS registered_name  text;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS street_address   text;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS phone            text;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS acn              text;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS logo_url         text;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS primary_email    text;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS payment_terms_days integer DEFAULT 14;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS auto_super_calc  boolean DEFAULT true;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS xero_payroll_calendar_id text;
ALTER TABLE portal_settings ADD COLUMN IF NOT EXISTS default_pay_calendar text DEFAULT 'MONTHLY';

-- pay_runs: extra columns
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS total_gross  numeric(12,2) DEFAULT 0;
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS total_payg   numeric(12,2) DEFAULT 0;
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS total_super  numeric(12,2) DEFAULT 0;
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS total_net    numeric(12,2) DEFAULT 0;
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS line_count   integer DEFAULT 0;
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS filed_at     timestamptz;
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS filed_by     uuid REFERENCES profiles(id);
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS stp_submitted     boolean DEFAULT false;
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS stp_submitted_at  timestamptz;
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS xero_pay_run_id   text;
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS updated_by        uuid REFERENCES profiles(id);
ALTER TABLE pay_runs ADD COLUMN IF NOT EXISTS xero_payroll_calendar_id text;

-- pay_run_lines: extra columns
ALTER TABLE pay_run_lines ADD COLUMN IF NOT EXISTS version_id    uuid REFERENCES timesheet_versions(id);
ALTER TABLE pay_run_lines ADD COLUMN IF NOT EXISTS rate_per_hour numeric(10,4) DEFAULT 0;

