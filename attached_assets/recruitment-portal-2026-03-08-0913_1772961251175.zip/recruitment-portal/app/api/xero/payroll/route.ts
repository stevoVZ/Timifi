// app/api/xero/payroll/route.ts
// Handles pay run filing: sync contractors → Xero, create pay run, post it (STP)

import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { syncContractorToXero, createXeroPayRun, postXeroPayRun } from '@/lib/xero/payroll'
import { logAudit } from '@/lib/audit'

// POST /api/xero/payroll — file a pay run to Xero + trigger STP
export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body = await request.json()
    const {
      payRunId,         // our internal pay_runs.id
      filedBy,
      xeroTenantId,
      xeroCalendarId,
    } = body

    if (!payRunId) return NextResponse.json({ error: 'payRunId required' }, { status: 400 })

    // 1. Fetch our pay run + lines
    const { data: run, error: runErr } = await supabase
      .from('pay_runs')
      .select('*, pay_run_lines(*)')
      .eq('id', payRunId)
      .single()

    if (runErr || !run) return NextResponse.json({ error: 'Pay run not found' }, { status: 404 })
    if (run.status === 'FILED') return NextResponse.json({ error: 'Pay run already filed' }, { status: 409 })

    const tenantId = xeroTenantId ?? run.xero_tenant_id
    if (!tenantId) return NextResponse.json({ error: 'No Xero tenant ID — connect Xero first' }, { status: 422 })

    const results: Record<string, { xeroEmployeeId?: string; error?: string }> = {}

    // 2. Sync each contractor → Xero employee
    for (const line of (run.pay_run_lines ?? []) as Record<string,unknown>[]) {
      const contractorId = line.contractor_id as string
      try {
        const xeroEmployeeId = await syncContractorToXero(contractorId, tenantId)
        results[contractorId] = { xeroEmployeeId }
      } catch (err) {
        results[contractorId] = { error: err instanceof Error ? err.message : 'Sync failed' }
        console.error(`[xero/payroll] Sync failed for contractor ${contractorId}:`, err)
      }
    }

    // 3. Create pay run in Xero
    const calendarId = xeroCalendarId ?? run.xero_payroll_calendar_id
    if (!calendarId) {
      return NextResponse.json({
        error: 'No Xero payroll calendar ID. Set this in Settings → Xero → Payroll Calendar.',
      }, { status: 422 })
    }

    const xeroPayRunId = await createXeroPayRun(
      tenantId,
      calendarId,
      run.period_start,
      run.period_end,
      run.payment_date,
    )

    // 4. Post pay run → triggers STP Phase 2 lodgement
    await postXeroPayRun(tenantId, xeroPayRunId)

    // 5. Update our pay run record
    const { error: updateErr } = await supabase
      .from('pay_runs')
      .update({
        status:             'FILED',
        xero_pay_run_id:    xeroPayRunId,
        xero_tenant_id:     tenantId,
        filed_at:           new Date().toISOString(),
        filed_by:           filedBy ?? null,
        stp_submitted:      true,
        stp_submitted_at:   new Date().toISOString(),
      })
      .eq('id', payRunId)

    if (updateErr) throw new Error(updateErr.message)

    await logAudit({
      action:     'PAY_RUN_FILED',
      targetType: 'pay_run',
      targetId:   payRunId,
      userId:     filedBy,
      metadata:   { xeroPayRunId, tenantId, contractorResults: results },
    })

    return NextResponse.json({
      success:      true,
      xeroPayRunId,
      contractorSyncResults: results,
      stpSubmitted: true,
    })
  } catch (err: unknown) {
    console.error('[api/xero/payroll]', err)
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown error' }, { status: 500 })
  }
}

// POST /api/xero/payroll/employee — sync single contractor to Xero
export async function PUT(request: NextRequest) {
  try {
    const { contractorId, xeroTenantId } = await request.json()
    if (!contractorId || !xeroTenantId) {
      return NextResponse.json({ error: 'contractorId and xeroTenantId required' }, { status: 400 })
    }
    const xeroEmployeeId = await syncContractorToXero(contractorId, xeroTenantId)
    return NextResponse.json({ success: true, xeroEmployeeId })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
