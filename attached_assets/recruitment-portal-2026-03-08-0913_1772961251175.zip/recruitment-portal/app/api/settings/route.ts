// app/api/settings/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'

export async function GET() {
  try {
    const supabase = createServiceClient()
    const { data, error } = await supabase
      .from('portal_settings')
      .select('*')
      .eq('id', 1)
      .single()

    if (error) throw new Error(error.message)
    // Check Xero token exists
    const { data: xeroToken } = await supabase
      .from('xero_tokens')
      .select('id, expires_at')
      .order('created_at', { ascending: false })
      .limit(1)
      .single()
    const xeroConnected = !!(xeroToken && new Date(xeroToken.expires_at) > new Date())
    return NextResponse.json({ ...data, xero_connected: xeroConnected })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body = await request.json()

    // Map camelCase body to snake_case columns
    const patch: Record<string, unknown> = {}
    const fieldMap: Record<string, string> = {
      agencyName:           'agency_name',
      accentColor:          'accent_color',
      logoUrl:              'logo_url',
      primaryEmail:         'primary_email',
      abn:                  'abn',
      acn:                  'acn',
      registeredName:       'registered_name',
      streetAddress:        'street_address',
      suburb:               'suburb',
      state:                'state',
      postcode:             'postcode',
      phone:                'phone',
      superRate:            'super_rate',
      paymentTermsDays:     'payment_terms_days',
      defaultPayCalendar:   'default_pay_calendar',
      stpEnabled:           'stp_enabled',
      autoSuperCalc:        'auto_super_calc',
      contractorPortal:     'contractor_portal',
      contractorUpload:     'contractor_upload',
      mfaRequired:          'mfa_required',
      sessionTimeoutMins:   'session_timeout_mins',
    }

    for (const [camel, snake] of Object.entries(fieldMap)) {
      if (body[camel] !== undefined) patch[snake] = body[camel]
    }

    const { error } = await supabase
      .from('portal_settings')
      .upsert({ id: 1, ...patch }, { onConflict: 'id' })

    if (error) throw new Error(error.message)

    await logAudit({
      action:     'SETTINGS_UPDATE',
      targetType: 'portal_settings',
      metadata:   { fields: Object.keys(patch) },
    })

    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
