// GET /api/timesheets — list timesheet versions with filters
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { searchParams } = new URL(request.url)
    const contractorId = searchParams.get('contractorId')
    const status       = searchParams.get('status')
    const year         = searchParams.get('year')
    const month        = searchParams.get('month')
    const portal       = searchParams.get('portal') === 'true'

    let query = supabase
      .from('timesheet_versions')
      .select(\`
        id, contractor_id, year, month, total_hours, gross_value, status,
        submitted_at, reviewed_at, rejection_reason,
        reviewer:profiles!reviewed_by(full_name),
        contractor:contractors(id, first_name, last_name, hourly_rate, profile_id)
      \`)
      .order('year', { ascending: false })
      .order('month', { ascending: false })

    if (contractorId) query = query.eq('contractor_id', contractorId)
    if (status)       query = query.eq('status', status)
    if (year)         query = query.eq('year', Number(year))
    if (month)        query = query.eq('month', Number(month))

    // Portal mode: only return versions for the authenticated contractor
    if (portal) {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 })
      const { data: contractor } = await supabase
        .from('contractors').select('id').eq('profile_id', user.id).single()
      if (contractor) query = query.eq('contractor_id', contractor.id)
    }

    const { data, error } = await query.limit(50)
    if (error) throw new Error(error.message)

    return NextResponse.json({
      timesheets: (data ?? []).map(t => ({
        ...t,
        reviewer_name: (t.reviewer as Record<string,unknown>)?.full_name ?? null,
        hourly_rate:   (t.contractor as Record<string,unknown>)?.hourly_rate ?? null,
      })),
    })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// app/api/timesheets/route.ts
// PATCH — approve or reject a timesheet version
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'
import { sendNotification } from '@/lib/notifications'

export async function PATCH(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body     = await request.json()
    const { versionId, action, rejectionReason, reviewerName, reviewerId } = body

    if (!versionId || !action) {
      return NextResponse.json({ error: 'versionId and action are required' }, { status: 400 })
    }
    if (!['approve', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'action must be approve or reject' }, { status: 400 })
    }
    if (action === 'reject' && !rejectionReason) {
      return NextResponse.json({ error: 'rejectionReason is required for rejection' }, { status: 400 })
    }

    // Load version + contractor
    const { data: version, error: vErr } = await supabase
      .from('timesheet_versions')
      .select('*, contractor:contractors(id, profile_id, first_name, last_name, email)')
      .eq('id', versionId)
      .single()

    if (vErr || !version) {
      return NextResponse.json({ error: 'Version not found' }, { status: 404 })
    }

    if (version.status !== 'SUBMITTED') {
      return NextResponse.json(
        { error: `Cannot ${action} a timesheet in ${version.status} status` },
        { status: 422 }
      )
    }

    const now = new Date().toISOString()
    const newStatus = action === 'approve' ? 'APPROVED' : 'REJECTED'

    // Update version
    const patch: Record<string, unknown> = { status: newStatus }
    if (action === 'approve') {
      patch.approved_at = now
      patch.approved_by = reviewerId ?? null
    } else {
      patch.rejected_at      = now
      patch.rejected_by      = reviewerId ?? null
      patch.rejection_reason = rejectionReason
    }

    const { error: uErr } = await supabase
      .from('timesheet_versions')
      .update(patch)
      .eq('id', versionId)

    if (uErr) throw new Error(uErr.message)

    // Update parent timesheet status to match
    if (version.timesheet_id) {
      await supabase
        .from('timesheets')
        .update({ status: newStatus, reviewed_at: now, reviewed_by: reviewerId ?? null,
                  rejection_reason: action === 'reject' ? rejectionReason : null })
        .eq('id', version.timesheet_id)
    }

    // Audit log
    await logAudit({
      userId:     reviewerId,
      userName:   reviewerName,
      action:     action === 'approve' ? 'APPROVE_TIMESHEET' : 'REJECT_TIMESHEET',
      targetType: 'timesheet_version',
      targetId:   versionId,
      metadata:   { contractorId: version.contractor_id, month: version.month, year: version.year, reason: rejectionReason },
    })

    // Notify contractor
    if (version.contractor?.profile_id) {
      await sendNotification({
        userId:        version.contractor.profile_id,
        type:          'TIMESHEET',
        priority:      action === 'reject' ? 'HIGH' : 'MEDIUM',
        title:         action === 'approve'
          ? `Timesheet approved — ${version.scan_period || `Month ${version.month}`}`
          : `Timesheet returned — ${version.scan_period || `Month ${version.month}`}`,
        body:          action === 'reject' ? rejectionReason : undefined,
        actionLabel:   action === 'reject' ? 'Resubmit timesheet' : 'View payslip',
        actionRoute:   '/portal/timesheets',
        contractorId:  version.contractor_id,
        timesheetId:   version.timesheet_id ?? undefined,
      })
    }

    return NextResponse.json({ success: true, status: newStatus })

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    console.error('[timesheets PATCH]', message)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
