// app/api/payslips/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { generatePayslipHTML, buildPayslipData } from '@/lib/payslip'
import { logAudit } from '@/lib/audit'

// GET /api/payslips?contractorId=...
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { searchParams } = new URL(request.url)
    const contractorId = searchParams.get('contractorId')

    let query = supabase
      .from('pay_run_lines')
      .select(`
        *,
        pay_run:pay_runs(id, year, month, period_start, period_end, payment_date, status, super_rate),
        contractor:contractors(id, first_name, last_name)
      `)
      .in('pay_run.status', ['FILED', 'APPROVED'])
      .order('pay_run(period_end)', { ascending: false })

    if (contractorId) query = query.eq('contractor_id', contractorId)

    const { data, error } = await query
    if (error) throw new Error(error.message)

    return NextResponse.json({ payslips: data })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// GET /api/payslips/[id] — generate HTML payslip (see [id]/route.ts)
// POST /api/payslips/generate — generate payslips for a pay run, store in Supabase Storage
export async function POST(request: NextRequest) {
  try {
    const supabase  = createServiceClient()
    const { payRunId, generateFor } = await request.json()

    if (!payRunId) return NextResponse.json({ error: 'payRunId required' }, { status: 400 })

    // Fetch pay run
    const { data: run, error: runErr } = await supabase
      .from('pay_runs')
      .select('*')
      .eq('id', payRunId)
      .single()

    if (runErr || !run) return NextResponse.json({ error: 'Pay run not found' }, { status: 404 })

    // Fetch settings
    const { data: settings } = await supabase
      .from('portal_settings')
      .select('*')
      .eq('id', 1)
      .single()

    // Fetch all pay run lines (or just one contractor if generateFor set)
    let linesQuery = supabase
      .from('pay_run_lines')
      .select(`
        *,
        contractor:contractors(*, bank_accounts(*))
      `)
      .eq('pay_run_id', payRunId)

    if (generateFor) linesQuery = linesQuery.eq('contractor_id', generateFor)

    const { data: lines, error: linesErr } = await linesQuery
    if (linesErr) throw new Error(linesErr.message)

    const generated: string[] = []

    for (const line of (lines ?? []) as Record<string,unknown>[]) {
      const contractor = line.contractor as Record<string, unknown>
      const banks = (contractor.bank_accounts as Record<string,unknown>[]) ?? []
      const bank  = banks.find(b => b.is_primary) ?? banks[0]

      // Fetch YTD data
      const { data: ytdLines } = await supabase
        .from('pay_run_lines')
        .select('gross_earnings,payg_withheld,super_amount,pay_runs!inner(year,status)')
        .eq('contractor_id', line.contractor_id as string)
        .eq('pay_runs.year', run.year)
        .in('pay_runs.status', ['FILED', 'APPROVED'])

      const ytd = (ytdLines ?? []).reduce((acc, l: Record<string,unknown>) => ({
        gross: acc.gross + Number(l.gross_earnings ?? 0),
        payg:  acc.payg  + Number(l.payg_withheld  ?? 0),
        super: acc.super + Number(l.super_amount    ?? 0),
      }), { gross: 0, payg: 0, super: 0 })

      const payslipNum = `PS-${run.year}-${String(run.month).padStart(2,'0')}-${String(generated.length + 1).padStart(3,'0')}`

      const payslipData = buildPayslipData({
        line, contractor, bank, settings: settings ?? {}, ytd, payRun: run, payslipNum,
      })

      const html = generatePayslipHTML(payslipData)

      // Store HTML in Supabase Storage (payslips bucket)
      const path = `payslips/${run.year}/${String(run.month).padStart(2,'0')}/${line.contractor_id}/${payslipNum}.html`
      const { error: storageErr } = await supabase.storage
        .from('payslips')
        .upload(path, html, {
          contentType: 'text/html',
          upsert: true,
        })

      if (storageErr) {
        console.warn(`[payslips] Storage upload failed for ${payslipNum}:`, storageErr.message)
      }

      // Record in documents table
      const { data: publicUrlData } = supabase.storage
        .from('payslips')
        .getPublicUrl(path)

      await supabase.from('documents').upsert({
        contractor_id: line.contractor_id,
        type:          'PAYSLIP',
        name:          `Payslip — ${payslipData.payPeriodLabel}`,
        file_url:      publicUrlData?.publicUrl ?? '',
        file_type:     'text/html',
        metadata:      { payRunId, payslipNum, year: run.year, month: run.month },
      })

      generated.push(payslipNum)
    }

    await logAudit({
      action: 'PAYSLIPS_GENERATED',
      targetType: 'pay_run',
      targetId: payRunId,
      metadata: { generated, count: generated.length },
    })

    return NextResponse.json({ success: true, generated, count: generated.length })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
