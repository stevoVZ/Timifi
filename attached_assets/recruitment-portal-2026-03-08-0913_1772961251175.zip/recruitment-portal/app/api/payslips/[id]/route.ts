// app/api/payslips/[id]/route.ts
// GET /api/payslips/[lineId] — returns HTML payslip for a specific pay run line
// The browser can then print-to-PDF

import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { generatePayslipHTML, buildPayslipData } from '@/lib/payslip'

type Params = { params: { id: string } }

export async function GET(_req: NextRequest, { params }: Params) {
  try {
    const supabase = createServiceClient()

    // Fetch the pay run line
    const { data: line, error: lineErr } = await supabase
      .from('pay_run_lines')
      .select(`
        *,
        pay_run:pay_runs(*),
        contractor:contractors(*, bank_accounts(*))
      `)
      .eq('id', params.id)
      .single()

    if (lineErr || !line) {
      return NextResponse.json({ error: 'Payslip not found' }, { status: 404 })
    }

    const lineData      = line as Record<string, unknown>
    const contractor    = lineData.contractor as Record<string, unknown>
    const run           = lineData.pay_run    as Record<string, unknown>
    const banks         = (contractor.bank_accounts as Record<string,unknown>[]) ?? []
    const bank          = banks.find(b => b.is_primary) ?? banks[0]

    // Fetch settings
    const { data: settings } = await supabase
      .from('portal_settings')
      .select('*')
      .eq('id', 1)
      .single()

    // Fetch YTD
    const { data: ytdLines } = await supabase
      .from('pay_run_lines')
      .select('gross_earnings,payg_withheld,super_amount,pay_runs!inner(year,status)')
      .eq('contractor_id', lineData.contractor_id as string)
      .eq('pay_runs.year', run.year)
      .in('pay_runs.status', ['FILED', 'APPROVED'])

    const ytd = (ytdLines ?? []).reduce((acc, l: Record<string,unknown>) => ({
      gross: acc.gross + Number(l.gross_earnings ?? 0),
      payg:  acc.payg  + Number(l.payg_withheld  ?? 0),
      super: acc.super + Number(l.super_amount    ?? 0),
    }), { gross: 0, payg: 0, super: 0 })

    const payslipNum = `PS-${run.year}-${String(run.month).padStart(2,'0')}-${String(params.id).slice(-4)}`

    const payslipData = buildPayslipData({
      line: lineData, contractor, bank, settings: settings ?? {}, ytd, payRun: run, payslipNum,
    })

    const html = generatePayslipHTML(payslipData)

    return new NextResponse(html, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': `inline; filename="${payslipNum}.html"`,
        'Cache-Control': 'private, max-age=3600',
      },
    })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
