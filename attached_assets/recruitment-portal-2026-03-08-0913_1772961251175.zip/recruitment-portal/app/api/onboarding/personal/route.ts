// app/api/onboarding/personal/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'

export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { contractorId, dateOfBirth, gender, addressLine1, suburb, state, postcode } = await request.json()

    if (!contractorId) return NextResponse.json({ error: 'contractorId required' }, { status: 400 })

    const { error } = await supabase
      .from('contractors')
      .update({
        date_of_birth: dateOfBirth || null,
        gender:        gender       || null,
        address_line1: addressLine1 || null,
        suburb:        suburb       || null,
        state:         state        || null,
        postcode:      postcode     || null,
      })
      .eq('id', contractorId)

    if (error) throw new Error(error.message)

    await logAudit({ action: 'UPDATE_CONTRACTOR', targetType: 'contractor', targetId: contractorId, metadata: { step: 'personal' } })
    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
