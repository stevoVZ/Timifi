// app/api/onboarding/tax/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'

export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const {
      contractorId,
      tfn,
      residencyStatus,
      claimTaxFreeThreshold,
      helpDebt,
      studentLoan,
      seniorsOffset,
    } = await request.json()

    if (!contractorId) return NextResponse.json({ error: 'contractorId required' }, { status: 400 })
    if (!tfn)          return NextResponse.json({ error: 'tfn required' }, { status: 400 })

    const tfnClean = tfn.replace(/\s/g, '')
    if (!/^\d{8,9}$/.test(tfnClean)) {
      return NextResponse.json({ error: 'TFN must be 8 or 9 digits' }, { status: 400 })
    }

    // Upsert tax declaration — one per contractor
    const { error } = await supabase
      .from('tax_declarations')
      .upsert(
        {
          contractor_id:            contractorId,
          tfn:                      tfnClean,
          residency_status:         residencyStatus ?? 'RESIDENT',
          claim_tax_free_threshold: claimTaxFreeThreshold ?? true,
          help_debt:                helpDebt     ?? false,
          student_loan:             studentLoan  ?? false,
          seniors_offset:           seniorsOffset ?? false,
          declaration_date:         new Date().toISOString().slice(0, 10),
          is_current:               true,
        },
        { onConflict: 'contractor_id' }
      )

    if (error) throw new Error(error.message)

    await logAudit({
      action: 'TAX_DECLARATION_SUBMITTED',
      targetType: 'tax_declaration',
      targetId: contractorId,
      metadata: { residencyStatus, claimTaxFreeThreshold, helpDebt },
    })

    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
