// app/api/onboarding/bank/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'

export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { contractorId, bsb, accountNumber, accountName, bankName } = await request.json()

    if (!contractorId) return NextResponse.json({ error: 'contractorId required' }, { status: 400 })

    const bsnClean = (bsb ?? '').replace(/[^0-9]/g, '')
    if (!bsnClean || bsnClean.length !== 6) {
      return NextResponse.json({ error: 'BSB must be 6 digits' }, { status: 400 })
    }
    if (!accountNumber?.trim()) return NextResponse.json({ error: 'Account number required' }, { status: 400 })
    if (!accountName?.trim())   return NextResponse.json({ error: 'Account name required'   }, { status: 400 })

    // Deactivate any existing primary bank account
    await supabase
      .from('bank_accounts')
      .update({ is_primary: false })
      .eq('contractor_id', contractorId)
      .eq('is_primary', true)

    const { error } = await supabase
      .from('bank_accounts')
      .insert({
        contractor_id:  contractorId,
        bsb:            bsnClean,
        account_number: accountNumber.trim(),
        account_name:   accountName.trim(),
        bank_name:      bankName?.trim() ?? null,
        is_primary:     true,
      })

    if (error) throw new Error(error.message)

    await logAudit({
      action: 'BANK_ACCOUNT_ADDED',
      targetType: 'bank_account',
      targetId: contractorId,
      metadata: { bsb: `${bsnClean.slice(0,3)}-${bsnClean.slice(3)}`, accountName },
    })

    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
