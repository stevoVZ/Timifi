// app/api/onboarding/super/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'

export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { contractorId, fundName, fundABN, memberNumber, usi, useStapledFund } = await request.json()

    if (!contractorId) return NextResponse.json({ error: 'contractorId required' }, { status: 400 })

    if (useStapledFund) {
      // Mark contractor to use ATO stapled fund — no super record needed
      await supabase
        .from('contractors')
        .update({ super_stapled: true })
        .eq('id', contractorId)
      return NextResponse.json({ success: true, useStapledFund: true })
    }

    if (!fundName?.trim())    return NextResponse.json({ error: 'Fund name required' },    { status: 400 })
    if (!memberNumber?.trim()) return NextResponse.json({ error: 'Member number required' }, { status: 400 })

    // Deactivate existing super membership
    await supabase
      .from('super_memberships')
      .update({ is_active: false })
      .eq('contractor_id', contractorId)
      .eq('is_active', true)

    const { error } = await supabase
      .from('super_memberships')
      .insert({
        contractor_id:  contractorId,
        fund_name:      fundName.trim(),
        fund_abn:       fundABN?.replace(/\s/g,'') ?? null,
        member_number:  memberNumber.trim(),
        usi:            usi?.trim() ?? null,
        is_active:      true,
        is_employer_nominated: false,
      })

    if (error) throw new Error(error.message)

    await logAudit({
      action: 'SUPER_FUND_ADDED',
      targetType: 'super_membership',
      targetId: contractorId,
      metadata: { fundName, memberNumber },
    })

    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
