// app/api/auth/me/route.ts
// GET /api/auth/me — returns the current authenticated user's profile and contractor info
// Used by portal pages to know which contractor's data to fetch

import { NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase/server'

export async function GET() {
  try {
    const supabase = createServerClient()

    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
    }

    // Get profile
    const { data: profile } = await supabase
      .from('profiles')
      .select('id, role, full_name, email')
      .eq('id', user.id)
      .single()

    if (!profile) {
      return NextResponse.json({ error: 'Profile not found' }, { status: 404 })
    }

    // If contractor, get contractor record
    let contractorId: string | null = null
    let contractorStatus: string | null = null
    let onboardingComplete = false

    if (profile.role === 'contractor') {
      const { data: contractor } = await supabase
        .from('contractors')
        .select('id, status, onboarding_complete')
        .eq('profile_id', user.id)
        .single()

      if (contractor) {
        contractorId       = contractor.id
        contractorStatus   = contractor.status
        onboardingComplete = contractor.onboarding_complete ?? false
      }
    }

    return NextResponse.json({
      profileId:         profile.id,
      role:              profile.role,
      fullName:          profile.full_name,
      email:             profile.email ?? user.email,
      contractorId,
      contractorStatus,
      onboardingComplete,
    })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
