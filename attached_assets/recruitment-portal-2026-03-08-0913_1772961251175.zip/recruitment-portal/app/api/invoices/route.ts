// app/api/invoices/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'

// GET /api/invoices?status=...&contractorId=...&year=...
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { searchParams } = new URL(request.url)
    const status       = searchParams.get('status')
    const contractorId = searchParams.get('contractorId')
    const year         = searchParams.get('year')
    const limit        = Number(searchParams.get('limit') ?? 50)

    let query = supabase
      .from('invoices')
      .select(`
        *,
        contractor:contractors(id, first_name, last_name, client_name, hourly_rate)
      `)
      .order('due_date', { ascending: false })
      .limit(limit)

    if (status)       query = query.eq('status', status)
    if (contractorId) query = query.eq('contractor_id', contractorId)
    if (year)         query = query.gte('due_date', `${year}-01-01`).lte('due_date', `${year}-12-31`)

    const { data, error } = await query
    if (error) throw new Error(error.message)

    // Compute totals
    const all = data ?? []
    const outstanding = all.filter(i => ['AUTHORISED','SENT'].includes(i.status))
    const overdue     = all.filter(i => i.status === 'OVERDUE')

    return NextResponse.json({
      invoices: all,
      totals: {
        outstanding:      outstanding.reduce((s,i) => s + Number(i.total_amount ?? 0), 0),
        outstandingCount: outstanding.length,
        overdue:          overdue.reduce((s,i) => s + Number(i.total_amount ?? 0), 0),
        overdueCount:     overdue.length,
        paid:             all.filter(i=>i.status==='PAID').reduce((s,i)=>s+Number(i.total_amount??0),0),
      },
    })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// PATCH /api/invoices — update invoice status
export async function PATCH(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { invoiceId, status, xeroInvoiceId, xeroContactId } = await request.json()

    if (!invoiceId || !status) {
      return NextResponse.json({ error: 'invoiceId and status required' }, { status: 400 })
    }

    const patch: Record<string, unknown> = { status }
    if (xeroInvoiceId) patch.xero_invoice_id = xeroInvoiceId
    if (xeroContactId) patch.xero_contact_id = xeroContactId
    if (status === 'PAID') patch.paid_at = new Date().toISOString()

    const { error } = await supabase.from('invoices').update(patch).eq('id', invoiceId)
    if (error) throw new Error(error.message)

    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
