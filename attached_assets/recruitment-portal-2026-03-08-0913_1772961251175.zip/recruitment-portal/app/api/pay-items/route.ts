// app/api/pay-items/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'

export async function GET() {
  try {
    const supabase = createServiceClient()
    const { data, error } = await supabase
      .from('pay_items')
      .select('*')
      .order('item_type')
      .order('is_system', { ascending: false })
      .order('name')

    if (error) throw new Error(error.message)
    return NextResponse.json({ payItems: data })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { code, name, description, itemType, rateMultiplier, atpCategory, xeroPayrollId } = await request.json()

    if (!code || !name) return NextResponse.json({ error: 'code and name required' }, { status: 400 })

    const { data, error } = await supabase
      .from('pay_items')
      .insert({
        code:            code.toUpperCase().replace(/\s+/g,'_'),
        name,
        description:     description ?? null,
        item_type:       itemType    ?? 'EARNINGS',
        rate_multiplier: rateMultiplier ?? 1.000,
        is_system:       false,
        is_active:       true,
        ato_category:    atpCategory ?? null,
        xero_payroll_id: xeroPayrollId ?? null,
      })
      .select()
      .single()

    if (error) throw new Error(error.message)

    await logAudit({ action: 'UPDATE_CONTRACTOR', targetType: 'pay_item', targetId: data.id, metadata: { action: 'CREATED', code } })
    return NextResponse.json({ payItem: data }, { status: 201 })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { id, ...fields } = await request.json()
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })

    // Prevent editing system items
    const { data: existing } = await supabase.from('pay_items').select('is_system').eq('id', id).single()
    if (existing?.is_system) return NextResponse.json({ error: 'System pay items cannot be modified' }, { status: 403 })

    const colMap: Record<string,string> = {
      name:'name', description:'description', rateMultiplier:'rate_multiplier',
      isActive:'is_active', atpCategory:'ato_category', xeroPayrollId:'xero_payroll_id',
    }
    const patch: Record<string,unknown> = {}
    for (const [k,v] of Object.entries(colMap)) {
      if (fields[k] !== undefined) patch[v] = fields[k]
    }

    const { error } = await supabase.from('pay_items').update(patch).eq('id', id)
    if (error) throw new Error(error.message)
    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { id } = await request.json()
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })

    const { data: existing } = await supabase.from('pay_items').select('is_system,code').eq('id', id).single()
    if (existing?.is_system) return NextResponse.json({ error: 'System pay items cannot be deleted' }, { status: 403 })

    await supabase.from('pay_items').delete().eq('id', id)
    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
