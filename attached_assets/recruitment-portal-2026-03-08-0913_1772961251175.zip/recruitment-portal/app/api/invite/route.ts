// app/api/invite/route.ts
// Send a Supabase auth invite to a newly created contractor
// This creates a Supabase auth user and sends them a magic link
// pointing to /portal/onboarding so they can complete their profile

import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { createClient } from '@supabase/supabase-js'
import { logAudit } from '@/lib/audit'
import { sendNotification } from '@/lib/notifications'

// We need the service role key to create users via admin API
function getAdminClient() {
  const url  = process.env.NEXT_PUBLIC_SUPABASE_URL!
  const key  = process.env.SUPABASE_SERVICE_ROLE_KEY!
  if (!key) throw new Error('SUPABASE_SERVICE_ROLE_KEY not set — add to .env.local')
  return createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } })
}

// POST /api/invite — invite a contractor to the portal
export async function POST(request: NextRequest) {
  try {
    const supabase      = createServiceClient()
    const adminSupabase = getAdminClient()

    const { contractorId, resend } = await request.json()

    if (!contractorId) return NextResponse.json({ error: 'contractorId required' }, { status: 400 })

    // Fetch contractor
    const { data: contractor, error: cErr } = await supabase
      .from('contractors')
      .select('id, first_name, last_name, email, status, profile_id, onboarding_complete')
      .eq('id', contractorId)
      .single()

    if (cErr || !contractor) {
      return NextResponse.json({ error: 'Contractor not found' }, { status: 404 })
    }
    if (!contractor.email) {
      return NextResponse.json({ error: 'Contractor has no email address' }, { status: 422 })
    }

    // Check if already has a profile
    if (contractor.profile_id && !resend) {
      return NextResponse.json({ error: 'Contractor already has a portal account. Pass resend=true to resend.' }, { status: 409 })
    }

    // Get portal settings for agency name
    const { data: settings } = await supabase
      .from('portal_settings')
      .select('agency_name, portal_domain')
      .eq('id', 1)
      .single()

    const agencyName  = settings?.agency_name  ?? 'Your Agency'
    const portalDomain = settings?.portal_domain ?? process.env.NEXTAUTH_URL ?? 'http://localhost:3000'

    const redirectUrl = `${portalDomain}/portal/onboarding`

    let userId: string

    if (contractor.profile_id) {
      // Resend: just send a new magic link
      userId = contractor.profile_id
      const { error: otpErr } = await adminSupabase.auth.admin.generateLink({
        type:          'magiclink',
        email:         contractor.email,
        options: {
          redirectTo: redirectUrl,
        },
      })
      if (otpErr) throw new Error(`Magic link error: ${otpErr.message}`)
    } else {
      // New invite: create the auth user
      const { data: inviteData, error: inviteErr } = await adminSupabase.auth.admin.inviteUserByEmail(
        contractor.email,
        {
          redirectTo: redirectUrl,
          data: {
            full_name:     `${contractor.first_name} ${contractor.last_name}`,
            contractor_id: contractorId,
            role:          'contractor',
          },
        }
      )

      if (inviteErr) throw new Error(`Invite error: ${inviteErr.message}`)
      if (!inviteData?.user) throw new Error('No user returned from invite')

      userId = inviteData.user.id

      // Create profile record
      const { error: profileErr } = await supabase
        .from('profiles')
        .upsert({
          id:         userId,
          full_name:  `${contractor.first_name} ${contractor.last_name}`,
          email:      contractor.email,
          role:       'contractor',
        })

      if (profileErr) throw new Error(`Profile create error: ${profileErr.message}`)

      // Link contractor → profile
      await supabase
        .from('contractors')
        .update({ profile_id: userId })
        .eq('id', contractorId)
    }

    // Send in-app notification too (in case they're already logged in somehow)
    await sendNotification({
      userId,
      type:     'SYSTEM',
      priority: 'HIGH',
      title:    `Welcome to ${agencyName}`,
      body:     'Your portal account is ready. Please complete your onboarding to activate your account.',
      link:     '/portal/onboarding',
    }).catch(() => null)

    await logAudit({
      action:     'CONTRACTOR_INVITED',
      targetType: 'contractor',
      targetId:   contractorId,
      metadata:   { email: contractor.email, resend: !!resend },
    })

    return NextResponse.json({
      success: true,
      email:   contractor.email,
      userId,
      message: `Invite sent to ${contractor.email}`,
    })
  } catch (err: unknown) {
    console.error('[api/invite]', err)
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown error' }, { status: 500 })
  }
}

// GET /api/invite?contractorId= — check invite status
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const contractorId = new URL(request.url).searchParams.get('contractorId')
    if (!contractorId) return NextResponse.json({ error: 'contractorId required' }, { status: 400 })

    const { data: contractor } = await supabase
      .from('contractors')
      .select('id, email, status, profile_id, onboarding_complete')
      .eq('id', contractorId)
      .single()

    if (!contractor) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    return NextResponse.json({
      hasAccount:          !!contractor.profile_id,
      onboardingComplete:  contractor.onboarding_complete,
      email:               contractor.email,
      status:              contractor.status,
    })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
