// app/api/messages/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { sendNotification } from '@/lib/notifications'

// GET /api/messages?profileId=...&contractorId=...&unreadOnly=true
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { searchParams } = new URL(request.url)
    const profileId    = searchParams.get('profileId')
    const contractorId = searchParams.get('contractorId')
    const unreadOnly   = searchParams.get('unreadOnly') === 'true'
    const threadId     = searchParams.get('threadId')

    if (!profileId) return NextResponse.json({ error: 'profileId required' }, { status: 400 })

    let query = supabase
      .from('messages')
      .select(`
        id, thread_id, subject, body, status, is_read, read_at, created_at,
        from_profile:profiles!from_profile_id(id, full_name, role),
        to_profile:profiles!to_profile_id(id, full_name, role),
        contractor:contractors(id, first_name, last_name)
      `)
      .or(`from_profile_id.eq.${profileId},to_profile_id.eq.${profileId}`)
      .order('created_at', { ascending: false })

    if (contractorId) query = query.eq('contractor_id', contractorId)
    if (unreadOnly)   query = query.eq('is_read', false).eq('to_profile_id', profileId)
    if (threadId)     query = query.eq('thread_id', threadId).order('created_at', { ascending: true })

    const { data, error } = await query
    if (error) throw new Error(error.message)

    // Group by thread if no threadId filter
    if (!threadId) {
      const threads = new Map<string, Record<string, unknown>>()
      for (const msg of (data ?? []) as Record<string, unknown>[]) {
        const tid = msg.thread_id as string
        if (!threads.has(tid)) threads.set(tid, msg)
        else {
          const existing = threads.get(tid)!
          // Keep thread with latest created_at but count unread
          const unreadCount = (existing._unreadCount as number ?? 0) +
            (msg.is_read === false && msg.to_profile_id === profileId ? 1 : 0)
          threads.set(tid, { ...existing, _unreadCount: unreadCount, _latestAt: msg.created_at })
        }
      }
      return NextResponse.json({ messages: Array.from(threads.values()) })
    }

    return NextResponse.json({ messages: data })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// POST /api/messages — send a message
export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { fromProfileId, toProfileId, contractorId, subject, body, threadId } = await request.json()

    if (!fromProfileId || !toProfileId || !body?.trim()) {
      return NextResponse.json({ error: 'fromProfileId, toProfileId and body are required' }, { status: 400 })
    }

    const { data, error } = await supabase
      .from('messages')
      .insert({
        thread_id:       threadId ?? '00000000-0000-0000-0000-000000000000', // trigger will set = id if null
        from_profile_id: fromProfileId,
        to_profile_id:   toProfileId,
        contractor_id:   contractorId ?? null,
        subject:         subject?.trim() ?? null,
        body:            body.trim(),
        status:          'SENT',
        is_read:         false,
      })
      .select()
      .single()

    if (error) throw new Error(error.message)

    // Notify recipient
    await sendNotification({
      userId:       toProfileId,
      type:         'MESSAGE',
      priority:     'MEDIUM',
      title:        subject ? `New message: ${subject}` : 'New message',
      body:         body.slice(0, 120) + (body.length > 120 ? '…' : ''),
      contractorId: contractorId ?? undefined,
      actionUrl:    '/portal/messages',
    })

    return NextResponse.json({ message: data }, { status: 201 })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// PATCH /api/messages — mark read / archive
export async function PATCH(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { messageIds, threadId, action, profileId } = await request.json()

    const patch: Record<string, unknown> = {}
    if (action === 'markRead')   { patch.is_read = true; patch.read_at = new Date().toISOString(); patch.status = 'READ' }
    if (action === 'archive')    { patch.status = 'ARCHIVED' }
    if (action === 'markUnread') { patch.is_read = false; patch.read_at = null; patch.status = 'DELIVERED' }

    if (threadId) {
      await supabase.from('messages').update(patch).eq('thread_id', threadId).eq('to_profile_id', profileId)
    } else if (messageIds?.length) {
      await supabase.from('messages').update(patch).in('id', messageIds)
    } else {
      return NextResponse.json({ error: 'messageIds or threadId required' }, { status: 400 })
    }

    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
