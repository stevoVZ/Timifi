// app/api/documents/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'

// GET /api/documents?contractorId=...&type=...
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { searchParams } = new URL(request.url)
    const contractorId = searchParams.get('contractorId')
    const type         = searchParams.get('type')

    let query = supabase
      .from('documents')
      .select('*')
      .order('created_at', { ascending: false })

    if (contractorId) query = query.eq('contractor_id', contractorId)
    if (type)         query = query.eq('type', type)

    const { data, error } = await query
    if (error) throw new Error(error.message)
    return NextResponse.json({ documents: data })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// POST /api/documents — record a document after upload (file already in Storage)
export async function POST(request: NextRequest) {
  try {
    const supabase  = createServiceClient()
    const { contractorId, type, name, fileUrl, fileType, fileSizeBytes, uploadedBy } = await request.json()

    if (!contractorId || !type || !name || !fileUrl) {
      return NextResponse.json({ error: 'contractorId, type, name, fileUrl required' }, { status: 400 })
    }

    const { data, error } = await supabase
      .from('documents')
      .insert({
        contractor_id:   contractorId,
        type,
        name,
        file_url:        fileUrl,
        file_type:       fileType ?? null,
        file_size_bytes: fileSizeBytes ?? null,
        uploaded_by:     uploadedBy ?? null,
      })
      .select()
      .single()

    if (error) throw new Error(error.message)

    await logAudit({
      action:     'UPDATE_CONTRACTOR',
      targetType: 'document',
      targetId:   data.id,
      userId:     uploadedBy,
      metadata:   { contractorId, type, name },
    })

    return NextResponse.json({ document: data }, { status: 201 })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// DELETE /api/documents — delete document record + storage file
export async function DELETE(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { documentId, storagePath } = await request.json()

    if (!documentId) return NextResponse.json({ error: 'documentId required' }, { status: 400 })

    // Remove from storage if path provided
    if (storagePath) {
      const bucket = storagePath.startsWith('payslips/') ? 'payslips' : 'documents'
      await supabase.storage.from(bucket).remove([storagePath])
    }

    const { error } = await supabase.from('documents').delete().eq('id', documentId)
    if (error) throw new Error(error.message)

    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// POST /api/documents/signed-url — get a signed URL for download
export async function PUT(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { storagePath, bucket = 'documents', expiresIn = 3600 } = await request.json()

    if (!storagePath) return NextResponse.json({ error: 'storagePath required' }, { status: 400 })

    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUrl(storagePath, expiresIn)

    if (error) throw new Error(error.message)
    return NextResponse.json({ signedUrl: data.signedUrl })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
