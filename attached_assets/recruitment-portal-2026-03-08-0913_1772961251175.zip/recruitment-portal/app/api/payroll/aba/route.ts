// app/api/payroll/aba/route.ts
// POST /api/payroll/aba — generate ABA direct entry file for a pay run

import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { buildABAFromPayRun, type ABAHeader } from '@/lib/aba'
import { logAudit } from '@/lib/audit'

export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body     = await request.json()
    const {
      payRunId,
      // Agency bank details (override from portal_settings if not passed)
      agencyBSB,
      agencyAccountNumber,
      agencyAccountName,
      apcsUserId,       // 6-digit APCS user ID from your bank
      generatedBy,
    } = body

    if (!payRunId) return NextResponse.json({ error: 'payRunId required' }, { status: 400 })

    // Fetch pay run + lines + contractor bank details
    const { data: run, error: runErr } = await supabase
      .from('pay_runs')
      .select('*')
      .eq('id', payRunId)
      .single()

    if (runErr || !run) return NextResponse.json({ error: 'Pay run not found' }, { status: 404 })

    const { data: lines, error: linesErr } = await supabase
      .from('pay_run_lines')
      .select(`
        net_pay, contractor_id,
        contractor:contractors(first_name, last_name, bank_accounts(*))
      `)
      .eq('pay_run_id', payRunId)
      .eq('status', 'INCLUDED')

    if (linesErr) throw new Error(linesErr.message)

    // Fetch settings for agency bank details
    const { data: settings } = await supabase
      .from('portal_settings')
      .select('agency_name, abn')
      .eq('id', 1)
      .single()

    // Validate all contractors have bank details
    const missing: string[] = []
    const abaLines = []
    let lineIdx = 1

    for (const line of (lines ?? []) as Record<string, unknown>[]) {
      const c = line.contractor as Record<string, unknown>
      const banks = (c.bank_accounts as Record<string,unknown>[]) ?? []
      const bank  = banks.find(b => b.is_primary) ?? banks[0]

      if (!bank) {
        missing.push(`${c.first_name} ${c.last_name}`)
        continue
      }

      const payslipNum = `PS-${run.year}-${String(run.month).padStart(2,'0')}-${String(lineIdx++).padStart(3,'0')}`
      abaLines.push({
        contractorName: `${c.first_name} ${c.last_name}`,
        bsb:            bank.bsb as string,
        accountNumber:  bank.account_number as string,
        netPay:         Number(line.net_pay ?? 0),
        payslipNumber:  payslipNum,
      })
    }

    if (missing.length > 0) {
      return NextResponse.json({
        error: `Missing bank details for: ${missing.join(', ')}. Add bank accounts before generating ABA file.`,
      }, { status: 422 })
    }

    if (abaLines.length === 0) {
      return NextResponse.json({ error: 'No pay run lines to include' }, { status: 422 })
    }

    // Format processing date as DDMMYY
    const pd = new Date(run.payment_date ?? new Date())
    const processingDate = `${String(pd.getDate()).padStart(2,'0')}${String(pd.getMonth()+1).padStart(2,'0')}${String(pd.getFullYear()).slice(-2)}`

    const header: ABAHeader = {
      bsb:            agencyBSB           ?? '000-000',
      accountNumber:  agencyAccountNumber ?? '000000000',
      accountName:    agencyAccountName   ?? settings?.agency_name ?? 'Agency',
      apcsUserName:   agencyAccountName   ?? settings?.agency_name ?? 'Agency',
      apcsUserId:     apcsUserId          ?? '000000',
      description:    'PAYROLL',
      processingDate,
    }

    const { content, totalAmount, entryCount } = buildABAFromPayRun({
      header,
      lines: abaLines,
      paymentDate: run.payment_date,
    })

    // Save ABA record to DB
    const fileName = `payroll-${run.year}-${String(run.month).padStart(2,'0')}-${Date.now()}.aba`

    const { data: abaRecord } = await supabase
      .from('aba_payments')
      .insert({
        pay_run_id:     payRunId,
        file_name:      fileName,
        file_content:   content,    // store for audit
        total_amount:   totalAmount,
        entry_count:    entryCount,
        bsb:            agencyBSB   ?? '000-000',
        account_number: agencyAccountNumber ?? '000000000',
        account_name:   agencyAccountName   ?? 'Agency',
        description:    'PAYROLL',
        status:         'GENERATED',
        generated_by:   generatedBy ?? null,
      })
      .select()
      .single()

    await logAudit({
      action:     'ABA_GENERATED',
      targetType: 'pay_run',
      targetId:   payRunId,
      userId:     generatedBy,
      metadata:   { fileName, totalAmount, entryCount },
    })

    // Return ABA file as download
    return new NextResponse(content, {
      status: 200,
      headers: {
        'Content-Type':        'text/plain; charset=utf-8',
        'Content-Disposition': `attachment; filename="${fileName}"`,
        'X-ABA-Total':         String(totalAmount),
        'X-ABA-Entries':       String(entryCount),
        'X-ABA-Record-ID':     abaRecord?.id ?? '',
      },
    })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
