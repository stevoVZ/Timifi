'use client'
// app/admin/contractors/new/page.tsx
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

const STEPS = ['Identity','Contact','Engagement','Payroll','Review']

interface FormData {
  firstName:string; lastName:string; email:string; phone:string
  dateOfBirth:string; suburb:string; state:string; postcode:string; addressLine1:string
  jobTitle:string; clientName:string; startDate:string; clearanceLevel:string
  hourlyRate:string; contractHoursPA:string; payFrequency:string
  employmentType:string; incomeType:string; notes:string
}

const INIT: FormData = {
  firstName:'',lastName:'',email:'',phone:'',dateOfBirth:'',
  suburb:'',state:'NSW',postcode:'',addressLine1:'',
  jobTitle:'',clientName:'',startDate:new Date().toISOString().slice(0,10),clearanceLevel:'NONE',
  hourlyRate:'',contractHoursPA:'2000',payFrequency:'MONTHLY',
  employmentType:'LABOURHIRE',incomeType:'LABOURHIRE',notes:'',
}

const Field = ({label,value,onChange,type='text',hint,required}:{label:string,value:string,onChange:(v:string)=>void,type?:string,hint?:string,required?:boolean}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>
      {label}{required&&<span style={{color:B.red,marginLeft:3}}>*</span>}
    </label>
    <input type={type} value={value} onChange={e=>onChange(e.target.value)} required={required}
      style={{width:'100%',padding:'10px 13px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,outline:'none',background:B.surface,boxSizing:'border-box',transition:'border .13s'}}
      onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
    />
    {hint&&<div style={{fontSize:12,color:B.sub,marginTop:5}}>{hint}</div>}
  </div>
)

const Select_ = ({label,value,onChange,options,hint}:{label:string,value:string,onChange:(v:string)=>void,options:{v:string,l:string}[],hint?:string}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>{label}</label>
    <select value={value} onChange={e=>onChange(e.target.value)}
      style={{width:'100%',padding:'10px 13px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,background:B.surface,boxSizing:'border-box'}}>
      {options.map(o=><option key={o.v} value={o.v}>{o.l}</option>)}
    </select>
    {hint&&<div style={{fontSize:12,color:B.sub,marginTop:5}}>{hint}</div>}
  </div>
)

export default function NewContractorPage() {
  const router  = useRouter()
  const [step,    setStep]    = useState(0)
  const [form,    setForm]    = useState<FormData>(INIT)
  const [saving,  setSaving]  = useState(false)
  const [errors,  setErrors]  = useState<string[]>([])

  const set = (field: keyof FormData) => (v: string) => setForm(f => ({...f, [field]:v}))

  const validate = (): string[] => {
    const errs: string[] = []
    if (step===0) {
      if (!form.firstName.trim()) errs.push('First name is required')
      if (!form.lastName.trim())  errs.push('Last name is required')
      if (!form.email.trim())     errs.push('Email is required')
      if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errs.push('Invalid email address')
    }
    if (step===2) {
      if (!form.jobTitle.trim())  errs.push('Job title is required')
      if (!form.clientName.trim())errs.push('Client name is required')
    }
    if (step===3) {
      if (!form.hourlyRate || isNaN(Number(form.hourlyRate))) errs.push('Valid hourly rate required')
    }
    return errs
  }

  const next = () => {
    const errs = validate()
    if (errs.length) { setErrors(errs); return }
    setErrors([])
    setStep(s => Math.min(s+1, STEPS.length-1))
  }

  const back = () => { setErrors([]); setStep(s => Math.max(s-1, 0)) }

  const handleSubmit = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/contractors', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          firstName:     form.firstName,
          lastName:      form.lastName,
          email:         form.email,
          phone:         form.phone || undefined,
          jobTitle:      form.jobTitle,
          clientName:    form.clientName,
          hourlyRate:    Number(form.hourlyRate),
          contractHoursPA: Number(form.contractHoursPA),
          startDate:     form.startDate || undefined,
          clearanceLevel: form.clearanceLevel,
          employmentType: form.employmentType,
          incomeType:    form.incomeType,
          payFrequency:  form.payFrequency,
          addressLine1:  form.addressLine1 || undefined,
          suburb:        form.suburb || undefined,
          state:         form.state,
          postcode:      form.postcode || undefined,
          notes:         form.notes || undefined,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to create contractor')

      const contractorId = data.contractor?.id
      if (!contractorId) throw new Error('No contractor ID returned')

      // Auto-send portal invite after creation
      try {
        await fetch('/api/invite', {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ contractorId }),
        })
      } catch {
        // Non-fatal — invite can be resent from detail page
      }

      router.push(`/admin/contractors/${contractorId}`)
    } catch (err) {
      setErrors([err instanceof Error ? err.message : 'Unknown error'])
      setSaving(false)
    }
  }

  return (
    <>
      <TopBar title="Add contractor" subtitle="New contractor onboarding"
        actions={<a href="/admin/contractors" style={{fontSize:13,color:B.dim,textDecoration:'none'}}>← Back to contractors</a>}
      />
      <main style={{flex:1,padding:'28px 32px',background:B.bg}}>
        <div style={{maxWidth:640,margin:'0 auto'}}>

          {/* Step progress */}
          <div style={{display:'flex',alignItems:'center',gap:0,marginBottom:28}}>
            {STEPS.map((s,i)=>(
              <div key={s} style={{display:'flex',alignItems:'center',flex:i<STEPS.length-1?1:'auto'}}>
                <div style={{
                  width:30,height:30,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',
                  fontSize:12,fontWeight:700,flexShrink:0,
                  background: i<step ? B.green : i===step ? B.accent : B.border,
                  color: i<=step ? '#fff' : B.sub,
                }}>
                  {i<step ? '✓' : i+1}
                </div>
                <div style={{marginLeft:8,marginRight:i<STEPS.length-1?16:0}}>
                  <div style={{fontSize:12.5,fontWeight:i===step?700:400,color:i===step?B.text:B.dim,whiteSpace:'nowrap'}}>{s}</div>
                </div>
                {i<STEPS.length-1 && <div style={{flex:1,height:2,background:i<step?B.green:B.border,marginRight:16,borderRadius:1}}/>}
              </div>
            ))}
          </div>

          {/* Errors */}
          {errors.length>0 && (
            <div style={{padding:'12px 16px',background:B.rP,border:`1px solid ${B.rB}`,borderRadius:10,marginBottom:16}}>
              {errors.map(e=><div key={e} style={{fontSize:13,color:B.red}}>{e}</div>)}
            </div>
          )}

          <div className="card" style={{padding:'28px 28px 24px'}}>

            {/* Step 0 — Identity */}
            {step===0 && (
              <div style={{display:'flex',flexDirection:'column',gap:16}}>
                <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:4}}>Identity</h2>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                  <Field label="First name" value={form.firstName} onChange={set('firstName')} required/>
                  <Field label="Last name"  value={form.lastName}  onChange={set('lastName')}  required/>
                </div>
                <Field label="Email" value={form.email} onChange={set('email')} type="email" required hint="Used for Supabase auth invite and Xero contact"/>
                <Field label="Date of birth" value={form.dateOfBirth} onChange={set('dateOfBirth')} type="date" hint="Required for Xero Payroll"/>
              </div>
            )}

            {/* Step 1 — Contact */}
            {step===1 && (
              <div style={{display:'flex',flexDirection:'column',gap:16}}>
                <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:4}}>Contact & address</h2>
                <Field label="Phone" value={form.phone} onChange={set('phone')} type="tel"/>
                <Field label="Street address" value={form.addressLine1} onChange={set('addressLine1')}/>
                <div style={{display:'grid',gridTemplateColumns:'1fr auto auto',gap:12}}>
                  <Field label="Suburb" value={form.suburb} onChange={set('suburb')}/>
                  <Select_ label="State" value={form.state} onChange={set('state')}
                    options={['NSW','VIC','QLD','SA','WA','TAS','ACT','NT'].map(s=>({v:s,l:s}))}/>
                  <Field label="Postcode" value={form.postcode} onChange={set('postcode')}/>
                </div>
              </div>
            )}

            {/* Step 2 — Engagement */}
            {step===2 && (
              <div style={{display:'flex',flexDirection:'column',gap:16}}>
                <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:4}}>Engagement</h2>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                  <Field label="Job title"   value={form.jobTitle}   onChange={set('jobTitle')}   required/>
                  <Field label="Client name" value={form.clientName} onChange={set('clientName')} required/>
                  <Field label="Start date"  value={form.startDate}  onChange={set('startDate')}  type="date"/>
                </div>
                <Select_ label="Security clearance" value={form.clearanceLevel} onChange={set('clearanceLevel')}
                  options={[{v:'NONE',l:'None'},{v:'BASELINE',l:'Baseline'},{v:'NV1',l:'NV1'},{v:'NV2',l:'NV2'},{v:'PV',l:'PV'}]}/>
                <Field label="Notes" value={form.notes} onChange={set('notes')} hint="Internal notes — not visible to contractor"/>
              </div>
            )}

            {/* Step 3 — Payroll */}
            {step===3 && (
              <div style={{display:'flex',flexDirection:'column',gap:16}}>
                <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:4}}>Payroll configuration</h2>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                  <Field label="Hourly rate ($)" value={form.hourlyRate} onChange={set('hourlyRate')} type="number" required hint="Excluding GST"/>
                  <Field label="Contract hours / year" value={form.contractHoursPA} onChange={set('contractHoursPA')} type="number" hint="Used for utilisation tracking"/>
                </div>
                <Select_ label="Pay frequency" value={form.payFrequency} onChange={set('payFrequency')}
                  options={[{v:'WEEKLY',l:'Weekly'},{v:'FORTNIGHTLY',l:'Fortnightly'},{v:'MONTHLY',l:'Monthly'}]}/>
                <Select_ label="Employment type" value={form.employmentType} onChange={set('employmentType')}
                  options={[{v:'LABOURHIRE',l:'Labour hire'},{v:'CASUAL',l:'Casual'},{v:'PARTTIME',l:'Part time'},{v:'FULLTIME',l:'Full time'}]}/>
                {form.hourlyRate && (
                  <div style={{padding:'14px 16px',background:B.bg,border:`1px solid ${B.border}`,borderRadius:10}}>
                    <div style={{fontSize:12,color:B.dim,marginBottom:6}}>Estimated annual contract value</div>
                    <div style={{fontFamily:"'DM Mono',monospace",fontSize:18,fontWeight:700,color:B.accent}}>
                      ${(Number(form.hourlyRate)*Number(form.contractHoursPA)).toLocaleString('en-AU')}
                    </div>
                    <div style={{fontSize:12,color:B.sub,marginTop:3}}>{form.contractHoursPA}h × ${form.hourlyRate}/hr</div>
                  </div>
                )}
              </div>
            )}

            {/* Step 4 — Review */}
            {step===4 && (
              <div style={{display:'flex',flexDirection:'column',gap:16}}>
                <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:4}}>Review & confirm</h2>
                <div style={{background:B.bg,borderRadius:10,border:`1px solid ${B.border}`,overflow:'hidden'}}>
                  {[
                    ['Full name',   `${form.firstName} ${form.lastName}`],
                    ['Email',       form.email],
                    ['Phone',       form.phone||'—'],
                    ['Job title',   form.jobTitle],
                    ['Client',      form.clientName],
                    ['Start date',  form.startDate||'—'],
                    ['Hourly rate', form.hourlyRate?`$${form.hourlyRate}/hr`:'—'],
                    ['Contract hrs',`${form.contractHoursPA}h/yr`],
                    ['Pay freq',    form.payFrequency.toLowerCase()],
                    ['Clearance',   form.clearanceLevel],
                    ['Address',     [form.addressLine1,form.suburb,form.state,form.postcode].filter(Boolean).join(' ')||'—'],
                  ].map(([k,v],i,arr)=>(
                    <div key={k} style={{display:'flex',padding:'10px 16px',borderBottom:i<arr.length-1?`1px solid ${B.faint}`:'none'}}>
                      <span style={{fontSize:13,color:B.dim,width:140,flexShrink:0}}>{k}</span>
                      <span style={{fontSize:13,color:B.text,fontWeight:500}}>{v}</span>
                    </div>
                  ))}
                </div>
                <div style={{padding:'12px 16px',background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:10,fontSize:13,color:B.amber}}>
                  Creating this contractor will set their status to <strong>Pending setup</strong>. You'll need to invite them to the portal separately via Supabase Auth.
                </div>
              </div>
            )}

            {/* Navigation */}
            <div style={{display:'flex',justifyContent:'space-between',marginTop:24,paddingTop:16,borderTop:`1px solid ${B.faint}`}}>
              <button onClick={back} disabled={step===0} className="btn btn-ghost" style={{opacity:step===0?0:1,visibility:step===0?'hidden':'visible'}}>
                ← Back
              </button>
              {step < STEPS.length-1
                ? <button onClick={next} className="btn btn-accent">Next →</button>
                : <button onClick={handleSubmit} disabled={saving} className="btn btn-accent" style={{opacity:saving?0.7:1}}>
                    {saving ? 'Creating…' : '✓ Create contractor'}
                  </button>
              }
            </div>
          </div>
        </div>
      </main>
    </>
  )
}
