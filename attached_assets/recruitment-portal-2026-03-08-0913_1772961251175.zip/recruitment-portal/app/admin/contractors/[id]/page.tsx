'use client'
// app/admin/contractors/[id]/page.tsx
import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

/* ── Types ───────────────────────────────────────────────────────────────── */
interface Contractor {
  id:string; firstName:string; lastName:string; initials:string; col:string; bg:string
  email:string; phone:string; status:string; jobTitle:string; client:string
  hourlyRate:number; contractHoursPA:number; payFrequency:string
  startDate:string; endDate:string|null; clearanceLevel:string; clearanceExpiry:string|null
  suburb:string; state:string; postcode:string; addressLine1:string
  xeroEmployeeId:string|null; xeroContactId:string|null
  onboardingComplete:boolean; notes:string
}
interface Timesheet { id:string; month:string; hours:number; status:string; invoiced:boolean }
interface Invoice    { id:string; number:string; period:string; amount:number; status:string; due:string }
interface Doc        { id:string; name:string; type:string; fileUrl:string; createdAt:string }

/* ── Status pills ────────────────────────────────────────────────────────── */
const SP: Record<string,{bg:string,c:string}> = {
  ACTIVE:        {bg:B.gP,   c:B.green },  PENDING_SETUP: {bg:B.aLP, c:B.amber },
  OFFBOARDED:    {bg:B.faint,c:B.dim   },  APPROVED:      {bg:B.gP,  c:B.green },
  SUBMITTED:     {bg:B.aLP,  c:B.amber },  REJECTED:      {bg:B.rP,  c:B.red   },
  DRAFT:         {bg:B.faint,c:B.dim   },  PAID:          {bg:B.gP,  c:B.green },
  SENT:          {bg:B.aP,   c:B.accent},  OVERDUE:       {bg:B.rP,  c:B.red   },
  AUTHORISED:    {bg:B.aP,   c:B.accent},
}

const SEED: Record<string, Contractor & { timesheets:Timesheet[]; invoices:Invoice[]; docs:Doc[] }> = {
  c1: {
    id:'c1',firstName:'Alex',lastName:'Rivera',initials:'AR',col:'#2563eb',bg:'#eff6ff',
    email:'alex.rivera@email.com',phone:'0412 345 678',status:'ACTIVE',
    jobTitle:'Senior Developer',client:'Client A',hourlyRate:120,contractHoursPA:2000,
    payFrequency:'MONTHLY',startDate:'2024-01-15',endDate:null,
    clearanceLevel:'BASELINE',clearanceExpiry:'2026-12-31',
    suburb:'North Sydney',state:'NSW',postcode:'2060',addressLine1:'12 Pacific Hwy',
    xeroEmployeeId:'EMP-001',xeroContactId:'xero-contact-c1',onboardingComplete:true,notes:'',
    timesheets:[
      {id:'t1',month:'March 2026',hours:172,status:'APPROVED',invoiced:true},
      {id:'t2',month:'February 2026',hours:160,status:'APPROVED',invoiced:true},
      {id:'t3',month:'January 2026',hours:144,status:'APPROVED',invoiced:false},
    ],
    invoices:[
      {id:'i1',number:'INV-0047',period:'March 2026',amount:20640,status:'SENT',due:'2026-04-15'},
      {id:'i2',number:'INV-0039',period:'February 2026',amount:19200,status:'PAID',due:'2026-03-14'},
      {id:'i3',number:'INV-0031',period:'January 2026',amount:17280,status:'OVERDUE',due:'2026-02-14'},
    ],
    docs:[
      {id:'d1',name:'Employment contract — Jan 2024',type:'CONTRACT',fileUrl:'#',createdAt:'2024-01-10'},
      {id:'d2',name:'Baseline clearance certificate',type:'CLEARANCE',fileUrl:'#',createdAt:'2024-01-10'},
    ],
  },
  c2: {
    id:'c2',firstName:'Jordan',lastName:'Kim',initials:'JK',col:'#7c3aed',bg:'#f5f3ff',
    email:'jordan.kim@email.com',phone:'0423 456 789',status:'ACTIVE',
    jobTitle:'Business Analyst',client:'Client B',hourlyRate:95,contractHoursPA:2000,
    payFrequency:'MONTHLY',startDate:'2024-03-01',endDate:null,
    clearanceLevel:'NONE',clearanceExpiry:null,
    suburb:'Surry Hills',state:'NSW',postcode:'2010',addressLine1:'45 Crown St',
    xeroEmployeeId:'EMP-002',xeroContactId:'xero-contact-c2',onboardingComplete:true,notes:'',
    timesheets:[{id:'t4',month:'March 2026',hours:164,status:'SUBMITTED',invoiced:false}],
    invoices:[],docs:[],
  },
  c3: {
    id:'c3',firstName:'Sam',lastName:'Okafor',initials:'SO',col:'#059669',bg:'#ecfdf5',
    email:'sam.okafor@email.com',phone:'0434 567 890',status:'PENDING_SETUP',
    jobTitle:'Project Manager',client:'Client C',hourlyRate:105,contractHoursPA:1800,
    payFrequency:'MONTHLY',startDate:'2026-03-10',endDate:null,
    clearanceLevel:'NONE',clearanceExpiry:null,
    suburb:'Melbourne',state:'VIC',postcode:'3000',addressLine1:'',
    xeroEmployeeId:null,xeroContactId:null,onboardingComplete:false,notes:'New starter — awaiting onboarding.',
    timesheets:[],invoices:[],docs:[],
  },
}

const fmt = (n:number) => '$'+n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})

const ROW = ({label,value,mono}:{label:string;value:string|null;mono?:boolean}) => (
  <div style={{display:'flex',padding:'9px 0',borderBottom:`1px solid ${B.faint}`}}>
    <span style={{width:160,flexShrink:0,fontSize:13,color:B.dim}}>{label}</span>
    <span style={{fontSize:13,color:value?B.text:B.sub,fontFamily:mono?"'DM Mono',monospace":undefined,fontWeight:mono?500:400}}>{value||'—'}</span>
  </div>
)

const FLD = ({label,value,onChange,type='text',hint}:{label:string;value:string;onChange:(v:string)=>void;type?:string;hint?:string}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:5}}>{label}</label>
    <input type={type} value={value} onChange={e=>onChange(e.target.value)}
      style={{width:'100%',padding:'9px 12px',borderRadius:8,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:13.5,color:B.text,outline:'none',background:B.surface,boxSizing:'border-box'}}
      onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
    />
    {hint&&<div style={{fontSize:11.5,color:B.sub,marginTop:4}}>{hint}</div>}
  </div>
)

const SEL = ({label,value,onChange,opts}:{label:string;value:string;onChange:(v:string)=>void;opts:{v:string;l:string}[]}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:5}}>{label}</label>
    <select value={value} onChange={e=>onChange(e.target.value)}
      style={{width:'100%',padding:'9px 12px',borderRadius:8,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:13.5,color:B.text,background:B.surface}}>
      {opts.map(o=><option key={o.v} value={o.v}>{o.l}</option>)}
    </select>
  </div>
)

/* ═══════════════════════════════════════════════════════════════════════════ */
export default function ContractorDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()

  const colPairs = [
    ['#2563eb','#eff6ff'],['#7c3aed','#f5f3ff'],['#059669','#ecfdf5'],
    ['#dc2626','#fef2f2'],['#b45309','#fffbeb'],['#0891b2','#ecfeff'],
  ]
  const colorFor = (id: string) => colPairs[id.charCodeAt(0) % colPairs.length]

  const [c,            setC]            = useState<(Contractor & { timesheets:Timesheet[]; invoices:Invoice[]; docs:Doc[] })|null>(null)
  const [loading,      setLoading]      = useState(true)
  const [notFound,     setNotFound]     = useState(false)
  const [tab,          setTab]          = useState<'profile'|'timesheets'|'invoices'|'documents'>('profile')
  const [editMode,     setEditMode]     = useState(false)
  const [draft,        setDraft]        = useState<Contractor|null>(null)
  const [saving,       setSaving]       = useState(false)
  const [syncing,      setSyncing]      = useState(false)
  const [creatingInv,  setCreatingInv]  = useState<string|null>(null)
  const [toast,        setToast]        = useState<string|null>(null)

  const toast_ = useCallback((m:string)=>{ setToast(m); setTimeout(()=>setToast(null),3000) },[])

  useEffect(() => {
    setLoading(true)
    fetch(`/api/contractors/${params.id}`)
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        if (!d?.contractor) { setNotFound(true); return }
        const rc = d.contractor
        const [col, bg] = colorFor(rc.id)
        const fn = rc.first_name ?? ''
        const ln = rc.last_name  ?? ''
        setC({
          id: rc.id, firstName: fn, lastName: ln,
          initials: `${fn[0] ?? '?'}${ln[0] ?? '?'}`, col, bg,
          email: rc.email, phone: rc.phone ?? '',
          status: rc.status, jobTitle: rc.job_title ?? '', client: rc.client_name ?? '',
          hourlyRate: rc.hourly_rate ?? 0, contractHoursPA: rc.contract_hours_pa ?? 2000,
          payFrequency: rc.pay_frequency ?? 'MONTHLY',
          startDate: rc.start_date ?? '', endDate: rc.end_date ?? null,
          clearanceLevel: rc.clearance_level ?? 'NONE', clearanceExpiry: rc.clearance_expiry ?? null,
          suburb: rc.suburb ?? '', state: rc.state ?? 'NSW',
          postcode: rc.postcode ?? '', addressLine1: rc.address_line1 ?? '',
          xeroEmployeeId: rc.xero_employee_id, xeroContactId: rc.xero_contact_id,
          onboardingComplete: rc.onboarding_complete ?? false, notes: rc.notes ?? '',
          timesheets: [], invoices: [], docs: [],
        })

        // Fetch timesheets
        fetch(`/api/timesheets?contractorId=${rc.id}&limit=20`)
          .then(r => r.ok ? r.json() : null)
          .then(td => {
            if (!td?.timesheets) return
            setC(prev => prev ? { ...prev, timesheets: td.timesheets.map((t: Record<string,unknown>) => ({
              id: t.id, month: t.period_label ?? `${t.month}/${t.year}`,
              hours: Number(t.total_hours ?? 0), status: t.status, invoiced: !!t.invoice_id,
            }))} : prev)
          }).catch(()=>null)

        // Fetch invoices
        fetch(`/api/invoices?contractorId=${rc.id}&limit=20`)
          .then(r => r.ok ? r.json() : null)
          .then(id => {
            if (!id?.invoices) return
            setC(prev => prev ? { ...prev, invoices: id.invoices.map((inv: Record<string,unknown>) => ({
              id: inv.id, number: inv.invoice_number ?? inv.xero_invoice_number ?? '—',
              period: inv.period_label ?? '—', amount: Number(inv.total_amount ?? 0),
              status: inv.status, due: inv.due_date ?? '',
            }))} : prev)
          }).catch(()=>null)

        // Fetch documents
        fetch(`/api/documents?contractorId=${rc.id}`)
          .then(r => r.ok ? r.json() : null)
          .then(dd => {
            if (!dd?.documents) return
            setC(prev => prev ? { ...prev, docs: dd.documents.map((doc: Record<string,unknown>) => ({
              id: doc.id, name: doc.name, type: doc.type, url: doc.file_url, uploaded: doc.created_at,
            }))} : prev)
          }).catch(()=>null)
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false))
  }, [params.id])

  if (loading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'60vh',flexDirection:'column',gap:12}}>
      <div className="spin" style={{width:32,height:32,border:`3px solid ${B.border}`,borderTopColor:B.accent,borderRadius:'50%'}}/>
      <div style={{fontSize:13,color:B.dim}}>Loading…</div>
    </div>
  )

  if (notFound || !c) return (
    <div style={{padding:48,textAlign:'center'}}>
      <div style={{fontSize:14,color:B.dim}}>Contractor not found</div>
      <button onClick={()=>router.push('/admin/contractors')} className="btn btn-ghost" style={{marginTop:12}}>← Back</button>
    </div>
  )

  const startEdit = () => { setDraft({...c}); setEditMode(true) }
  const cancelEdit = () => { setDraft(null); setEditMode(false) }

  const saveEdit = async () => {
    if (!draft) return
    setSaving(true)
    try {
      const res = await fetch(`/api/contractors/${c.id}`, {
        method:'PATCH', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          firstName:draft.firstName, lastName:draft.lastName,
          email:draft.email, phone:draft.phone,
          jobTitle:draft.jobTitle, clientName:draft.client,
          hourlyRate:Number(draft.hourlyRate), contractHoursPA:Number(draft.contractHoursPA),
          startDate:draft.startDate, endDate:draft.endDate||null,
          status:draft.status, clearanceLevel:draft.clearanceLevel,
          suburb:draft.suburb, state:draft.state, postcode:draft.postcode, addressLine1:draft.addressLine1,
          notes:draft.notes,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error||'Save failed')
      setC(prev => prev ? {...prev,...draft} : prev)
      setEditMode(false); setDraft(null)
      toast_('✓ Saved')
    } catch(e){ toast_(`⚠ ${e instanceof Error?e.message:'Save failed'}`) }
    setSaving(false)
  }

  const syncXero = async () => {
    setSyncing(true)
    try {
      const res = await fetch('/api/xero/payroll', {
        method:'PUT', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ contractorId:c.id, xeroTenantId:'TENANT_ID' }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error||'Xero sync failed')
      toast_(`✓ Synced to Xero: ${data.xeroEmployeeId}`)
    } catch(e){ toast_(`⚠ ${e instanceof Error?e.message:'Sync failed'}`) }
    setSyncing(false)
  }

  const createInvoice = async (timesheetId:string) => {
    setCreatingInv(timesheetId)
    try {
      const res = await fetch('/api/xero/invoices', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ versionId: timesheetId, sendEmail: false }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error||'Invoice creation failed')
      toast_('✓ Invoice created in Xero')
    } catch(e){ toast_(`⚠ ${e instanceof Error?e.message:'Failed'}`) }
    setCreatingInv(null)
  }

  const sp     = SP[c.status]||{bg:B.faint,c:B.dim}
  const ytdHrs = c.timesheets?.reduce((s,t)=>s+(t.status==='APPROVED'?t.hours:0),0)??0
  const ytdVal = ytdHrs * c.hourlyRate

  const [inviting, setInviting] = useState(false)
  const handleInvite = async (resend = false) => {
    setInviting(true)
    try {
      const res  = await fetch('/api/invite', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ contractorId: c.id, resend }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Invite failed')
      toast_(`✓ Invite sent to ${c.email}`)
      setC(prev => prev ? {...prev, onboardingComplete: false} : prev)
    } catch (e) {
      toast_(`⚠ ${e instanceof Error ? e.message : 'Invite failed'}`)
    }
    setInviting(false)
  }

  return (
    <>
      <TopBar
        title={`${c.firstName} ${c.lastName}`}
        subtitle={`${c.jobTitle} · ${c.client}`}
        actions={
          <div style={{display:'flex',gap:8,alignItems:'center'}}>
            {!editMode
              ? <>
                  {c.status === 'PENDING_SETUP' && !c.onboardingComplete && (
                    <button onClick={() => handleInvite(false)} disabled={inviting}
                      className="btn btn-green btn-sm" style={{opacity:inviting?.7:1}}>
                      {inviting ? 'Sending…' : '✉ Send portal invite'}
                    </button>
                  )}
                  {c.onboardingComplete && (
                    <button onClick={() => handleInvite(true)} disabled={inviting}
                      className="btn btn-ghost btn-sm" style={{opacity:inviting?.7:1}}>
                      {inviting ? 'Sending…' : '↻ Resend invite'}
                    </button>
                  )}
                  <button onClick={startEdit} className="btn btn-ghost btn-sm">✏ Edit</button>
                  <button onClick={syncXero} disabled={syncing} className="btn btn-ghost btn-sm" style={{opacity:syncing?.7:1}}>
                    {syncing?'Syncing…':'↕ Sync Xero'}
                  </button>
                  <a href="/admin/contractors" style={{fontSize:13,color:B.dim,textDecoration:'none',padding:'6px 10px'}}>← All contractors</a>
                </>
              : <>
                  <button onClick={cancelEdit} className="btn btn-ghost btn-sm">Cancel</button>
                  <button onClick={saveEdit} disabled={saving} className="btn btn-accent btn-sm" style={{opacity:saving?.7:1}}>{saving?'Saving…':'✓ Save changes'}</button>
                </>
            }
          </div>
        }
      />

      <main style={{flex:1,padding:'24px 32px',background:B.bg}}>
        <div style={{display:'grid',gridTemplateColumns:'260px 1fr',gap:20,alignItems:'start'}}>

          {/* Left: profile card */}
          <div style={{display:'flex',flexDirection:'column',gap:14}}>
            <div className="card" style={{padding:'20px',textAlign:'center'}}>
              <div style={{width:64,height:64,borderRadius:16,background:c.bg,color:c.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:22,fontWeight:700,margin:'0 auto 12px'}}>{c.initials}</div>
              <div style={{fontSize:17,fontWeight:700,color:B.text}}>{c.firstName} {c.lastName}</div>
              <div style={{fontSize:13,color:B.dim,marginBottom:10}}>{c.jobTitle}</div>
              <span style={{fontSize:12,fontWeight:600,padding:'3px 10px',borderRadius:100,background:sp.bg,color:sp.c}}>{c.status.replace('_',' ')}</span>
            </div>

            {/* KPIs */}
            <div className="card" style={{padding:'16px',display:'flex',flexDirection:'column',gap:12}}>
              {[
                ['Hourly rate',     `$${c.hourlyRate}/hr`,             false],
                ['YTD hours',       `${ytdHrs}h`,                      false],
                ['YTD billings',    fmt(ytdVal),                        true ],
                ['Contract hrs/yr', `${c.contractHoursPA}h`,           false],
                ['Pay frequency',   c.payFrequency.toLowerCase(),       false],
              ].map(([l,v,green])=>(
                <div key={l as string}>
                  <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.sub,marginBottom:3}}>{l}</div>
                  <div style={{fontFamily:"'DM Mono',monospace",fontSize:15,fontWeight:700,color:(green?B.green:B.text) as string}}>{v}</div>
                </div>
              ))}
            </div>

            {/* Xero status */}
            <div className="card" style={{padding:'14px 16px'}}>
              <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:8}}>Xero</div>
              <div style={{fontSize:13,color:c.xeroEmployeeId?B.green:B.sub,fontWeight:600,marginBottom:4}}>
                {c.xeroEmployeeId ? `✓ Employee: ${c.xeroEmployeeId}` : '✕ Not synced'}
              </div>
              <div style={{fontSize:13,color:c.xeroContactId?B.green:B.sub}}>
                {c.xeroContactId ? `✓ Contact linked` : '✕ No contact'}
              </div>
            </div>

            {/* Onboarding */}
            <div className="card" style={{padding:'14px 16px'}}>
              <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:8}}>Onboarding</div>
              <div style={{fontSize:13,color:c.onboardingComplete?B.green:B.amber,fontWeight:600}}>
                {c.onboardingComplete ? '✓ Complete' : '⏳ Pending'}
              </div>
              {!c.onboardingComplete && (
                <div style={{fontSize:12,color:B.sub,marginTop:4}}>TFN, bank & super not yet submitted</div>
              )}
            </div>
          </div>

          {/* Right: tabs */}
          <div className="card" style={{overflow:'hidden'}}>
            <div style={{display:'flex',borderBottom:`1px solid ${B.border}`,padding:'0 4px'}}>
              {(['profile','timesheets','invoices','documents'] as const).map(t=>(
                <button key={t} onClick={()=>setTab(t)} className={`tab${tab===t?' on':''}`} style={{textTransform:'capitalize'}}>
                  {t}
                  {t==='timesheets'&&c.timesheets?.length>0&&<span style={{marginLeft:6,fontSize:11,padding:'1px 6px',borderRadius:4,background:tab===t?B.accent:B.border,color:tab===t?'#fff':B.dim}}>{c.timesheets.length}</span>}
                </button>
              ))}
            </div>

            {/* ── Profile tab ── */}
            {tab==='profile' && (
              <div style={{padding:'22px 24px'}}>
                {!editMode ? (
                  <>
                    <div style={{fontWeight:700,color:B.text,fontSize:13,marginBottom:10}}>Identity</div>
                    <ROW label="Full name"   value={`${c.firstName} ${c.lastName}`}/>
                    <ROW label="Email"       value={c.email}/>
                    <ROW label="Phone"       value={c.phone}/>
                    <div style={{fontWeight:700,color:B.text,fontSize:13,margin:'16px 0 10px'}}>Engagement</div>
                    <ROW label="Job title"       value={c.jobTitle}/>
                    <ROW label="Client"          value={c.client}/>
                    <ROW label="Status"          value={c.status.replace('_',' ')}/>
                    <ROW label="Hourly rate"      value={`$${c.hourlyRate}/hr`} mono/>
                    <ROW label="Contract hrs/yr" value={`${c.contractHoursPA}h`} mono/>
                    <ROW label="Start date"      value={c.startDate}/>
                    <ROW label="Security clearance" value={c.clearanceLevel}/>
                    {c.clearanceExpiry && <ROW label="Clearance expiry" value={c.clearanceExpiry}/>}
                    <div style={{fontWeight:700,color:B.text,fontSize:13,margin:'16px 0 10px'}}>Address</div>
                    <ROW label="Street" value={c.addressLine1}/>
                    <ROW label="Suburb" value={[c.suburb,c.state,c.postcode].filter(Boolean).join(', ')}/>
                    {c.notes&&(
                      <div style={{marginTop:16,padding:'12px 14px',background:B.faint,borderRadius:10,fontSize:13,color:B.mid}}><span style={{fontWeight:600,color:B.dim}}>Notes: </span>{c.notes}</div>
                    )}
                  </>
                ) : draft && (
                  <div style={{display:'flex',flexDirection:'column',gap:14}}>
                    <div style={{fontWeight:700,color:B.text,fontSize:13,marginBottom:2}}>Identity</div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
                      <FLD label="First name" value={draft.firstName} onChange={v=>setDraft(d=>d?{...d,firstName:v}:d)}/>
                      <FLD label="Last name"  value={draft.lastName}  onChange={v=>setDraft(d=>d?{...d,lastName:v}:d)}/>
                      <FLD label="Email"      value={draft.email}     onChange={v=>setDraft(d=>d?{...d,email:v}:d)}   type="email"/>
                      <FLD label="Phone"      value={draft.phone}     onChange={v=>setDraft(d=>d?{...d,phone:v}:d)}/>
                    </div>
                    <div style={{fontWeight:700,color:B.text,fontSize:13,marginTop:4,marginBottom:2}}>Engagement</div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
                      <FLD label="Job title"   value={draft.jobTitle} onChange={v=>setDraft(d=>d?{...d,jobTitle:v}:d)}/>
                      <FLD label="Client"      value={draft.client}   onChange={v=>setDraft(d=>d?{...d,client:v}:d)}/>
                      <FLD label="Hourly rate" value={String(draft.hourlyRate)} onChange={v=>setDraft(d=>d?{...d,hourlyRate:Number(v)}:d)} type="number"/>
                      <FLD label="Contract hrs/yr" value={String(draft.contractHoursPA)} onChange={v=>setDraft(d=>d?{...d,contractHoursPA:Number(v)}:d)} type="number"/>
                      <FLD label="Start date"  value={draft.startDate} onChange={v=>setDraft(d=>d?{...d,startDate:v}:d)} type="date"/>
                      <FLD label="End date"    value={draft.endDate??''} onChange={v=>setDraft(d=>d?{...d,endDate:v||null}:d)} type="date"/>
                    </div>
                    <SEL label="Status" value={draft.status} onChange={v=>setDraft(d=>d?{...d,status:v}:d)}
                      opts={[{v:'ACTIVE',l:'Active'},{v:'PENDING_SETUP',l:'Pending setup'},{v:'OFFBOARDED',l:'Offboarded'}]}/>
                    <SEL label="Security clearance" value={draft.clearanceLevel} onChange={v=>setDraft(d=>d?{...d,clearanceLevel:v}:d)}
                      opts={[{v:'NONE',l:'None'},{v:'BASELINE',l:'Baseline'},{v:'NV1',l:'NV1'},{v:'NV2',l:'NV2'},{v:'PV',l:'PV'}]}/>
                    <div style={{fontWeight:700,color:B.text,fontSize:13,marginTop:4,marginBottom:2}}>Address</div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
                      <FLD label="Street address" value={draft.addressLine1} onChange={v=>setDraft(d=>d?{...d,addressLine1:v}:d)}/>
                      <FLD label="Suburb"         value={draft.suburb}       onChange={v=>setDraft(d=>d?{...d,suburb:v}:d)}/>
                      <FLD label="State"          value={draft.state}        onChange={v=>setDraft(d=>d?{...d,state:v}:d)}/>
                      <FLD label="Postcode"       value={draft.postcode}     onChange={v=>setDraft(d=>d?{...d,postcode:v}:d)}/>
                    </div>
                    <div>
                      <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:5}}>Notes</label>
                      <textarea value={draft.notes} onChange={e=>setDraft(d=>d?{...d,notes:e.target.value}:d)} rows={3}
                        style={{width:'100%',padding:'9px 12px',borderRadius:8,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:13.5,color:B.text,outline:'none',background:B.surface,resize:'none',boxSizing:'border-box'}}
                        onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ── Timesheets tab ── */}
            {tab==='timesheets' && (
              <div>
                {(c.timesheets?.length??0)===0 ? (
                  <div style={{padding:'48px',textAlign:'center',color:B.dim}}>
                    <div style={{fontSize:28,marginBottom:10}}>📄</div>
                    <div style={{fontSize:14,fontWeight:600,color:B.text}}>No timesheets yet</div>
                  </div>
                ) : (
                  <table style={{width:'100%',borderCollapse:'collapse'}}>
                    <thead>
                      <tr style={{background:B.bg,borderBottom:`1px solid ${B.border}`}}>
                        {['Period','Hours','Status','Invoice',''].map(h=>(
                          <th key={h} style={{padding:'11px 18px',textAlign:'left',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim}}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {c.timesheets.map((t,i)=>{
                        const tsp = SP[t.status]||{bg:B.faint,c:B.dim}
                        return (
                          <tr key={t.id} style={{borderBottom:i<c.timesheets.length-1?`1px solid ${B.faint}`:'none'}}>
                            <td style={{padding:'13px 18px',fontSize:14,color:B.text,fontWeight:500}}>{t.month}</td>
                            <td style={{padding:'13px 18px',fontFamily:"'DM Mono',monospace",fontSize:13.5,color:B.text}}>{t.hours}h</td>
                            <td style={{padding:'13px 18px'}}><span style={{fontSize:12,fontWeight:600,padding:'3px 9px',borderRadius:100,...tsp}}>{t.status}</span></td>
                            <td style={{padding:'13px 18px'}}>
                              {t.invoiced ? <span style={{fontSize:12,color:B.green,fontWeight:600}}>✓ Invoiced</span>
                                : <span style={{fontSize:12,color:B.sub}}>Pending</span>}
                            </td>
                            <td style={{padding:'13px 18px'}}>
                              {t.status==='APPROVED'&&!t.invoiced&&(
                                <button onClick={()=>createInvoice(t.id)} disabled={creatingInv===t.id} style={{
                                  fontSize:12,fontWeight:600,color:B.accent,background:B.aP,border:`1px solid ${B.aBd}`,
                                  padding:'5px 11px',borderRadius:7,cursor:'pointer',opacity:creatingInv===t.id?.6:1,
                                }}>{creatingInv===t.id?'Creating…':'Create invoice'}</button>
                              )}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {/* ── Invoices tab ── */}
            {tab==='invoices' && (
              <div>
                {(c.invoices?.length??0)===0 ? (
                  <div style={{padding:'48px',textAlign:'center',color:B.dim}}>
                    <div style={{fontSize:28,marginBottom:10}}>🧾</div>
                    <div style={{fontSize:14,fontWeight:600,color:B.text,marginBottom:4}}>No invoices yet</div>
                    <div style={{fontSize:13,color:B.dim}}>Invoices appear here once created from approved timesheets.</div>
                  </div>
                ) : (
                  <table style={{width:'100%',borderCollapse:'collapse'}}>
                    <thead>
                      <tr style={{background:B.bg,borderBottom:`1px solid ${B.border}`}}>
                        {['Invoice','Period','Amount','Status','Due',''].map(h=>(
                          <th key={h} style={{padding:'11px 18px',textAlign:'left',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim}}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {c.invoices.map((inv,i)=>{
                        const isp=SP[inv.status]||{bg:B.faint,c:B.dim}
                        return (
                          <tr key={inv.id} style={{borderBottom:i<c.invoices.length-1?`1px solid ${B.faint}`:'none'}}>
                            <td style={{padding:'13px 18px',fontFamily:"'DM Mono',monospace",fontSize:13.5,color:B.accent,fontWeight:600}}>{inv.number}</td>
                            <td style={{padding:'13px 18px',fontSize:13.5,color:B.text}}>{inv.period}</td>
                            <td style={{padding:'13px 18px',fontFamily:"'DM Mono',monospace",fontSize:13.5,fontWeight:600,color:B.text}}>{fmt(inv.amount)}</td>
                            <td style={{padding:'13px 18px'}}><span style={{fontSize:12,fontWeight:600,padding:'3px 9px',borderRadius:100,...isp}}>{inv.status}</span></td>
                            <td style={{padding:'13px 18px',fontSize:13,color:inv.status==='OVERDUE'?B.red:B.dim}}>{inv.due}</td>
                            <td style={{padding:'13px 18px'}}>
                              <a href="#" style={{fontSize:12.5,color:B.accent,fontWeight:600,textDecoration:'none'}}>View in Xero →</a>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {/* ── Documents tab ── */}
            {tab==='documents' && (
              <div style={{padding:'20px 22px'}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
                  <div style={{fontSize:13,color:B.dim}}>{c.docs?.length??0} document{(c.docs?.length??0)!==1?'s':''}</div>
                  <label style={{
                    padding:'7px 14px',borderRadius:8,background:B.accent,color:'#fff',
                    fontSize:12.5,fontWeight:600,cursor:'pointer',display:'inline-flex',alignItems:'center',gap:6,
                  }}>
                    + Upload
                    <input type="file" style={{display:'none'}} accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                      onChange={async e=>{
                        const file = e.target.files?.[0]
                        if (!file) return
                        // In production: upload to Supabase Storage first, then POST /api/documents
                        toast_('📎 Upload to Supabase Storage — wired in production')
                      }}
                    />
                  </label>
                </div>
                {(c.docs?.length??0)===0 ? (
                  <div style={{padding:'40px',textAlign:'center',border:`2px dashed ${B.border}`,borderRadius:12,color:B.dim}}>
                    <div style={{fontSize:28,marginBottom:10}}>📁</div>
                    <div style={{fontSize:14,fontWeight:600,color:B.text,marginBottom:4}}>No documents</div>
                    <div style={{fontSize:13}}>Upload contracts, clearances and certifications.</div>
                  </div>
                ) : (
                  <div style={{display:'flex',flexDirection:'column',gap:8}}>
                    {c.docs.map(doc=>{
                      const typeCol: Record<string,string> = {CONTRACT:B.accent,CLEARANCE:B.purple,ID:B.amber,CERT:B.green}
                      const col_ = typeCol[doc.type]||B.dim
                      return (
                        <div key={doc.id} style={{display:'flex',alignItems:'center',gap:12,padding:'11px 14px',background:B.bg,borderRadius:10,border:`1px solid ${B.border}`}}>
                          <div style={{width:36,height:36,borderRadius:9,background:B.surface,border:`1px solid ${B.border}`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,flexShrink:0}}>
                            {doc.type==='CONTRACT'?'📝':doc.type==='CLEARANCE'?'🛡️':doc.type==='ID'?'🪪':'📄'}
                          </div>
                          <div style={{flex:1,minWidth:0}}>
                            <div style={{fontSize:13.5,fontWeight:600,color:B.text,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{doc.name}</div>
                            <div style={{fontSize:11.5,color:B.sub,marginTop:2}}>{doc.createdAt}</div>
                          </div>
                          <span style={{fontSize:11,fontWeight:700,padding:'2px 8px',borderRadius:4,background:B.faint,color:col_}}>{doc.type}</span>
                          <a href={doc.fileUrl} style={{fontSize:12.5,color:B.accent,fontWeight:600,textDecoration:'none',padding:'5px 10px',background:B.aP,border:`1px solid ${B.aBd}`,borderRadius:7}}>↓ View</a>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      {toast&&<div style={{position:'fixed',bottom:24,right:24,zIndex:999,background:B.text,color:'#fff',padding:'12px 22px',borderRadius:10,fontWeight:600,fontSize:13,boxShadow:'0 4px 16px rgba(0,0,0,.18)'}}>{toast}</div>}
    </>
  )
}
