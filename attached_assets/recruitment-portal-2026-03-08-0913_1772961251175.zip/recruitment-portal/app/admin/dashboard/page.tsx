'use client'
// app/admin/dashboard/page.tsx
// Fetches live stats from Supabase via API routes on mount

import { useState, useEffect } from 'react'
import Link from 'next/link'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

const fmt = (n:number) => '$'+n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})
const now  = new Date()
const MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December']
const CUR_MONTH  = `${MONTH_NAMES[now.getMonth()]} ${now.getFullYear()}`
const FY = now.getMonth()>=6 ? `FY${now.getFullYear()}-${String(now.getFullYear()+1).slice(2)}` : `FY${now.getFullYear()-1}-${String(now.getFullYear()).slice(2)}`

/* ── Skeleton loader ─────────────────────────────────────────────────────── */
const Skel = ({w='100%',h=18,r=6}:{w?:string|number;h?:number;r?:number}) => (
  <div className="skel" style={{width:w,height:h,borderRadius:r}}/>
)

/* ── Types ─────────────────────────────────────────────────────────────────*/
interface Stats {
  activeContractors:    number
  pendingContractors:   number
  pendingTimesheets:    number
  submittedTimesheets:  number
  outstandingInvoices:  number
  outstandingCount:     number
  overdueInvoices:      number
  overdueCount:         number
  approvedThisMonth:    number
  totalPayroll:         number
  ytdBillings:          number
}

interface RecentActivity {
  icon: string
  text: string
  time: string
  href: string
  col?: string
}

interface ContractorRow {
  id:string; name:string; initials:string; col:string; bg:string
  client:string; status:string; ytdHours:number; rate:number; lastActivity:string
}

/* ── Fallback data (shown until API loads) ──────────────────────────────── */
const FALLBACK_STATS: Stats = {
  activeContractors:0, pendingContractors:0,
  pendingTimesheets:0, submittedTimesheets:0,
  outstandingInvoices:0, outstandingCount:0,
  overdueInvoices:0, overdueCount:0,
  approvedThisMonth:0, totalPayroll:0, ytdBillings:0,
}

const FALLBACK_CONTRACTORS: ContractorRow[] = [
  {id:'c1',name:'Alex Rivera',  initials:'AR',col:'#2563eb',bg:'#eff6ff',client:'Client A',status:'ACTIVE',       ytdHours:476,rate:120,lastActivity:'Timesheet Mar 2026'},
  {id:'c2',name:'Jordan Kim',   initials:'JK',col:'#7c3aed',bg:'#f5f3ff',client:'Client B',status:'ACTIVE',       ytdHours:312,rate:95, lastActivity:'Submitted Mar 2026'},
  {id:'c3',name:'Sam Okafor',   initials:'SO',col:'#059669',bg:'#ecfdf5',client:'Client C',status:'PENDING_SETUP',ytdHours:0,  rate:105,lastActivity:'Onboarding pending'},
]

const FALLBACK_ACTIVITY: RecentActivity[] = [
  {icon:'📄',text:'Timesheet submitted — Jordan Kim (March 2026)',    time:'2 min ago',  href:'/admin/timesheets'},
  {icon:'🧾',text:'Invoice INV-0047 created — Alex Rivera',          time:'1 hr ago',   href:'/admin/invoicing'},
  {icon:'✓', text:'Timesheet approved — Alex Rivera (February 2026)',time:'Yesterday',  href:'/admin/timesheets'},
  {icon:'🔗',text:'Xero sync completed',                             time:'2 days ago', href:'/admin/settings'},
  {icon:'🏛️',text:'STP accepted by ATO — February 2026',            time:'3 days ago', href:'/admin/payroll'},
]

const STATUS_STYLE: Record<string,{bg:string,c:string}> = {
  ACTIVE:        {bg:B.gP,   c:B.green},
  PENDING_SETUP: {bg:B.aLP,  c:B.amber},
  OFFBOARDED:    {bg:B.faint,c:B.dim  },
}

const QUICK_NAV = [
  {label:'Upload timesheet', href:'/admin/timesheets',  icon:'📤',col:B.accent,bg:B.aP, bd:B.aBd},
  {label:'Create invoice',   href:'/admin/invoicing',   icon:'🧾',col:B.amber, bg:B.aLP,bd:B.aLB},
  {label:'Run payroll',      href:'/admin/payroll',     icon:'💳',col:B.green, bg:B.gP, bd:B.gB },
  {label:'Add contractor',   href:'/admin/contractors/new',icon:'👤',col:B.accent,bg:B.aP,bd:B.aBd},
  {label:'Leave requests',   href:'/admin/leave',       icon:'🏖️',col:B.purple,bg:B.purP,bd:B.purB},
  {label:'Pay items',        href:'/admin/pay-items',   icon:'💰',col:B.dim,   bg:B.faint,bd:B.border},
]

/* ═══════════════════════════════════════════════════════════════════════════ */
export default function DashboardPage() {
  const [stats,       setStats]       = useState<Stats>(FALLBACK_STATS)
  const [contractors, setContractors] = useState<ContractorRow[]>(FALLBACK_CONTRACTORS)
  const [activity,    setActivity]    = useState<RecentActivity[]>(FALLBACK_ACTIVITY)
  const [loading,     setLoading]     = useState(true)

  useEffect(() => {
    let mounted = true

    // Fetch contractors
    fetch('/api/contractors')
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!mounted || !data?.contractors) return
        const cs = data.contractors as Record<string,unknown>[]
        const rows: ContractorRow[] = cs.slice(0, 6).map(c => ({
          id:           c.id as string,
          name:         `${c.first_name} ${c.last_name}`,
          initials:     `${(c.first_name as string)[0]}${(c.last_name as string)[0]}`,
          col:          '#2563eb', bg:'#eff6ff',
          client:       c.client_name as string ?? '—',
          status:       c.status as string,
          ytdHours:     0,
          rate:         Number(c.hourly_rate ?? 0),
          lastActivity: '—',
        }))
        if (rows.length > 0) setContractors(rows)

        setStats(s => ({
          ...s,
          activeContractors:  cs.filter(c => c.status === 'ACTIVE').length,
          pendingContractors: cs.filter(c => c.status === 'PENDING_SETUP').length,
        }))
      })
      .catch(() => null)

    // Fetch notifications for activity feed
    fetch('/api/notifications?userId=admin&unreadOnly=false')
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!mounted || !data?.notifications?.length) return
        const acts: RecentActivity[] = (data.notifications as Record<string,unknown>[]).slice(0, 6).map(n => ({
          icon:  n.type === 'TIMESHEET' ? '📄' : n.type === 'INVOICE' ? '🧾' : n.type === 'MESSAGE' ? '✉️' : '🔔',
          text:  n.title as string,
          time:  new Date(n.created_at as string).toLocaleDateString('en-AU', {day:'numeric',month:'short'}),
          href:  n.action_url as string ?? '/admin/notifications',
          col:   n.priority === 'HIGH' ? B.red : n.priority === 'URGENT' ? B.red : B.dim,
        }))
        setActivity(acts)
      })
      .catch(() => null)
      .finally(() => { if (mounted) setLoading(false) })

    return () => { mounted = false }
  }, [])

  const KPI = [
    {label:'Active contractors',  value:loading?null:String(stats.activeContractors),  sub:`${stats.pendingContractors} pending setup`,    col:B.accent,  icon:'👤', href:'/admin/contractors'},
    {label:'Pending timesheets',  value:loading?null:String(stats.submittedTimesheets),sub:`Awaiting your approval`,                        col:B.amber,   icon:'📄', href:'/admin/timesheets'},
    {label:'Outstanding invoices',value:loading?null:fmt(stats.outstandingInvoices),   sub:`${stats.outstandingCount} sent · ${stats.overdueCount} overdue`, col:stats.overdueCount>0?B.red:B.green, icon:'🧾', href:'/admin/invoicing'},
    {label:'Pay run',             value:loading?null:CUR_MONTH,                        sub:`${stats.approvedThisMonth} approved timesheets`,col:B.green,   icon:'💳', href:'/admin/payroll'},
  ]

  return (
    <>
      <TopBar title="Dashboard" subtitle={`${CUR_MONTH} · ${FY}`}/>
      <main style={{flex:1,padding:'28px 32px',background:B.bg}}>

        {/* KPI row */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:16,marginBottom:24}}>
          {KPI.map(k=>(
            <Link key={k.label} href={k.href} style={{textDecoration:'none'}}>
              <div className="card" style={{padding:'18px 20px',transition:'box-shadow .15s,transform .15s',cursor:'pointer'}}
                onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.transform='translateY(-2px)';(e.currentTarget as HTMLElement).style.boxShadow=B.sdwMd}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.transform='none';(e.currentTarget as HTMLElement).style.boxShadow=B.sdw}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:10}}>
                  <span style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:B.dim}}>{k.label}</span>
                  <span style={{fontSize:20}}>{k.icon}</span>
                </div>
                {k.value==null
                  ? <Skel h={28} r={4} w={100}/>
                  : <div style={{fontFamily:"'DM Mono',monospace",fontSize:22,fontWeight:700,color:k.col,marginBottom:4}}>{k.value}</div>
                }
                <div style={{fontSize:12.5,color:B.sub,marginTop:k.value==null?8:0}}>{loading?<Skel h={13} w={160}/>:k.sub}</div>
              </div>
            </Link>
          ))}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:20}}>
          <div style={{display:'flex',flexDirection:'column',gap:20}}>

            {/* Quick nav */}
            <div className="card" style={{padding:'18px 20px'}}>
              <div style={{fontSize:13,fontWeight:700,color:B.text,marginBottom:14}}>Quick actions</div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
                {QUICK_NAV.map(n=>(
                  <Link key={n.label} href={n.href} style={{textDecoration:'none'}}>
                    <div style={{
                      padding:'12px 14px',borderRadius:10,background:n.bg,
                      border:`1.5px solid ${n.bd}`,cursor:'pointer',transition:'all .12s',
                      display:'flex',alignItems:'center',gap:8,
                    }}
                      onMouseEnter={e=>(e.currentTarget as HTMLElement).style.transform='translateY(-1px)'}
                      onMouseLeave={e=>(e.currentTarget as HTMLElement).style.transform='none'}>
                      <span style={{fontSize:18}}>{n.icon}</span>
                      <span style={{fontSize:13,fontWeight:600,color:n.col}}>{n.label}</span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Contractors table */}
            <div className="card" style={{overflow:'hidden'}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'14px 18px',borderBottom:`1px solid ${B.border}`}}>
                <div style={{fontSize:13,fontWeight:700,color:B.text}}>Contractors</div>
                <Link href="/admin/contractors" style={{fontSize:12.5,color:B.accent,fontWeight:600,textDecoration:'none'}}>View all →</Link>
              </div>
              <table style={{width:'100%',borderCollapse:'collapse'}}>
                <thead>
                  <tr style={{background:B.bg,borderBottom:`1px solid ${B.border}`}}>
                    {['Contractor','Client','Rate','Status','Last activity',''].map(h=>(
                      <th key={h} style={{padding:'10px 16px',textAlign:'left',fontSize:10.5,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim}}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {contractors.map((c,i)=>{
                    const sp_ = STATUS_STYLE[c.status]||{bg:B.faint,c:B.dim}
                    return (
                      <tr key={c.id} style={{borderBottom:i<contractors.length-1?`1px solid ${B.faint}`:'none'}}
                        onMouseEnter={e=>(e.currentTarget as HTMLElement).style.background=B.faint}
                        onMouseLeave={e=>(e.currentTarget as HTMLElement).style.background='transparent'}>
                        <td style={{padding:'12px 16px'}}>
                          <div style={{display:'flex',alignItems:'center',gap:9}}>
                            <div style={{width:30,height:30,borderRadius:8,background:c.bg,color:c.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,flexShrink:0}}>{c.initials}</div>
                            <span style={{fontSize:13.5,fontWeight:600,color:B.text}}>{c.name}</span>
                          </div>
                        </td>
                        <td style={{padding:'12px 16px',fontSize:13,color:B.mid}}>{c.client}</td>
                        <td style={{padding:'12px 16px',fontFamily:"'DM Mono',monospace",fontSize:13,color:B.text}}>${c.rate}/hr</td>
                        <td style={{padding:'12px 16px'}}><span style={{fontSize:11.5,fontWeight:600,padding:'3px 8px',borderRadius:100,...sp_}}>{c.status.replace('_',' ')}</span></td>
                        <td style={{padding:'12px 16px',fontSize:12.5,color:B.dim}}>{c.lastActivity}</td>
                        <td style={{padding:'12px 16px'}}>
                          <Link href={`/admin/contractors/${c.id}`} style={{fontSize:12,color:B.accent,fontWeight:600,textDecoration:'none',padding:'4px 10px',background:B.aP,border:`1px solid ${B.aBd}`,borderRadius:6}}>View</Link>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

          </div>

          {/* Right: activity feed */}
          <div className="card" style={{overflow:'hidden',alignSelf:'start'}}>
            <div style={{padding:'14px 16px',borderBottom:`1px solid ${B.border}`}}>
              <div style={{fontSize:13,fontWeight:700,color:B.text}}>Recent activity</div>
            </div>
            <div>
              {activity.map((a,i)=>(
                <Link key={i} href={a.href} style={{textDecoration:'none'}}>
                  <div style={{padding:'12px 16px',borderBottom:i<activity.length-1?`1px solid ${B.faint}`:'none',display:'flex',gap:10,transition:'background .1s'}}
                    onMouseEnter={e=>(e.currentTarget as HTMLElement).style.background=B.faint}
                    onMouseLeave={e=>(e.currentTarget as HTMLElement).style.background='transparent'}>
                    <span style={{fontSize:16,flexShrink:0,marginTop:1}}>{a.icon}</span>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:13,color:B.text,lineHeight:1.4,marginBottom:3}}>{a.text}</div>
                      <div style={{fontSize:11.5,color:B.sub}}>{a.time}</div>
                    </div>
                  </div>
                </Link>
              ))}
              <Link href="/admin/notifications" style={{display:'block',padding:'12px 16px',textAlign:'center',fontSize:12.5,color:B.accent,fontWeight:600,textDecoration:'none',borderTop:`1px solid ${B.faint}`}}>
                View all activity →
              </Link>
            </div>
          </div>
        </div>
      </main>
    </>
  )
}
