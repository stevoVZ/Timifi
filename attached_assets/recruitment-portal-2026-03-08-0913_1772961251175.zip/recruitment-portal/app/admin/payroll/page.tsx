'use client'
// app/admin/payroll/page.tsx
import { useState, useEffect } from 'react'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

/* ── Types ───────────────────────────────────────────────────────────────── */
interface PayLine {
  id:         string
  name:       string
  initials:   string
  col:        string
  bg:         string
  client:     string
  hours:      number
  rate:       number
  gross:      number
  payg:       number
  super:      number
  net:        number
  status:     'APPROVED' | 'MISSING' | 'PENDING'
  timesheetId?: string
}

/* ── Helpers ────────────────────────────────────────────────────────────── */
const fmt = (n: number) =>
  '$' + n.toLocaleString('en-AU', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

// Simplified PAYG estimate (use ATO tax tables in production)
function estimatePayg(annualGross: number): number {
  if (annualGross <= 18200)  return 0
  if (annualGross <= 45000)  return (annualGross - 18200) * 0.19
  if (annualGross <= 120000) return 5092 + (annualGross - 45000) * 0.325
  if (annualGross <= 180000) return 29467 + (annualGross - 120000) * 0.37
  return 51667 + (annualGross - 180000) * 0.45
}

function buildLine(
  id: string, name: string, initials: string, col: string, bg: string,
  client: string, hours: number, rate: number, status: PayLine['status']
): PayLine {
  const gross      = hours * rate
  const annualised = gross * 12
  const paygAnnual = estimatePayg(annualised)
  const payg       = Math.round(paygAnnual / 12)
  const superAmt   = Math.round(gross * 0.115)
  return { id, name, initials, col, bg, client, hours, rate, gross, payg, super: superAmt, net: gross - payg, status, timesheetId: status === 'APPROVED' ? id : undefined }
}

/* ── Seed data ───────────────────────────────────────────────────────────── */
const INITIAL_LINES: PayLine[] = [
  buildLine('c1','Alex Rivera', 'AR','#2563eb','#eff6ff','Client A',172, 120,'APPROVED'),
  buildLine('c2','Jordan Kim',  'JK','#7c3aed','#f5f3ff','Client B',164, 95, 'APPROVED'),
  buildLine('c3','Sam Okafor',  'SO','#059669','#ecfdf5','Client C',0,   105,'MISSING'),
]

const MONTHS = ['January','February','March','April','May','June',
                'July','August','September','October','November','December']

type RunStatus = 'draft' | 'review' | 'filing' | 'filed'

/* ═══════════════════════════════════════════════════════════════════════════ */
export default function PayrollPage() {
  const now = new Date()
  const [month, setMonth]   = useState(now.getMonth())
  const [year,  setYear]    = useState(now.getFullYear())
  const [lines, setLines]   = useState<PayLine[]>(INITIAL_LINES)
  const [status, setStatus] = useState<RunStatus>('draft')
  const [filing,          setFiling]          = useState(false)
  const [toast,           setToast]           = useState<string | null>(null)
  const [xeroConnected,   setXeroConnected]   = useState(false)
  const [currentPayRunId, setCurrentPayRunId] = useState<string|null>(null)

  useEffect(() => {
    fetch('/api/settings').then(r=>r.ok?r.json():null).then(d => {
      if (d?.xero_connected) setXeroConnected(true)
    }).catch(()=>null)
  }, [])

  const toast_ = (msg: string) => { setToast(msg); setTimeout(() => setToast(null), 3200) }

  const included    = lines.filter(l => l.status === 'APPROVED')
  const totalGross  = included.reduce((s, l) => s + l.gross,  0)
  const totalPayg   = included.reduce((s, l) => s + l.payg,   0)
  const totalSuper  = included.reduce((s, l) => s + l.super,  0)
  const totalNet    = included.reduce((s, l) => s + l.net,    0)

  const handleFile = async () => {
    setFiling(true)
    try {
      // 1. Create pay run record in DB
      const now = new Date()
      const year = now.getFullYear()
      const month = now.getMonth() + 1
      const createRes = await fetch('/api/payroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          year, month,
          periodStart:  new Date(year, month-1, 1).toISOString().slice(0,10),
          periodEnd:    new Date(year, month, 0).toISOString().slice(0,10),
          paymentDate:  new Date(year, month, 7).toISOString().slice(0,10),
          superRate:    0.115,
        }),
      })
      const createData = await createRes.json().catch(()=>({}))

      // 2. File to Xero + STP if connected
      if (xeroConnected && createData?.payRun?.id) {
        const fileRes = await fetch('/api/xero/payroll', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ payRunId: createData.payRun.id }),
        })
        const fileData = await fileRes.json().catch(()=>({}))
        if (!fileRes.ok) throw new Error(fileData.error || 'Xero filing failed')
      }

      if (createData?.payRun?.id) setCurrentPayRunId(createData.payRun.id)
      setStatus('filed')
      toast_('✓ Pay run filed to Xero · STP submitted to ATO')
    } catch (err) {
      toast_(`⚠ ${err instanceof Error ? err.message : 'Filing failed'}`)
      setStatus('review')
    }
    setFiling(false)
  }

  return (
    <>
      <TopBar title="Pay Runs" subtitle="Review, calculate and file payroll"/>

      <main style={{ flex:1, padding:'28px 32px', background:B.bg }}>

        {/* Period selector */}
        <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:24 }}>
          <select
            value={month}
            onChange={e => setMonth(Number(e.target.value))}
            disabled={status !== 'draft'}
            style={{ padding:'9px 14px', borderRadius:8, border:`1.5px solid ${B.border}`, fontFamily:"'DM Sans',sans-serif", fontSize:14, color:B.text, background:B.surface, cursor:'pointer' }}
          >
            {MONTHS.map((m, i) => <option key={m} value={i}>{m}</option>)}
          </select>
          <select
            value={year}
            onChange={e => setYear(Number(e.target.value))}
            disabled={status !== 'draft'}
            style={{ padding:'9px 14px', borderRadius:8, border:`1.5px solid ${B.border}`, fontFamily:"'DM Sans',sans-serif", fontSize:14, color:B.text, background:B.surface, cursor:'pointer' }}
          >
            {[2025,2026,2027].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
          <div style={{ padding:'8px 14px', borderRadius:8, fontSize:13, fontWeight:600,
            background: status==='filed'?B.gP:status==='review'?B.aLP:B.faint,
            color:      status==='filed'?B.green:status==='review'?B.amber:B.dim,
            border:`1px solid ${status==='filed'?B.gB:status==='review'?B.aLB:B.border}`,
          }}>
            {status==='filed'?'✓ Filed':status==='review'?'Pending review':'Draft'}
          </div>
        </div>

        {/* Xero not connected banner */}
        {!xeroConnected && (
          <div style={{ padding:'12px 16px', background:B.aLP, border:`1px solid ${B.aLB}`, borderRadius:10, marginBottom:20, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <span style={{ fontSize:13.5, color:B.amber }}>⚠ Xero not connected — pay run will be calculated but not filed until connected.</span>
            <a href="/api/xero/auth" style={{ fontSize:13, fontWeight:600, color:B.accent, textDecoration:'none' }}>Connect Xero →</a>
          </div>
        )}

        <div style={{ display:'grid', gridTemplateColumns:'1fr 300px', gap:20, alignItems:'start' }}>

          {/* ── Left: contractor table ── */}
          <div>
            <div className="card" style={{ overflow:'hidden' }}>
              <div style={{ padding:'14px 18px', borderBottom:`1px solid ${B.faint}`, background:B.bg, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                <span style={{ fontSize:13, fontWeight:700, color:B.text }}>{MONTHS[month]} {year} — {included.length} contractors</span>
                <span style={{ fontSize:12.5, color:B.dim }}>{lines.filter(l=>l.status==='MISSING').length} missing timesheets</span>
              </div>

              <table style={{ width:'100%', borderCollapse:'collapse' }}>
                <thead>
                  <tr style={{ background:B.bg, borderBottom:`1px solid ${B.border}` }}>
                    {['Contractor','Hours','Rate','Gross','PAYG','Super','Net',''].map(h => (
                      <th key={h} style={{ padding:'10px 16px', textAlign:h===''?'center':'left', fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {lines.map((l, i) => (
                    <tr key={l.id} style={{ borderBottom: i < lines.length-1 ? `1px solid ${B.faint}` : 'none', opacity: l.status==='MISSING' ? 0.55 : 1 }}>
                      <td style={{ padding:'13px 16px' }}>
                        <div style={{ display:'flex', alignItems:'center', gap:9 }}>
                          <div style={{ width:30,height:30,borderRadius:8,background:l.bg,color:l.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,flexShrink:0 }}>{l.initials}</div>
                          <div>
                            <div style={{ fontSize:13.5, fontWeight:600, color:B.text }}>{l.name}</div>
                            <div style={{ fontSize:11.5, color:B.dim }}>{l.client}</div>
                          </div>
                        </div>
                      </td>
                      <td style={{ padding:'13px 16px', fontFamily:"'DM Mono',monospace", fontSize:13.5, color:l.status==='MISSING'?B.red:B.text }}>
                        {l.status==='MISSING' ? '—' : `${l.hours}h`}
                      </td>
                      <td style={{ padding:'13px 16px', fontFamily:"'DM Mono',monospace", fontSize:13, color:B.dim }}>${l.rate}/hr</td>
                      <td style={{ padding:'13px 16px', fontFamily:"'DM Mono',monospace", fontSize:13.5, color:B.text }}>{l.status==='MISSING'?'—':fmt(l.gross)}</td>
                      <td style={{ padding:'13px 16px', fontFamily:"'DM Mono',monospace", fontSize:13, color:B.amber }}>{l.status==='MISSING'?'—':fmt(l.payg)}</td>
                      <td style={{ padding:'13px 16px', fontFamily:"'DM Mono',monospace", fontSize:13, color:B.accent }}>{l.status==='MISSING'?'—':fmt(l.super)}</td>
                      <td style={{ padding:'13px 16px', fontFamily:"'DM Mono',monospace", fontSize:13.5, fontWeight:600, color:B.green }}>{l.status==='MISSING'?'—':fmt(l.net)}</td>
                      <td style={{ padding:'13px 16px', textAlign:'center' }}>
                        {l.status==='MISSING' && (
                          <a href="/admin/timesheets" style={{ fontSize:12, color:B.amber, fontWeight:600, textDecoration:'none', whiteSpace:'nowrap' }}>Upload →</a>
                        )}
                        {l.status==='APPROVED' && (
                          <span style={{ fontSize:11, padding:'2px 8px', borderRadius:4, background:B.gP, color:B.green, border:`1px solid ${B.gB}`, fontWeight:600 }}>✓ Ready</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Totals row */}
              <div style={{ padding:'14px 18px', borderTop:`2px solid ${B.border}`, display:'flex', gap:24, background:B.bg, flexWrap:'wrap' }}>
                {[['Total gross', fmt(totalGross), B.text],['PAYG', fmt(totalPayg), B.amber],['Super', fmt(totalSuper), B.accent],['Net payable', fmt(totalNet), B.green]].map(([k,v,c]) => (
                  <div key={k as string}>
                    <div style={{ fontSize:11, color:B.dim, marginBottom:2 }}>{k}</div>
                    <div style={{ fontFamily:"'DM Mono',monospace", fontSize:15, fontWeight:700, color:c as string }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Missing timesheets warning */}
            {lines.some(l => l.status==='MISSING') && (
              <div style={{ marginTop:12, padding:'12px 16px', background:B.aLP, border:`1px solid ${B.aLB}`, borderRadius:10, fontSize:13, color:B.amber }}>
                ⚠ {lines.filter(l=>l.status==='MISSING').length} contractor{lines.filter(l=>l.status==='MISSING').length>1?'s have':' has'} no approved timesheet for {MONTHS[month]}. They will be excluded from this pay run.
              </div>
            )}
          </div>

          {/* ── Right: file panel ── */}
          <div style={{ display:'flex', flexDirection:'column', gap:12, position:'sticky', top:24 }}>
            <div className="card" style={{ overflow:'hidden' }}>
              <div style={{ padding:'14px 16px', borderBottom:`1px solid ${B.faint}`, background:B.bg }}>
                <div style={{ fontSize:13, fontWeight:700, color:B.text }}>File pay run</div>
                <div style={{ fontSize:12, color:B.dim, marginTop:2 }}>{MONTHS[month]} {year}</div>
              </div>
              <div style={{ padding:'16px' }}>
                {/* Summary */}
                {[['Contractors', `${included.length} of ${lines.length}`], ['Total gross', fmt(totalGross)], ['Total PAYG', fmt(totalPayg)], ['Total super', fmt(totalSuper)], ['Total net', fmt(totalNet)]].map(([k,v]) => (
                  <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'7px 0', borderBottom:`1px solid ${B.faint}` }}>
                    <span style={{ fontSize:13, color:B.dim }}>{k}</span>
                    <span style={{ fontFamily:"'DM Mono',monospace", fontSize:13, fontWeight:600, color:B.text }}>{v}</span>
                  </div>
                ))}

                <div style={{ marginTop:16 }}>
                  {status !== 'filed' ? (
                    <button
                      onClick={handleFile}
                      disabled={filing || included.length === 0}
                      style={{ width:'100%', padding:'13px', background:B.accent, color:'#fff', border:'none', borderRadius:9, fontSize:14, fontWeight:600, fontFamily:"'DM Sans',sans-serif", cursor:filing?'not-allowed':'pointer', opacity:included.length===0?0.4:1, display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}
                    >
                      {filing ? (
                        <><span style={{ width:14,height:14,borderRadius:'50%',border:'2px solid rgba(255,255,255,.3)',borderTopColor:'#fff',animation:'spin .8s linear infinite',display:'inline-block' }}/>Filing…</>
                      ) : '📤 File to Xero + STP →'}
                    </button>
                  ) : (
                    <div style={{ padding:'14px', background:B.gP, border:`1px solid ${B.gB}`, borderRadius:9, textAlign:'center' }}>
                      <div style={{ fontSize:22, marginBottom:6 }}>✓</div>
                      <div style={{ fontSize:14, fontWeight:700, color:B.green }}>Pay run filed</div>
                      <div style={{ fontSize:12.5, color:B.dim, marginTop:4 }}>STP submitted to ATO</div>
                    </div>
                  )}
                </div>

                {/* ABA file download */}
                {status === 'filed' && (
                  <div style={{ marginTop:12 }}>
                    <button
                      onClick={async () => {
                        const res = await fetch('/api/payroll/aba', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ payRunId: currentPayRunId ?? 'DEMO' }),
                        })
                        if (!res.ok) { toast_('⚠ ABA generation failed'); return }
                        const blob = await res.blob()
                        const url  = URL.createObjectURL(blob)
                        const a    = document.createElement('a')
                        a.href     = url
                        a.download = `payroll-${new Date().toISOString().slice(0,7)}.aba`
                        a.click()
                        URL.revokeObjectURL(url)
                        toast_('⬇ ABA file downloaded')
                      }}
                      className="btn btn-ghost btn-sm"
                      style={{ width:'100%', justifyContent:'center' }}
                    >
                      ⬇ Download ABA file
                    </button>
                    <div style={{ fontSize:11.5, color:B.sub, marginTop:6, textAlign:'center' }}>
                      Upload to your bank for direct entry payroll payments
                    </div>
                  </div>
                )}

                {status !== 'filed' && (
                  <div style={{ marginTop:12, fontSize:12, color:B.dim, lineHeight:1.5, textAlign:'center' }}>
                    Filing will push to Xero Payroll, generate payslips, and lodge STP Phase 2 with the ATO.
                  </div>
                )}
              </div>
            </div>

            {/* Create invoices link */}
            <div style={{ padding:'14px 16px', background:B.surface, border:`1px solid ${B.border}`, borderRadius:12 }}>
              <div style={{ fontSize:13, fontWeight:600, color:B.text, marginBottom:4 }}>Create invoices</div>
              <div style={{ fontSize:12.5, color:B.dim, marginBottom:10 }}>Invoice client companies for approved timesheets separately to payroll.</div>
              <a href="/admin/invoicing" style={{ fontSize:13, fontWeight:600, color:B.accent, textDecoration:'none' }}>Go to invoicing →</a>
            </div>
          </div>
        </div>
      </main>

      {/* Toast */}
      {toast && (
        <div style={{ position:'fixed', bottom:24, right:24, zIndex:999, background:B.text, color:'#fff', padding:'12px 22px', borderRadius:10, fontWeight:600, fontSize:13, boxShadow:'0 4px 16px rgba(0,0,0,.18)' }}>
          {toast}
        </div>
      )}
    </>
  )
}
