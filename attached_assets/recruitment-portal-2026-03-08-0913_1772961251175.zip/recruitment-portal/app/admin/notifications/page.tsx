'use client'
// app/admin/notifications/page.tsx
import { useState, useEffect } from 'react'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

const PRIORITY_STYLE: Record<string,{bg:string,c:string,dot:string}> = {
  URGENT: {bg:B.rP,  c:B.red,   dot:B.red   },
  HIGH:   {bg:B.aLP, c:B.amber, dot:B.amber  },
  MEDIUM: {bg:B.aP,  c:B.accent,dot:B.accent },
  LOW:    {bg:B.faint,c:B.dim,  dot:B.sub    },
}

const TYPE_ICON: Record<string,string> = {
  TIMESHEET:'📄', INVOICE:'🧾', PAYRUN:'💳', STP:'🏛️',
  SUPER:'🏦', XERO:'🔗', CLEARANCE:'🔒', SYSTEM:'⚙️',
}

interface Notification {
  id:string; type:string; priority:string; title:string; body:string
  actionLabel?:string; actionRoute?:string; read:boolean; createdAt:string
  contractor?:string
}

const SEED: Notification[] = [
  {id:'n1',type:'TIMESHEET',priority:'HIGH',title:'Timesheet returned — Jordan Kim',body:'Missing signature on Week 3. Please resubmit.',actionLabel:'View timesheet',actionRoute:'/admin/timesheets',read:false,createdAt:'2 min ago',contractor:'Jordan Kim'},
  {id:'n2',type:'INVOICE',priority:'URGENT',title:'Invoice overdue — INV-0031',body:'Alex Rivera — January 2026 — $17,280 — 22 days overdue.',actionLabel:'View invoice',actionRoute:'/admin/invoicing',read:false,createdAt:'1 hr ago',contractor:'Alex Rivera'},
  {id:'n3',type:'PAYRUN',priority:'MEDIUM',title:'Pay run due — March 2026',body:'3 approved timesheets ready. File before 31 March to meet pay date.',actionLabel:'Open pay run',actionRoute:'/admin/payroll',read:false,createdAt:'3 hr ago'},
  {id:'n4',type:'CLEARANCE',priority:'HIGH',title:'Clearance expiring — Alex Rivera',body:'BASELINE clearance expires 31 Dec 2026. Renew 60 days in advance.',actionLabel:'View contractor',actionRoute:'/admin/contractors/c1',read:true,createdAt:'Yesterday',contractor:'Alex Rivera'},
  {id:'n5',type:'XERO',priority:'LOW',title:'Xero sync complete',body:'48 contacts synced successfully. 0 errors.',read:true,createdAt:'2 days ago'},
  {id:'n6',type:'STP',priority:'MEDIUM',title:'STP accepted — February 2026',body:'ATO accepted STP submission. Reference: STP-2026-0021.',read:true,createdAt:'3 days ago'},
  {id:'n7',type:'SUPER',priority:'HIGH',title:'Super contribution due',body:'$4,830 SGC due by 28 April 2026 for Q3. 3 contractors.',actionLabel:'Review payroll',actionRoute:'/admin/payroll',read:true,createdAt:'5 days ago'},
]

export default function NotificationsPage() {
  const [items,   setItems]   = useState<Notification[]>(SEED)
  const [filter,  setFilter]  = useState<'all'|'unread'|'urgent'>('all')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/notifications?userId=admin&unreadOnly=false')
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        if (d?.notifications?.length) {
          setItems(d.notifications.map((n: Record<string,unknown>) => ({
            id:          n.id,
            type:        n.type,
            priority:    n.priority,
            title:       n.title,
            body:        n.body,
            actionLabel: n.action_label,
            actionRoute: n.action_url,
            read:        n.is_read,
            createdAt:   new Date(n.created_at as string).toLocaleDateString('en-AU', {day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}),
            contractor:  (n as Record<string,unknown>).contractor_name as string | undefined,
          })))
        }
      })
      .catch(() => null)
      .finally(() => setLoading(false))
  }, [])

  const apiMarkRead = (id: string) => {
    fetch('/api/notifications', {
      method:'PATCH', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ notificationId: id, action:'markRead' }),
    }).catch(()=>null)
  }
  const apiMarkAllRead = () => {
    fetch('/api/notifications', {
      method:'PATCH', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ userId:'admin', action:'markAllRead' }),
    }).catch(()=>null)
  }

  const unreadCount = items.filter(n => !n.read).length

  const filtered = items.filter(n => {
    if (filter === 'unread') return !n.read
    if (filter === 'urgent') return n.priority === 'URGENT' || n.priority === 'HIGH'
    return true
  })

  const markRead   = (id: string) => { setItems(prev => prev.map(n => n.id===id ? {...n,read:true} : n)); apiMarkRead(id) }
  const markAllRead = ()          => { setItems(prev => prev.map(n => ({...n,read:true}))); apiMarkAllRead() }
  const dismiss    = (id: string) => setItems(prev => prev.filter(n => n.id!==id))

  return (
    <>
      <TopBar
        title="Notifications"
        subtitle={unreadCount > 0 ? `${unreadCount} unread` : 'All caught up'}
        actions={
          unreadCount > 0
            ? <button onClick={markAllRead} className="btn btn-ghost btn-sm">Mark all read</button>
            : undefined
        }
      />

      <main style={{flex:1, padding:'28px 32px', background:B.bg}}>
        <div style={{maxWidth:720}}>

          {/* Filter pills */}
          <div style={{display:'flex', gap:8, marginBottom:20}}>
            {([['all','All'], ['unread','Unread'], ['urgent','Urgent & High']] as const).map(([v,l]) => (
              <button key={v} onClick={()=>setFilter(v)} style={{
                padding:'7px 16px', borderRadius:100, border:'none', cursor:'pointer',
                fontFamily:"'DM Sans',sans-serif", fontSize:13, fontWeight:600,
                background:filter===v ? B.accent : B.surface,
                color:filter===v ? '#fff' : B.dim,
                border:`1.5px solid ${filter===v ? B.accent : B.border}`,
                transition:'all .13s',
              }}>{l}{v==='unread'&&unreadCount>0&&<span style={{marginLeft:6,background:'rgba(255,255,255,.25)',borderRadius:10,padding:'1px 6px',fontSize:11}}>{unreadCount}</span>}</button>
            ))}
          </div>

          {/* Notification list */}
          <div style={{display:'flex', flexDirection:'column', gap:8}}>
            {filtered.length === 0 && (
              <div style={{padding:'56px', textAlign:'center', background:B.surface, border:`1px solid ${B.border}`, borderRadius:12, color:B.dim}}>
                <div style={{fontSize:32, marginBottom:12}}>🔔</div>
                <div style={{fontSize:15, fontWeight:600, color:B.text, marginBottom:4}}>Nothing here</div>
                <div style={{fontSize:13.5}}>No {filter==='unread'?'unread':filter==='urgent'?'urgent':''} notifications.</div>
              </div>
            )}

            {filtered.map(n => {
              const ps = PRIORITY_STYLE[n.priority] || PRIORITY_STYLE.LOW
              return (
                <div key={n.id} className="card" style={{
                  padding:'16px 18px',
                  opacity: n.read ? 0.72 : 1,
                  borderLeft: `3px solid ${n.read ? B.border : ps.dot}`,
                  transition:'opacity .15s',
                }}>
                  <div style={{display:'flex', alignItems:'flex-start', gap:12}}>
                    {/* Icon */}
                    <div style={{
                      width:36, height:36, borderRadius:10, flexShrink:0,
                      background:ps.bg, display:'flex', alignItems:'center',
                      justifyContent:'center', fontSize:18,
                    }}>
                      {TYPE_ICON[n.type] || '📌'}
                    </div>

                    {/* Content */}
                    <div style={{flex:1, minWidth:0}}>
                      <div style={{display:'flex', alignItems:'center', gap:8, marginBottom:3, flexWrap:'wrap'}}>
                        <span style={{fontSize:14, fontWeight:n.read?500:700, color:B.text}}>{n.title}</span>
                        {!n.read && <span style={{width:7,height:7,borderRadius:'50%',background:ps.dot,flexShrink:0,display:'inline-block'}}/>}
                        <span style={{marginLeft:'auto', fontSize:12, color:B.sub, whiteSpace:'nowrap'}}>{n.createdAt}</span>
                      </div>

                      {n.contractor && (
                        <div style={{fontSize:12, color:B.accent, fontWeight:600, marginBottom:4}}>{n.contractor}</div>
                      )}

                      <div style={{fontSize:13, color:B.mid, lineHeight:1.5, marginBottom:n.actionLabel?10:0}}>{n.body}</div>

                      {n.actionLabel && (
                        <div style={{display:'flex', gap:8, alignItems:'center'}}>
                          <a href={n.actionRoute} style={{
                            fontSize:13, fontWeight:600, color:B.accent, textDecoration:'none',
                            padding:'5px 12px', borderRadius:7, background:B.aP,
                            border:`1px solid ${B.aBd}`,
                          }}>
                            {n.actionLabel} →
                          </a>
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div style={{display:'flex', flexDirection:'column', gap:4, flexShrink:0}}>
                      {!n.read && (
                        <button onClick={()=>markRead(n.id)} title="Mark read" style={{
                          padding:'5px 10px', borderRadius:6, border:`1px solid ${B.border}`,
                          background:B.surface, cursor:'pointer', fontSize:11, color:B.dim,
                          fontFamily:"'DM Sans',sans-serif",
                        }}>✓ Read</button>
                      )}
                      <button onClick={()=>dismiss(n.id)} title="Dismiss" style={{
                        padding:'5px 10px', borderRadius:6, border:`1px solid ${B.border}`,
                        background:B.surface, cursor:'pointer', fontSize:11, color:B.dim,
                        fontFamily:"'DM Sans',sans-serif",
                      }}>✕</button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </main>
    </>
  )
}
