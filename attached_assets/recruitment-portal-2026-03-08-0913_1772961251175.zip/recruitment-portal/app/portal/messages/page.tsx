'use client'
// app/portal/messages/page.tsx
import { useState, useEffect, useRef } from 'react'
import { B } from '@/lib/design'

interface Message {
  id:string; from:string; initials:string; subject:string
  body:string; date:string; read:boolean; fromAdmin:boolean
}

const SEED: Message[] = [
  {id:'m1',from:'Sarah Chen',initials:'SC',subject:'Your March timesheet has been received',body:'Hi Alex, just confirming we received your March 2026 timesheet. It\'s currently being reviewed and you\'ll hear back within 1 business day.',date:'Today, 9:14 AM',read:false,fromAdmin:true},
  {id:'m2',from:'Sarah Chen',initials:'SC',subject:'February payslip ready',body:'Hi Alex, your February payslip has been processed and is now available in your portal under Payslips. Your net pay of $14,016.00 will be in your account by end of business today.',date:'28 Feb 2026',read:true,fromAdmin:true},
  {id:'m3',from:'Sarah Chen',initials:'SC',subject:'Contract renewal — action required',body:'Hi Alex, your current contract is due to expire on 30 June 2026. Please review the attached renewal terms and let us know if you\'d like to proceed. We need your response by 15 June.',date:'14 Feb 2026',read:true,fromAdmin:true},
]

export default function PortalMessages() {
  const [messages,   setMessages]   = useState<Message[]>(SEED)
  const [selected,   setSelected]   = useState<Message|null>(SEED[0]??null)
  const [replyText,  setReplyText]  = useState('')
  const [sending,    setSending]    = useState(false)
  const [loading,    setLoading]    = useState(true)
  const [myProfileId,setMyProfileId]= useState<string|null>(null)
  const [agentId,    setAgentId]    = useState<string|null>(null)

  // Get current contractor profile
  useEffect(() => {
    fetch('/api/auth/me').then(r=>r.ok?r.json():null).then(d => {
      if (d?.profileId) setMyProfileId(d.profileId)
    }).catch(()=>null)
  }, [])

  // Fetch messages
  useEffect(() => {
    if (!myProfileId) return
    fetch(`/api/messages?profileId=${myProfileId}`)
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        if (!d?.messages?.length) return
        const mapped: Message[] = d.messages.map((m: Record<string,unknown>) => {
          const from = m.from_profile as Record<string,unknown> ?? {}
          const name = from.full_name as string ?? 'Agency'
          const initials = name.split(' ').map((w:string)=>w[0]).join('').slice(0,2).toUpperCase()
          return {
            id:       m.id,
            threadId: m.thread_id,
            from:     name,
            initials,
            subject:  m.subject as string ?? '(No subject)',
            body:     m.body as string ?? '',
            date:     new Date(m.created_at as string).toLocaleDateString('en-AU',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}),
            read:     m.is_read as boolean,
            fromAdmin:from.role !== 'contractor',
          }
        })
        setMessages(mapped)
        if (!selected && mapped[0]) setSelected(mapped[0])
        // Save an admin profile id for replies
        const adminMsg = d.messages.find((m: Record<string,unknown>) => {
          const fp = m.from_profile as Record<string,unknown>
          return fp?.role !== 'contractor'
        })
        if (adminMsg) {
          const fp = adminMsg.from_profile as Record<string,unknown>
          setAgentId(fp?.id as string)
        }
      })
      .catch(() => null)
      .finally(() => setLoading(false))
  }, [myProfileId])

  const select = (m: Message) => {
    setSelected(m)
    if (!m.read) {
      setMessages(prev => prev.map(msg => msg.id===m.id ? {...msg,read:true} : msg))
      fetch('/api/messages', {
        method:'PATCH', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ threadId: (m as unknown as {threadId:string}).threadId ?? m.id, action:'markRead', profileId: myProfileId }),
      }).catch(()=>null)
    }
  }

  const handleSend = async () => {
    if (!replyText.trim() || !myProfileId) return
    setSending(true)
    try {
      const toId = agentId ?? selected?.id
      if (!toId) throw new Error('No recipient')
      await fetch('/api/messages', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          fromProfileId: myProfileId,
          toProfileId:   toId,
          subject:       `Re: ${selected?.subject ?? ''}`,
          body:          replyText.trim(),
          threadId:      (selected as unknown as {threadId:string})?.threadId ?? undefined,
        }),
      })
      setReplyText('')
      // Optimistically add to list
      const myMsg: Message = {
        id: `local-${Date.now()}`, from:'You', initials:'ME',
        subject:`Re: ${selected?.subject ?? ''}`, body:replyText.trim(),
        date:'Just now', read:true, fromAdmin:false,
      }
      setMessages(prev=>[myMsg,...prev])
    } catch(e) {
      alert('Message failed to send. Please try again.')
    }
    setSending(false)
  }

  return (
    <main style={{ flex:1, display:'flex', background:B.bg, maxHeight:'calc(100vh - 58px)', overflow:'hidden' }}>

      {/* Inbox list */}
      <div style={{ width:300, borderRight:`1px solid ${B.border}`, background:B.surface, display:'flex', flexDirection:'column', flexShrink:0 }}>
        <div style={{ padding:'16px 18px', borderBottom:`1px solid ${B.faint}` }}>
          <h1 style={{ fontSize:15, fontWeight:700, color:B.text, margin:0 }}>Messages</h1>
        </div>
        <div style={{ flex:1, overflowY:'auto' }}>
          {messages.map(m => (
            <button key={m.id} onClick={() => select(m)} style={{
              width:'100%', padding:'14px 18px', border:'none', textAlign:'left',
              background: selected?.id===m.id ? B.aP : 'transparent',
              borderBottom:`1px solid ${B.faint}`,
              cursor:'pointer', fontFamily:"'DM Sans',sans-serif",
              borderLeft:`3px solid ${selected?.id===m.id ? B.accent : 'transparent'}`,
              transition:'all .12s',
            }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                <div style={{ width:28,height:28,borderRadius:8,background:B.aP,color:B.accent,display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,flexShrink:0 }}>{m.initials}</div>
                <span style={{ fontSize:13, fontWeight:600, color:B.text, flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{m.from}</span>
                {!m.read && <span style={{ width:7,height:7,borderRadius:'50%',background:B.accent,flexShrink:0 }}/>}
              </div>
              <div style={{ fontSize:13, fontWeight:m.read?400:600, color:B.text, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', marginBottom:3 }}>{m.subject}</div>
              <div style={{ fontSize:12, color:B.sub }}>{m.date}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Message detail */}
      {selected ? (
        <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
          {/* Header */}
          <div style={{ padding:'18px 24px', borderBottom:`1px solid ${B.border}`, background:B.surface }}>
            <h2 style={{ fontSize:16, fontWeight:700, color:B.text, marginBottom:4 }}>{selected.subject}</h2>
            <div style={{ fontSize:13, color:B.dim }}>From {selected.from} · {selected.date}</div>
          </div>

          {/* Body */}
          <div style={{ flex:1, padding:'24px 28px', overflowY:'auto' }}>
            <div style={{ maxWidth:600 }}>
              <div style={{ display:'flex', gap:12, marginBottom:20 }}>
                <div style={{ width:36,height:36,borderRadius:10,background:B.aP,color:B.accent,display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,fontWeight:700,flexShrink:0 }}>{selected.initials}</div>
                <div style={{ background:B.surface, border:`1px solid ${B.border}`, borderRadius:'0 12px 12px 12px', padding:'14px 18px', flex:1 }}>
                  <div style={{ fontSize:14, color:B.text, lineHeight:1.65 }}>{selected.body}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Reply */}
          <div style={{ padding:'16px 24px', borderTop:`1px solid ${B.border}`, background:B.surface }}>
            <div style={{ display:'flex', gap:10, alignItems:'flex-end', maxWidth:640 }}>
              <textarea
                value={replyText}
                onChange={e => setReplyText(e.target.value)}
                placeholder="Reply to your agency…"
                rows={3}
                style={{
                  flex:1, padding:'11px 14px', borderRadius:9, resize:'none',
                  border:`1.5px solid ${B.border}`, fontFamily:"'DM Sans',sans-serif",
                  fontSize:14, color:B.text, outline:'none', background:B.surface,
                  transition:'border .13s',
                }}
                onFocus={e => e.target.style.borderColor=B.accent}
                onBlur={e => e.target.style.borderColor=B.border}
              />
              <button onClick={handleSend} disabled={sending || !replyText.trim()} style={{
                padding:'11px 20px', background:B.accent, color:'#fff', border:'none',
                borderRadius:9, fontSize:14, fontWeight:600,
                fontFamily:"'DM Sans',sans-serif", cursor:'pointer',
                opacity:!replyText.trim()?0.4:1, transition:'all .13s', flexShrink:0,
              }}>
                {sending ? '…' : 'Send →'}
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', color:B.dim }}>
          <div style={{ textAlign:'center' }}>
            <div style={{ fontSize:36, marginBottom:12 }}>✉️</div>
            <div style={{ fontSize:15, fontWeight:600, color:B.text, marginBottom:4 }}>Select a message</div>
          </div>
        </div>
      )}
    </main>
  )
}
