'use client'
// app/portal/onboarding/page.tsx
// Contractor self-service onboarding wizard — 7 steps
// Saves to: tax_declarations, bank_accounts, super_memberships tables

import { useState, useEffect } from 'react'
import { B } from '@/lib/design'

/* ── Step config ─────────────────────────────────────────────────────────── */
const STEPS = [
  { id: 'welcome',  label: 'Welcome',  icon: '👋' },
  { id: 'personal', label: 'Personal', icon: '👤' },
  { id: 'address',  label: 'Address',  icon: '🏠' },
  { id: 'tax',      label: 'Tax',      icon: '📋' },
  { id: 'bank',     label: 'Bank',     icon: '🏦' },
  { id: 'super',    label: 'Super',    icon: '🛡️' },
  { id: 'done',     label: 'Done',     icon: '✓'  },
]

/* ── Form state shape ────────────────────────────────────────────────────── */
interface OnboardForm {
  // Personal
  dateOfBirth: string
  gender:      string
  // Address
  addressLine1: string
  suburb:       string
  state:        string
  postcode:     string
  // TFN Declaration
  tfn:               string
  residencyStatus:   string
  claimTaxFreeThreshold: boolean
  helpDebt:          boolean
  studentLoan:       boolean
  seniorsOffset:     boolean
  // Bank
  bsb:         string
  accountNumber: string
  accountName: string
  bankName:    string
  // Super
  superFundName:   string
  superFundABN:    string
  memberNumber:    string
  usiNumber:       string
  useStapledfund:  boolean
}

const INIT: OnboardForm = {
  dateOfBirth: '', gender: '',
  addressLine1: '', suburb: '', state: 'NSW', postcode: '',
  tfn: '', residencyStatus: 'RESIDENT', claimTaxFreeThreshold: true,
  helpDebt: false, studentLoan: false, seniorsOffset: false,
  bsb: '', accountNumber: '', accountName: '', bankName: '',
  superFundName: '', superFundABN: '', memberNumber: '', usiNumber: '', useStapledfund: false,
}

/* ── Sub-components ───────────────────────────────────────────────────────── */
const Field = ({
  label, value, onChange, type='text', hint, required, placeholder, masked,
}: {
  label:string; value:string; onChange:(v:string)=>void; type?:string
  hint?:string; required?:boolean; placeholder?:string; masked?:boolean
}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>
      {label}{required && <span style={{color:B.red,marginLeft:3}}>*</span>}
    </label>
    <input
      type={masked ? 'password' : type} value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      autoComplete={masked ? 'off' : undefined}
      style={{width:'100%',padding:'10px 13px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:`'DM ${masked?'Mono':'Sans'}',sans-serif`,fontSize:14,color:B.text,outline:'none',background:B.surface,boxSizing:'border-box',transition:'border .13s'}}
      onFocus={e=>e.target.style.borderColor=B.accent}
      onBlur={e=>e.target.style.borderColor=B.border}
    />
    {hint && <div style={{fontSize:12,color:B.sub,marginTop:5}}>{hint}</div>}
  </div>
)

const Sel = ({label,value,onChange,options,hint}:{label:string;value:string;onChange:(v:string)=>void;options:{v:string;l:string}[];hint?:string}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>{label}</label>
    <select value={value} onChange={e=>onChange(e.target.value)}
      style={{width:'100%',padding:'10px 13px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,background:B.surface,boxSizing:'border-box',outline:'none'}}>
      {options.map(o=><option key={o.v} value={o.v}>{o.l}</option>)}
    </select>
    {hint && <div style={{fontSize:12,color:B.sub,marginTop:5}}>{hint}</div>}
  </div>
)

const Toggle = ({label,checked,onChange,hint}:{label:string;checked:boolean;onChange:(v:boolean)=>void;hint?:string}) => (
  <label style={{display:'flex',alignItems:'flex-start',gap:12,cursor:'pointer',userSelect:'none'}}>
    <div onClick={()=>onChange(!checked)} style={{
      width:42,height:24,borderRadius:12,flexShrink:0,marginTop:2,
      background:checked?B.accent:B.border,position:'relative',transition:'background .18s',cursor:'pointer',
    }}>
      <span style={{position:'absolute',top:3,left:checked?21:3,width:18,height:18,borderRadius:'50%',background:'#fff',boxShadow:'0 1px 4px rgba(0,0,0,.2)',transition:'left .18s'}}/>
    </div>
    <div>
      <div style={{fontSize:14,color:B.text,fontWeight:checked?600:400}}>{label}</div>
      {hint && <div style={{fontSize:12,color:B.sub,marginTop:2}}>{hint}</div>}
    </div>
  </label>
)

const InfoBox = ({icon,title,body,color=B.accent,bg=B.aP}:{icon:string;title:string;body:string;color?:string;bg?:string}) => (
  <div style={{padding:'12px 14px',background:bg,borderRadius:10,display:'flex',gap:10}}>
    <span style={{fontSize:18,flexShrink:0}}>{icon}</span>
    <div>
      <div style={{fontSize:13,fontWeight:700,color,marginBottom:3}}>{title}</div>
      <div style={{fontSize:12.5,color:B.mid,lineHeight:1.5}}>{body}</div>
    </div>
  </div>
)

/* ── Validation per step ─────────────────────────────────────────────────── */
function validate(step: number, f: OnboardForm): string[] {
  if (step === 1) {
    const errs: string[] = []
    if (!f.dateOfBirth) errs.push('Date of birth is required')
    return errs
  }
  if (step === 2) {
    const errs: string[] = []
    if (!f.suburb.trim())   errs.push('Suburb is required')
    if (!f.postcode.trim()) errs.push('Postcode is required')
    return errs
  }
  if (step === 3) {
    const errs: string[] = []
    const tfnClean = f.tfn.replace(/\s/g, '')
    if (!tfnClean) errs.push('TFN is required')
    else if (!/^\d{8,9}$/.test(tfnClean)) errs.push('TFN must be 8 or 9 digits')
    return errs
  }
  if (step === 4) {
    const errs: string[] = []
    const bsb = f.bsb.replace(/[^0-9]/g,'')
    if (!bsb)            errs.push('BSB is required')
    else if (bsb.length !== 6) errs.push('BSB must be 6 digits (e.g. 062-000)')
    if (!f.accountNumber.replace(/\s/g,'')) errs.push('Account number is required')
    if (!f.accountName.trim()) errs.push('Account name is required')
    return errs
  }
  if (step === 5) {
    if (f.useStapledfund) return []
    const errs: string[] = []
    if (!f.superFundName.trim()) errs.push('Super fund name is required')
    if (!f.memberNumber.trim())  errs.push('Member number is required')
    return errs
  }
  return []
}

/* ── Format BSB as user types ────────────────────────────────────────────── */
function fmtBSB(raw: string) {
  const d = raw.replace(/[^0-9]/g,'').slice(0,6)
  if (d.length > 3) return d.slice(0,3)+'-'+d.slice(3)
  return d
}

/* ── Main component ──────────────────────────────────────────────────────── */
export default function OnboardingPage() {
  const [step,     setStep]     = useState(0)
  const [form,     setForm]     = useState<OnboardForm>(INIT)
  const [errors,   setErrors]   = useState<string[]>([])
  const [saving,   setSaving]   = useState(false)
  const [progress, setProgress] = useState(0)

  // Animated progress bar
  useEffect(() => {
    const pct = Math.round((step / (STEPS.length - 1)) * 100)
    setTimeout(() => setProgress(pct), 50)
  }, [step])

  const set = <K extends keyof OnboardForm>(k: K) => (v: OnboardForm[K]) =>
    setForm(f => ({...f, [k]: v}))

  const next = () => {
    const errs = validate(step, form)
    if (errs.length) { setErrors(errs); return }
    setErrors([])
    setStep(s => s + 1)
  }

  const back = () => { setErrors([]); setStep(s => s - 1) }

  const submit = async () => {
    setSaving(true)
    try {
      // 1. Save tax declaration
      await fetch('/api/onboarding/tax', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          tfn:                   form.tfn.replace(/\s/g,''),
          residencyStatus:       form.residencyStatus,
          claimTaxFreeThreshold: form.claimTaxFreeThreshold,
          helpDebt:              form.helpDebt,
          studentLoan:           form.studentLoan,
          seniorsOffset:         form.seniorsOffset,
        }),
      }).catch(() => null)

      // 2. Save bank account
      await fetch('/api/onboarding/bank', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          bsb:           form.bsb.replace(/[^0-9]/g,''),
          accountNumber: form.accountNumber,
          accountName:   form.accountName,
          bankName:      form.bankName,
        }),
      }).catch(() => null)

      // 3. Save super membership
      if (!form.useStapledfund) {
        await fetch('/api/onboarding/super', {
          method: 'POST', headers: {'Content-Type':'application/json'},
          body: JSON.stringify({
            fundName:    form.superFundName,
            fundABN:     form.superFundABN,
            memberNumber: form.memberNumber,
            usi:         form.usiNumber,
          }),
        }).catch(() => null)
      }

      // 4. Update contractor personal info
      await fetch('/api/onboarding/personal', {
        method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          dateOfBirth:  form.dateOfBirth,
          gender:       form.gender,
          addressLine1: form.addressLine1,
          suburb:       form.suburb,
          state:        form.state,
          postcode:     form.postcode,
        }),
      }).catch(() => null)

      setStep(6)
    } catch {
      setErrors(['An error occurred — please try again.'])
    }
    setSaving(false)
  }

  /* ── Render ─────────────────────────────────────────────────────────────── */
  return (
    <div style={{minHeight:'100vh',background:B.bg,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'flex-start',padding:'40px 16px 80px'}}>
      <div style={{width:'100%',maxWidth:560}}>

        {/* Header */}
        <div style={{textAlign:'center',marginBottom:28}}>
          <div style={{fontSize:28,marginBottom:8}}>🚀</div>
          <h1 style={{fontSize:22,fontWeight:700,color:B.text,marginBottom:6}}>Get started</h1>
          <p style={{fontSize:14,color:B.dim}}>Complete your profile to activate your contractor account</p>
        </div>

        {/* Progress bar */}
        {step < 6 && (
          <div style={{marginBottom:24}}>
            <div style={{display:'flex',justifyContent:'space-between',marginBottom:8}}>
              {STEPS.slice(1,6).map((s,i) => {
                const stepIdx = i + 1
                return (
                  <div key={s.id} style={{textAlign:'center',flex:1}}>
                    <div style={{
                      width:32,height:32,borderRadius:'50%',margin:'0 auto 4px',
                      display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,
                      background: step > stepIdx ? B.green : step === stepIdx ? B.accent : B.border,
                      color: step >= stepIdx ? '#fff' : B.sub,
                      transition:'all .2s',
                    }}>
                      {step > stepIdx ? '✓' : s.icon}
                    </div>
                    <div style={{fontSize:10.5,fontWeight:600,color:step===stepIdx?B.accent:B.sub,textTransform:'uppercase',letterSpacing:'.05em'}}>{s.label}</div>
                  </div>
                )
              })}
            </div>
            <div style={{height:5,borderRadius:3,background:B.border,overflow:'hidden'}}>
              <div style={{height:'100%',width:`${progress}%`,background:`linear-gradient(90deg,${B.accent},${B.green})`,borderRadius:3,transition:'width .4s cubic-bezier(.4,0,.2,1)'}}/>
            </div>
          </div>
        )}

        {/* Error banner */}
        {errors.length > 0 && (
          <div style={{padding:'12px 14px',background:B.rP,border:`1px solid ${B.rB}`,borderRadius:10,marginBottom:14}}>
            {errors.map(e => <div key={e} style={{fontSize:13,color:B.red,lineHeight:1.5}}>• {e}</div>)}
          </div>
        )}

        {/* Card */}
        <div className="card" style={{padding:'28px 28px 24px'}}>

          {/* Step 0: Welcome */}
          {step === 0 && (
            <div style={{display:'flex',flexDirection:'column',gap:18}}>
              <div style={{textAlign:'center',padding:'8px 0 16px'}}>
                <div style={{fontSize:48,marginBottom:12}}>👋</div>
                <h2 style={{fontSize:18,fontWeight:700,color:B.text,marginBottom:8}}>Welcome to the contractor portal</h2>
                <p style={{fontSize:14,color:B.dim,lineHeight:1.6,maxWidth:420,margin:'0 auto'}}>
                  This short wizard will collect your tax file number, bank details and super fund so we can process your pay correctly and on time.
                </p>
              </div>
              <div style={{display:'flex',flexDirection:'column',gap:10}}>
                {[
                  ['📋','Tax declaration','Your TFN and residency status for ATO compliance'],
                  ['🏦','Bank account','Where your pay gets deposited'],
                  ['🛡️','Superannuation','Your super fund details for SGC contributions'],
                ].map(([icon,title,body])=>(
                  <div key={title} style={{display:'flex',gap:12,padding:'12px 14px',background:B.bg,borderRadius:10,border:`1px solid ${B.border}`}}>
                    <span style={{fontSize:22,flexShrink:0}}>{icon}</span>
                    <div>
                      <div style={{fontSize:13.5,fontWeight:600,color:B.text,marginBottom:2}}>{title}</div>
                      <div style={{fontSize:12.5,color:B.dim}}>{body}</div>
                    </div>
                  </div>
                ))}
              </div>
              <InfoBox icon="🔒" title="Your information is secure"
                body="All data is encrypted in transit and at rest. Your TFN is masked after submission and only used for ATO lodgement."
                color={B.green} bg={B.gP}
              />
            </div>
          )}

          {/* Step 1: Personal */}
          {step === 1 && (
            <div style={{display:'flex',flexDirection:'column',gap:16}}>
              <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:2}}>Personal details</h2>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                <Field label="Date of birth" value={form.dateOfBirth} onChange={set('dateOfBirth')} type="date" required
                  hint="Required for Xero Payroll and ATO reporting"/>
                <Sel label="Gender" value={form.gender} onChange={set('gender')}
                  options={[{v:'',l:'Prefer not to say'},{v:'M',l:'Male'},{v:'F',l:'Female'},{v:'X',l:'Non-binary / other'}]}
                  hint="Used for ATO STP2 reporting"/>
              </div>
              <InfoBox icon="ℹ️" title="Why we need this"
                body="Your date of birth is required for ATO Single Touch Payroll Phase 2 (STP2) lodgement and to apply the correct PAYG tax rates."
                color={B.accent} bg={B.aP}
              />
            </div>
          )}

          {/* Step 2: Address */}
          {step === 2 && (
            <div style={{display:'flex',flexDirection:'column',gap:16}}>
              <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:2}}>Residential address</h2>
              <Field label="Street address" value={form.addressLine1} onChange={set('addressLine1')} placeholder="e.g. 42 George Street"/>
              <div style={{display:'grid',gridTemplateColumns:'1fr auto auto',gap:12}}>
                <Field label="Suburb" value={form.suburb} onChange={set('suburb')} required placeholder="e.g. Sydney"/>
                <Sel label="State" value={form.state} onChange={set('state')}
                  options={['NSW','VIC','QLD','SA','WA','TAS','ACT','NT'].map(s=>({v:s,l:s}))}/>
                <Field label="Postcode" value={form.postcode} onChange={set('postcode')} required placeholder="2000"/>
              </div>
              <InfoBox icon="ℹ️" title="Residential address"
                body="Your address is used for payslip records and to determine the correct Medicare levy surcharge zone. A PO Box is not acceptable."
                color={B.accent} bg={B.aP}
              />
            </div>
          )}

          {/* Step 3: Tax (TFN Declaration) */}
          {step === 3 && (
            <div style={{display:'flex',flexDirection:'column',gap:16}}>
              <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:2}}>Tax file number declaration</h2>

              <div style={{padding:'14px 16px',background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:10,fontSize:13,color:B.amber}}>
                ⚠ Your TFN is sensitive. It will be masked immediately after submission and is only accessed for ATO STP2 lodgement.
              </div>

              <Field label="Tax file number (TFN)" value={form.tfn} onChange={v=>set('tfn')(v.replace(/\s/g,'').replace(/(.{3})(.{3})/,'$1 $2 '))} required
                masked placeholder="000 000 000"
                hint="8 or 9 digit number — found on your myGov account or previous payment summaries"/>

              <Sel label="Residency status" value={form.residencyStatus} onChange={set('residencyStatus')}
                options={[
                  {v:'RESIDENT',          l:'Australian resident'},
                  {v:'FOREIGN_RESIDENT',  l:'Foreign resident'},
                  {v:'WORKING_HOLIDAY',   l:'Working holiday maker'},
                ]}
              />

              <div style={{display:'flex',flexDirection:'column',gap:10}}>
                <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:2}}>Tax offset claims</div>
                <Toggle label="Claim tax-free threshold" checked={form.claimTaxFreeThreshold} onChange={set('claimTaxFreeThreshold')}
                  hint="Claim if this is your main job and your annual income is ≤ $18,200. Reduces tax withheld."/>
                <Toggle label="HELP / HECS debt" checked={form.helpDebt} onChange={set('helpDebt')}
                  hint="Check if you have a student HELP debt. We'll withhold extra tax to cover repayments."/>
                <Toggle label="Student loan (SSL/ABSTUDY)" checked={form.studentLoan} onChange={set('studentLoan')}
                  hint="Check if you have a Student Start-up Loan or similar government debt."/>
                <Toggle label="Seniors and pensioners tax offset" checked={form.seniorsOffset} onChange={set('seniorsOffset')}
                  hint="You may qualify if you're a senior Australian and your income is below the threshold."/>
              </div>

              <div style={{fontSize:12,color:B.sub,lineHeight:1.5,padding:'10px 14px',background:B.faint,borderRadius:9}}>
                By submitting this declaration you confirm the information is true and correct. Penalties may apply for deliberate false declarations.
              </div>
            </div>
          )}

          {/* Step 4: Bank */}
          {step === 4 && (
            <div style={{display:'flex',flexDirection:'column',gap:16}}>
              <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:2}}>Bank account</h2>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                <Field label="BSB" value={form.bsb} onChange={v=>set('bsb')(fmtBSB(v))} required
                  placeholder="062-000" hint="6 digits — find on your internet banking or bank app"/>
                <Field label="Account number" value={form.accountNumber} onChange={set('accountNumber')} required
                  placeholder="12345678" hint="Up to 9 digits"/>
              </div>
              <Field label="Account name" value={form.accountName} onChange={set('accountName')} required
                placeholder="e.g. Alex Rivera" hint="Must match the name on the bank account — used for ABA file matching"/>
              <Field label="Bank / financial institution" value={form.bankName} onChange={set('bankName')}
                placeholder="e.g. Commonwealth Bank" hint="Optional — for your records"/>
              <InfoBox icon="✅" title="Payments are processed via ABA direct entry"
                body="Your pay will be deposited within 1 business day of the pay date via the BECS payment system. We do not support international bank accounts."
                color={B.green} bg={B.gP}
              />
            </div>
          )}

          {/* Step 5: Super */}
          {step === 5 && (
            <div style={{display:'flex',flexDirection:'column',gap:16}}>
              <h2 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:2}}>Superannuation</h2>

              <Toggle label="Use my stapled super fund (ATO nominated fund)"
                checked={form.useStapledfund} onChange={set('useStapledfund')}
                hint="If you don't nominate a fund, we're required by law to use the ATO's Superannuation Stapling service to find your existing fund."/>

              {!form.useStapledfund && (
                <>
                  <Field label="Super fund name" value={form.superFundName} onChange={set('superFundName')} required
                    placeholder="e.g. Australian Super" hint="Full name of your chosen APRA-regulated fund"/>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                    <Field label="Fund ABN" value={form.superFundABN} onChange={set('superFundABN')}
                      placeholder="65 714 394 898" hint="11-digit ABN for the fund"/>
                    <Field label="USI (Unique Superannuation Identifier)" value={form.usiNumber} onChange={set('usiNumber')}
                      placeholder="STA0100AU" hint="Used by your employer to send contributions"/>
                  </div>
                  <Field label="Member number" value={form.memberNumber} onChange={set('memberNumber')} required
                    placeholder="e.g. 1234567890" hint="Found on your super fund's app or welcome letter"/>
                </>
              )}

              <InfoBox icon="🛡️" title={`Employer super rate: 11.5%`}
                body="Your employer will contribute 11.5% of your ordinary time earnings to your nominated super fund, as required by the Superannuation Guarantee."
                color={B.purple} bg={B.purP}
              />

              <div style={{padding:'12px 14px',background:B.faint,borderRadius:10,fontSize:12.5,color:B.dim,lineHeight:1.6}}>
                You can update your super fund details at any time from the portal. Changes take effect from the next pay cycle.
              </div>
            </div>
          )}

          {/* Step 6: Done */}
          {step === 6 && (
            <div style={{display:'flex',flexDirection:'column',gap:18,textAlign:'center',padding:'16px 0'}}>
              <div style={{fontSize:56,lineHeight:1}}>🎉</div>
              <div>
                <h2 style={{fontSize:20,fontWeight:700,color:B.text,marginBottom:8}}>You're all set!</h2>
                <p style={{fontSize:14,color:B.dim,lineHeight:1.7,maxWidth:400,margin:'0 auto'}}>
                  Your onboarding is complete. Your agency will review your details and activate your account. You'll receive an email when you're cleared to start.
                </p>
              </div>
              <div style={{display:'flex',flexDirection:'column',gap:10}}>
                {[
                  [B.gP, B.gB, B.green, '✓', 'TFN declaration submitted'],
                  [B.gP, B.gB, B.green, '✓', 'Bank account saved'],
                  [B.gP, B.gB, B.green, '✓', 'Super fund nominated'],
                  [B.aLP, B.aLB, B.amber, '⏳', 'Account activation pending'],
                ].map(([bg,bd,c,icon,label])=>(
                  <div key={label as string} style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',background:bg as string,border:`1px solid ${bd}`,borderRadius:10,textAlign:'left'}}>
                    <span style={{fontSize:16,color:c as string,fontWeight:700}}>{icon}</span>
                    <span style={{fontSize:13.5,color:c as string,fontWeight:600}}>{label as string}</span>
                  </div>
                ))}
              </div>
              <a href="/portal/dashboard" style={{display:'block',padding:'13px',background:B.accent,color:'#fff',borderRadius:10,textDecoration:'none',fontWeight:700,fontSize:14,marginTop:4}}>
                Go to dashboard →
              </a>
            </div>
          )}

          {/* Navigation */}
          {step < 6 && (
            <div style={{display:'flex',justifyContent:'space-between',marginTop:24,paddingTop:16,borderTop:`1px solid ${B.faint}`}}>
              <button onClick={back} disabled={step===0}
                className="btn btn-ghost"
                style={{opacity:step===0?0:'1',visibility:step===0?'hidden':'visible'}}>
                ← Back
              </button>
              {step < 5
                ? <button onClick={next} className="btn btn-accent">Continue →</button>
                : <button onClick={submit} disabled={saving} className="btn btn-accent" style={{opacity:saving?.7:1}}>
                    {saving ? 'Submitting…' : '✓ Submit & complete'}
                  </button>
              }
            </div>
          )}
        </div>

        {/* Legal footer */}
        {step > 0 && step < 6 && (
          <div style={{textAlign:'center',marginTop:16,fontSize:12,color:B.sub,lineHeight:1.6}}>
            Your information is collected and held in accordance with the Privacy Act 1988.<br/>
            Contact your agency if you have questions about how your data is used.
          </div>
        )}
      </div>
    </div>
  )
}
