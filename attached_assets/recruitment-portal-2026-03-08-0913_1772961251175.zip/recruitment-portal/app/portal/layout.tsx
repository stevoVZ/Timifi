// app/portal/layout.tsx
import type { ReactNode } from 'react'
import { createServerClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import PortalShell from '@/components/portal/PortalShell'

export default async function PortalLayout({ children }: { children: ReactNode }) {
  const supabase = createServerClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/portal/login')

  // Verify this user is a contractor (not admin trying to access portal)
  const { data: profile } = await supabase
    .from('profiles')
    .select('role, full_name')
    .eq('id', user.id)
    .single()

  if (!profile || profile.role !== 'contractor') redirect('/admin/dashboard')

  // Check onboarding completion — redirect PENDING_SETUP to wizard
  const { data: contractor } = await supabase
    .from('contractors')
    .select('id, status, onboarding_complete, onboarding_step')
    .eq('profile_id', user.id)
    .single()

  // If contractor hasn't completed onboarding, send them to the wizard.
  // We check the request path via headers to avoid redirect loops on the onboarding page itself.
  if (contractor && !contractor.onboarding_complete) {
    // Note: Next.js layout doesn't receive the current pathname directly.
    // We redirect — the onboarding page is public (middleware allows it),
    // so it renders outside this layout and won't loop.
    redirect('/portal/onboarding')
  }

  return <PortalShell fullName={profile.full_name}>{children}</PortalShell>
}
