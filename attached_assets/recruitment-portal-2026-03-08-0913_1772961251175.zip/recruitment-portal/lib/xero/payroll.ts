// lib/xero/payroll.ts
// Xero Payroll API helpers for Australian payroll
// Docs: https://developer.xero.com/documentation/payroll-api/overview

import { getValidAccessToken, xeroFetch } from './client'
import { createServiceClient } from '@/lib/supabase/server'

/* ── Types ───────────────────────────────────────────────────────────────── */

export interface XeroEmployee {
  FirstName:   string
  LastName:    string
  DateOfBirth: string          // YYYY-MM-DD
  Email?:      string
  Gender?:     'M' | 'F' | 'N'
  Status:      'ACTIVE' | 'TERMINATED'
  StartDate:   string          // /Date(timestamp+0000)/
  HomeAddress: {
    AddressLine1?: string
    City?:         string
    Region?:       string     // State
    PostalCode?:   string
    Country?:      string
  }
  TaxDeclaration?: {
    EmployeeNumber?:          string
    TFN?:                     string
    TaxScaleType?:            string  // 'REGULAR' | 'ACTORARTIST' etc.
    TFNExemptionType?:        string  // 'PENSIONER' | 'UNDER18' etc.
    ResidencyStatus?:         string  // 'AUSTRALIANRESIDENT' | 'FOREIGNRESIDENT'
    TaxFreeThreshold?:        boolean
    HasHELPDebt?:             boolean
    HasSTSLDebt?:             boolean
    HasStudentLoan?:          boolean
    HasSFSSDebt?:             boolean
    HasSeniorsOffsetCode?:    boolean
    EligibleToReceiveLeave?:  boolean
    UpwardVariationTaxWithholdingAmount?: number
    NumberOfSupportPersons?:  number
  }
  BankAccounts?: {
    AccountName:   string
    BSB:           string
    AccountNumber: string
    Remainder:     boolean
    Amount?:       number
  }[]
}

export interface XeroPayRun {
  PayrollCalendarID: string
  PayRunPeriodStartDate: string   // /Date(.../
  PayRunPeriodEndDate:   string
  PaymentDate:           string
  PayLines?: {
    EmployeeID:  string
    EarningsLines: {
      EarningsRateID:    string
      RatePerUnit?:      number
      NumberOfUnits:     number
      Amount?:           number
      FixedAmount?:      number
    }[]
  }[]
}

/* ── Date conversion (Xero uses /Date(ms+timezone)/ format) ─────────────── */
function toXeroDate(dateStr: string): string {
  const ms = new Date(dateStr).getTime()
  return `/Date(${ms}+0000)/`
}

/* ── Employee CRUD ───────────────────────────────────────────────────────── */

/**
 * Create or update an employee in Xero Payroll
 * Returns the Xero EmployeeID
 */
export async function createXeroEmployee(
  tenantId: string,
  employee: XeroEmployee
): Promise<string> {
  const token = await getValidAccessToken()
  const response = await xeroFetch(
    '/payroll.xro/1.0/Employees',
    {
      method: 'POST',
      headers: {
        'Xero-Tenant-Id': tenantId,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ Employees: [employee] }),
    },
    token
  )

  const data = await response.json()
  if (!response.ok) {
    throw new Error(data?.Message || `Xero employee create failed: ${response.status}`)
  }

  const xeroId = data?.Employees?.[0]?.EmployeeID
  if (!xeroId) throw new Error('No EmployeeID returned from Xero')
  return xeroId
}

/**
 * Get an employee by Xero EmployeeID
 */
export async function getXeroEmployee(tenantId: string, xeroEmployeeId: string) {
  const token = await getValidAccessToken()
  const response = await xeroFetch(
    `/payroll.xro/1.0/Employees/${xeroEmployeeId}`,
    { headers: { 'Xero-Tenant-Id': tenantId } },
    token
  )
  const data = await response.json()
  if (!response.ok) throw new Error(data?.Message || 'Xero employee fetch failed')
  return data?.Employees?.[0] ?? null
}

/**
 * Sync a contractor from our DB → Xero Payroll
 * Creates if no xero_employee_id, updates if exists
 */
export async function syncContractorToXero(contractorId: string, tenantId: string): Promise<string> {
  const supabase = createServiceClient()

  // Fetch full contractor record including related tables
  const { data: c, error } = await supabase
    .from('contractors')
    .select(`
      *, 
      tax_declarations(*),
      bank_accounts(*),
      super_memberships(*)
    `)
    .eq('id', contractorId)
    .single()

  if (error || !c) throw new Error('Contractor not found')

  const td   = c.tax_declarations?.[0]
  const bank = c.bank_accounts?.find((b: Record<string,unknown>) => b.is_primary) ?? c.bank_accounts?.[0]

  const employee: XeroEmployee = {
    FirstName:   c.first_name,
    LastName:    c.last_name,
    DateOfBirth: c.date_of_birth,
    Email:       c.email,
    Gender:      c.gender as 'M' | 'F' | undefined,
    Status:      c.status === 'ACTIVE' ? 'ACTIVE' : 'TERMINATED',
    StartDate:   toXeroDate(c.start_date ?? new Date().toISOString()),
    HomeAddress: {
      AddressLine1: c.address_line1 ?? undefined,
      City:         c.suburb       ?? undefined,
      Region:       c.state        ?? undefined,
      PostalCode:   c.postcode     ?? undefined,
      Country:      'Australia',
    },
    TaxDeclaration: td ? {
      TFN:                 td.tfn,
      ResidencyStatus:     td.residency_status === 'RESIDENT' ? 'AUSTRALIANRESIDENT' : 'FOREIGNRESIDENT',
      TaxFreeThreshold:    td.claim_tax_free_threshold,
      HasHELPDebt:         td.help_debt,
      HasStudentLoan:      td.student_loan,
      HasSeniorsOffsetCode: td.seniors_offset,
    } : undefined,
    BankAccounts: bank ? [{
      AccountName:   bank.account_name,
      BSB:           bank.bsb,
      AccountNumber: bank.account_number,
      Remainder:     true,
    }] : undefined,
  }

  let xeroEmployeeId: string

  if (c.xero_employee_id) {
    // Update existing
    const token = await getValidAccessToken()
    await xeroFetch(
      `/payroll.xro/1.0/Employees/${c.xero_employee_id}`,
      {
        method: 'POST',
        headers: { 'Xero-Tenant-Id': tenantId, 'Content-Type': 'application/json' },
        body: JSON.stringify({ Employees: [{ ...employee, EmployeeID: c.xero_employee_id }] }),
      },
      token
    )
    xeroEmployeeId = c.xero_employee_id
  } else {
    xeroEmployeeId = await createXeroEmployee(tenantId, employee)
    // Save back
    await supabase
      .from('contractors')
      .update({ xero_employee_id: xeroEmployeeId })
      .eq('id', contractorId)
  }

  return xeroEmployeeId
}

/* ── Pay Runs ────────────────────────────────────────────────────────────── */

/**
 * Create a pay run in Xero Payroll
 */
export async function createXeroPayRun(
  tenantId:          string,
  payrollCalendarId: string,
  periodStart:       string,
  periodEnd:         string,
  paymentDate:       string
): Promise<string> {
  const token = await getValidAccessToken()

  const payload = {
    PayRuns: [{
      PayrollCalendarID:     payrollCalendarId,
      PayRunPeriodStartDate: toXeroDate(periodStart),
      PayRunPeriodEndDate:   toXeroDate(periodEnd),
      PaymentDate:           toXeroDate(paymentDate),
    }]
  }

  const response = await xeroFetch(
    '/payroll.xro/1.0/PayRuns',
    {
      method: 'POST',
      headers: { 'Xero-Tenant-Id': tenantId, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    },
    token
  )

  const data = await response.json()
  if (!response.ok) throw new Error(data?.Message || `Xero PayRun create failed: ${response.status}`)

  const payRunId = data?.PayRuns?.[0]?.PayRunID
  if (!payRunId) throw new Error('No PayRunID returned from Xero')
  return payRunId
}

/**
 * Post (approve) a pay run in Xero, triggering STP lodgement
 */
export async function postXeroPayRun(tenantId: string, payRunId: string): Promise<void> {
  const token = await getValidAccessToken()

  const response = await xeroFetch(
    `/payroll.xro/1.0/PayRuns/${payRunId}`,
    {
      method: 'POST',
      headers: { 'Xero-Tenant-Id': tenantId, 'Content-Type': 'application/json' },
      body: JSON.stringify({ PayRuns: [{ PayRunID: payRunId, PayRunStatus: 'POSTED' }] }),
    },
    token
  )

  if (!response.ok) {
    const data = await response.json().catch(() => ({}))
    throw new Error(data?.Message || `Xero PayRun post failed: ${response.status}`)
  }
}

/**
 * Get payslip for an employee from a pay run
 */
export async function getXeroPayslip(tenantId: string, payslipId: string) {
  const token = await getValidAccessToken()
  const response = await xeroFetch(
    `/payroll.xro/1.0/Payslip/${payslipId}`,
    { headers: { 'Xero-Tenant-Id': tenantId } },
    token
  )
  const data = await response.json()
  if (!response.ok) throw new Error(data?.Message || 'Xero payslip fetch failed')
  return data?.Payslip ?? null
}

/**
 * Get pay run details including all pay stubs
 */
export async function getXeroPayRun(tenantId: string, payRunId: string) {
  const token = await getValidAccessToken()
  const response = await xeroFetch(
    `/payroll.xro/1.0/PayRuns/${payRunId}`,
    { headers: { 'Xero-Tenant-Id': tenantId } },
    token
  )
  const data = await response.json()
  if (!response.ok) throw new Error(data?.Message || 'Xero PayRun fetch failed')
  return data?.PayRuns?.[0] ?? null
}

/* ── Leave API ───────────────────────────────────────────────────────────── */

/**
 * Create a leave application in Xero Payroll
 */
export async function createXeroLeaveApplication(
  tenantId:     string,
  employeeId:   string,
  leaveTypeId:  string,
  startDate:    string,
  endDate:      string,
  title?:       string
) {
  const token = await getValidAccessToken()

  const response = await xeroFetch(
    '/payroll.xro/1.0/LeaveApplications',
    {
      method: 'POST',
      headers: { 'Xero-Tenant-Id': tenantId, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        LeaveApplications: [{
          EmployeeID:   employeeId,
          LeaveTypeID:  leaveTypeId,
          StartDate:    toXeroDate(startDate),
          EndDate:      toXeroDate(endDate),
          Title:        title ?? 'Leave application',
        }]
      }),
    },
    token
  )

  const data = await response.json()
  if (!response.ok) throw new Error(data?.Message || 'Xero leave application failed')
  return data?.LeaveApplications?.[0]?.LeaveApplicationID ?? null
}
