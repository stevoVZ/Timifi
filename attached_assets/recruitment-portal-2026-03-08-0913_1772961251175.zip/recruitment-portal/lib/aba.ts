// lib/aba.ts
// Australian Banking Association (ABA) Direct Entry file generator
// Used for batch payroll payments via BECS (Bulk Electronic Clearing System)
// Spec: https://www.cemtexaba.com/aba-format

export interface ABAHeader {
  bsb:            string   // Agency debit BSB, e.g. "062-000"
  accountNumber:  string   // Agency debit account number
  accountName:    string   // Agency account name (max 26 chars)
  apcsUserName:   string   // Financial institution user name (max 26 chars)
  apcsUserId:     string   // 6-digit APCS user ID assigned by bank
  description:    string   // Payment description (max 12 chars), e.g. "PAYROLL"
  processingDate: string   // DDMMYY e.g. "010426"
}

export interface ABAEntry {
  bsb:           string   // Recipient BSB e.g. "062-000"
  accountNumber: string   // Recipient account number (max 9 chars)
  accountName:   string   // Recipient name (max 32 chars)
  transactionCode: '50' | '53'  // 50=credit (pay), 53=debit
  amount:        number   // Amount in dollars (will be rounded to 2dp, stored as cents in file)
  lodgementRef:  string   // Reference for recipient's statement (max 18 chars)
  traceRecord:   string   // Trace BSB+account (same as header debit account)
  remittanceInfo: string  // Optional remittance (max 18 chars)
  indicator:     ' ' | 'W' | 'X' | 'Y'  // ' '=normal, 'W'=dividend, etc.
}

/* ── Pad / truncate helpers ───────────────────────────────────────────────── */
const padR  = (s: string, n: number) => s.slice(0, n).padEnd(n, ' ')
const padL  = (s: string, n: number) => s.slice(0, n).padStart(n, ' ')
const padLZ = (s: string, n: number) => s.slice(0, n).padStart(n, '0')

function cleanBSB(bsb: string): string {
  const d = bsb.replace(/[^0-9]/g, '')
  if (d.length !== 6) throw new Error(`Invalid BSB: ${bsb}`)
  return `${d.slice(0,3)}-${d.slice(3)}`
}

function centStr(amount: number): string {
  return padLZ(String(Math.round(amount * 100)), 10)
}

/* ── Header record (Type 0) ───────────────────────────────────────────────── */
function buildHeader(h: ABAHeader): string {
  let r = ''
  r += '0'                                     // Record type
  r += '                 '                     // BSB (blank for descriptive)
  r += '         '                             // Account number (blank)
  r += ' '                                     // Reserved
  r += padR(h.apcsUserName, 26)               // APCS user name
  r += padR(h.apcsUserId.padStart(6,'0'), 6) // APCS user ID
  r += padR(h.description, 12)               // Description
  r += h.processingDate.slice(0,6)           // Processing date DDMMYY
  r += ' '.repeat(40)                         // Reserved
  return r.padEnd(120, ' ')
}

/* ── Detail record (Type 1) ──────────────────────────────────────────────── */
function buildDetail(e: ABAEntry, traceId: string): string {
  let r = ''
  r += '1'                                    // Record type
  r += cleanBSB(e.bsb)                       // BSB
  r += padR(e.accountNumber.replace(/\s/g,''), 9)   // Account number
  r += e.indicator                           // Indicator
  r += e.transactionCode                     // Transaction code
  r += centStr(e.amount)                     // Amount (cents, zero-padded 10)
  r += padR(e.accountName, 32)              // Account name
  r += padR(e.lodgementRef, 18)             // Lodgement reference
  r += cleanBSB(traceId.slice(0,7))         // Trace BSB
  r += padR(traceId.slice(7), 9)            // Trace account
  r += padR(e.remittanceInfo, 16)           // Remittance (name of payee, 16)
  r += centStr(0)                            // Withholding amount (00s for PAYG—we report separately)
  return r.padEnd(120, ' ')
}

/* ── File total record (Type 7) ─────────────────────────────────────────── */
function buildTotal(
  netTotal:    number,
  creditTotal: number,
  debitTotal:  number,
  entryCount:  number,
): string {
  let r = ''
  r += '7'                               // Record type
  r += '999-999'                         // BSB (filler)
  r += '         '                       // Filler
  r += ' '                               // Reserved
  r += centStr(netTotal)                // Net total
  r += centStr(creditTotal)            // Credit total
  r += centStr(debitTotal)             // Debit total
  r += ' '.repeat(24)                   // Reserved
  r += padLZ(String(entryCount), 6)    // Entry count
  r += ' '.repeat(40)                   // Reserved
  return r.padEnd(120, ' ')
}

/* ── Main generator ──────────────────────────────────────────────────────── */
export function generateABAFile(header: ABAHeader, entries: ABAEntry[]): string {
  if (entries.length === 0) throw new Error('ABA file must have at least one entry')
  if (entries.length > 999) throw new Error('ABA file cannot exceed 999 entries')

  // Trace record: agency debit BSB + account (16 chars)
  const traceBSB  = cleanBSB(header.bsb)
  const traceId   = traceBSB + header.accountNumber.replace(/\s/g,'').padEnd(9,' ')

  const creditTotal = entries
    .filter(e => e.transactionCode === '50')
    .reduce((s, e) => s + e.amount, 0)
  const debitTotal = entries
    .filter(e => e.transactionCode === '53')
    .reduce((s, e) => s + e.amount, 0)
  const netTotal = Math.abs(creditTotal - debitTotal)

  const lines = [
    buildHeader(header),
    ...entries.map(e => buildDetail(e, traceId)),
    buildTotal(netTotal, creditTotal, debitTotal, entries.length),
  ]

  return lines.join('\r\n') + '\r\n'
}

/* ── Build ABA from pay run lines ────────────────────────────────────────── */
export interface PayRunLineForABA {
  contractorName:  string
  bsb:             string
  accountNumber:   string
  netPay:          number
  payslipNumber:   string
}

export function buildABAFromPayRun(opts: {
  header:         ABAHeader
  lines:          PayRunLineForABA[]
  paymentDate:    string    // YYYY-MM-DD
}): { content: string; totalAmount: number; entryCount: number } {
  const { header, lines } = opts

  const entries: ABAEntry[] = lines.map(line => ({
    bsb:             line.bsb,
    accountNumber:   line.accountNumber,
    accountName:     line.contractorName.slice(0, 32),
    transactionCode: '50',
    amount:          Math.round(line.netPay * 100) / 100,
    lodgementRef:    line.payslipNumber.slice(0, 18),
    traceRecord:     '',
    remittanceInfo:  'PAY',
    indicator:       ' ',
  }))

  const content = generateABAFile(header, entries)
  const totalAmount = entries.reduce((s, e) => s + e.amount, 0)

  return { content, totalAmount, entryCount: entries.length }
}
