# Recruitment Portal

White-label labour hire agency portal — Next.js 14 App Router + Supabase + Xero.

## Quick Start (Replit)

1. Import ZIP → new Replit project
2. `npm install` in Shell
3. Add Secrets (see below)
4. Supabase SQL Editor — run in order:
   - `supabase/schema.sql`
   - `supabase/schema-additions.sql`
   - `supabase/schema-v2.sql`
   - `supabase/storage.sql`
5. Press **Run** → port 3000

## Required Secrets

| Secret | Description |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Service role key (API routes) |
| `NEXT_PUBLIC_ANTHROPIC_API_KEY` | For AI timesheet scanning |
| `XERO_CLIENT_ID` | Xero app Client ID (optional) |
| `XERO_CLIENT_SECRET` | Xero app Client Secret (optional) |
| `XERO_REDIRECT_URI` | `https://yourapp.repl.co/api/xero/callback` |

## Admin Portal

| Path | Description |
|---|---|
| `/admin/dashboard` | Live KPIs, contractor table, activity feed |
| `/admin/contractors` | List, search, filter, Xero status |
| `/admin/contractors/new` | 5-step wizard |
| `/admin/contractors/[id]` | Profile edit, timesheets, invoices, documents |
| `/admin/timesheets` | AI-scan upload, approve/reject |
| `/admin/payroll` | PAYG calc, Xero STP filing, ABA download |
| `/admin/invoicing` | Create/send via Xero |
| `/admin/leave` | Approve/reject requests |
| `/admin/notifications` | Priority-filtered notification centre |
| `/admin/pay-items` | System + custom pay codes |
| `/admin/settings` | Branding, Company, Payroll, Xero, Portal, Users |

## Contractor Portal

| Path | Description |
|---|---|
| `/portal/login` | Email/password + magic link |
| `/portal/onboarding` | 7-step: TFN, bank, super (public — no auth required) |
| `/portal/dashboard` | KPIs, utilisation, recent activity |
| `/portal/timesheets` | History, weekly breakdown |
| `/portal/payslips` | YTD, expandable, PDF download |
| `/portal/messages` | Two-pane inbox, reply |
| `/portal/leave` | Balances, history, new request |

## Key API Routes

`GET/POST /api/contractors` · `GET/PATCH/DELETE /api/contractors/[id]`
`GET/PATCH /api/timesheets` · `GET/PATCH /api/invoices`
`GET/POST/PATCH /api/payroll` · `POST /api/payroll/aba`
`POST /api/xero/payroll` (file pay run + STP)
`POST /api/xero/invoices` · `GET/POST/PATCH /api/leave`
`GET/POST/PATCH /api/messages` · `GET/PATCH /api/notifications`
`GET/POST/PATCH/DELETE /api/pay-items` · `GET/POST /api/settings`
`GET/POST /api/payslips` · `GET /api/payslips/[id]`
`POST /api/onboarding/{personal,tax,bank,super}`
`GET /api/auth/me` · `GET /api/documents`

## Supabase Tables

profiles · contractors · tax_declarations · bank_accounts · super_memberships
timesheets · timesheet_versions · invoices · pay_runs · pay_run_lines · aba_payments
notifications · messages · portal_settings · pay_items · leave_requests · leave_balances
organisations · org_members · documents · audit_log · xero_tokens · webhook_events

Storage buckets: `timesheets` `payslips` `documents` `logos`

## Xero Setup

1. Create app at developer.xero.com
2. Redirect URI: `https://yourapp/api/xero/callback`
3. Scopes: `accounting.transactions accounting.contacts payroll.employees payroll.payslip payroll.settings offline_access`
4. Settings → Xero → Connect Xero

## Design Tokens (`lib/design.ts`)

`B.bg` `B.surface` `B.border` · `B.text` `B.mid` `B.dim` `B.sub`
`B.accent` `B.green` `B.amber` `B.red` `B.purple`
Fonts: DM Sans (body) · DM Mono (numbers)
