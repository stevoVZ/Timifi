// lib/design.ts
// ─────────────────────────────────────────────────────────────────────────────
// Design tokens. B.accent reads the runtime CSS variable set by AccentProvider,
// allowing per-org theming without a full re-render cycle.
// ─────────────────────────────────────────────────────────────────────────────

/** Returns the current accent colour from the CSS variable (client) or the
 *  provided fallback (server / SSR where `document` is unavailable). */
function getAccent(fallback = '#6366f1'): string {
  if (typeof window === 'undefined') return fallback;
  const val = getComputedStyle(document.documentElement)
    .getPropertyValue('--accent')
    .trim();
  return val || fallback;
}

// ── Colour tokens ─────────────────────────────────────────────────────────────
export const B = {
  /** Dynamic accent — reads --accent CSS variable at call time */
  get accent() {
    return getAccent();
  },

  // Surfaces
  bg:          '#f4f5f7',
  surface:     '#ffffff',
  surfaceAlt:  '#f9fafb',
  border:      '#e5e7eb',
  borderLight: '#f0f1f3',

  // Text
  text:        '#111827',
  textMuted:   '#6b7280',
  textFaint:   '#9ca3af',

  // Semantic
  success:     '#10b981',
  warning:     '#f59e0b',
  danger:      '#ef4444',
  info:        '#3b82f6',

  // Sidebar / nav (dark surface)
  navBg:       '#1e2635',
  navText:     '#c8d0dc',
  navActive:   '#ffffff',
  navBorder:   '#2d3748',
} as const;

// ── Typography scale ──────────────────────────────────────────────────────────
export const T = {
  xs:   { fontSize: 11, lineHeight: '16px' },
  sm:   { fontSize: 13, lineHeight: '20px' },
  base: { fontSize: 14, lineHeight: '22px' },
  md:   { fontSize: 16, lineHeight: '24px' },
  lg:   { fontSize: 18, lineHeight: '28px' },
  xl:   { fontSize: 22, lineHeight: '32px' },
  h1:   { fontSize: 28, lineHeight: '36px', fontWeight: 700 },
  h2:   { fontSize: 22, lineHeight: '30px', fontWeight: 600 },
  h3:   { fontSize: 16, lineHeight: '24px', fontWeight: 600 },
} as const;

// ── Spacing ───────────────────────────────────────────────────────────────────
export const S = {
  1:  4,
  2:  8,
  3:  12,
  4:  16,
  5:  20,
  6:  24,
  8:  32,
  10: 40,
  12: 48,
} as const;

// ── Shadows ───────────────────────────────────────────────────────────────────
export const Shadow = {
  sm:  '0 1px 2px rgba(0,0,0,0.06)',
  md:  '0 4px 12px rgba(0,0,0,0.08)',
  lg:  '0 8px 24px rgba(0,0,0,0.10)',
  xl:  '0 16px 48px rgba(0,0,0,0.14)',
} as const;

// ── Border radius ─────────────────────────────────────────────────────────────
export const R = {
  sm:  6,
  md:  10,
  lg:  14,
  xl:  20,
  full: 9999,
} as const;

// ── Status badge colours ──────────────────────────────────────────────────────
export const StatusColour: Record<string, { bg: string; text: string; dot: string }> = {
  active:    { bg: '#ecfdf5', text: '#059669', dot: '#10b981' },
  pending:   { bg: '#fffbeb', text: '#d97706', dot: '#f59e0b' },
  approved:  { bg: '#eff6ff', text: '#2563eb', dot: '#3b82f6' },
  rejected:  { bg: '#fef2f2', text: '#dc2626', dot: '#ef4444' },
  inactive:  { bg: '#f3f4f6', text: '#6b7280', dot: '#9ca3af' },
  draft:     { bg: '#f5f3ff', text: '#7c3aed', dot: '#8b5cf6' },
  paid:      { bg: '#ecfdf5', text: '#059669', dot: '#10b981' },
  overdue:   { bg: '#fef2f2', text: '#dc2626', dot: '#ef4444' },
  cancelled: { bg: '#f3f4f6', text: '#6b7280', dot: '#9ca3af' },
};
