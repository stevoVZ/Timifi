// lib/payslip.ts
// ─────────────────────────────────────────────────────────────────────────────
// Payslip PDF builder using jsPDF.
// Call generatePayslipPDF(data) → returns a jsPDF doc ready to save or stream.
// ─────────────────────────────────────────────────────────────────────────────

import { jsPDF } from 'jspdf';

export interface PayslipLineItem {
  description: string;
  hours?:      number;
  rate?:       number;
  amount:      number;
}

export interface PayslipData {
  // Company
  companyName:    string;
  companyAbn:     string;
  companyAddress: string;
  logoBase64?:    string;        // data-URL, optional
  accentColour?:  string;        // hex, defaults to #6366f1

  // Employee
  employeeName:   string;
  employeeId:     string;
  position:       string;
  payPeriodStart: string;        // ISO date
  payPeriodEnd:   string;        // ISO date
  payDate:        string;        // ISO date

  // Earnings
  earnings:       PayslipLineItem[];

  // Deductions
  tax:            number;
  superAmount:    number;
  otherDeductions?: PayslipLineItem[];

  // YTD
  ytdGross:       number;
  ytdTax:         number;
  ytdSuper:       number;
  ytdNet:         number;

  // Bank
  bankName?:      string;
  bsb?:           string;
  accountLast4?:  string;
}

const money = (n: number) =>
  new Intl.NumberFormat('en-AU', { style: 'currency', currency: 'AUD' }).format(n);

const fmtDate = (iso: string) => {
  const d = new Date(iso);
  return d.toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' });
};

export function generatePayslipPDF(data: PayslipData): jsPDF {
  const accent = data.accentColour ?? '#6366f1';
  const accentR = parseInt(accent.slice(1, 3), 16);
  const accentG = parseInt(accent.slice(3, 5), 16);
  const accentB = parseInt(accent.slice(5, 7), 16);

  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = 210;
  const margin = 16;
  let y = 0;

  // ── Helper: horizontal rule ─────────────────────────────────────────────────
  const hr = (yPos: number, colour = [229, 231, 235] as [number, number, number]) => {
    doc.setDrawColor(...colour);
    doc.setLineWidth(0.3);
    doc.line(margin, yPos, W - margin, yPos);
  };

  // ── Header band ─────────────────────────────────────────────────────────────
  doc.setFillColor(accentR, accentG, accentB);
  doc.rect(0, 0, W, 34, 'F');

  // Company name
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(255, 255, 255);
  doc.text(data.companyName, margin, 14);

  // "PAYSLIP" label
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('PAYSLIP', W - margin, 10, { align: 'right' });

  // Pay period
  doc.setFontSize(8);
  doc.text(
    `Pay period: ${fmtDate(data.payPeriodStart)} – ${fmtDate(data.payPeriodEnd)}   |   Pay date: ${fmtDate(data.payDate)}`,
    W - margin,
    16,
    { align: 'right' }
  );

  // ABN
  doc.text(`ABN ${data.companyAbn}`, W - margin, 22, { align: 'right' });
  doc.text(data.companyAddress, W - margin, 27, { align: 'right' });

  y = 42;

  // ── Employee details ────────────────────────────────────────────────────────
  doc.setTextColor(17, 24, 39);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text(data.employeeName, margin, y);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(107, 114, 128);
  doc.text(`${data.position}   |   ID: ${data.employeeId}`, margin, y + 6);

  y += 18;
  hr(y);
  y += 8;

  // ── Earnings table ──────────────────────────────────────────────────────────
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(17, 24, 39);
  doc.text('EARNINGS', margin, y);

  // Column headers
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(107, 114, 128);
  y += 5;
  doc.text('Description',  margin,      y);
  doc.text('Hours',        115,         y, { align: 'right' });
  doc.text('Rate',         145,         y, { align: 'right' });
  doc.text('Amount',       W - margin,  y, { align: 'right' });
  y += 2;
  hr(y, [209, 213, 219]);
  y += 5;

  let grossTotal = 0;
  doc.setFontSize(9);
  doc.setTextColor(17, 24, 39);
  for (const item of data.earnings) {
    doc.setFont('helvetica', 'normal');
    doc.text(item.description, margin, y);
    if (item.hours != null) doc.text(String(item.hours.toFixed(2)), 115, y, { align: 'right' });
    if (item.rate  != null) doc.text(money(item.rate),              145, y, { align: 'right' });
    doc.text(money(item.amount), W - margin, y, { align: 'right' });
    grossTotal += item.amount;
    y += 6;
  }

  y += 2;
  hr(y);
  y += 5;
  doc.setFont('helvetica', 'bold');
  doc.text('Gross Earnings', margin, y);
  doc.text(money(grossTotal), W - margin, y, { align: 'right' });
  y += 10;

  // ── Deductions ──────────────────────────────────────────────────────────────
  hr(y);
  y += 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('DEDUCTIONS', margin, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(17, 24, 39);

  const deductions: Array<{ label: string; amount: number }> = [
    { label: 'PAYG Withholding Tax', amount: data.tax },
    ...(data.otherDeductions ?? []).map(d => ({ label: d.description, amount: d.amount })),
  ];

  let totalDeductions = data.tax;
  for (const d of deductions) {
    doc.text(d.label, margin, y);
    doc.setTextColor(220, 38, 38);
    doc.text(`(${money(d.amount)})`, W - margin, y, { align: 'right' });
    doc.setTextColor(17, 24, 39);
    totalDeductions += (d === deductions[0] ? 0 : d.amount); // tax already counted
    y += 6;
  }

  y += 2;
  hr(y);
  y += 5;
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(17, 24, 39);
  doc.text('Total Deductions', margin, y);
  doc.setTextColor(220, 38, 38);
  doc.text(`(${money(totalDeductions)})`, W - margin, y, { align: 'right' });
  y += 10;

  // ── Net pay ─────────────────────────────────────────────────────────────────
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(229, 231, 235);
  doc.roundedRect(margin, y - 3, W - margin * 2, 14, 3, 3, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(17, 24, 39);
  doc.text('NET PAY', margin + 6, y + 6);

  doc.setTextColor(accentR, accentG, accentB);
  doc.text(money(grossTotal - totalDeductions), W - margin - 6, y + 6, { align: 'right' });

  y += 20;

  // ── Superannuation ──────────────────────────────────────────────────────────
  doc.setFontSize(9);
  doc.setTextColor(107, 114, 128);
  doc.setFont('helvetica', 'normal');
  doc.text(`Superannuation (employer contribution, not deducted from net pay): ${money(data.superAmount)}`, margin, y);
  y += 10;

  // ── YTD Summary ─────────────────────────────────────────────────────────────
  hr(y);
  y += 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(17, 24, 39);
  doc.text('YEAR-TO-DATE SUMMARY', margin, y);
  y += 6;

  const ytdCols = [
    { label: 'Gross Earnings', value: data.ytdGross },
    { label: 'Tax Withheld',   value: data.ytdTax   },
    { label: 'Superannuation', value: data.ytdSuper  },
    { label: 'Net Pay',        value: data.ytdNet    },
  ];

  const colW = (W - margin * 2) / ytdCols.length;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');

  for (let i = 0; i < ytdCols.length; i++) {
    const x = margin + i * colW;
    doc.setFillColor(accentR, accentG, accentB, 0.08);
    doc.setDrawColor(accentR, accentG, accentB);
    doc.roundedRect(x, y - 2, colW - 3, 16, 2, 2, 'FD');

    doc.setTextColor(107, 114, 128);
    doc.text(ytdCols[i].label, x + 4, y + 4);

    doc.setFont('helvetica', 'bold');
    doc.setTextColor(17, 24, 39);
    doc.text(money(ytdCols[i].value), x + 4, y + 11);
    doc.setFont('helvetica', 'normal');
  }

  y += 24;

  // ── Bank details ─────────────────────────────────────────────────────────────
  if (data.bankName || data.bsb) {
    hr(y);
    y += 6;
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(107, 114, 128);
    const bankStr = [
      data.bankName,
      data.bsb ? `BSB ${data.bsb}` : null,
      data.accountLast4 ? `Account ••••${data.accountLast4}` : null,
    ].filter(Boolean).join('   |   ');
    doc.text(`Paid to: ${bankStr}`, margin, y);
    y += 10;
  }

  // ── Footer ───────────────────────────────────────────────────────────────────
  const footerY = 284;
  doc.setFillColor(accentR, accentG, accentB);
  doc.rect(0, footerY, W, 13, 'F');
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(255, 255, 255);
  doc.text(
    'This is a computer-generated payslip and does not require a signature.',
    W / 2,
    footerY + 5,
    { align: 'center' }
  );
  doc.text(
    `Generated ${new Date().toLocaleDateString('en-AU')}`,
    W / 2,
    footerY + 10,
    { align: 'center' }
  );

  return doc;
}
