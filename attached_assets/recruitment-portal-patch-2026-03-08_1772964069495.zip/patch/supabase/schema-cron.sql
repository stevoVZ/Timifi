-- ─────────────────────────────────────────────────────────────────────────────
-- schema-cron.sql
-- Organisations table + leave balance deduction + pg_cron scheduler
-- Run in Supabase SQL Editor (requires pg_cron enabled in Supabase dashboard)
-- ─────────────────────────────────────────────────────────────────────────────

-- ── Enable extensions ─────────────────────────────────────────────────────────
create extension if not exists "pg_cron" with schema extensions;
create extension if not exists "uuid-ossp";

-- ── Organisations (multi-tenant) ──────────────────────────────────────────────
create table if not exists organisations (
  id            uuid primary key default uuid_generate_v4(),
  name          text not null,
  slug          text not null unique,
  logo_url      text,
  accent_colour text not null default '#6366f1',
  abn           text,
  address       text,
  contact_email text,
  contact_phone text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- RLS
alter table organisations enable row level security;

create policy "Org members can read their org"
  on organisations for select
  using (
    id in (
      select organisation_id from profiles
      where id = auth.uid()
    )
  );

create policy "Admins can update their org"
  on organisations for update
  using (
    id in (
      select organisation_id from profiles
      where id = auth.uid() and role = 'admin'
    )
  );

-- ── Leave types ───────────────────────────────────────────────────────────────
create table if not exists leave_types (
  id              uuid primary key default uuid_generate_v4(),
  organisation_id uuid not null references organisations(id) on delete cascade,
  name            text not null,          -- 'Annual Leave', 'Sick Leave', etc.
  accrual_days    numeric(5,2) default 20, -- days per year
  color           text default '#6366f1',
  created_at      timestamptz default now()
);

alter table leave_types enable row level security;

create policy "Org members read leave types"
  on leave_types for select
  using (
    organisation_id in (
      select organisation_id from profiles where id = auth.uid()
    )
  );

-- ── Leave balances ────────────────────────────────────────────────────────────
create table if not exists leave_balances (
  id              uuid primary key default uuid_generate_v4(),
  contractor_id   uuid not null references contractors(id) on delete cascade,
  leave_type_id   uuid not null references leave_types(id) on delete cascade,
  organisation_id uuid not null references organisations(id) on delete cascade,
  balance_days    numeric(6,2) not null default 0,
  accrued_ytd     numeric(6,2) not null default 0,
  taken_ytd       numeric(6,2) not null default 0,
  updated_at      timestamptz default now(),
  unique (contractor_id, leave_type_id)
);

alter table leave_balances enable row level security;

create policy "Contractors read own balances"
  on leave_balances for select
  using (
    contractor_id in (
      select id from contractors where profile_id = auth.uid()
    )
  );

create policy "Admins read all balances in org"
  on leave_balances for select
  using (
    organisation_id in (
      select organisation_id from profiles
      where id = auth.uid() and role in ('admin', 'consultant')
    )
  );

-- ── Leave requests ────────────────────────────────────────────────────────────
create table if not exists leave_requests (
  id              uuid primary key default uuid_generate_v4(),
  contractor_id   uuid not null references contractors(id) on delete cascade,
  leave_type_id   uuid not null references leave_types(id),
  organisation_id uuid not null references organisations(id) on delete cascade,
  start_date      date not null,
  end_date        date not null,
  days_requested  numeric(5,2) not null,
  reason          text,
  status          text not null default 'pending'  -- pending | approved | rejected
                  check (status in ('pending','approved','rejected')),
  reviewed_by     uuid references profiles(id),
  reviewed_at     timestamptz,
  reviewer_note   text,
  created_at      timestamptz not null default now()
);

alter table leave_requests enable row level security;

create policy "Contractors read own requests"
  on leave_requests for select
  using (
    contractor_id in (
      select id from contractors where profile_id = auth.uid()
    )
  );

create policy "Contractors insert own requests"
  on leave_requests for insert
  with check (
    contractor_id in (
      select id from contractors where profile_id = auth.uid()
    )
  );

create policy "Admins read all requests in org"
  on leave_requests for select
  using (
    organisation_id in (
      select organisation_id from profiles
      where id = auth.uid() and role in ('admin', 'consultant')
    )
  );

create policy "Admins update requests in org"
  on leave_requests for update
  using (
    organisation_id in (
      select organisation_id from profiles
      where id = auth.uid() and role in ('admin', 'consultant')
    )
  );

-- ── deduct_leave_balance() ────────────────────────────────────────────────────
-- Called after a leave request is approved. Deducts days from the balance and
-- records accrual movement.
create or replace function deduct_leave_balance(
  p_contractor_id  uuid,
  p_leave_type_id  uuid,
  p_days           numeric
)
returns void
language plpgsql
security definer
as $$
begin
  update leave_balances
  set
    balance_days = balance_days - p_days,
    taken_ytd    = taken_ytd + p_days,
    updated_at   = now()
  where
    contractor_id = p_contractor_id
    and leave_type_id = p_leave_type_id;

  if not found then
    raise exception 'No leave balance record found for contractor % / type %',
      p_contractor_id, p_leave_type_id;
  end if;
end;
$$;

-- ── accrue_leave_monthly() ────────────────────────────────────────────────────
-- Adds 1/12 of annual entitlement to each active contractor's leave balance.
-- Scheduled by pg_cron to run on the 1st of each month.
create or replace function accrue_leave_monthly()
returns void
language plpgsql
security definer
as $$
declare
  r record;
begin
  for r in
    select
      lb.id,
      lb.contractor_id,
      lb.leave_type_id,
      lt.accrual_days
    from leave_balances lb
    join leave_types    lt  on lt.id = lb.leave_type_id
    join contractors    c   on c.id  = lb.contractor_id
    where c.status = 'active'
  loop
    update leave_balances
    set
      balance_days = balance_days + (r.accrual_days / 12.0),
      accrued_ytd  = accrued_ytd  + (r.accrual_days / 12.0),
      updated_at   = now()
    where id = r.id;
  end loop;
end;
$$;

-- ── reset_leave_ytd() ─────────────────────────────────────────────────────────
-- Resets YTD counters on 1 July each year (Australian financial year).
create or replace function reset_leave_ytd()
returns void
language plpgsql
security definer
as $$
begin
  update leave_balances
  set
    accrued_ytd = 0,
    taken_ytd   = 0,
    updated_at  = now();
end;
$$;

-- ── pg_cron schedules ─────────────────────────────────────────────────────────
-- Monthly accrual: 1st of every month at 00:05 AEST (14:05 UTC prev day — adjust
-- for UTC offset; here we use 00:05 UTC on 1st as a safe approximation)
select cron.schedule(
  'monthly-leave-accrual',
  '5 0 1 * *',
  'select accrue_leave_monthly()'
);

-- Annual YTD reset: 1 July at 00:01 UTC
select cron.schedule(
  'annual-leave-ytd-reset',
  '1 0 1 7 *',
  'select reset_leave_ytd()'
);

-- ── Indexes ───────────────────────────────────────────────────────────────────
create index if not exists idx_leave_requests_contractor on leave_requests(contractor_id);
create index if not exists idx_leave_requests_status     on leave_requests(status);
create index if not exists idx_leave_requests_org        on leave_requests(organisation_id);
create index if not exists idx_leave_balances_contractor on leave_balances(contractor_id);
create index if not exists idx_organisations_slug        on organisations(slug);

-- ── profiles: add organisation_id column if missing ──────────────────────────
do $$
begin
  if not exists (
    select 1 from information_schema.columns
    where table_name = 'profiles' and column_name = 'organisation_id'
  ) then
    alter table profiles add column organisation_id uuid references organisations(id);
  end if;
end $$;
