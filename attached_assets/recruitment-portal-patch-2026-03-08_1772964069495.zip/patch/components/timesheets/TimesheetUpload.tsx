'use client';

// components/timesheets/TimesheetUpload.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Timesheet upload form. Fetches live contractor list from /api/contractors
// so the contractor dropdown is always up-to-date without a page reload.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useRef, useState } from 'react';
import { B, Shadow, R } from '@/lib/design';
import { useAccent } from '@/components/layout/AccentProvider';

interface Contractor {
  id:         string;
  full_name:  string;
  position:   string;
  avatar_url?: string | null;
}

interface TimesheetUploadProps {
  /** Called after a successful upload */
  onUploaded?: (timesheetId: string) => void;
}

type UploadStatus = 'idle' | 'uploading' | 'success' | 'error';

export default function TimesheetUpload({ onUploaded }: TimesheetUploadProps) {
  const { accent }    = useAccent();
  const fileRef       = useRef<HTMLInputElement>(null);

  const [contractors,  setContractors]  = useState<Contractor[]>([]);
  const [loadingCtrs,  setLoadingCtrs]  = useState(true);
  const [contractorId, setContractorId] = useState('');
  const [weekEnding,   setWeekEnding]   = useState('');
  const [file,         setFile]         = useState<File | null>(null);
  const [dragOver,     setDragOver]     = useState(false);
  const [status,       setStatus]       = useState<UploadStatus>('idle');
  const [errorMsg,     setErrorMsg]     = useState('');

  // ── Fetch contractors ───────────────────────────────────────────────────────
  useEffect(() => {
    setLoadingCtrs(true);
    fetch('/api/contractors?status=active&select=id,full_name,position,avatar_url')
      .then(r => r.json())
      .then(({ contractors: data }: { contractors: Contractor[] }) => {
        setContractors(data ?? []);
      })
      .catch(() => setContractors([]))
      .finally(() => setLoadingCtrs(false));
  }, []);

  // ── Default week-ending to last Friday ─────────────────────────────────────
  useEffect(() => {
    const now = new Date();
    const dow = now.getDay(); // 0=Sun ... 6=Sat
    const diff = (dow + 2) % 7; // days back to Friday
    const friday = new Date(now);
    friday.setDate(now.getDate() - diff);
    setWeekEnding(friday.toISOString().slice(0, 10));
  }, []);

  // ── File drop ───────────────────────────────────────────────────────────────
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped) validateAndSetFile(dropped);
  };

  const validateAndSetFile = (f: File) => {
    const ok = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'].includes(f.type);
    if (!ok) {
      setErrorMsg('Please upload a PDF or image file.');
      return;
    }
    if (f.size > 10 * 1024 * 1024) {
      setErrorMsg('File must be under 10 MB.');
      return;
    }
    setFile(f);
    setErrorMsg('');
  };

  // ── Submit ──────────────────────────────────────────────────────────────────
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contractorId) { setErrorMsg('Please select a contractor.'); return; }
    if (!weekEnding)   { setErrorMsg('Please set the week ending date.'); return; }
    if (!file)         { setErrorMsg('Please attach a timesheet file.'); return; }

    setStatus('uploading');
    setErrorMsg('');

    try {
      const form = new FormData();
      form.append('contractorId', contractorId);
      form.append('weekEnding',   weekEnding);
      form.append('file',         file);

      const res  = await fetch('/api/timesheets', { method: 'POST', body: form });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error ?? 'Upload failed');

      setStatus('success');
      setFile(null);
      if (fileRef.current) fileRef.current.value = '';
      onUploaded?.(data.id);

      // Reset after 2 s
      setTimeout(() => setStatus('idle'), 2000);
    } catch (err: any) {
      setErrorMsg(err.message ?? 'Something went wrong.');
      setStatus('error');
    }
  };

  const selectedContractor = contractors.find(c => c.id === contractorId);

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        background: B.surface,
        border: `1px solid ${B.border}`,
        borderRadius: R.lg,
        padding: 24,
        boxShadow: Shadow.md,
        maxWidth: 560,
      }}
    >
      <h3 style={{ fontSize: 16, fontWeight: 600, color: B.text, marginBottom: 20 }}>
        Upload Timesheet
      </h3>

      {/* Contractor selector */}
      <div style={{ marginBottom: 16 }}>
        <label style={labelStyle}>Contractor</label>
        {loadingCtrs ? (
          <div style={{ height: 38, borderRadius: R.sm, background: B.bg, animation: 'pulse 1.4s ease infinite' }} />
        ) : (
          <select
            value={contractorId}
            onChange={e => setContractorId(e.target.value)}
            style={selectStyle(accent)}
          >
            <option value="">— Select contractor —</option>
            {contractors.map(c => (
              <option key={c.id} value={c.id}>
                {c.full_name} {c.position ? `(${c.position})` : ''}
              </option>
            ))}
          </select>
        )}
        {selectedContractor && (
          <div style={{ marginTop: 6, display: 'flex', alignItems: 'center', gap: 6 }}>
            <ContractorAvatar c={selectedContractor} accent={accent} />
            <span style={{ fontSize: 12, color: B.textMuted }}>
              {selectedContractor.position}
            </span>
          </div>
        )}
      </div>

      {/* Week ending */}
      <div style={{ marginBottom: 16 }}>
        <label style={labelStyle}>Week Ending</label>
        <input
          type="date"
          value={weekEnding}
          onChange={e => setWeekEnding(e.target.value)}
          style={inputStyle(accent)}
        />
      </div>

      {/* File drop zone */}
      <div style={{ marginBottom: 16 }}>
        <label style={labelStyle}>Timesheet File</label>
        <div
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => fileRef.current?.click()}
          style={{
            border: `2px dashed ${dragOver ? accent : file ? '#10b981' : B.border}`,
            borderRadius: R.md,
            padding: '28px 20px',
            textAlign: 'center',
            cursor: 'pointer',
            background: dragOver ? `${accent}0d` : file ? '#ecfdf5' : B.bg,
            transition: 'all 0.15s',
          }}
        >
          {file ? (
            <div>
              <div style={{ fontSize: 22, marginBottom: 4 }}>📄</div>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#059669' }}>{file.name}</div>
              <div style={{ fontSize: 11, color: B.textMuted, marginTop: 2 }}>
                {(file.size / 1024).toFixed(0)} KB — click to replace
              </div>
            </div>
          ) : (
            <div>
              <div style={{ fontSize: 28, marginBottom: 6 }}>☁️</div>
              <div style={{ fontSize: 13, color: B.textMuted }}>
                Drag & drop PDF or image, or <span style={{ color: accent, fontWeight: 600 }}>browse</span>
              </div>
              <div style={{ fontSize: 11, color: B.textFaint, marginTop: 4 }}>PDF, JPG, PNG, WEBP — max 10 MB</div>
            </div>
          )}
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="application/pdf,image/*"
          onChange={e => { if (e.target.files?.[0]) validateAndSetFile(e.target.files[0]); }}
          style={{ display: 'none' }}
        />
      </div>

      {/* Error */}
      {errorMsg && (
        <div style={{
          background: '#fef2f2', border: '1px solid #fecaca',
          borderRadius: R.sm, padding: '8px 12px',
          fontSize: 12, color: '#dc2626', marginBottom: 12,
        }}>
          {errorMsg}
        </div>
      )}

      {/* Submit */}
      <button
        type="submit"
        disabled={status === 'uploading'}
        style={{
          width: '100%',
          padding: '11px 0',
          borderRadius: R.md,
          border: 'none',
          background: status === 'success' ? '#10b981' : accent,
          color: '#fff',
          fontSize: 14,
          fontWeight: 600,
          cursor: status === 'uploading' ? 'not-allowed' : 'pointer',
          opacity: status === 'uploading' ? 0.7 : 1,
          transition: 'all 0.2s',
        }}
      >
        {status === 'uploading' ? 'Uploading…' : status === 'success' ? '✓ Uploaded!' : 'Upload Timesheet'}
      </button>
    </form>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function ContractorAvatar({ c, accent }: { c: Contractor; accent: string }) {
  return c.avatar_url ? (
    <img src={c.avatar_url} alt={c.full_name} width={20} height={20}
      style={{ borderRadius: '50%', objectFit: 'cover' }} />
  ) : (
    <div style={{
      width: 20, height: 20, borderRadius: '50%',
      background: accent, color: '#fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: 9, fontWeight: 700,
    }}>
      {c.full_name.slice(0, 1)}
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: 'block', fontSize: 12, fontWeight: 600,
  color: '#374151', marginBottom: 5, letterSpacing: '0.02em',
};

const inputStyle = (accent: string): React.CSSProperties => ({
  width: '100%', padding: '9px 11px', borderRadius: R.sm,
  border: `1px solid ${B.border}`, background: B.surface,
  fontSize: 13, color: B.text, outline: 'none',
  transition: 'border-color 0.15s',
  boxSizing: 'border-box',
});

const selectStyle = (accent: string): React.CSSProperties => ({
  ...inputStyle(accent),
  appearance: 'none',
  backgroundImage: `url("data:image/svg+xml,%3Csvg width='12' height='8' viewBox='0 0 12 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%236b7280' stroke-width='1.5' stroke-linecap='round'/%3E%3C/svg%3E")`,
  backgroundRepeat: 'no-repeat',
  backgroundPosition: 'right 10px center',
  paddingRight: 30,
});
