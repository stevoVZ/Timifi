'use client';

// components/layout/Sidebar.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Main admin/portal sidebar. Includes OrgSwitcher at the bottom.
// Role prop determines which nav items to show.
// ─────────────────────────────────────────────────────────────────────────────

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import OrgSwitcher from './OrgSwitcher';
import { B } from '@/lib/design';
import { useAccent } from './AccentProvider';

type Role = 'admin' | 'consultant' | 'contractor';

interface NavItem {
  label:    string;
  href:     string;
  icon:     React.ReactNode;
  badge?:   number;
  roles:    Role[];
}

const NAV_ITEMS: NavItem[] = [
  {
    label: 'Dashboard',
    href:  '/admin',
    icon:  <DashIcon />,
    roles: ['admin', 'consultant'],
  },
  {
    label: 'Contractors',
    href:  '/admin/contractors',
    icon:  <PeopleIcon />,
    roles: ['admin', 'consultant'],
  },
  {
    label: 'Timesheets',
    href:  '/admin/timesheets',
    icon:  <ClockIcon />,
    roles: ['admin', 'consultant'],
  },
  {
    label: 'Leave',
    href:  '/admin/leave',
    icon:  <LeaveIcon />,
    roles: ['admin', 'consultant'],
  },
  {
    label: 'Payroll',
    href:  '/admin/payroll',
    icon:  <PayIcon />,
    roles: ['admin'],
  },
  {
    label: 'Invoices',
    href:  '/admin/invoices',
    icon:  <InvoiceIcon />,
    roles: ['admin', 'consultant'],
  },
  {
    label: 'Reports',
    href:  '/admin/reports',
    icon:  <ChartIcon />,
    roles: ['admin'],
  },
  {
    label: 'Settings',
    href:  '/admin/settings',
    icon:  <SettingsIcon />,
    roles: ['admin'],
  },

  // Contractor portal
  {
    label: 'Home',
    href:  '/portal',
    icon:  <DashIcon />,
    roles: ['contractor'],
  },
  {
    label: 'Timesheets',
    href:  '/portal/timesheets',
    icon:  <ClockIcon />,
    roles: ['contractor'],
  },
  {
    label: 'Payslips',
    href:  '/portal/payslips',
    icon:  <PayIcon />,
    roles: ['contractor'],
  },
  {
    label: 'Leave',
    href:  '/portal/leave',
    icon:  <LeaveIcon />,
    roles: ['contractor'],
  },
  {
    label: 'Documents',
    href:  '/portal/documents',
    icon:  <DocIcon />,
    roles: ['contractor'],
  },
];

interface SidebarProps {
  role:        Role;
  currentOrgId: string;
  userName?:   string;
  userAvatar?: string;
  pendingLeave?: number;
}

export default function Sidebar({
  role,
  currentOrgId,
  userName,
  userAvatar,
  pendingLeave = 0,
}: SidebarProps) {
  const pathname   = usePathname();
  const { accent } = useAccent();

  const visibleItems = NAV_ITEMS.filter(i => i.roles.includes(role));

  return (
    <aside style={{
      width: 232,
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: B.navBg,
      borderRight: `1px solid ${B.navBorder}`,
      flexShrink: 0,
    }}>
      {/* Logo / brand strip */}
      <div style={{
        height: 56,
        display: 'flex',
        alignItems: 'center',
        padding: '0 16px',
        borderBottom: `1px solid ${B.navBorder}`,
        gap: 10,
      }}>
        <div style={{
          width: 30, height: 30,
          borderRadius: 8,
          background: accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14, fontWeight: 800, color: '#fff', flexShrink: 0,
        }}>
          R
        </div>
        <span style={{ fontSize: 14, fontWeight: 700, color: B.navActive, letterSpacing: '-0.3px' }}>
          {role === 'contractor' ? 'Contractor Portal' : 'Recruit Admin'}
        </span>
      </div>

      {/* Nav items */}
      <nav style={{ flex: 1, padding: '10px 8px', overflowY: 'auto' }}>
        {visibleItems.map(item => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
          const badge    = item.label === 'Leave' ? pendingLeave : (item.badge ?? 0);

          return (
            <Link
              key={item.href}
              href={item.href}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '9px 10px',
                borderRadius: 8,
                marginBottom: 2,
                background: isActive ? `${accent}22` : 'transparent',
                color: isActive ? B.navActive : B.navText,
                fontWeight: isActive ? 600 : 400,
                fontSize: 13.5,
                textDecoration: 'none',
                transition: 'background 0.12s, color 0.12s',
                position: 'relative',
              }}
            >
              {/* Active indicator bar */}
              {isActive && (
                <span style={{
                  position: 'absolute', left: 0, top: '20%', bottom: '20%',
                  width: 3, borderRadius: '0 3px 3px 0',
                  background: accent,
                }} />
              )}

              <span style={{ opacity: isActive ? 1 : 0.7, color: isActive ? accent : 'inherit' }}>
                {item.icon}
              </span>
              <span style={{ flex: 1 }}>{item.label}</span>

              {badge > 0 && (
                <span style={{
                  background: accent,
                  color: '#fff',
                  fontSize: 10, fontWeight: 700,
                  borderRadius: 99, padding: '1px 6px',
                  lineHeight: '16px',
                  minWidth: 20, textAlign: 'center',
                }}>
                  {badge > 99 ? '99+' : badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Bottom: org switcher + user */}
      <div style={{ padding: '8px 8px 12px', borderTop: `1px solid ${B.navBorder}` }}>
        {/* Org switcher */}
        <div style={{ marginBottom: 8 }}>
          <OrgSwitcher currentOrgId={currentOrgId} />
        </div>

        {/* User pill */}
        {userName && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8,
            padding: '8px 10px',
            borderRadius: 8,
            background: 'rgba(255,255,255,0.04)',
          }}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
              background: accent,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 11, fontWeight: 700, color: '#fff',
              overflow: 'hidden',
            }}>
              {userAvatar
                ? <img src={userAvatar} alt={userName} width={28} height={28} style={{ objectFit: 'cover' }} />
                : userName.slice(0, 1).toUpperCase()
              }
            </div>
            <div style={{ flex: 1, overflow: 'hidden' }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: B.navActive, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {userName}
              </div>
              <div style={{ fontSize: 10, color: B.navText, textTransform: 'capitalize' }}>{role}</div>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}

// ── Icons ─────────────────────────────────────────────────────────────────────
function DashIcon()     { return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.4"/><rect x="9" y="1" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.4"/><rect x="1" y="9" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.4"/><rect x="9" y="9" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.4"/></svg>; }
function PeopleIcon()   { return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="6" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.4"/><path d="M1 13c0-2.761 2.239-5 5-5s5 2.239 5 5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/><circle cx="12" cy="5" r="2" stroke="currentColor" strokeWidth="1.4"/><path d="M14 13c0-2.209-1.343-4-3-4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>; }
function ClockIcon()    { return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.4"/><path d="M8 4.5V8l2.5 2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>; }
function LeaveIcon()    { return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="2" y="3" width="12" height="11" rx="2" stroke="currentColor" strokeWidth="1.4"/><path d="M5 1v3M11 1v3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/><path d="M2 7h12" stroke="currentColor" strokeWidth="1.4"/><path d="M5.5 10.5l1.5 1.5L11 9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>; }
function PayIcon()      { return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="4" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.4"/><path d="M1 7h14" stroke="currentColor" strokeWidth="1.4"/><circle cx="5" cy="10.5" r="1" fill="currentColor"/></svg>; }
function InvoiceIcon()  { return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 1H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V5l-4-4z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/><path d="M10 1v4h4M5 9h6M5 12h4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>; }
function ChartIcon()    { return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 12l3.5-4 3 2.5L12 5l2 2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/><path d="M2 14h12" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>; }
function SettingsIcon() { return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="2.5" stroke="currentColor" strokeWidth="1.4"/><path d="M8 1v1.5M8 13.5V15M1 8h1.5M13.5 8H15M2.929 2.929l1.06 1.06M12.01 12.01l1.06 1.06M2.929 13.07l1.06-1.06M12.01 3.99l1.06-1.06" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>; }
function DocIcon()      { return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 1H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V5l-4-4z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/><path d="M10 1v4h4M5 8h6M5 11h4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>; }
