'use client';

// components/layout/AccentProvider.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Injects the org's accent colour as --accent CSS variable on <html>.
// Wrap app layout with this so B.accent and all Tailwind accent-* utilities
// pick up the correct per-org colour at runtime without a full re-render.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, createContext, useContext, useState, useCallback } from 'react';

interface AccentContextValue {
  accent: string;
  setAccent: (colour: string) => void;
}

const AccentContext = createContext<AccentContextValue>({
  accent: '#6366f1',
  setAccent: () => {},
});

export function useAccent() {
  return useContext(AccentContext);
}

interface AccentProviderProps {
  /** Initial accent colour — typically from org row in DB */
  initialAccent?: string;
  children: React.ReactNode;
}

export function AccentProvider({ initialAccent = '#6366f1', children }: AccentProviderProps) {
  const [accent, _setAccent] = useState(initialAccent);

  const applyAccent = useCallback((colour: string) => {
    document.documentElement.style.setProperty('--accent', colour);

    // Derive lighter variants for hover states / backgrounds
    // Simple approach: just store the base; components derive opacity via Tailwind
    document.documentElement.style.setProperty('--accent-light', colour + '22'); // ~13% opacity
    document.documentElement.style.setProperty('--accent-muted', colour + '44'); // ~27% opacity
  }, []);

  // Apply on mount (and whenever initialAccent changes — e.g. org switch)
  useEffect(() => {
    applyAccent(initialAccent);
    _setAccent(initialAccent);
  }, [initialAccent, applyAccent]);

  const setAccent = useCallback((colour: string) => {
    _setAccent(colour);
    applyAccent(colour);
  }, [applyAccent]);

  return (
    <AccentContext.Provider value={{ accent, setAccent }}>
      {children}
    </AccentContext.Provider>
  );
}

// ── Convenience hook: returns inline style with accent background ─────────────
export function useAccentStyle(options?: { opacity?: number; asText?: boolean }) {
  const { accent } = useAccent();
  if (options?.asText) return { color: accent };
  return { backgroundColor: accent };
}
