'use client';

// components/layout/OrgSwitcher.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Multi-tenant org switcher dropdown.
// Fetches the user's orgs from /api/org, lets them switch, then refreshes
// the router so all server components re-fetch with the new org context.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useRef, useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useAccent } from './AccentProvider';
import { B } from '@/lib/design';

interface Org {
  id:           string;
  name:         string;
  slug:         string;
  accent_colour: string;
  logo_url?:    string | null;
}

interface OrgSwitcherProps {
  currentOrgId: string;
  /** Called after a successful switch so the parent can update server state */
  onSwitch?: (org: Org) => void;
}

export default function OrgSwitcher({ currentOrgId, onSwitch }: OrgSwitcherProps) {
  const router = useRouter();
  const { setAccent } = useAccent();
  const [orgs, setOrgs]       = useState<Org[]>([]);
  const [current, setCurrent] = useState<Org | null>(null);
  const [open, setOpen]       = useState(false);
  const [isPending, startTransition] = useTransition();
  const ref = useRef<HTMLDivElement>(null);

  // ── Load orgs ───────────────────────────────────────────────────────────────
  useEffect(() => {
    fetch('/api/org')
      .then(r => r.json())
      .then(({ orgs }: { orgs: Org[] }) => {
        setOrgs(orgs);
        const found = orgs.find(o => o.id === currentOrgId) ?? orgs[0] ?? null;
        setCurrent(found);
        if (found) setAccent(found.accent_colour);
      })
      .catch(console.error);
  }, [currentOrgId, setAccent]);

  // ── Close on outside click ──────────────────────────────────────────────────
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSwitch = async (org: Org) => {
    setOpen(false);
    if (org.id === current?.id) return;

    try {
      const res = await fetch('/api/org', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ orgId: org.id }),
      });
      if (!res.ok) throw new Error('Switch failed');

      setCurrent(org);
      setAccent(org.accent_colour);
      onSwitch?.(org);

      startTransition(() => {
        router.refresh();
      });
    } catch (err) {
      console.error('Org switch error:', err);
    }
  };

  if (!current || orgs.length <= 1) {
    // Single org — just show name, no dropdown
    return (
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '6px 10px',
        borderRadius: 8,
        background: B.navBorder,
        color: B.navText,
        fontSize: 13,
        fontWeight: 500,
      }}>
        <OrgAvatar org={current} size={22} />
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 140 }}>
          {current?.name ?? 'Loading…'}
        </span>
      </div>
    );
  }

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      {/* Trigger button */}
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          display: 'flex', alignItems: 'center', gap: 8,
          width: '100%',
          padding: '7px 10px',
          borderRadius: 8,
          border: `1px solid ${open ? B.accent : B.navBorder}`,
          background: open ? 'rgba(255,255,255,0.06)' : 'transparent',
          color: B.navActive,
          fontSize: 13,
          fontWeight: 500,
          cursor: 'pointer',
          transition: 'all 0.15s',
        }}
      >
        <OrgAvatar org={current} size={22} />
        <span style={{ flex: 1, textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {current.name}
        </span>
        <ChevronIcon open={open} />
      </button>

      {/* Dropdown */}
      {open && (
        <div style={{
          position: 'absolute', bottom: 'calc(100% + 6px)', left: 0, right: 0,
          background: '#1a2232',
          border: `1px solid ${B.navBorder}`,
          borderRadius: 10,
          boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
          overflow: 'hidden',
          zIndex: 200,
          animation: 'fadeUp 0.18s ease both',
        }}>
          <div style={{ padding: '6px 10px 4px', fontSize: 10, fontWeight: 600, color: B.navText, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
            Switch organisation
          </div>
          {orgs.map(org => (
            <button
              key={org.id}
              onClick={() => handleSwitch(org)}
              disabled={isPending}
              style={{
                display: 'flex', alignItems: 'center', gap: 10,
                width: '100%',
                padding: '9px 10px',
                background: org.id === current.id ? 'rgba(255,255,255,0.07)' : 'transparent',
                border: 'none',
                borderRadius: 0,
                color: org.id === current.id ? B.navActive : B.navText,
                fontSize: 13,
                fontWeight: org.id === current.id ? 600 : 400,
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'background 0.1s',
              }}
              onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.05)')}
              onMouseLeave={e => (e.currentTarget.style.background = org.id === current.id ? 'rgba(255,255,255,0.07)' : 'transparent')}
            >
              <OrgAvatar org={org} size={24} />
              <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {org.name}
              </span>
              {org.id === current.id && (
                <CheckIcon />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────────────────────────

function OrgAvatar({ org, size }: { org: Org | null; size: number }) {
  const { accent } = useAccent();
  if (!org) return <div style={{ width: size, height: size, borderRadius: 6, background: B.navBorder }} />;

  if (org.logo_url) {
    return (
      <img
        src={org.logo_url}
        alt={org.name}
        width={size}
        height={size}
        style={{ borderRadius: 6, objectFit: 'cover', flexShrink: 0 }}
      />
    );
  }

  return (
    <div style={{
      width: size, height: size, borderRadius: 6, flexShrink: 0,
      background: org.accent_colour ?? accent,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: size * 0.45, fontWeight: 700, color: '#fff',
    }}>
      {org.name.slice(0, 1).toUpperCase()}
    </div>
  );
}

function ChevronIcon({ open }: { open: boolean }) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" style={{ transition: 'transform 0.15s', transform: open ? 'rotate(180deg)' : 'rotate(0deg)', flexShrink: 0 }}>
      <path d="M3 5l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M2.5 7l3.5 3.5 5.5-6" stroke="#10b981" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
