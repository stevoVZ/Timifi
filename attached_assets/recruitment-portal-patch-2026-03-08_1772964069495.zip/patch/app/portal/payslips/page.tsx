'use client';

// app/portal/payslips/page.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Contractor payslips portal page.
// Shows a YTD summary strip at the top, then a table of payslips with
// per-row PDF download buttons.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useState } from 'react';
import { B, Shadow, R, StatusColour } from '@/lib/design';
import { useAccent } from '@/components/layout/AccentProvider';

interface Payslip {
  id:           string;
  pay_date:     string;
  period_start: string;
  period_end:   string;
  gross_amount: number;
  tax_amount:   number;
  super_amount: number;
  net_amount:   number;
  pdf_url:      string | null;
  status:       string;
}

interface YTD {
  gross:  number;
  tax:    number;
  super_: number;
  net:    number;
}

const money = (n: number) =>
  new Intl.NumberFormat('en-AU', { style: 'currency', currency: 'AUD', maximumFractionDigits: 0 }).format(n);

const fmtDate = (iso: string) =>
  new Date(iso).toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' });

export default function PayslipsPage() {
  const { accent }              = useAccent();
  const [payslips, setPayslips] = useState<Payslip[]>([]);
  const [ytd, setYtd]           = useState<YTD>({ gross: 0, tax: 0, super_: 0, net: 0 });
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState('');
  const [downloading, setDownloading] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/payslips')
      .then(r => r.json())
      .then(data => {
        setPayslips(data.payslips ?? []);
        setYtd(data.ytd ?? { gross: 0, tax: 0, super_: 0, net: 0 });
      })
      .catch(() => setError('Failed to load payslips.'))
      .finally(() => setLoading(false));
  }, []);

  const handleDownload = async (ps: Payslip) => {
    setDownloading(ps.id);
    try {
      const res = await fetch(`/api/payslips/${ps.id}`);
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = `payslip-${ps.pay_date}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      alert('Could not download payslip. Please try again.');
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div style={{ padding: '32px 28px', maxWidth: 900, margin: '0 auto' }}>
      {/* Page header */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: B.text, marginBottom: 4 }}>
          My Payslips
        </h1>
        <p style={{ fontSize: 13, color: B.textMuted }}>
          Download payslips and track your year-to-date earnings.
        </p>
      </div>

      {/* YTD Summary strip */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: 12,
        marginBottom: 28,
      }}>
        {[
          { label: 'Gross YTD',  value: ytd.gross,  icon: '💰', colour: accent  },
          { label: 'Tax YTD',    value: ytd.tax,    icon: '🏛️', colour: '#f59e0b' },
          { label: 'Super YTD',  value: ytd.super_, icon: '🏦', colour: '#10b981' },
          { label: 'Net YTD',    value: ytd.net,    icon: '✅', colour: '#6366f1' },
        ].map(card => (
          <div
            key={card.label}
            style={{
              background: B.surface,
              border: `1px solid ${B.border}`,
              borderRadius: R.lg,
              padding: '18px 16px',
              boxShadow: Shadow.sm,
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            {/* Accent top bar */}
            <div style={{
              position: 'absolute', top: 0, left: 0, right: 0,
              height: 3, background: card.colour,
            }} />
            <div style={{ fontSize: 18, marginBottom: 6 }}>{card.icon}</div>
            <div style={{ fontSize: 11, fontWeight: 600, color: B.textMuted, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>
              {card.label}
            </div>
            {loading ? (
              <div style={{ height: 26, width: 80, background: B.bg, borderRadius: 4, animation: 'pulse 1.4s ease infinite' }} />
            ) : (
              <div style={{ fontSize: 20, fontWeight: 700, color: B.text }}>
                {money(card.value)}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Payslips table */}
      <div style={{
        background: B.surface,
        border: `1px solid ${B.border}`,
        borderRadius: R.lg,
        boxShadow: Shadow.md,
        overflow: 'hidden',
      }}>
        <div style={{
          padding: '14px 20px',
          borderBottom: `1px solid ${B.border}`,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <span style={{ fontSize: 14, fontWeight: 600, color: B.text }}>
            Payslip History
          </span>
          <span style={{ fontSize: 12, color: B.textMuted }}>
            {payslips.length} payslip{payslips.length !== 1 ? 's' : ''}
          </span>
        </div>

        {loading ? (
          <SkeletonRows />
        ) : error ? (
          <div style={{ padding: 32, textAlign: 'center', color: B.danger, fontSize: 13 }}>{error}</div>
        ) : payslips.length === 0 ? (
          <div style={{ padding: 48, textAlign: 'center' }}>
            <div style={{ fontSize: 36, marginBottom: 10 }}>📄</div>
            <div style={{ fontSize: 14, color: B.textMuted }}>No payslips yet.</div>
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: B.bg }}>
                {['Pay Date', 'Period', 'Gross', 'Tax', 'Super', 'Net', 'Status', ''].map(h => (
                  <th key={h} style={{
                    padding: '10px 16px',
                    textAlign: h === '' ? 'center' : 'left',
                    fontSize: 11, fontWeight: 600,
                    color: B.textMuted, textTransform: 'uppercase', letterSpacing: '0.06em',
                    borderBottom: `1px solid ${B.border}`,
                  }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {payslips.map((ps, i) => {
                const sc = StatusColour[ps.status] ?? StatusColour.inactive;
                return (
                  <tr
                    key={ps.id}
                    style={{
                      borderBottom: i < payslips.length - 1 ? `1px solid ${B.borderLight}` : 'none',
                      transition: 'background 0.1s',
                    }}
                    onMouseEnter={e => ((e.currentTarget as HTMLTableRowElement).style.background = B.bg)}
                    onMouseLeave={e => ((e.currentTarget as HTMLTableRowElement).style.background = 'transparent')}
                  >
                    <td style={tdStyle}>{fmtDate(ps.pay_date)}</td>
                    <td style={{ ...tdStyle, color: B.textMuted, fontSize: 12 }}>
                      {fmtDate(ps.period_start)} – {fmtDate(ps.period_end)}
                    </td>
                    <td style={{ ...tdStyle, fontWeight: 600 }}>{money(ps.gross_amount)}</td>
                    <td style={{ ...tdStyle, color: B.textMuted }}>{money(ps.tax_amount)}</td>
                    <td style={{ ...tdStyle, color: B.textMuted }}>{money(ps.super_amount)}</td>
                    <td style={{ ...tdStyle, fontWeight: 700, color: accent }}>{money(ps.net_amount)}</td>
                    <td style={tdStyle}>
                      <span style={{
                        background: sc.bg, color: sc.text,
                        fontSize: 11, fontWeight: 600,
                        borderRadius: 99, padding: '3px 10px',
                        textTransform: 'capitalize',
                      }}>
                        {ps.status}
                      </span>
                    </td>
                    <td style={{ ...tdStyle, textAlign: 'center' }}>
                      <button
                        onClick={() => handleDownload(ps)}
                        disabled={downloading === ps.id}
                        title="Download PDF"
                        style={{
                          padding: '5px 12px',
                          borderRadius: R.sm,
                          border: `1px solid ${B.border}`,
                          background: B.surface,
                          color: accent,
                          fontSize: 12, fontWeight: 600,
                          cursor: downloading === ps.id ? 'wait' : 'pointer',
                          display: 'inline-flex', alignItems: 'center', gap: 4,
                          transition: 'all 0.15s',
                        }}
                      >
                        {downloading === ps.id ? '…' : '↓ PDF'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const tdStyle: React.CSSProperties = {
  padding: '13px 16px',
  fontSize: 13,
  color: B.text,
};

function SkeletonRows() {
  return (
    <div style={{ padding: '8px 0' }}>
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} style={{ display: 'flex', gap: 12, padding: '14px 20px', alignItems: 'center' }}>
          {[100, 160, 80, 70, 70, 80, 60, 60].map((w, j) => (
            <div key={j} style={{ height: 14, width: w, borderRadius: 4, background: B.bg, animation: 'pulse 1.4s ease infinite', flexShrink: 0 }} />
          ))}
        </div>
      ))}
    </div>
  );
}
