'use client';

// app/admin/contractors/[id]/DocumentsTab.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Document management tab on the contractor detail page.
// Admins can upload, categorise, and delete contractor documents.
// Files are uploaded to Supabase Storage via /api/contractors/[id]/documents.
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useRef, useState } from 'react';
import { B, Shadow, R } from '@/lib/design';
import { useAccent } from '@/components/layout/AccentProvider';

interface Document {
  id:          string;
  name:        string;
  category:    string;
  file_url:    string;
  file_size:   number;
  uploaded_at: string;
  uploaded_by: string;
}

const CATEGORIES = [
  'Contract',
  'Tax File Number Declaration',
  'Super Choice Form',
  'ID Verification',
  'Police Check',
  'Working With Vulnerable People',
  'Qualification / Certification',
  'Other',
];

const CATEGORY_ICONS: Record<string, string> = {
  'Contract':                         '📝',
  'Tax File Number Declaration':       '🏛️',
  'Super Choice Form':                 '🏦',
  'ID Verification':                   '🪪',
  'Police Check':                      '🔍',
  'Working With Vulnerable People':    '🛡️',
  'Qualification / Certification':     '🎓',
  'Other':                             '📄',
};

const fmt = (bytes: number) => {
  if (bytes < 1024)        return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

const fmtDate = (iso: string) =>
  new Date(iso).toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' });

interface DocumentsTabProps {
  contractorId: string;
}

export default function DocumentsTab({ contractorId }: DocumentsTabProps) {
  const { accent }          = useAccent();
  const fileRef             = useRef<HTMLInputElement>(null);

  const [docs,        setDocs]       = useState<Document[]>([]);
  const [loading,     setLoading]    = useState(true);
  const [uploading,   setUploading]  = useState(false);
  const [dragOver,    setDragOver]   = useState(false);
  const [file,        setFile]       = useState<File | null>(null);
  const [category,    setCategory]   = useState(CATEGORIES[0]);
  const [customName,  setCustomName] = useState('');
  const [error,       setError]      = useState('');
  const [deleteId,    setDeleteId]   = useState<string | null>(null);

  // ── Load documents ──────────────────────────────────────────────────────────
  useEffect(() => {
    fetch(`/api/contractors/${contractorId}/documents`)
      .then(r => r.json())
      .then(d => setDocs(d.documents ?? []))
      .catch(() => setError('Failed to load documents.'))
      .finally(() => setLoading(false));
  }, [contractorId]);

  // ── File validation ─────────────────────────────────────────────────────────
  const validateFile = (f: File) => {
    const allowed = [
      'application/pdf',
      'image/jpeg', 'image/png', 'image/webp',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    ];
    if (!allowed.includes(f.type)) {
      setError('Unsupported file type. Please upload PDF, image, or Word document.');
      return false;
    }
    if (f.size > 20 * 1024 * 1024) {
      setError('File must be under 20 MB.');
      return false;
    }
    setError('');
    return true;
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f && validateFile(f)) {
      setFile(f);
      if (!customName) setCustomName(f.name.replace(/\.[^.]+$/, ''));
    }
  };

  // ── Upload ──────────────────────────────────────────────────────────────────
  const handleUpload = async () => {
    if (!file)     { setError('Please select a file.'); return; }
    if (!category) { setError('Please select a category.'); return; }

    setUploading(true);
    setError('');

    try {
      const form = new FormData();
      form.append('file',     file);
      form.append('category', category);
      form.append('name',     customName || file.name);

      const res  = await fetch(`/api/contractors/${contractorId}/documents`, {
        method: 'POST', body: form,
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error ?? 'Upload failed');

      setDocs(prev => [data.document, ...prev]);
      setFile(null);
      setCustomName('');
      setCategory(CATEGORIES[0]);
      if (fileRef.current) fileRef.current.value = '';
    } catch (e: any) {
      setError(e.message);
    } finally {
      setUploading(false);
    }
  };

  // ── Delete ──────────────────────────────────────────────────────────────────
  const handleDelete = async (docId: string) => {
    setDeleteId(docId);
    try {
      const res = await fetch(`/api/contractors/${contractorId}/documents/${docId}`, {
        method: 'DELETE',
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? 'Delete failed');
      }
      setDocs(prev => prev.filter(d => d.id !== docId));
    } catch (e: any) {
      alert(e.message);
    } finally {
      setDeleteId(null);
    }
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 24, alignItems: 'start' }}>

      {/* ── Document list ────────────────────────────────────────────────────── */}
      <div>
        <h3 style={{ fontSize: 15, fontWeight: 600, color: B.text, marginBottom: 14 }}>
          Documents ({docs.length})
        </h3>

        {loading ? (
          <SkeletonList />
        ) : docs.length === 0 ? (
          <div style={{
            background: B.bg, border: `1px dashed ${B.border}`,
            borderRadius: R.lg, padding: 36, textAlign: 'center',
          }}>
            <div style={{ fontSize: 30, marginBottom: 8 }}>📂</div>
            <div style={{ fontSize: 13, color: B.textMuted }}>No documents uploaded yet.</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {docs.map(doc => (
              <div
                key={doc.id}
                style={{
                  background: B.surface, border: `1px solid ${B.border}`,
                  borderRadius: R.md, padding: '13px 14px',
                  display: 'flex', alignItems: 'center', gap: 12,
                  boxShadow: Shadow.sm,
                }}
              >
                {/* Icon */}
                <div style={{
                  width: 38, height: 38, borderRadius: R.sm, flexShrink: 0,
                  background: `${accent}15`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 18,
                }}>
                  {CATEGORY_ICONS[doc.category] ?? '📄'}
                </div>

                {/* Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: B.text, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {doc.name}
                  </div>
                  <div style={{ fontSize: 11, color: B.textMuted, marginTop: 1 }}>
                    {doc.category} · {fmt(doc.file_size)} · {fmtDate(doc.uploaded_at)}
                  </div>
                </div>

                {/* Actions */}
                <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                  <a
                    href={doc.file_url}
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      padding: '5px 10px', borderRadius: R.sm,
                      border: `1px solid ${B.border}`, background: B.surface,
                      color: accent, fontSize: 12, fontWeight: 600,
                      textDecoration: 'none',
                    }}
                  >
                    View
                  </a>
                  <button
                    onClick={() => handleDelete(doc.id)}
                    disabled={deleteId === doc.id}
                    title="Delete document"
                    style={{
                      padding: '5px 10px', borderRadius: R.sm,
                      border: `1px solid #fecaca`, background: '#fef2f2',
                      color: '#dc2626', fontSize: 12, fontWeight: 600,
                      cursor: deleteId === doc.id ? 'wait' : 'pointer',
                    }}
                  >
                    {deleteId === doc.id ? '…' : 'Delete'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Upload panel ─────────────────────────────────────────────────────── */}
      <div style={{
        background: B.surface, border: `1px solid ${B.border}`,
        borderRadius: R.lg, padding: 20, boxShadow: Shadow.md,
      }}>
        <h3 style={{ fontSize: 14, fontWeight: 600, color: B.text, marginBottom: 16 }}>
          Upload Document
        </h3>

        {/* Drop zone */}
        <div
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => fileRef.current?.click()}
          style={{
            border: `2px dashed ${dragOver ? accent : file ? '#10b981' : B.border}`,
            borderRadius: R.md, padding: '22px 16px', textAlign: 'center',
            cursor: 'pointer', marginBottom: 14,
            background: dragOver ? `${accent}0d` : file ? '#ecfdf5' : B.bg,
            transition: 'all 0.15s',
          }}
        >
          {file ? (
            <>
              <div style={{ fontSize: 20, marginBottom: 4 }}>📄</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#059669' }}>{file.name}</div>
              <div style={{ fontSize: 10, color: B.textMuted, marginTop: 2 }}>{fmt(file.size)}</div>
            </>
          ) : (
            <>
              <div style={{ fontSize: 24, marginBottom: 4 }}>☁️</div>
              <div style={{ fontSize: 12, color: B.textMuted }}>
                Drag & drop or <span style={{ color: accent, fontWeight: 600 }}>browse</span>
              </div>
              <div style={{ fontSize: 10, color: B.textFaint, marginTop: 2 }}>PDF, Word, images — max 20 MB</div>
            </>
          )}
        </div>
        <input
          ref={fileRef}
          type="file"
          accept=".pdf,.doc,.docx,image/*"
          onChange={e => {
            const f = e.target.files?.[0];
            if (f && validateFile(f)) {
              setFile(f);
              if (!customName) setCustomName(f.name.replace(/\.[^.]+$/, ''));
            }
          }}
          style={{ display: 'none' }}
        />

        {/* Document name */}
        <label style={labelStyle}>Document Name</label>
        <input
          type="text"
          value={customName}
          onChange={e => setCustomName(e.target.value)}
          placeholder="e.g. Employment Contract 2024"
          style={{ ...inputStyle, marginBottom: 12 }}
        />

        {/* Category */}
        <label style={labelStyle}>Category</label>
        <select
          value={category}
          onChange={e => setCategory(e.target.value)}
          style={{ ...inputStyle, marginBottom: 14, appearance: 'none' }}
        >
          {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>

        {error && (
          <div style={{
            background: '#fef2f2', border: '1px solid #fecaca',
            borderRadius: R.sm, padding: '7px 10px',
            fontSize: 11, color: '#dc2626', marginBottom: 12,
          }}>
            {error}
          </div>
        )}

        <button
          onClick={handleUpload}
          disabled={uploading || !file}
          style={{
            width: '100%', padding: '10px 0',
            borderRadius: R.md, border: 'none',
            background: !file ? B.bg : accent,
            color: !file ? B.textMuted : '#fff',
            fontSize: 13, fontWeight: 600,
            cursor: uploading || !file ? 'not-allowed' : 'pointer',
            transition: 'all 0.15s',
          }}
        >
          {uploading ? 'Uploading…' : 'Upload Document'}
        </button>
      </div>
    </div>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const labelStyle: React.CSSProperties = {
  display: 'block', fontSize: 11, fontWeight: 600,
  color: B.textMuted, marginBottom: 4, letterSpacing: '0.03em',
};

const inputStyle: React.CSSProperties = {
  width: '100%', padding: '8px 10px', borderRadius: R.sm,
  border: `1px solid ${B.border}`, background: B.bg,
  fontSize: 12, color: B.text, outline: 'none', boxSizing: 'border-box',
};

function SkeletonList() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} style={{
          height: 62, borderRadius: R.md, background: B.bg,
          animation: 'pulse 1.4s ease infinite',
        }} />
      ))}
    </div>
  );
}
