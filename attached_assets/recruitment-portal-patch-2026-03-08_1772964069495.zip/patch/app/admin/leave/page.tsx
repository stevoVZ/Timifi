'use client';

// app/admin/leave/page.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Admin leave approval queue.
// Lists all pending leave requests for the org, with approve / reject actions
// and current leave balance display per contractor.
// ─────────────────────────────────────────────────────────────────────────────

import { useCallback, useEffect, useState } from 'react';
import { B, Shadow, R, StatusColour } from '@/lib/design';
import { useAccent } from '@/components/layout/AccentProvider';

interface LeaveType {
  id:    string;
  name:  string;
  color: string;
}

interface LeaveBalance {
  balance_days: number;
  taken_ytd:    number;
  accrued_ytd:  number;
  leave_types:  LeaveType;
}

interface Contractor {
  id:          string;
  full_name:   string;
  position:    string;
  avatar_url?: string | null;
  leave_balances: LeaveBalance[];
}

interface LeaveRequest {
  id:             string;
  start_date:     string;
  end_date:       string;
  days_requested: number;
  reason:         string | null;
  status:         'pending' | 'approved' | 'rejected';
  reviewer_note:  string | null;
  reviewed_at:    string | null;
  created_at:     string;
  leave_types:    LeaveType;
  contractors:    Contractor;
}

type FilterStatus = 'pending' | 'approved' | 'rejected' | 'all';

const fmtDate = (iso: string) =>
  new Date(iso).toLocaleDateString('en-AU', { day: '2-digit', month: 'short', year: 'numeric' });

const fmtRelative = (iso: string) => {
  const diff = Date.now() - new Date(iso).getTime();
  const d    = Math.floor(diff / 86400000);
  if (d === 0) return 'Today';
  if (d === 1) return 'Yesterday';
  if (d  <  7) return `${d} days ago`;
  return fmtDate(iso);
};

export default function AdminLeavePage() {
  const { accent }            = useAccent();
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [filter,   setFilter]   = useState<FilterStatus>('pending');
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState('');

  // Review modal state
  const [reviewTarget, setReviewTarget] = useState<LeaveRequest | null>(null);
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject' | null>(null);
  const [reviewNote,   setReviewNote]   = useState('');
  const [submitting,   setSubmitting]   = useState(false);

  const load = useCallback((status: FilterStatus) => {
    setLoading(true);
    const qs = status === 'all' ? 'admin=1' : `admin=1&status=${status}`;
    fetch(`/api/leave?${qs}`)
      .then(r => r.json())
      .then(d => setRequests(d.requests ?? []))
      .catch(() => setError('Failed to load leave requests.'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(filter); }, [filter, load]);

  const handleReview = async () => {
    if (!reviewTarget || !reviewAction) return;
    setSubmitting(true);
    try {
      const res = await fetch(`/api/leave/${reviewTarget.id}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ action: reviewAction, reviewerNote: reviewNote }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? 'Update failed');
      }
      // Update local state
      setRequests(prev =>
        prev.map(r =>
          r.id === reviewTarget.id
            ? { ...r, status: reviewAction === 'approve' ? 'approved' : 'rejected', reviewer_note: reviewNote }
            : r
        )
      );
      setReviewTarget(null);
      setReviewNote('');
      setReviewAction(null);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  const pendingCount = requests.filter(r => r.status === 'pending').length;

  return (
    <div style={{ padding: '32px 28px', maxWidth: 1000, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: B.text, marginBottom: 4 }}>
            Leave Requests
          </h1>
          <p style={{ fontSize: 13, color: B.textMuted }}>
            Review and action leave requests from contractors.
          </p>
        </div>
        {pendingCount > 0 && (
          <span style={{
            background: accent, color: '#fff',
            fontWeight: 700, fontSize: 13,
            borderRadius: 99, padding: '4px 14px',
          }}>
            {pendingCount} pending
          </span>
        )}
      </div>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 20 }}>
        {(['pending', 'approved', 'rejected', 'all'] as FilterStatus[]).map(s => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            style={{
              padding: '7px 16px',
              borderRadius: R.md,
              border: `1px solid ${filter === s ? accent : B.border}`,
              background: filter === s ? `${accent}18` : B.surface,
              color: filter === s ? accent : B.textMuted,
              fontSize: 13, fontWeight: filter === s ? 600 : 400,
              cursor: 'pointer', transition: 'all 0.15s',
              textTransform: 'capitalize',
            }}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Requests list */}
      {loading ? (
        <SkeletonCards />
      ) : error ? (
        <div style={{ padding: 32, textAlign: 'center', color: B.danger, fontSize: 13 }}>{error}</div>
      ) : requests.length === 0 ? (
        <div style={{
          background: B.surface, border: `1px solid ${B.border}`,
          borderRadius: R.lg, padding: 48, textAlign: 'center',
        }}>
          <div style={{ fontSize: 36, marginBottom: 10 }}>📋</div>
          <div style={{ fontSize: 14, color: B.textMuted }}>
            No {filter === 'all' ? '' : filter} leave requests.
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {requests.map(req => (
            <RequestCard
              key={req.id}
              req={req}
              accent={accent}
              onApprove={() => { setReviewTarget(req); setReviewAction('approve'); }}
              onReject={()  => { setReviewTarget(req); setReviewAction('reject');  }}
            />
          ))}
        </div>
      )}

      {/* Review modal */}
      {reviewTarget && reviewAction && (
        <div
          onClick={() => { setReviewTarget(null); setReviewNote(''); }}
          style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)',
            backdropFilter: 'blur(4px)', zIndex: 1000,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
        >
          <div
            onClick={e => e.stopPropagation()}
            style={{
              background: B.surface, borderRadius: R.xl,
              boxShadow: Shadow.xl, padding: 28,
              width: 480, maxWidth: '95vw',
            }}
          >
            <h3 style={{ fontSize: 17, fontWeight: 700, color: B.text, marginBottom: 4 }}>
              {reviewAction === 'approve' ? '✅ Approve' : '❌ Reject'} Leave Request
            </h3>
            <p style={{ fontSize: 13, color: B.textMuted, marginBottom: 16 }}>
              {reviewTarget.contractors.full_name} · {reviewTarget.days_requested} day(s) ·{' '}
              {fmtDate(reviewTarget.start_date)} – {fmtDate(reviewTarget.end_date)}
            </p>

            <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: B.textMuted, marginBottom: 4 }}>
              Note to contractor <span style={{ fontWeight: 400 }}>(optional)</span>
            </label>
            <textarea
              value={reviewNote}
              onChange={e => setReviewNote(e.target.value)}
              placeholder={reviewAction === 'approve' ? 'Approved — enjoy your leave!' : 'Reason for rejection…'}
              rows={3}
              style={{
                width: '100%', borderRadius: R.sm, border: `1px solid ${B.border}`,
                background: B.bg, padding: '9px 11px', fontSize: 13, color: B.text,
                outline: 'none', resize: 'vertical', marginBottom: 16, boxSizing: 'border-box',
              }}
            />

            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button
                onClick={() => { setReviewTarget(null); setReviewNote(''); }}
                style={{ padding: '9px 18px', borderRadius: R.md, border: `1px solid ${B.border}`, background: 'transparent', color: B.textMuted, fontSize: 13, cursor: 'pointer' }}
              >
                Cancel
              </button>
              <button
                onClick={handleReview}
                disabled={submitting}
                style={{
                  padding: '9px 20px', borderRadius: R.md, border: 'none',
                  background: reviewAction === 'approve' ? '#10b981' : '#ef4444',
                  color: '#fff', fontSize: 13, fontWeight: 600,
                  cursor: submitting ? 'wait' : 'pointer',
                  opacity: submitting ? 0.7 : 1,
                }}
              >
                {submitting ? 'Saving…' : reviewAction === 'approve' ? 'Approve' : 'Reject'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── RequestCard ───────────────────────────────────────────────────────────────
function RequestCard({
  req, accent, onApprove, onReject,
}: {
  req: LeaveRequest;
  accent: string;
  onApprove: () => void;
  onReject:  () => void;
}) {
  const sc = StatusColour[req.status] ?? StatusColour.inactive;
  const ctBalance = req.contractors.leave_balances?.find(
    b => b.leave_types.id === req.leave_types.id
  );

  return (
    <div style={{
      background: B.surface, border: `1px solid ${B.border}`,
      borderRadius: R.lg, padding: '18px 20px',
      boxShadow: Shadow.sm,
      display: 'grid', gridTemplateColumns: '1fr auto',
      gap: 16, alignItems: 'start',
    }}>
      {/* Left: info */}
      <div>
        {/* Contractor */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
          <ContractorAvatar c={req.contractors} accent={accent} />
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: B.text }}>{req.contractors.full_name}</div>
            <div style={{ fontSize: 11, color: B.textMuted }}>{req.contractors.position}</div>
          </div>
          <span style={{
            background: sc.bg, color: sc.text,
            fontSize: 10, fontWeight: 700,
            borderRadius: 99, padding: '2px 9px',
            textTransform: 'uppercase', letterSpacing: '0.05em',
            marginLeft: 'auto',
          }}>
            {req.status}
          </span>
        </div>

        {/* Leave details row */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, marginBottom: 8 }}>
          <Detail label="Type">
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: req.leave_types.color, display: 'inline-block' }} />
              {req.leave_types.name}
            </span>
          </Detail>
          <Detail label="Dates">
            {fmtDate(req.start_date)} – {fmtDate(req.end_date)}
          </Detail>
          <Detail label="Days">{req.days_requested}</Detail>
          <Detail label="Submitted">{fmtRelative(req.created_at)}</Detail>
          {ctBalance && (
            <Detail label="Balance remaining">
              <span style={{ color: ctBalance.balance_days < req.days_requested ? B.danger : B.success, fontWeight: 600 }}>
                {ctBalance.balance_days.toFixed(1)} days
              </span>
            </Detail>
          )}
        </div>

        {req.reason && (
          <div style={{
            background: B.bg, borderRadius: R.sm, padding: '8px 11px',
            fontSize: 12, color: B.textMuted, marginBottom: 6,
          }}>
            "{req.reason}"
          </div>
        )}

        {req.reviewer_note && (
          <div style={{ fontSize: 12, color: B.textMuted, fontStyle: 'italic' }}>
            Note: {req.reviewer_note}
          </div>
        )}
      </div>

      {/* Right: actions */}
      {req.status === 'pending' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, minWidth: 100 }}>
          <button
            onClick={onApprove}
            style={{
              padding: '8px 16px', borderRadius: R.md, border: 'none',
              background: '#ecfdf5', color: '#059669',
              fontSize: 13, fontWeight: 600, cursor: 'pointer',
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = '#d1fae5'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#ecfdf5'; }}
          >
            ✓ Approve
          </button>
          <button
            onClick={onReject}
            style={{
              padding: '8px 16px', borderRadius: R.md, border: 'none',
              background: '#fef2f2', color: '#dc2626',
              fontSize: 13, fontWeight: 600, cursor: 'pointer',
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = '#fee2e2'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#fef2f2'; }}
          >
            ✕ Reject
          </button>
        </div>
      )}
    </div>
  );
}

function Detail({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div style={{ fontSize: 10, fontWeight: 600, color: B.textFaint, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>
        {label}
      </div>
      <div style={{ fontSize: 13, color: B.text }}>{children}</div>
    </div>
  );
}

function ContractorAvatar({ c, accent }: { c: Contractor; accent: string }) {
  return c.avatar_url ? (
    <img src={c.avatar_url} alt={c.full_name} width={34} height={34}
      style={{ borderRadius: '50%', objectFit: 'cover', flexShrink: 0 }} />
  ) : (
    <div style={{
      width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
      background: accent, color: '#fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: 13, fontWeight: 700,
    }}>
      {c.full_name.slice(0, 1).toUpperCase()}
    </div>
  );
}

function SkeletonCards() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} style={{
          background: B.surface, border: `1px solid ${B.border}`,
          borderRadius: R.lg, padding: '18px 20px', height: 110,
          animation: 'pulse 1.4s ease infinite',
        }} />
      ))}
    </div>
  );
}
