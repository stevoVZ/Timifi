// app/api/payslips/[id]/route.ts
// ─────────────────────────────────────────────────────────────────────────────
// GET /api/payslips/:id          → download generated PDF payslip
//     If a pdf_url is already stored in Supabase, redirect to it.
//     Otherwise, generate on-the-fly with jsPDF and stream back.
// ─────────────────────────────────────────────────────────────────────────────

import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

type Params = { params: { id: string } };

export async function GET(req: NextRequest, { params }: Params) {
  const { id }      = params;
  const cookieStore = cookies();
  const supabase    = createRouteHandlerClient({ cookies: () => cookieStore });

  // ── Auth ────────────────────────────────────────────────────────────────────
  const { data: { user }, error: authErr } = await supabase.auth.getUser();
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role, organisation_id')
    .eq('id', user.id)
    .single();

  if (!profile) return NextResponse.json({ error: 'Profile not found' }, { status: 404 });

  // ── Fetch payslip ───────────────────────────────────────────────────────────
  const { data: payslip, error: psErr } = await supabase
    .from('payslips')
    .select(`
      id, pay_date, period_start, period_end,
      gross_amount, tax_amount, super_amount, net_amount,
      pdf_url, status, earnings_breakdown, organisation_id,
      contractors (
        id, full_name, position, profile_id,
        bank_bsb, bank_account_last4, bank_name
      ),
      organisations (
        name, abn, address, accent_colour
      )
    `)
    .eq('id', id)
    .single();

  if (psErr || !payslip) {
    return NextResponse.json({ error: 'Payslip not found' }, { status: 404 });
  }

  // ── Authorisation: contractor can only see own payslips ─────────────────────
  const isAdmin = ['admin', 'consultant'].includes(profile.role ?? '');

  if (!isAdmin) {
    const contractor = payslip.contractors as any;
    if (contractor?.profile_id !== user.id) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }
  }

  // Org guard
  if (payslip.organisation_id !== profile.organisation_id && !isAdmin) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  // ── If a stored PDF exists, redirect to it ──────────────────────────────────
  if (payslip.pdf_url) {
    return NextResponse.redirect(payslip.pdf_url);
  }

  // ── Generate PDF on-the-fly with jsPDF ─────────────────────────────────────
  // NOTE: jsPDF must be imported dynamically — it references browser APIs
  // so we lazy-load to avoid issues in the Node.js edge/server environment.
  // In production you may want to pre-generate and store in Supabase Storage.
  const { generatePayslipPDF } = await import('@/lib/payslip');

  const contractor = payslip.contractors as any;
  const org        = payslip.organisations as any;

  // Compute YTD for this contractor up to this payslip's pay date
  const { data: allPayslips } = await supabase
    .from('payslips')
    .select('pay_date, gross_amount, tax_amount, super_amount, net_amount')
    .eq('contractor_id', contractor.id)
    .lte('pay_date', payslip.pay_date)
    .order('pay_date', { ascending: true });

  const fyStart = (() => {
    const d = new Date(payslip.pay_date);
    return new Date(d.getMonth() >= 6 ? d.getFullYear() : d.getFullYear() - 1, 6, 1);
  })();

  const ytd = (allPayslips ?? [])
    .filter(p => new Date(p.pay_date) >= fyStart)
    .reduce(
      (acc, p) => ({
        gross:  acc.gross  + (p.gross_amount ?? 0),
        tax:    acc.tax    + (p.tax_amount   ?? 0),
        super_: acc.super_ + (p.super_amount ?? 0),
        net:    acc.net    + (p.net_amount   ?? 0),
      }),
      { gross: 0, tax: 0, super_: 0, net: 0 }
    );

  // Parse earnings breakdown (stored as JSON in DB, or fallback)
  const earnings: Array<{ description: string; hours?: number; rate?: number; amount: number }> =
    Array.isArray(payslip.earnings_breakdown)
      ? payslip.earnings_breakdown
      : [{ description: 'Base Salary / Wages', amount: payslip.gross_amount }];

  const doc = generatePayslipPDF({
    companyName:    org?.name    ?? 'Recruitment Co.',
    companyAbn:     org?.abn     ?? '',
    companyAddress: org?.address ?? '',
    accentColour:   org?.accent_colour ?? '#6366f1',

    employeeName:   contractor?.full_name ?? 'Contractor',
    employeeId:     contractor?.id?.slice(0, 8).toUpperCase() ?? '',
    position:       contractor?.position ?? '',
    payPeriodStart: payslip.period_start,
    payPeriodEnd:   payslip.period_end,
    payDate:        payslip.pay_date,

    earnings,
    tax:            payslip.tax_amount,
    superAmount:    payslip.super_amount,

    ytdGross:  ytd.gross,
    ytdTax:    ytd.tax,
    ytdSuper:  ytd.super_,
    ytdNet:    ytd.net,

    bankName:       contractor?.bank_name         ?? undefined,
    bsb:            contractor?.bank_bsb          ?? undefined,
    accountLast4:   contractor?.bank_account_last4 ?? undefined,
  });

  const pdfBytes = doc.output('arraybuffer');

  const filename = `payslip-${contractor?.full_name?.replace(/\s+/g, '-').toLowerCase() ?? 'contractor'}-${payslip.pay_date}.pdf`;

  return new NextResponse(pdfBytes, {
    headers: {
      'Content-Type':        'application/pdf',
      'Content-Disposition': `attachment; filename="${filename}"`,
      'Cache-Control':       'private, no-store',
    },
  });
}
