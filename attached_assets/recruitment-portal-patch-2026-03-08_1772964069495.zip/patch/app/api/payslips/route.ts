// app/api/payslips/route.ts
// ─────────────────────────────────────────────────────────────────────────────
// GET /api/payslips               → contractor: own payslips + YTD totals
//     /api/payslips?contractorId= → admin: specific contractor
//     /api/payslips?admin=1        → admin: all payslips in org
// ─────────────────────────────────────────────────────────────────────────────

import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

interface YTD {
  gross:  number;
  tax:    number;
  super_: number;
  net:    number;
}

function computeYTD(payslips: any[]): YTD {
  // YTD = financial year to date (1 July → 30 June)
  const now     = new Date();
  const fyStart = new Date(
    now.getMonth() >= 6 ? now.getFullYear() : now.getFullYear() - 1,
    6, // July
    1
  );

  return payslips
    .filter(p => new Date(p.pay_date) >= fyStart)
    .reduce<YTD>(
      (acc, p) => ({
        gross:  acc.gross  + (p.gross_amount ?? 0),
        tax:    acc.tax    + (p.tax_amount   ?? 0),
        super_: acc.super_ + (p.super_amount ?? 0),
        net:    acc.net    + (p.net_amount   ?? 0),
      }),
      { gross: 0, tax: 0, super_: 0, net: 0 }
    );
}

export async function GET(req: NextRequest) {
  const cookieStore = cookies();
  const supabase    = createRouteHandlerClient({ cookies: () => cookieStore });

  const { data: { user }, error: authErr } = await supabase.auth.getUser();
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role, organisation_id')
    .eq('id', user.id)
    .single();

  if (!profile) return NextResponse.json({ error: 'Profile not found' }, { status: 404 });

  const isAdmin      = ['admin', 'consultant'].includes(profile.role ?? '');
  const adminMode    = req.nextUrl.searchParams.get('admin') === '1' && isAdmin;
  const contractorIdParam = req.nextUrl.searchParams.get('contractorId');

  const PAYSLIP_FIELDS = `
    id, pay_date, period_start, period_end,
    gross_amount, tax_amount, super_amount, net_amount,
    pdf_url, status,
    contractors ( id, full_name, position )
  `;

  // ── Admin: all payslips in org, or specific contractor ──────────────────────
  if (isAdmin && (adminMode || contractorIdParam)) {
    let query = supabase
      .from('payslips')
      .select(PAYSLIP_FIELDS)
      .eq('organisation_id', profile.organisation_id)
      .order('pay_date', { ascending: false });

    if (contractorIdParam) {
      query = query.eq('contractor_id', contractorIdParam);
    }

    const { data: payslips, error } = await query;
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });

    const ytd = computeYTD(payslips ?? []);
    return NextResponse.json({ payslips: payslips ?? [], ytd });
  }

  // ── Contractor: own payslips ────────────────────────────────────────────────
  const { data: contractor } = await supabase
    .from('contractors')
    .select('id')
    .eq('profile_id', user.id)
    .single();

  if (!contractor) return NextResponse.json({ error: 'Contractor record not found' }, { status: 404 });

  const { data: payslips, error } = await supabase
    .from('payslips')
    .select(PAYSLIP_FIELDS)
    .eq('contractor_id', contractor.id)
    .order('pay_date', { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const ytd = computeYTD(payslips ?? []);

  return NextResponse.json({ payslips: payslips ?? [], ytd });
}
