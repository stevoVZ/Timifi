// app/api/org/route.ts
// ─────────────────────────────────────────────────────────────────────────────
// GET  /api/org          → return orgs the current user belongs to
// POST /api/org { orgId } → switch active org (stored in cookie)
// ─────────────────────────────────────────────────────────────────────────────

import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

const ORG_COOKIE = 'active_org_id';

export async function GET(_req: NextRequest) {
  const cookieStore = cookies();
  const supabase    = createRouteHandlerClient({ cookies: () => cookieStore });

  const { data: { user }, error: authErr } = await supabase.auth.getUser();
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  }

  // Fetch profile to get current org membership
  const { data: profile, error: profileErr } = await supabase
    .from('profiles')
    .select('organisation_id, role')
    .eq('id', user.id)
    .single();

  if (profileErr || !profile) {
    return NextResponse.json({ error: 'Profile not found' }, { status: 404 });
  }

  // For super-admins who can access all orgs, return all
  // For regular users, return just their org
  let orgsQuery = supabase
    .from('organisations')
    .select('id, name, slug, accent_colour, logo_url')
    .order('name');

  if (profile.role !== 'superadmin') {
    orgsQuery = orgsQuery.eq('id', profile.organisation_id);
  }

  const { data: orgs, error: orgsErr } = await orgsQuery;

  if (orgsErr) {
    return NextResponse.json({ error: 'Failed to load organisations' }, { status: 500 });
  }

  // Current active org from cookie (or fallback to profile org)
  const activeOrgId =
    cookieStore.get(ORG_COOKIE)?.value ?? profile.organisation_id;

  return NextResponse.json({ orgs: orgs ?? [], activeOrgId });
}

export async function POST(req: NextRequest) {
  const cookieStore = cookies();
  const supabase    = createRouteHandlerClient({ cookies: () => cookieStore });

  const { data: { user }, error: authErr } = await supabase.auth.getUser();
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  }

  let body: { orgId?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const { orgId } = body;
  if (!orgId) {
    return NextResponse.json({ error: 'orgId required' }, { status: 400 });
  }

  // Verify the user has access to this org
  const { data: profile } = await supabase
    .from('profiles')
    .select('organisation_id, role')
    .eq('id', user.id)
    .single();

  if (!profile) {
    return NextResponse.json({ error: 'Profile not found' }, { status: 404 });
  }

  const allowed =
    profile.role === 'superadmin' || profile.organisation_id === orgId;

  if (!allowed) {
    return NextResponse.json({ error: 'Access denied to this organisation' }, { status: 403 });
  }

  // Fetch org details to return to client
  const { data: org, error: orgErr } = await supabase
    .from('organisations')
    .select('id, name, slug, accent_colour, logo_url')
    .eq('id', orgId)
    .single();

  if (orgErr || !org) {
    return NextResponse.json({ error: 'Organisation not found' }, { status: 404 });
  }

  const res = NextResponse.json({ org });

  // Store active org in a server-side cookie (httpOnly, same-site)
  res.cookies.set(ORG_COOKIE, orgId, {
    httpOnly: true,
    sameSite: 'lax',
    secure:   process.env.NODE_ENV === 'production',
    maxAge:   60 * 60 * 24 * 30, // 30 days
    path:     '/',
  });

  return res;
}
