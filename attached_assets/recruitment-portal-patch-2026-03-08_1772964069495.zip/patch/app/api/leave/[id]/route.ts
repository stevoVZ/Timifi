// app/api/leave/[id]/route.ts
// ─────────────────────────────────────────────────────────────────────────────
// PATCH /api/leave/:id   → admin approves or rejects a leave request
//   body: { action: 'approve' | 'reject', reviewerNote?: string }
//
// On approve: calls deduct_leave_balance() RPC to update the contractor's
// leave balance and records the reviewer + timestamp.
// ─────────────────────────────────────────────────────────────────────────────

import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

type Params = { params: { id: string } };

export async function PATCH(req: NextRequest, { params }: Params) {
  const { id } = params;
  const cookieStore = cookies();
  const supabase    = createRouteHandlerClient({ cookies: () => cookieStore });

  // ── Auth ────────────────────────────────────────────────────────────────────
  const { data: { user }, error: authErr } = await supabase.auth.getUser();
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role, organisation_id')
    .eq('id', user.id)
    .single();

  if (!profile || !['admin', 'consultant'].includes(profile.role ?? '')) {
    return NextResponse.json({ error: 'Forbidden — admin only' }, { status: 403 });
  }

  // ── Body ────────────────────────────────────────────────────────────────────
  let body: { action?: string; reviewerNote?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const { action, reviewerNote } = body;
  if (!['approve', 'reject'].includes(action ?? '')) {
    return NextResponse.json({ error: "action must be 'approve' or 'reject'" }, { status: 400 });
  }

  // ── Fetch the leave request ─────────────────────────────────────────────────
  const { data: leaveReq, error: fetchErr } = await supabase
    .from('leave_requests')
    .select('id, status, contractor_id, leave_type_id, days_requested, organisation_id')
    .eq('id', id)
    .single();

  if (fetchErr || !leaveReq) {
    return NextResponse.json({ error: 'Leave request not found' }, { status: 404 });
  }

  // Ensure the request belongs to the admin's org
  if (leaveReq.organisation_id !== profile.organisation_id) {
    return NextResponse.json({ error: 'Access denied' }, { status: 403 });
  }

  if (leaveReq.status !== 'pending') {
    return NextResponse.json(
      { error: `Request is already ${leaveReq.status}` },
      { status: 409 }
    );
  }

  // ── Update leave_requests ───────────────────────────────────────────────────
  const newStatus = action === 'approve' ? 'approved' : 'rejected';

  const { data: updated, error: updateErr } = await supabase
    .from('leave_requests')
    .update({
      status:        newStatus,
      reviewed_by:   user.id,
      reviewed_at:   new Date().toISOString(),
      reviewer_note: reviewerNote ?? null,
    })
    .eq('id', id)
    .select()
    .single();

  if (updateErr) {
    return NextResponse.json({ error: updateErr.message }, { status: 500 });
  }

  // ── If approved: deduct leave balance via RPC ───────────────────────────────
  if (action === 'approve') {
    const { error: rpcErr } = await supabase.rpc('deduct_leave_balance', {
      p_contractor_id: leaveReq.contractor_id,
      p_leave_type_id: leaveReq.leave_type_id,
      p_days:          leaveReq.days_requested,
    });

    if (rpcErr) {
      // Roll back the status change
      await supabase
        .from('leave_requests')
        .update({ status: 'pending', reviewed_by: null, reviewed_at: null, reviewer_note: null })
        .eq('id', id);

      return NextResponse.json(
        { error: `Balance deduction failed: ${rpcErr.message}` },
        { status: 500 }
      );
    }
  }

  return NextResponse.json({ request: updated });
}
