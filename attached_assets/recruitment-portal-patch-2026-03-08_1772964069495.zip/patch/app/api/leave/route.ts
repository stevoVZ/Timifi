// app/api/leave/route.ts
// ─────────────────────────────────────────────────────────────────────────────
// GET  /api/leave               → contractor: own requests + balances
//      /api/leave?admin=1        → admin: all pending requests for org + balances
//      /api/leave?status=pending → filter by status
// POST /api/leave               → contractor submits a new leave request
// ─────────────────────────────────────────────────────────────────────────────

import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

export async function GET(req: NextRequest) {
  const cookieStore = cookies();
  const supabase    = createRouteHandlerClient({ cookies: () => cookieStore });

  const { data: { user }, error: authErr } = await supabase.auth.getUser();
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('role, organisation_id')
    .eq('id', user.id)
    .single();

  if (!profile) return NextResponse.json({ error: 'Profile not found' }, { status: 404 });

  const isAdmin   = ['admin', 'consultant'].includes(profile.role ?? '');
  const adminMode = req.nextUrl.searchParams.get('admin') === '1' && isAdmin;
  const status    = req.nextUrl.searchParams.get('status');    // optional filter
  const orgId     = profile.organisation_id;

  // ── Admin: all pending (or filtered) requests in org ─────────────────────
  if (adminMode) {
    let query = supabase
      .from('leave_requests')
      .select(`
        id, start_date, end_date, days_requested, reason, status,
        reviewer_note, reviewed_at, created_at,
        leave_types ( id, name, color ),
        contractors (
          id, full_name, position, avatar_url,
          leave_balances (
            balance_days, taken_ytd, accrued_ytd,
            leave_types ( id, name )
          )
        ),
        profiles:reviewed_by ( full_name )
      `)
      .eq('organisation_id', orgId)
      .order('created_at', { ascending: false });

    if (status) query = query.eq('status', status);

    const { data, error } = await query;
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ requests: data ?? [] });
  }

  // ── Contractor: own requests + balances ───────────────────────────────────
  const { data: contractor } = await supabase
    .from('contractors')
    .select('id')
    .eq('profile_id', user.id)
    .single();

  if (!contractor) return NextResponse.json({ error: 'Contractor record not found' }, { status: 404 });

  const [reqResult, balResult] = await Promise.all([
    supabase
      .from('leave_requests')
      .select(`
        id, start_date, end_date, days_requested, reason, status,
        reviewer_note, reviewed_at, created_at,
        leave_types ( id, name, color )
      `)
      .eq('contractor_id', contractor.id)
      .order('created_at', { ascending: false }),

    supabase
      .from('leave_balances')
      .select(`
        id, balance_days, accrued_ytd, taken_ytd,
        leave_types ( id, name, color )
      `)
      .eq('contractor_id', contractor.id),
  ]);

  if (reqResult.error) return NextResponse.json({ error: reqResult.error.message }, { status: 500 });
  if (balResult.error) return NextResponse.json({ error: balResult.error.message }, { status: 500 });

  return NextResponse.json({
    requests: reqResult.data ?? [],
    balances: balResult.data ?? [],
  });
}

export async function POST(req: NextRequest) {
  const cookieStore = cookies();
  const supabase    = createRouteHandlerClient({ cookies: () => cookieStore });

  const { data: { user }, error: authErr } = await supabase.auth.getUser();
  if (authErr || !user) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  }

  let body: {
    leaveTypeId:  string;
    startDate:    string;
    endDate:      string;
    daysRequested: number;
    reason?:      string;
  };

  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  const { leaveTypeId, startDate, endDate, daysRequested, reason } = body;

  if (!leaveTypeId || !startDate || !endDate || !daysRequested) {
    return NextResponse.json({ error: 'leaveTypeId, startDate, endDate, daysRequested required' }, { status: 400 });
  }

  // Look up contractor and org
  const { data: contractor } = await supabase
    .from('contractors')
    .select('id, organisation_id')
    .eq('profile_id', user.id)
    .single();

  if (!contractor) return NextResponse.json({ error: 'Contractor record not found' }, { status: 404 });

  // Check sufficient balance
  const { data: balance } = await supabase
    .from('leave_balances')
    .select('balance_days')
    .eq('contractor_id', contractor.id)
    .eq('leave_type_id', leaveTypeId)
    .single();

  if (!balance) {
    return NextResponse.json({ error: 'No leave balance found for this leave type' }, { status: 422 });
  }

  if (balance.balance_days < daysRequested) {
    return NextResponse.json(
      { error: `Insufficient balance. Available: ${balance.balance_days} days, requested: ${daysRequested} days.` },
      { status: 422 }
    );
  }

  const { data: request, error: insertErr } = await supabase
    .from('leave_requests')
    .insert({
      contractor_id:  contractor.id,
      leave_type_id:  leaveTypeId,
      organisation_id: contractor.organisation_id,
      start_date:     startDate,
      end_date:       endDate,
      days_requested: daysRequested,
      reason:         reason ?? null,
      status:         'pending',
    })
    .select()
    .single();

  if (insertErr) return NextResponse.json({ error: insertErr.message }, { status: 500 });

  return NextResponse.json({ request }, { status: 201 });
}
