// middleware.ts
import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() { return request.cookies.getAll() },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value))
          supabaseResponse = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  // Refresh session
  const { data: { user } } = await supabase.auth.getUser()
  const { pathname } = request.nextUrl

  // ── Public paths ──────────────────────────────────────────────────────────
  const publicPaths = [
    '/',
    '/auth/login',
    '/portal/login',
    '/api/auth',
    '/api/xero/auth',
    '/api/xero/callback',
  ]
  const isPublic = publicPaths.some(p => pathname === p || pathname.startsWith(p + '/'))

  // ── Unauthenticated → send to correct login ───────────────────────────────
  if (!isPublic && !user) {
    const url = request.nextUrl.clone()
    if (pathname.startsWith('/portal')) {
      url.pathname = '/portal/login'
    } else {
      url.pathname = '/auth/login'
      url.searchParams.set('redirectTo', pathname)
    }
    return NextResponse.redirect(url)
  }

  // ── Authenticated on login pages → redirect home ─────────────────────────
  if (user) {
    if (pathname === '/auth/login') {
      const url = request.nextUrl.clone()
      url.pathname = '/admin/dashboard'
      return NextResponse.redirect(url)
    }
    if (pathname === '/portal/login') {
      const url = request.nextUrl.clone()
      url.pathname = '/portal/dashboard'
      return NextResponse.redirect(url)
    }
  }

  return supabaseResponse
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
