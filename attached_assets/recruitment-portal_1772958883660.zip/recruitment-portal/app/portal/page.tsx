// app/portal/page.tsx
import { redirect } from 'next/navigation'
export default function PortalRoot() {
  redirect('/portal/dashboard')
}
