// app/portal/layout.tsx
import type { ReactNode } from 'react'
import { createServerClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import PortalShell from '@/components/portal/PortalShell'

export default async function PortalLayout({ children }: { children: ReactNode }) {
  const supabase = createServerClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/portal/login')

  // Verify this user is a contractor (not admin trying to access portal)
  const { data: profile } = await supabase
    .from('profiles')
    .select('role, full_name')
    .eq('id', user.id)
    .single()

  if (!profile || profile.role !== 'contractor') redirect('/admin/dashboard')

  return <PortalShell fullName={profile.full_name}>{children}</PortalShell>
}
