'use client'
// app/portal/dashboard/page.tsx
import { B } from '@/lib/design'

const fmt = (n:number) => '$'+n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})

// Seed data — in production, fetch from Supabase based on auth'd contractor
const CONTRACTOR = {
  name: 'Alex Rivera', initials:'AR', col:'#2563eb', bg:'#eff6ff',
  jobTitle:'Senior Developer', client:'Client A',
  rate:120, contractHoursPA:2000, ytdHours:476, ytdGross:57120,
  nextPayDate:'31 Mar 2026',
}

const RECENT_TIMESHEETS = [
  {id:'t1', period:'March 2026',    hours:172, status:'APPROVED', gross:20640 },
  {id:'t2', period:'February 2026', hours:160, status:'APPROVED', gross:19200 },
  {id:'t3', period:'January 2026',  hours:144, status:'APPROVED', gross:17280 },
]

const RECENT_PAYSLIPS = [
  {id:'p1', period:'February 2026', gross:19200, net:13680, payDate:'28 Feb 2026'},
  {id:'p2', period:'January 2026',  gross:17280, net:12300, payDate:'31 Jan 2026'},
]

const STATUS_STYLE: Record<string,{bg:string,c:string}> = {
  APPROVED:  {bg:B.gP,   c:B.green  },
  SUBMITTED: {bg:B.aLP,  c:B.amber  },
  REJECTED:  {bg:B.rP,   c:B.red    },
  DRAFT:     {bg:B.faint, c:B.dim   },
}

export default function PortalDashboard() {
  const ytdPct     = Math.min(100, Math.round((CONTRACTOR.ytdHours / CONTRACTOR.contractHoursPA) * 100))
  const ytdBarCol  = ytdPct > 100 ? B.red : ytdPct > 80 ? B.amber : B.green
  const monthHours = RECENT_TIMESHEETS[0]?.hours ?? 0
  const monthPct   = Math.min(100, Math.round((monthHours / (CONTRACTOR.contractHoursPA / 12)) * 100))

  return (
    <main style={{ flex:1, padding:'28px 32px', background:B.bg, maxWidth:960, width:'100%', margin:'0 auto' }}>

      {/* Welcome */}
      <div style={{ marginBottom:28 }}>
        <h1 style={{ fontSize:22, fontWeight:700, color:B.text, margin:'0 0 4px' }}>
          Good {new Date().getHours()<12?'morning':new Date().getHours()<17?'afternoon':'evening'}, {CONTRACTOR.name.split(' ')[0]} 👋
        </h1>
        <p style={{ fontSize:14, color:B.dim }}>
          {CONTRACTOR.jobTitle} · {CONTRACTOR.client} · {fmt(CONTRACTOR.rate)}/hr
        </p>
      </div>

      {/* KPI cards */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:16, marginBottom:24 }}>
        {[
          ['This month',  `${monthHours}h`, `${monthPct}% of monthly target`, B.accent],
          ['YTD earnings', fmt(CONTRACTOR.ytdGross), `${CONTRACTOR.ytdHours}h billed`, B.green],
          ['Next pay date', CONTRACTOR.nextPayDate, 'Estimated', B.amber],
        ].map(([k,v,sub,col])=>(
          <div key={k as string} className="card" style={{padding:'18px 20px'}}>
            <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:B.dim,marginBottom:8}}>{k}</div>
            <div style={{fontFamily:"'DM Mono',monospace",fontSize:22,fontWeight:700,color:col as string,marginBottom:4}}>{v}</div>
            <div style={{fontSize:12.5,color:B.sub}}>{sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20 }}>

        {/* Contract utilisation */}
        <div className="card" style={{ padding:'20px 22px' }}>
          <h2 style={{ fontSize:14, fontWeight:700, color:B.text, margin:'0 0 16px' }}>Contract utilisation</h2>

          <div style={{ marginBottom:16 }}>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
              <span style={{ fontSize:13, color:B.dim }}>YTD hours</span>
              <span style={{ fontFamily:"'DM Mono',monospace", fontSize:13, color:ytdBarCol, fontWeight:600 }}>{CONTRACTOR.ytdHours} / {CONTRACTOR.contractHoursPA}h</span>
            </div>
            <div style={{ height:9, borderRadius:5, background:B.border, overflow:'hidden' }}>
              <div style={{ height:'100%', width:`${ytdPct}%`, background:ytdBarCol, borderRadius:5, transition:'width .5s' }}/>
            </div>
            <div style={{ fontSize:12, color:B.sub, marginTop:5 }}>{ytdPct}% of annual contract · {CONTRACTOR.contractHoursPA - CONTRACTOR.ytdHours}h remaining</div>
          </div>

          <div style={{ padding:'12px 14px', background:B.bg, borderRadius:9, border:`1px solid ${B.border}` }}>
            <div style={{ fontSize:12.5, color:B.dim, marginBottom:2 }}>Annual contract value</div>
            <div style={{ fontFamily:"'DM Mono',monospace", fontSize:18, fontWeight:700, color:B.text }}>
              {fmt(CONTRACTOR.contractHoursPA * CONTRACTOR.rate)}
            </div>
            <div style={{ fontSize:12, color:B.sub, marginTop:2 }}>{CONTRACTOR.contractHoursPA}h × {fmt(CONTRACTOR.rate)}/hr</div>
          </div>
        </div>

        {/* Quick actions */}
        <div className="card" style={{ padding:'20px 22px' }}>
          <h2 style={{ fontSize:14, fontWeight:700, color:B.text, margin:'0 0 16px' }}>Quick actions</h2>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            <a href="/portal/timesheets" style={{
              display:'flex', alignItems:'center', gap:12, padding:'13px 16px',
              background:B.aP, border:`1px solid ${B.aBd}`, borderRadius:10,
              textDecoration:'none', transition:'all .12s',
            }}
            onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor=B.accent}
            onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor=B.aBd}
            >
              <span style={{fontSize:22}}>📄</span>
              <div>
                <div style={{fontSize:14,fontWeight:600,color:B.accent}}>View timesheets</div>
                <div style={{fontSize:12.5,color:B.dim}}>Check status and history</div>
              </div>
              <span style={{marginLeft:'auto',color:B.accent}}>→</span>
            </a>
            <a href="/portal/payslips" style={{
              display:'flex', alignItems:'center', gap:12, padding:'13px 16px',
              background:B.gP, border:`1px solid ${B.gB}`, borderRadius:10,
              textDecoration:'none', transition:'all .12s',
            }}
            onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor=B.green}
            onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor=B.gB}
            >
              <span style={{fontSize:22}}>💵</span>
              <div>
                <div style={{fontSize:14,fontWeight:600,color:B.green}}>Download payslips</div>
                <div style={{fontSize:12.5,color:B.dim}}>View and save your payslips</div>
              </div>
              <span style={{marginLeft:'auto',color:B.green}}>→</span>
            </a>
            <a href="/portal/messages" style={{
              display:'flex', alignItems:'center', gap:12, padding:'13px 16px',
              background:B.faint, border:`1px solid ${B.border}`, borderRadius:10,
              textDecoration:'none', transition:'all .12s',
            }}
            onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor=B.accent}
            onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor=B.border}
            >
              <span style={{fontSize:22}}>✉️</span>
              <div>
                <div style={{fontSize:14,fontWeight:600,color:B.text}}>Messages</div>
                <div style={{fontSize:12.5,color:B.dim}}>Contact your agency</div>
              </div>
              <span style={{marginLeft:'auto',color:B.dim}}>→</span>
            </a>
          </div>
        </div>

        {/* Recent timesheets */}
        <div className="card" style={{ overflow:'hidden' }}>
          <div style={{ padding:'16px 20px', borderBottom:`1px solid ${B.faint}`, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <h2 style={{ fontSize:14, fontWeight:700, color:B.text, margin:0 }}>Recent timesheets</h2>
            <a href="/portal/timesheets" style={{ fontSize:13, color:B.accent, textDecoration:'none', fontWeight:600 }}>View all →</a>
          </div>
          <div>
            {RECENT_TIMESHEETS.map((t, i) => {
              const sp = STATUS_STYLE[t.status] || {bg:B.faint,c:B.dim}
              return (
                <div key={t.id} style={{ display:'flex', alignItems:'center', padding:'12px 20px', borderBottom:i<RECENT_TIMESHEETS.length-1?`1px solid ${B.faint}`:'none' }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:14, fontWeight:500, color:B.text }}>{t.period}</div>
                    <div style={{ fontSize:12.5, color:B.dim, marginTop:2 }}>{t.hours}h · {fmt(t.gross)}</div>
                  </div>
                  <span style={{ fontSize:11.5, fontWeight:600, padding:'3px 9px', borderRadius:100, ...sp }}>{t.status}</span>
                </div>
              )
            })}
          </div>
        </div>

        {/* Recent payslips */}
        <div className="card" style={{ overflow:'hidden' }}>
          <div style={{ padding:'16px 20px', borderBottom:`1px solid ${B.faint}`, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <h2 style={{ fontSize:14, fontWeight:700, color:B.text, margin:0 }}>Recent payslips</h2>
            <a href="/portal/payslips" style={{ fontSize:13, color:B.accent, textDecoration:'none', fontWeight:600 }}>View all →</a>
          </div>
          <div>
            {RECENT_PAYSLIPS.map((p, i) => (
              <div key={p.id} style={{ display:'flex', alignItems:'center', padding:'12px 20px', borderBottom:i<RECENT_PAYSLIPS.length-1?`1px solid ${B.faint}`:'none' }}>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:14, fontWeight:500, color:B.text }}>{p.period}</div>
                  <div style={{ fontSize:12.5, color:B.dim, marginTop:2 }}>Paid {p.payDate}</div>
                </div>
                <div style={{ textAlign:'right' }}>
                  <div style={{ fontFamily:"'DM Mono',monospace", fontSize:14, fontWeight:600, color:B.green }}>{fmt(p.net)}</div>
                  <div style={{ fontSize:12, color:B.sub }}>net · {fmt(p.gross)} gross</div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </main>
  )
}
