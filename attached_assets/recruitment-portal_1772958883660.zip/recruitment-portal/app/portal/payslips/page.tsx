'use client'
// app/portal/payslips/page.tsx
import { useState } from 'react'
import { B } from '@/lib/design'

const fmt  = (n:number) => '$'+n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})
const fmtN = (n:number) => n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})

interface PayItem { label:string; amount:number; type:'earn'|'deduct'|'info' }
interface Payslip {
  id:string; period:string; payDate:string; payPeriod:string
  gross:number; payg:number; help:number; net:number
  super:number; superRate:number; ytdGross:number; ytdPayg:number; ytdSuper:number
  hours:number; rate:number; items:PayItem[]
}

const SEED: Payslip[] = [
  {
    id:'p1', period:'February 2026', payDate:'28 Feb 2026', payPeriod:'1 Feb – 28 Feb 2026',
    gross:19200, payg:5184, help:0, net:14016,
    super:2208, superRate:11.5, ytdGross:36480, ytdPayg:9849.6, ytdSuper:4195.2,
    hours:160, rate:120,
    items:[
      {label:'Labour hire — 160h @ $120/hr', amount:19200, type:'earn'},
      {label:'PAYG withholding',              amount:-5184,  type:'deduct'},
    ],
  },
  {
    id:'p2', period:'January 2026', payDate:'31 Jan 2026', payPeriod:'1 Jan – 31 Jan 2026',
    gross:17280, payg:4665.6, help:0, net:12614.4,
    super:1987.2, superRate:11.5, ytdGross:17280, ytdPayg:4665.6, ytdSuper:1987.2,
    hours:144, rate:120,
    items:[
      {label:'Labour hire — 144h @ $120/hr', amount:17280, type:'earn'},
      {label:'PAYG withholding',              amount:-4665.6, type:'deduct'},
    ],
  },
]

export default function PortalPayslips() {
  const [expanded, setExpanded] = useState<string|null>(null)

  return (
    <main style={{ flex:1, padding:'28px 32px', background:B.bg, maxWidth:820, width:'100%', margin:'0 auto' }}>
      <div style={{ marginBottom:24 }}>
        <h1 style={{ fontSize:20, fontWeight:700, color:B.text, marginBottom:4 }}>My payslips</h1>
        <p style={{ fontSize:14, color:B.dim }}>Payslips are generated after each pay run is filed.</p>
      </div>

      {/* YTD summary */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:14, marginBottom:24 }}>
        {[
          ['YTD gross',  fmt(SEED[0].ytdGross), 'Total earnings this FY'],
          ['YTD PAYG',   fmt(SEED[0].ytdPayg),  'Tax withheld this FY'],
          ['YTD super',  fmt(SEED[0].ytdSuper),  '11.5% SGC contributed'],
        ].map(([k,v,sub])=>(
          <div key={k as string} style={{ background:B.surface, border:`1px solid ${B.border}`, borderRadius:12, padding:'16px 18px' }}>
            <div style={{ fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.07em', color:B.dim, marginBottom:6 }}>{k}</div>
            <div style={{ fontFamily:"'DM Mono',monospace", fontSize:20, fontWeight:700, color:B.text, marginBottom:3 }}>{v}</div>
            <div style={{ fontSize:12, color:B.sub }}>{sub}</div>
          </div>
        ))}
      </div>

      {/* Payslip list */}
      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
        {SEED.map(ps => {
          const open = expanded === ps.id
          return (
            <div key={ps.id} className="card" style={{ overflow:'hidden' }}>
              {/* Summary row */}
              <button
                onClick={() => setExpanded(open ? null : ps.id)}
                style={{
                  width:'100%', display:'flex', alignItems:'center', gap:16,
                  padding:'16px 20px', border:'none', background:'transparent',
                  cursor:'pointer', fontFamily:"'DM Sans',sans-serif", textAlign:'left',
                }}
              >
                {/* Pay date icon */}
                <div style={{
                  width:44, height:44, borderRadius:10, background:B.gP,
                  border:`1px solid ${B.gB}`, display:'flex', flexDirection:'column',
                  alignItems:'center', justifyContent:'center', flexShrink:0,
                }}>
                  <span style={{ fontSize:18 }}>💵</span>
                </div>

                <div style={{ flex:1 }}>
                  <div style={{ fontSize:15, fontWeight:600, color:B.text, marginBottom:3 }}>{ps.period}</div>
                  <div style={{ fontSize:13, color:B.dim }}>Pay date {ps.payDate} · {ps.hours}h @ {fmt(ps.rate)}/hr</div>
                </div>

                <div style={{ textAlign:'right', flexShrink:0 }}>
                  <div style={{ fontFamily:"'DM Mono',monospace", fontSize:16, fontWeight:700, color:B.green }}>{fmt(ps.net)}</div>
                  <div style={{ fontSize:12, color:B.sub }}>net pay</div>
                </div>

                <span style={{ fontSize:14, color:B.sub, transform:open?'rotate(180deg)':'none', transition:'transform .2s', flexShrink:0 }}>▼</span>
              </button>

              {/* Detail */}
              {open && (
                <div style={{ borderTop:`1px solid ${B.faint}`, animation:'up .2s ease both' }}>
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:0 }}>

                    {/* Left: earnings & deductions */}
                    <div style={{ padding:'18px 20px', borderRight:`1px solid ${B.faint}` }}>
                      <div style={{ fontSize:12, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim, marginBottom:12 }}>Earnings & deductions</div>

                      {ps.items.map((item,i)=>(
                        <div key={i} style={{ display:'flex', justifyContent:'space-between', padding:'8px 0', borderBottom:`1px solid ${B.faint}` }}>
                          <span style={{ fontSize:13.5, color:item.type==='deduct'?B.amber:B.text }}>{item.label}</span>
                          <span style={{ fontFamily:"'DM Mono',monospace", fontSize:13.5, fontWeight:600, color:item.type==='deduct'?B.amber:B.green }}>
                            {item.amount < 0 ? `-${fmt(Math.abs(item.amount))}` : fmt(item.amount)}
                          </span>
                        </div>
                      ))}

                      {/* Net */}
                      <div style={{ display:'flex', justifyContent:'space-between', padding:'11px 0 0', marginTop:4 }}>
                        <span style={{ fontSize:14, fontWeight:700, color:B.text }}>Net pay</span>
                        <span style={{ fontFamily:"'DM Mono',monospace", fontSize:15, fontWeight:700, color:B.green }}>{fmt(ps.net)}</span>
                      </div>

                      {/* Super (below the line — not take-home) */}
                      <div style={{ marginTop:12, padding:'10px 13px', background:B.aP, borderRadius:9, border:`1px solid ${B.aBd}` }}>
                        <div style={{ fontSize:12, color:B.dim, marginBottom:3 }}>Superannuation ({fmtN(ps.superRate)}%)</div>
                        <div style={{ fontFamily:"'DM Mono',monospace", fontSize:14, fontWeight:600, color:B.accent }}>{fmt(ps.super)}</div>
                        <div style={{ fontSize:11.5, color:B.sub, marginTop:2 }}>Paid to your super fund — not deducted from take-home</div>
                      </div>
                    </div>

                    {/* Right: YTD + meta */}
                    <div style={{ padding:'18px 20px' }}>
                      <div style={{ fontSize:12, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim, marginBottom:12 }}>Year to date</div>

                      {[
                        ['Gross earnings', fmt(ps.ytdGross)],
                        ['PAYG withheld',  fmt(ps.ytdPayg)],
                        ['Super contributed', fmt(ps.ytdSuper)],
                      ].map(([k,v])=>(
                        <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'8px 0', borderBottom:`1px solid ${B.faint}` }}>
                          <span style={{ fontSize:13, color:B.dim }}>{k}</span>
                          <span style={{ fontFamily:"'DM Mono',monospace", fontSize:13, fontWeight:600, color:B.text }}>{v}</span>
                        </div>
                      ))}

                      <div style={{ marginTop:16 }}>
                        <div style={{ fontSize:12, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim, marginBottom:10 }}>Pay period</div>
                        <div style={{ fontSize:13.5, color:B.text }}>{ps.payPeriod}</div>
                      </div>

                      <button
                        onClick={() => alert('In production: download signed PDF payslip from Supabase Storage.')}
                        style={{
                          marginTop:16, width:'100%', padding:'10px', borderRadius:9,
                          border:`1.5px solid ${B.gB}`, background:B.gP,
                          color:B.green, fontSize:13.5, fontWeight:600,
                          fontFamily:"'DM Sans',sans-serif", cursor:'pointer',
                          display:'flex', alignItems:'center', justifyContent:'center', gap:8,
                          transition:'all .13s',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.background=B.green; e.currentTarget.style.color='#fff' }}
                        onMouseLeave={e => { e.currentTarget.style.background=B.gP; e.currentTarget.style.color=B.green }}
                      >
                        ↓ Download PDF
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </main>
  )
}
