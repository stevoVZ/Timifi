'use client'
// app/portal/timesheets/page.tsx
import { useState } from 'react'
import { B } from '@/lib/design'

const fmt = (n:number) => '$'+n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})

const STATUS_STYLE: Record<string,{bg:string,c:string,label:string}> = {
  APPROVED:  {bg:B.gP,  c:B.green, label:'Approved'  },
  SUBMITTED: {bg:B.aLP, c:B.amber, label:'In review'  },
  REJECTED:  {bg:B.rP,  c:B.red,   label:'Returned'   },
  DRAFT:     {bg:B.faint,c:B.dim,  label:'Draft'      },
}

interface WeekRow { week:string; regular:number; overtime:number; total:number }

interface Timesheet {
  id:string; period:string; year:number; month:number
  hours:number; rate:number; status:string
  submittedDate:string; reviewedDate?:string
  rejectionReason?:string; weeks:WeekRow[]
  intakeSource?:string; reviewer?:string
}

const SEED: Timesheet[] = [
  {
    id:'t1', period:'March 2026', year:2026, month:3, hours:172, rate:120,
    status:'SUBMITTED', submittedDate:'2 Mar 2026',
    intakeSource:'Email',
    weeks:[
      {week:'3–7 Mar',  regular:40, overtime:0, total:40},
      {week:'10–14 Mar',regular:40, overtime:2, total:42},
      {week:'17–21 Mar',regular:40, overtime:0, total:40},
      {week:'24–28 Mar',regular:40, overtime:0, total:40},
      {week:'31 Mar',   regular:10, overtime:0, total:10},
    ],
  },
  {
    id:'t2', period:'February 2026', year:2026, month:2, hours:160, rate:120,
    status:'APPROVED', submittedDate:'3 Feb 2026', reviewedDate:'5 Feb 2026',
    reviewer:'Sarah Chen',
    weeks:[
      {week:'3–7 Feb',  regular:40, overtime:0, total:40},
      {week:'10–14 Feb',regular:40, overtime:0, total:40},
      {week:'17–21 Feb',regular:40, overtime:0, total:40},
      {week:'24–28 Feb',regular:40, overtime:0, total:40},
    ],
  },
  {
    id:'t3', period:'January 2026', year:2026, month:1, hours:144, rate:120,
    status:'APPROVED', submittedDate:'5 Jan 2026', reviewedDate:'7 Jan 2026',
    reviewer:'Sarah Chen',
    weeks:[
      {week:'6–10 Jan', regular:40, overtime:0, total:40},
      {week:'13–17 Jan',regular:40, overtime:0, total:40},
      {week:'20–24 Jan',regular:40, overtime:0, total:40},
      {week:'27–31 Jan',regular:24, overtime:0, total:24},
    ],
  },
  {
    id:'t4', period:'December 2025', year:2025, month:12, hours:120, rate:120,
    status:'REJECTED', submittedDate:'4 Dec 2025', reviewedDate:'6 Dec 2025',
    reviewer:'Sarah Chen',
    rejectionReason:'Hours on Week 2 (8–12 Dec) appear to be duplicated. Total exceeds approved leave schedule. Please correct and resubmit.',
    weeks:[
      {week:'1–5 Dec',  regular:40, overtime:0, total:40},
      {week:'8–12 Dec', regular:40, overtime:0, total:40},
      {week:'15–19 Dec',regular:40, overtime:0, total:40},
    ],
  },
]

export default function PortalTimesheets() {
  const [expanded, setExpanded] = useState<string|null>(null)

  const toggle = (id:string) => setExpanded(prev => prev===id ? null : id)

  return (
    <main style={{ flex:1, padding:'28px 32px', background:B.bg, maxWidth:820, width:'100%', margin:'0 auto' }}>
      <div style={{ marginBottom:24 }}>
        <h1 style={{ fontSize:20, fontWeight:700, color:B.text, marginBottom:4 }}>My timesheets</h1>
        <p style={{ fontSize:14, color:B.dim }}>Your timesheet submissions and their current status.</p>
      </div>

      {/* Upload note */}
      <div style={{ padding:'13px 16px', background:B.aP, border:`1px solid ${B.aBd}`, borderRadius:10, marginBottom:20, fontSize:13.5, color:B.accent }}>
        📄 To submit a timesheet, email your PDF to your agency or hand it in at the office. You'll be notified when it's been received and processed.
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
        {SEED.map(ts => {
          const sp   = STATUS_STYLE[ts.status] || {bg:B.faint,c:B.dim,label:ts.status}
          const open = expanded === ts.id
          const gross = ts.hours * ts.rate

          return (
            <div key={ts.id} className="card" style={{ overflow:'hidden', transition:'box-shadow .15s' }}>
              {/* Header row */}
              <button
                onClick={() => toggle(ts.id)}
                style={{
                  width:'100%', display:'flex', alignItems:'center', gap:16,
                  padding:'16px 20px', border:'none', background:'transparent',
                  cursor:'pointer', fontFamily:"'DM Sans',sans-serif", textAlign:'left',
                }}
              >
                {/* Period + status */}
                <div style={{ flex:1 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:4 }}>
                    <span style={{ fontSize:15, fontWeight:600, color:B.text }}>{ts.period}</span>
                    <span style={{ fontSize:11.5, fontWeight:600, padding:'3px 9px', borderRadius:100, background:sp.bg, color:sp.c }}>{sp.label}</span>
                    {ts.status === 'REJECTED' && <span style={{ fontSize:13 }}>⚠️</span>}
                  </div>
                  <div style={{ fontSize:13, color:B.dim }}>
                    Submitted {ts.submittedDate}
                    {ts.reviewedDate && ` · Reviewed ${ts.reviewedDate}`}
                    {ts.reviewer && ` by ${ts.reviewer}`}
                  </div>
                </div>

                {/* Hours + gross */}
                <div style={{ textAlign:'right', flexShrink:0 }}>
                  <div style={{ fontFamily:"'DM Mono',monospace", fontSize:15, fontWeight:700, color:B.text }}>{ts.hours}h</div>
                  <div style={{ fontFamily:"'DM Mono',monospace", fontSize:13, color:B.green }}>{fmt(gross)}</div>
                </div>

                {/* Expand chevron */}
                <span style={{ fontSize:14, color:B.sub, transform:open?'rotate(180deg)':'rotate(0)', transition:'transform .2s', flexShrink:0 }}>▼</span>
              </button>

              {/* Expanded detail */}
              {open && (
                <div style={{ borderTop:`1px solid ${B.faint}`, animation:'up .2s ease both' }}>

                  {/* Rejection reason */}
                  {ts.rejectionReason && (
                    <div style={{ margin:'16px 20px 0', padding:'13px 16px', background:B.rP, border:`1px solid ${B.rB}`, borderRadius:10 }}>
                      <div style={{ fontSize:12.5, fontWeight:700, color:B.red, marginBottom:5 }}>⚠ Returned for correction</div>
                      <div style={{ fontSize:13.5, color:B.red, lineHeight:1.55 }}>{ts.rejectionReason}</div>
                    </div>
                  )}

                  {/* Weekly breakdown table */}
                  <div style={{ padding:'16px 20px' }}>
                    <div style={{ fontSize:12, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim, marginBottom:10 }}>Weekly breakdown</div>
                    <table style={{ width:'100%', borderCollapse:'collapse' }}>
                      <thead>
                        <tr style={{ background:B.bg }}>
                          {['Week','Regular','Overtime','Total'].map(h=>(
                            <th key={h} style={{ padding:'8px 12px', textAlign:'left', fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.sub }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {ts.weeks.map((w,i)=>(
                          <tr key={i} style={{ borderTop:`1px solid ${B.faint}` }}>
                            <td style={{ padding:'9px 12px', fontSize:13.5, color:B.text }}>{w.week}</td>
                            <td style={{ padding:'9px 12px', fontFamily:"'DM Mono',monospace", fontSize:13, color:B.mid }}>{w.regular}h</td>
                            <td style={{ padding:'9px 12px', fontFamily:"'DM Mono',monospace", fontSize:13, color:w.overtime>0?B.amber:B.sub }}>{w.overtime>0?`${w.overtime}h`:'—'}</td>
                            <td style={{ padding:'9px 12px', fontFamily:"'DM Mono',monospace", fontSize:13, fontWeight:600, color:B.text }}>{w.total}h</td>
                          </tr>
                        ))}
                        {/* Totals */}
                        <tr style={{ borderTop:`2px solid ${B.border}`, background:B.bg }}>
                          <td style={{ padding:'9px 12px', fontSize:13, fontWeight:700, color:B.text }}>Total</td>
                          <td style={{ padding:'9px 12px', fontFamily:"'DM Mono',monospace", fontSize:13, fontWeight:700, color:B.mid }}>{ts.weeks.reduce((s,w)=>s+w.regular,0)}h</td>
                          <td style={{ padding:'9px 12px', fontFamily:"'DM Mono',monospace", fontSize:13, fontWeight:700, color:B.amber }}>{ts.weeks.reduce((s,w)=>s+w.overtime,0)>0?`${ts.weeks.reduce((s,w)=>s+w.overtime,0)}h`:'—'}</td>
                          <td style={{ padding:'9px 12px', fontFamily:"'DM Mono',monospace", fontSize:14, fontWeight:700, color:B.text }}>{ts.hours}h</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Summary footer */}
                  <div style={{ padding:'12px 20px 16px', display:'flex', gap:24, borderTop:`1px solid ${B.faint}`, background:B.bg, flexWrap:'wrap' }}>
                    {[
                      ['Rate',  `${fmt(ts.rate)}/hr`, B.dim],
                      ['Gross', fmt(gross), B.green],
                      ['Source', ts.intakeSource ?? 'Portal', B.dim],
                    ].map(([k,v,c])=>(
                      <div key={k as string}>
                        <div style={{ fontSize:11, color:B.sub, marginBottom:2 }}>{k}</div>
                        <div style={{ fontFamily:"'DM Mono',monospace", fontSize:13.5, fontWeight:600, color:c as string }}>{v}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </main>
  )
}
