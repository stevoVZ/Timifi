'use client'
// app/portal/login/page.tsx
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { B } from '@/lib/design'

export default function PortalLogin() {
  const router   = useRouter()
  const supabase = createClient()
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [loading,  setLoading]  = useState(false)
  const [error,    setError]    = useState<string|null>(null)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    const { error: authError } = await supabase.auth.signInWithPassword({ email, password })
    if (authError) {
      setError('Incorrect email or password. Please try again.')
      setLoading(false)
      return
    }
    router.push('/portal/dashboard')
    router.refresh()
  }

  const handleMagicLink = async () => {
    if (!email) { setError('Enter your email first.'); return }
    setLoading(true)
    await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: `${window.location.origin}/portal/dashboard` },
    })
    setLoading(false)
    setError(null)
    alert(`Magic link sent to ${email}. Check your inbox.`)
  }

  return (
    <div style={{
      minHeight:'100vh', background:B.bg,
      display:'flex', alignItems:'center', justifyContent:'center',
      fontFamily:"'DM Sans',sans-serif", padding:24,
    }}>
      <div style={{ width:'100%', maxWidth:400 }}>
        {/* Logo */}
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <div style={{
            width:52,height:52,borderRadius:14,background:B.accent,
            display:'flex',alignItems:'center',justifyContent:'center',
            fontSize:26,margin:'0 auto 14px',
          }}>🏢</div>
          <h1 style={{ fontSize:22, fontWeight:700, color:B.text, marginBottom:6 }}>Contractor Portal</h1>
          <p style={{ fontSize:14, color:B.dim }}>Sign in to view your timesheets and payslips</p>
        </div>

        {/* Card */}
        <div className="card" style={{ padding:'28px 28px 24px' }}>
          <form onSubmit={handleLogin} style={{ display:'flex', flexDirection:'column', gap:16 }}>

            <div>
              <label style={{ display:'block', fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim, marginBottom:6 }}>
                Email address
              </label>
              <input
                type="email" value={email} onChange={e => setEmail(e.target.value)}
                placeholder="your@email.com" required
                style={{ width:'100%', padding:'11px 13px', borderRadius:9, border:`1.5px solid ${B.border}`, fontFamily:"'DM Sans',sans-serif", fontSize:14, color:B.text, outline:'none', background:B.surface, boxSizing:'border-box', transition:'border .13s' }}
                onFocus={e => e.target.style.borderColor=B.accent}
                onBlur={e => e.target.style.borderColor=B.border}
              />
            </div>

            <div>
              <label style={{ display:'block', fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim, marginBottom:6 }}>
                Password
              </label>
              <input
                type="password" value={password} onChange={e => setPassword(e.target.value)}
                placeholder="••••••••" required
                style={{ width:'100%', padding:'11px 13px', borderRadius:9, border:`1.5px solid ${B.border}`, fontFamily:"'DM Sans',sans-serif", fontSize:14, color:B.text, outline:'none', background:B.surface, boxSizing:'border-box', transition:'border .13s' }}
                onFocus={e => e.target.style.borderColor=B.accent}
                onBlur={e => e.target.style.borderColor=B.border}
              />
            </div>

            {error && (
              <div style={{ padding:'10px 13px', background:B.rP, border:`1px solid ${B.rB}`, borderRadius:8, fontSize:13, color:B.red }}>
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} style={{
              padding:'13px', background:B.accent, color:'#fff', border:'none',
              borderRadius:9, fontSize:15, fontWeight:600, fontFamily:"'DM Sans',sans-serif",
              cursor:loading?'not-allowed':'pointer', opacity:loading?0.7:1,
              display:'flex', alignItems:'center', justifyContent:'center', gap:8,
              transition:'filter .13s, transform .13s',
            }}
            onMouseEnter={e => { if(!loading) e.currentTarget.style.filter='brightness(.9)' }}
            onMouseLeave={e => e.currentTarget.style.filter='brightness(1)'}
            >
              {loading ? (
                <><span style={{ width:16,height:16,borderRadius:'50%',border:'2px solid rgba(255,255,255,.3)',borderTopColor:'#fff',animation:'spin .8s linear infinite',display:'inline-block' }}/>Signing in…</>
              ) : 'Sign in →'}
            </button>
          </form>

          <div style={{ margin:'16px 0', display:'flex', alignItems:'center', gap:12 }}>
            <div style={{ flex:1, height:1, background:B.border }}/>
            <span style={{ fontSize:12, color:B.sub }}>or</span>
            <div style={{ flex:1, height:1, background:B.border }}/>
          </div>

          <button onClick={handleMagicLink} disabled={loading} style={{
            width:'100%', padding:'11px', background:'transparent', border:`1.5px solid ${B.border}`,
            borderRadius:9, fontSize:14, fontWeight:600, color:B.dim, cursor:'pointer',
            fontFamily:"'DM Sans',sans-serif", transition:'all .13s',
          }}
          onMouseEnter={e => { e.currentTarget.style.borderColor=B.accent; e.currentTarget.style.color=B.accent }}
          onMouseLeave={e => { e.currentTarget.style.borderColor=B.border; e.currentTarget.style.color=B.dim }}
          >
            ✉️ Send magic link
          </button>
        </div>

        <p style={{ textAlign:'center', fontSize:12.5, color:B.sub, marginTop:20 }}>
          Having trouble signing in? Contact your agency.
        </p>
      </div>
    </div>
  )
}
