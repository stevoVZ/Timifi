// app/api/xero/invoices/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { createXeroInvoice, emailXeroInvoice } from '@/lib/xero/invoices'

export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body     = await request.json()
    const { versionId, sendEmail = false } = body

    if (!versionId) {
      return NextResponse.json({ error: 'versionId is required' }, { status: 400 })
    }

    // ── Load version + contractor ────────────────────────────────────────────
    const { data: version, error: vErr } = await supabase
      .from('timesheet_versions')
      .select(`
        *,
        contractor:contractors (
          id, first_name, last_name, email,
          hourly_rate, client_name, xero_contact_id
        )
      `)
      .eq('id', versionId)
      .single()

    if (vErr || !version) {
      return NextResponse.json({ error: 'Version not found' }, { status: 404 })
    }

    if (version.status !== 'APPROVED') {
      return NextResponse.json(
        { error: 'Timesheet must be APPROVED before creating an invoice' },
        { status: 422 }
      )
    }

    if (version.xero_invoice_id) {
      return NextResponse.json(
        { error: 'Invoice already exists', xeroInvoiceId: version.xero_invoice_id },
        { status: 409 }
      )
    }

    const contractor = version.contractor
    if (!contractor.xero_contact_id) {
      return NextResponse.json(
        { error: 'Contractor has no xero_contact_id — add them to Xero first' },
        { status: 422 }
      )
    }

    // ── Build invoice params ─────────────────────────────────────────────────
    const MONTHS = ['January','February','March','April','May','June',
                    'July','August','September','October','November','December']
    const monthName  = MONTHS[(version.month ?? 1) - 1]
    const issueDate  = new Date()
    const dueDate    = new Date(issueDate)
    dueDate.setDate(dueDate.getDate() + 14)

    const formatDate = (d: Date) => d.toISOString().slice(0, 10)

    const xeroResult = await createXeroInvoice({
      xeroContactId: contractor.xero_contact_id,
      description:   `Labour hire services — ${contractor.first_name} ${contractor.last_name} — ${monthName} ${version.year}`,
      hours:         version.total_hours,
      hourlyRate:    contractor.hourly_rate,
      issueDate:     formatDate(issueDate),
      dueDate:       formatDate(dueDate),
      reference:     `${contractor.first_name} ${contractor.last_name} — ${monthName} ${version.year}`,
    })

    // ── Save invoice record to Supabase ──────────────────────────────────────
    const amountExcl = version.total_hours * contractor.hourly_rate
    const gst        = amountExcl * 0.1

    const { data: invoice, error: iErr } = await supabase
      .from('invoices')
      .insert({
        contractor_id:   contractor.id,
        version_id:      versionId,
        year:            version.year,
        month:           version.month,
        amount_excl_gst: amountExcl,
        gst_amount:      gst,
        amount_incl_gst: amountExcl + gst,
        hours:           version.total_hours,
        hourly_rate:     contractor.hourly_rate,
        description:     `Labour hire — ${monthName} ${version.year}`,
        issue_date:      formatDate(issueDate),
        due_date:        formatDate(dueDate),
        status:          'AUTHORISED',
        xero_invoice_id: xeroResult.xeroInvoiceId,
        xero_invoice_url:xeroResult.url,
      })
      .select()
      .single()

    if (iErr) throw new Error(`Failed to save invoice: ${iErr.message}`)

    // ── Link invoice back to version ─────────────────────────────────────────
    await supabase
      .from('timesheet_versions')
      .update({ xero_invoice_id: xeroResult.xeroInvoiceId })
      .eq('id', versionId)

    // ── Optionally email to client ───────────────────────────────────────────
    if (sendEmail) {
      await emailXeroInvoice(xeroResult.xeroInvoiceId)
      await supabase
        .from('invoices')
        .update({ sent_at: new Date().toISOString(), sent_to: contractor.email })
        .eq('id', invoice.id)
    }

    return NextResponse.json({
      success:      true,
      invoiceId:    invoice.id,
      invoiceNumber:xeroResult.invoiceNumber,
      xeroInvoiceId:xeroResult.xeroInvoiceId,
      xeroUrl:      xeroResult.url,
      amountIncGst: amountExcl + gst,
    })

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    console.error('Create invoice error:', message)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
