// app/api/xero/auth/route.ts
import { NextResponse } from 'next/server'

export async function GET() {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id:     process.env.XERO_CLIENT_ID!,
    redirect_uri:  process.env.XERO_REDIRECT_URI!,
    scope: [
      'openid', 'profile', 'email', 'offline_access',
      'accounting.transactions',
      'accounting.contacts',
      'accounting.settings',
      'payroll.employees',
      'payroll.payruns',
      'payroll.payslip',
      'payroll.timesheets',
      'payroll.settings',
      'files',
    ].join(' '),
    state: crypto.randomUUID(), // CSRF protection — store in session in production
  })

  const authUrl = `https://login.xero.com/identity/connect/authorize?${params}`
  return NextResponse.redirect(authUrl)
}
