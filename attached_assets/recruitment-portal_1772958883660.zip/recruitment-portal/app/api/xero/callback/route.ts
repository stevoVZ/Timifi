// app/api/xero/callback/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { saveXeroToken } from '@/lib/xero/client'

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url)
  const code  = searchParams.get('code')
  const error = searchParams.get('error')

  if (error || !code) {
    return NextResponse.redirect(`${origin}/admin/settings?xero=error&reason=${error || 'no_code'}`)
  }

  try {
    // Exchange code for tokens
    const credentials = Buffer.from(
      `${process.env.XERO_CLIENT_ID}:${process.env.XERO_CLIENT_SECRET}`
    ).toString('base64')

    const tokenRes = await fetch('https://identity.xero.com/connect/token', {
      method: 'POST',
      headers: {
        'Content-Type':  'application/x-www-form-urlencoded',
        'Authorization': `Basic ${credentials}`,
      },
      body: new URLSearchParams({
        grant_type:   'authorization_code',
        code,
        redirect_uri: process.env.XERO_REDIRECT_URI!,
      }),
    })

    if (!tokenRes.ok) throw new Error(`Token exchange failed: ${tokenRes.status}`)
    const tokens = await tokenRes.json()

    // Get connected tenants
    const tenantsRes = await fetch('https://api.xero.com/connections', {
      headers: { 'Authorization': `Bearer ${tokens.access_token}` },
    })
    const tenants = await tenantsRes.json()
    const tenant  = tenants[0] // use first connected org

    if (!tenant) throw new Error('No Xero organisation connected')

    await saveXeroToken({
      tenantId:     tenant.tenantId,
      tenantName:   tenant.tenantName,
      accessToken:  tokens.access_token,
      refreshToken: tokens.refresh_token,
      expiresAt:    new Date(Date.now() + tokens.expires_in * 1000),
    })

    return NextResponse.redirect(`${origin}/admin/settings?xero=connected&org=${encodeURIComponent(tenant.tenantName)}`)
  } catch (err) {
    console.error('Xero callback error:', err)
    return NextResponse.redirect(`${origin}/admin/settings?xero=error&reason=server`)
  }
}
