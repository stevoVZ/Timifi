'use client'
// app/admin/dashboard/page.tsx
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'
import Link from 'next/link'

const fmt = (n:number) => '$'+n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})

const KPI = [
  {label:'Active contractors', value:'2',      sub:'1 pending setup',  col:B.accent, icon:'👤', href:'/admin/contractors'},
  {label:'Awaiting approval',  value:'1',      sub:'1 submitted',      col:B.amber,  icon:'📄', href:'/admin/timesheets'},
  {label:'Outstanding invoices',value:fmt(55500),'sub':'2 invoices',   col:B.red,    icon:'🧾', href:'/admin/invoicing'},
  {label:'Pay run due',        value:'Mar 2026',sub:'3 approved',      col:B.green,  icon:'💳', href:'/admin/payroll'},
]

const RECENT_ACTIVITY = [
  {icon:'📄',text:'Timesheet submitted — Jordan Kim (March 2026)',    time:'2 min ago',  href:'/admin/timesheets'},
  {icon:'🧾',text:'Invoice INV-0047 created — Alex Rivera',          time:'1 hr ago',   href:'/admin/invoicing'},
  {icon:'✓', text:'Timesheet approved — Alex Rivera (February 2026)',time:'Yesterday',  href:'/admin/timesheets'},
  {icon:'🔗',text:'Xero sync completed — 48 contacts updated',       time:'2 days ago', href:'/admin/settings'},
  {icon:'🏛️',text:'STP accepted by ATO — February 2026',            time:'3 days ago', href:'/admin/payroll'},
]

const QUICK_NAV = [
  {label:'Upload timesheet',   href:'/admin/timesheets',    icon:'📤', col:B.accent, bg:B.aP,  bd:B.aBd},
  {label:'Create invoice',     href:'/admin/invoicing',     icon:'🧾', col:B.amber,  bg:B.aLP, bd:B.aLB},
  {label:'Run payroll',        href:'/admin/payroll',       icon:'💳', col:B.green,  bg:B.gP,  bd:B.gB},
  {label:'Add contractor',     href:'/admin/contractors',   icon:'👤', col:B.accent, bg:B.aP,  bd:B.aBd},
]

export default function DashboardPage() {
  return (
    <>
      <TopBar title="Dashboard" subtitle="March 2026 — FY2025–26" />
      <main style={{flex:1, padding:'28px 32px', background:B.bg}}>

        {/* KPI row */}
        <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16, marginBottom:24}}>
          {KPI.map(k => (
            <Link key={k.label} href={k.href} style={{textDecoration:'none'}}>
              <div className="card" style={{padding:'18px 20px', transition:'box-shadow .15s, transform .15s', cursor:'pointer'}}
                onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.transform='translateY(-2px)';(e.currentTarget as HTMLElement).style.boxShadow=B.sdwMd}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.transform='none';(e.currentTarget as HTMLElement).style.boxShadow=B.sdw}}
              >
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:10}}>
                  <span style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:B.dim}}>{k.label}</span>
                  <span style={{fontSize:20}}>{k.icon}</span>
                </div>
                <div style={{fontFamily:"'DM Mono',monospace",fontSize:22,fontWeight:700,color:k.col,marginBottom:4}}>{k.value}</div>
                <div style={{fontSize:12.5,color:B.sub}}>{k.sub}</div>
              </div>
            </Link>
          ))}
        </div>

        <div style={{display:'grid', gridTemplateColumns:'1fr 320px', gap:20}}>

          {/* Left col */}
          <div style={{display:'flex', flexDirection:'column', gap:20}}>

            {/* Quick actions */}
            <div>
              <div style={{fontSize:12,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:B.dim,marginBottom:10}}>Quick actions</div>
              <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10}}>
                {QUICK_NAV.map(n=>(
                  <Link key={n.label} href={n.href} style={{
                    display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
                    gap:8,padding:'16px 8px',borderRadius:12,textDecoration:'none',
                    background:n.bg,border:`1.5px solid ${n.bd}`,
                    transition:'all .13s',
                  }}
                  onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.transform='translateY(-2px)'}}
                  onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.transform='none'}}
                  >
                    <span style={{fontSize:24}}>{n.icon}</span>
                    <span style={{fontSize:12.5,fontWeight:600,color:n.col,textAlign:'center',lineHeight:1.3}}>{n.label}</span>
                  </Link>
                ))}
              </div>
            </div>

            {/* Contractor overview */}
            <div className="card" style={{overflow:'hidden'}}>
              <div style={{padding:'14px 18px',borderBottom:`1px solid ${B.faint}`,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <span style={{fontSize:13.5,fontWeight:700,color:B.text}}>Contractor overview</span>
                <Link href="/admin/contractors" style={{fontSize:13,color:B.accent,textDecoration:'none',fontWeight:600}}>View all →</Link>
              </div>
              <table style={{width:'100%',borderCollapse:'collapse'}}>
                <thead>
                  <tr style={{background:B.bg}}>
                    {['Contractor','Client','Rate','This month','YTD','Status'].map(h=>(
                      <th key={h} style={{padding:'10px 16px',textAlign:'left',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim}}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    {id:'c1',name:'Alex Rivera',  init:'AR',col:'#2563eb',bg:'#eff6ff',client:'Client A',rate:120,hours:172,ytd:57120,status:'ACTIVE'},
                    {id:'c2',name:'Jordan Kim',   init:'JK',col:'#7c3aed',bg:'#f5f3ff',client:'Client B',rate:95, hours:164,ytd:29640,status:'ACTIVE'},
                    {id:'c3',name:'Sam Okafor',   init:'SO',col:'#059669',bg:'#ecfdf5',client:'Client C',rate:105,hours:0,  ytd:0,    status:'PENDING_SETUP'},
                  ].map((c,i)=>(
                    <tr key={c.id} style={{borderTop:`1px solid ${B.faint}`}}>
                      <td style={{padding:'12px 16px'}}>
                        <Link href={`/admin/contractors/${c.id}`} style={{display:'flex',alignItems:'center',gap:8,textDecoration:'none'}}>
                          <div style={{width:28,height:28,borderRadius:8,background:c.bg,color:c.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,flexShrink:0}}>{c.init}</div>
                          <span style={{fontSize:13.5,fontWeight:500,color:B.text}}>{c.name}</span>
                        </Link>
                      </td>
                      <td style={{padding:'12px 16px',fontSize:13,color:B.dim}}>{c.client}</td>
                      <td style={{padding:'12px 16px',fontFamily:"'DM Mono',monospace",fontSize:13,color:B.dim}}>${c.rate}/hr</td>
                      <td style={{padding:'12px 16px',fontFamily:"'DM Mono',monospace",fontSize:13,color:B.text}}>{c.hours>0?`${c.hours}h`:'—'}</td>
                      <td style={{padding:'12px 16px',fontFamily:"'DM Mono',monospace",fontSize:13,color:B.green}}>{c.ytd>0?fmt(c.ytd):'—'}</td>
                      <td style={{padding:'12px 16px'}}>
                        <span style={{fontSize:11.5,fontWeight:600,padding:'3px 8px',borderRadius:100,
                          background:c.status==='ACTIVE'?B.gP:B.aLP,
                          color:c.status==='ACTIVE'?B.green:B.amber,
                        }}>{c.status.replace('_',' ')}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right col: activity feed */}
          <div className="card" style={{overflow:'hidden',alignSelf:'start'}}>
            <div style={{padding:'14px 18px',borderBottom:`1px solid ${B.faint}`}}>
              <span style={{fontSize:13.5,fontWeight:700,color:B.text}}>Recent activity</span>
            </div>
            <div>
              {RECENT_ACTIVITY.map((a,i)=>(
                <Link key={i} href={a.href} style={{
                  display:'flex',alignItems:'flex-start',gap:10,
                  padding:'12px 16px',borderBottom:i<RECENT_ACTIVITY.length-1?`1px solid ${B.faint}`:'none',
                  textDecoration:'none',transition:'background .12s',
                }}
                onMouseEnter={e=>(e.currentTarget as HTMLElement).style.background=B.faint}
                onMouseLeave={e=>(e.currentTarget as HTMLElement).style.background='transparent'}
                >
                  <span style={{fontSize:16,flexShrink:0,marginTop:1}}>{a.icon}</span>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:13,color:B.text,lineHeight:1.4}}>{a.text}</div>
                    <div style={{fontSize:11.5,color:B.sub,marginTop:3}}>{a.time}</div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </main>
    </>
  )
}
