// app/admin/timesheets/page.tsx
import TopBar from '@/components/layout/TopBar'
import TimesheetUpload from '@/components/timesheets/TimesheetUpload'

export default function TimesheetsPage() {
  return (
    <>
      <TopBar
        title="Timesheet Uploads"
        subtitle="AI scanning · duplicate detection · version history"
      />
      <main style={{ flex:1 }}>
        <TimesheetUpload />
      </main>
    </>
  )
}
