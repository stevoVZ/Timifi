'use client'
// app/admin/contractors/[id]/page.tsx
import { useState } from 'react'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

/* ── Static seed (replace with Supabase fetch in production) ─────────────── */
const CONTRACTORS: Record<string, ContractorData> = {
  c1: {
    id:'c1', firstName:'Alex', lastName:'Rivera', initials:'AR', col:'#2563eb', bg:'#eff6ff',
    email:'alex.rivera@email.com', phone:'0412 345 678', status:'ACTIVE',
    jobTitle:'Senior Developer', client:'Client A', hourlyRate:120, contractHoursPA:2000,
    payFrequency:'MONTHLY', startDate:'2024-01-15', clearance:'BASELINE', clearanceExpiry:'2026-12-31',
    suburb:'North Sydney', state:'NSW', postcode:'2060',
    xeroEmployeeId:'EMP-001', xeroContactId:'xero-contact-c1',
    timesheets:[
      { id:'t1', month:'March 2026',  hours:172, status:'APPROVED',   invoiced:true  },
      { id:'t2', month:'February 2026', hours:160, status:'APPROVED', invoiced:true  },
      { id:'t3', month:'January 2026',  hours:144, status:'APPROVED', invoiced:false },
    ],
    invoices:[
      { id:'i1', number:'INV-0047', period:'March 2026',    amount:20640, status:'SENT',      due:'2026-04-15' },
      { id:'i2', number:'INV-0039', period:'February 2026', amount:19200, status:'PAID',      due:'2026-03-14' },
      { id:'i3', number:'INV-0031', period:'January 2026',  amount:17280, status:'OVERDUE',   due:'2026-02-14' },
    ],
  },
  c2: {
    id:'c2', firstName:'Jordan', lastName:'Kim', initials:'JK', col:'#7c3aed', bg:'#f5f3ff',
    email:'jordan.kim@email.com', phone:'0423 456 789', status:'ACTIVE',
    jobTitle:'Business Analyst', client:'Client B', hourlyRate:95, contractHoursPA:2000,
    payFrequency:'MONTHLY', startDate:'2024-03-01', clearance:'NONE', clearanceExpiry:null,
    suburb:'Surry Hills', state:'NSW', postcode:'2010',
    xeroEmployeeId:'EMP-002', xeroContactId:'xero-contact-c2',
    timesheets:[ { id:'t4', month:'March 2026', hours:164, status:'SUBMITTED', invoiced:false } ],
    invoices:[],
  },
  c3: {
    id:'c3', firstName:'Sam', lastName:'Okafor', initials:'SO', col:'#059669', bg:'#ecfdf5',
    email:'sam.okafor@email.com', phone:'0434 567 890', status:'PENDING_SETUP',
    jobTitle:'Project Manager', client:'Client C', hourlyRate:105, contractHoursPA:1800,
    payFrequency:'MONTHLY', startDate:'2026-03-10', clearance:'NONE', clearanceExpiry:null,
    suburb:'Melbourne', state:'VIC', postcode:'3000',
    xeroEmployeeId:null, xeroContactId:null,
    timesheets:[], invoices:[],
  },
}

/* ── Types ───────────────────────────────────────────────────────────────── */
interface ContractorData {
  id:string; firstName:string; lastName:string; initials:string; col:string; bg:string
  email:string; phone:string; status:string; jobTitle:string; client:string
  hourlyRate:number; contractHoursPA:number; payFrequency:string
  startDate:string; clearance:string; clearanceExpiry:string|null
  suburb:string; state:string; postcode:string
  xeroEmployeeId:string|null; xeroContactId:string|null
  timesheets:{id:string;month:string;hours:number;status:string;invoiced:boolean}[]
  invoices:{id:string;number:string;period:string;amount:number;status:string;due:string}[]
}

const STATUS_PILL: Record<string,{bg:string,c:string}> = {
  ACTIVE:        {bg:B.gP,  c:B.green },
  PENDING_SETUP: {bg:B.aLP, c:B.amber },
  OFFBOARDED:    {bg:B.faint,c:B.dim  },
  APPROVED:      {bg:B.gP,  c:B.green },
  SUBMITTED:     {bg:B.aLP, c:B.amber },
  REJECTED:      {bg:B.rP,  c:B.red   },
  DRAFT:         {bg:B.faint,c:B.dim  },
  PAID:          {bg:B.gP,  c:B.green },
  SENT:          {bg:B.aP,  c:B.accent},
  AUTHORISED:    {bg:B.aP,  c:B.accent},
  OVERDUE:       {bg:B.rP,  c:B.red   },
}

const fmt = (n: number) =>
  '$' + n.toLocaleString('en-AU', { minimumFractionDigits:2, maximumFractionDigits:2 })

/* ═══════════════════════════════════════════════════════════════════════════ */
export default function ContractorDetailPage({ params }: { params: { id: string } }) {
  const [tab, setTab] = useState<'profile'|'timesheets'|'invoices'>('profile')
  const [creatingInvoice, setCreatingInvoice] = useState<string|null>(null)
  const [toast, setToast] = useState<string|null>(null)

  const toast_ = (msg:string) => { setToast(msg); setTimeout(()=>setToast(null),3200) }

  const c = CONTRACTORS[params.id] || CONTRACTORS['c1']
  const pill = STATUS_PILL[c.status] || {bg:B.faint,c:B.dim}

  const handleCreateInvoice = async (tsId: string) => {
    setCreatingInvoice(tsId)
    // In production: POST /api/xero/invoices with { versionId }
    await new Promise(r => setTimeout(r, 1200))
    setCreatingInvoice(null)
    toast_('✓ Invoice created in Xero — INV-0052')
  }

  return (
    <>
      <TopBar
        title={`${c.firstName} ${c.lastName}`}
        subtitle={`${c.jobTitle} · ${c.client}`}
        actions={
          <a href="/admin/contractors" style={{ fontSize:13, color:B.dim, textDecoration:'none' }}>← All contractors</a>
        }
      />

      <main style={{ flex:1, padding:'28px 32px', background:B.bg }}>
        <div style={{ display:'grid', gridTemplateColumns:'280px 1fr', gap:20, alignItems:'start' }}>

          {/* ── Left: identity card ── */}
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div className="card" style={{ padding:'22px 20px', textAlign:'center' }}>
              <div style={{ width:64,height:64,borderRadius:16,background:c.bg,color:c.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:22,fontWeight:700,margin:'0 auto 12px' }}>{c.initials}</div>
              <div style={{ fontSize:18, fontWeight:700, color:B.text }}>{c.firstName} {c.lastName}</div>
              <div style={{ fontSize:13, color:B.dim, margin:'4px 0 10px' }}>{c.jobTitle}</div>
              <span style={{ fontSize:12, fontWeight:600, padding:'4px 12px', borderRadius:100, background:pill.bg, color:pill.c }}>
                {c.status.replace('_',' ')}
              </span>
            </div>

            {/* Key info */}
            <div className="card" style={{ overflow:'hidden' }}>
              <div style={{ padding:'12px 16px', borderBottom:`1px solid ${B.faint}`, background:B.bg }}>
                <span style={{ fontSize:12, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim }}>Details</span>
              </div>
              <div style={{ padding:'14px 16px' }}>
                {[
                  ['Client',    c.client],
                  ['Rate',      `$${c.hourlyRate}/hr`],
                  ['Contract',  `${c.contractHoursPA.toLocaleString()}h/yr`],
                  ['Pay freq',  c.payFrequency.charAt(0)+c.payFrequency.slice(1).toLowerCase()],
                  ['Start',     c.startDate],
                  ['Location',  `${c.suburb} ${c.state} ${c.postcode}`],
                  ['Clearance', c.clearance + (c.clearanceExpiry ? ` · exp ${c.clearanceExpiry}` : '')],
                ].map(([k,v]) => (
                  <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'6px 0', borderBottom:`1px solid ${B.faint}` }}>
                    <span style={{ fontSize:12.5, color:B.dim }}>{k}</span>
                    <span style={{ fontSize:12.5, color:B.text, fontWeight:500, textAlign:'right', maxWidth:160 }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Xero status */}
            <div className="card" style={{ padding:'14px 16px' }}>
              <div style={{ fontSize:12, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim, marginBottom:10 }}>Xero</div>
              {c.xeroEmployeeId ? (
                <>
                  <div style={{ fontSize:13, color:B.green, fontWeight:600, marginBottom:4 }}>✓ Linked to Xero</div>
                  <div style={{ fontSize:12, color:B.dim }}>Employee: {c.xeroEmployeeId}</div>
                  <div style={{ fontSize:12, color:B.dim }}>Contact: {c.xeroContactId}</div>
                </>
              ) : (
                <div style={{ fontSize:13, color:B.amber }}>⚠ Not in Xero — <a href="/api/xero/auth" style={{ color:B.accent }}>connect</a> first</div>
              )}
            </div>

            {/* Quick actions */}
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              <a href={`/admin/timesheets?contractor=${c.id}`} className="btn btn-accent" style={{ textDecoration:'none', padding:'10px 0', justifyContent:'center' }}>📄 Upload timesheet</a>
              <a href="/admin/payroll" className="btn btn-ghost" style={{ textDecoration:'none', padding:'9px 0', justifyContent:'center' }}>💳 Pay runs</a>
            </div>
          </div>

          {/* ── Right: tabbed detail ── */}
          <div className="card" style={{ overflow:'hidden' }}>
            {/* Tabs */}
            <div style={{ display:'flex', borderBottom:`1px solid ${B.border}`, padding:'0 4px' }}>
              {(['profile','timesheets','invoices'] as const).map(t => (
                <button key={t} onClick={()=>setTab(t)} className={`tab${tab===t?' on':''}`} style={{ textTransform:'capitalize' }}>
                  {t}
                  {t==='timesheets' && c.timesheets.length>0 && (
                    <span style={{ marginLeft:6, fontSize:11, padding:'1px 6px', borderRadius:4, background:tab===t?B.accent:B.border, color:tab===t?'#fff':B.dim }}>{c.timesheets.length}</span>
                  )}
                </button>
              ))}
            </div>

            {/* Profile tab */}
            {tab==='profile' && (
              <div style={{ padding:'22px 24px' }}>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
                  {[
                    ['First name', c.firstName],['Last name', c.lastName],
                    ['Email', c.email],['Phone', c.phone],
                    ['Suburb', c.suburb],['State / Postcode', `${c.state} ${c.postcode}`],
                  ].map(([k,v]) => (
                    <div key={k}>
                      <div style={{ fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim, marginBottom:6 }}>{k}</div>
                      <div style={{ fontSize:14, color:B.text, padding:'9px 12px', background:B.bg, borderRadius:8, border:`1px solid ${B.border}` }}>{v}</div>
                    </div>
                  ))}
                </div>

                {/* Contract hours utilisation */}
                <div style={{ marginTop:20, padding:'16px', background:B.bg, borderRadius:10, border:`1px solid ${B.border}` }}>
                  <div style={{ fontSize:13, fontWeight:700, color:B.text, marginBottom:10 }}>Contract hours — {new Date().getFullYear()}</div>
                  {(() => {
                    const ytdHours  = c.timesheets.filter(t=>t.status==='APPROVED').reduce((s,t)=>s+t.hours,0)
                    const pct       = Math.min(100, Math.round((ytdHours/c.contractHoursPA)*100))
                    const col       = pct>100?B.red:pct>80?B.amber:B.green
                    return (
                      <>
                        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                          <span style={{ fontSize:13, color:B.dim }}>YTD: <strong style={{ color:B.text }}>{ytdHours}h</strong> of {c.contractHoursPA}h</span>
                          <span style={{ fontFamily:"'DM Mono',monospace", fontSize:13, color:col }}>{pct}%</span>
                        </div>
                        <div style={{ height:8, borderRadius:4, background:B.border, overflow:'hidden' }}>
                          <div style={{ height:'100%', width:`${pct}%`, background:col, borderRadius:4, transition:'width .4s' }}/>
                        </div>
                        <div style={{ fontSize:12, color:B.dim, marginTop:6 }}>
                          {c.contractHoursPA - ytdHours > 0 ? `${c.contractHoursPA - ytdHours}h remaining` : `${ytdHours - c.contractHoursPA}h over contract`}
                        </div>
                      </>
                    )
                  })()}
                </div>
              </div>
            )}

            {/* Timesheets tab */}
            {tab==='timesheets' && (
              <div style={{ padding:'0' }}>
                {c.timesheets.length === 0 ? (
                  <div style={{ padding:'48px', textAlign:'center', color:B.dim }}>
                    <div style={{ fontSize:32, marginBottom:12 }}>📄</div>
                    <div style={{ fontSize:15, fontWeight:600, color:B.text, marginBottom:6 }}>No timesheets yet</div>
                    <a href={`/admin/timesheets?contractor=${c.id}`} style={{ fontSize:13.5, color:B.accent, fontWeight:600, textDecoration:'none' }}>Upload first timesheet →</a>
                  </div>
                ) : (
                  <table style={{ width:'100%', borderCollapse:'collapse' }}>
                    <thead>
                      <tr style={{ background:B.bg, borderBottom:`1px solid ${B.border}` }}>
                        {['Period','Hours','Status','Invoiced',''].map(h => (
                          <th key={h} style={{ padding:'11px 18px', textAlign:'left', fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {c.timesheets.map((t, i) => {
                        const sp = STATUS_PILL[t.status] || {bg:B.faint,c:B.dim}
                        const canInvoice = t.status==='APPROVED' && !t.invoiced && !!c.xeroContactId
                        return (
                          <tr key={t.id} style={{ borderBottom:i<c.timesheets.length-1?`1px solid ${B.faint}`:'none' }}>
                            <td style={{ padding:'13px 18px', fontSize:14, fontWeight:500, color:B.text }}>{t.month}</td>
                            <td style={{ padding:'13px 18px', fontFamily:"'DM Mono',monospace", fontSize:13.5, color:B.text }}>{t.hours}h</td>
                            <td style={{ padding:'13px 18px' }}>
                              <span style={{ fontSize:12, fontWeight:600, padding:'3px 9px', borderRadius:100, background:sp.bg, color:sp.c }}>{t.status}</span>
                            </td>
                            <td style={{ padding:'13px 18px' }}>
                              {t.invoiced
                                ? <span style={{ fontSize:12, color:B.green, fontWeight:600 }}>✓ Invoiced</span>
                                : <span style={{ fontSize:12, color:B.sub }}>—</span>}
                            </td>
                            <td style={{ padding:'13px 18px' }}>
                              {canInvoice && (
                                <button
                                  onClick={() => handleCreateInvoice(t.id)}
                                  disabled={creatingInvoice===t.id}
                                  style={{ padding:'6px 12px', borderRadius:7, border:`1.5px solid ${B.aBd}`, background:B.aP, color:B.accent, fontSize:12, fontWeight:600, fontFamily:"'DM Sans',sans-serif", cursor:'pointer' }}
                                >
                                  {creatingInvoice===t.id ? 'Creating…' : '🧾 Create invoice'}
                                </button>
                              )}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {/* Invoices tab */}
            {tab==='invoices' && (
              <div style={{ padding:'0' }}>
                {c.invoices.length === 0 ? (
                  <div style={{ padding:'48px', textAlign:'center', color:B.dim }}>
                    <div style={{ fontSize:32, marginBottom:12 }}>🧾</div>
                    <div style={{ fontSize:15, fontWeight:600, color:B.text, marginBottom:6 }}>No invoices yet</div>
                    <div style={{ fontSize:13.5, color:B.dim }}>Invoices appear here once created from approved timesheets.</div>
                  </div>
                ) : (
                  <table style={{ width:'100%', borderCollapse:'collapse' }}>
                    <thead>
                      <tr style={{ background:B.bg, borderBottom:`1px solid ${B.border}` }}>
                        {['Invoice','Period','Amount','Status','Due',''].map(h => (
                          <th key={h} style={{ padding:'11px 18px', textAlign:'left', fontSize:11, fontWeight:700, textTransform:'uppercase', letterSpacing:'.06em', color:B.dim }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {c.invoices.map((inv, i) => {
                        const sp = STATUS_PILL[inv.status]||{bg:B.faint,c:B.dim}
                        return (
                          <tr key={inv.id} style={{ borderBottom:i<c.invoices.length-1?`1px solid ${B.faint}`:'none' }}>
                            <td style={{ padding:'13px 18px', fontFamily:"'DM Mono',monospace", fontSize:13.5, color:B.accent, fontWeight:600 }}>{inv.number}</td>
                            <td style={{ padding:'13px 18px', fontSize:13.5, color:B.text }}>{inv.period}</td>
                            <td style={{ padding:'13px 18px', fontFamily:"'DM Mono',monospace", fontSize:13.5, color:B.text, fontWeight:600 }}>{fmt(inv.amount)}</td>
                            <td style={{ padding:'13px 18px' }}>
                              <span style={{ fontSize:12, fontWeight:600, padding:'3px 9px', borderRadius:100, background:sp.bg, color:sp.c }}>{inv.status}</span>
                            </td>
                            <td style={{ padding:'13px 18px', fontSize:13, color:inv.status==='OVERDUE'?B.red:B.dim }}>{inv.due}</td>
                            <td style={{ padding:'13px 18px' }}>
                              <a href="#" style={{ fontSize:12.5, color:B.accent, fontWeight:600, textDecoration:'none' }}>View in Xero →</a>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      {toast && (
        <div style={{ position:'fixed', bottom:24, right:24, zIndex:999, background:B.text, color:'#fff', padding:'12px 22px', borderRadius:10, fontWeight:600, fontSize:13, boxShadow:'0 4px 16px rgba(0,0,0,.18)' }}>
          {toast}
        </div>
      )}
    </>
  )
}
