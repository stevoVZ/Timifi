// app/admin/contractors/page.tsx
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

const CONTRACTORS = [
  { id:'c1', name:'Alex Rivera',  initials:'AR', col:'#2563eb', bg:'#eff6ff', rate:120, client:'Client A', status:'Active'  },
  { id:'c2', name:'Jordan Kim',   initials:'JK', col:'#7c3aed', bg:'#f5f3ff', rate:95,  client:'Client B', status:'Active'  },
  { id:'c3', name:'Sam Okafor',   initials:'SO', col:'#059669', bg:'#ecfdf5', rate:105, client:'Client C', status:'Pending' },
]

const STATUS_STYLE: Record<string,{bg:string,color:string}> = {
  Active:  { bg:B.gP, color:B.green },
  Pending: { bg:B.aLP, color:B.amber },
  Inactive:{ bg:B.faint, color:B.dim },
}

export default function ContractorsPage() {
  return (
    <>
      <TopBar
        title="Contractors"
        subtitle={`${CONTRACTORS.length} contractors`}
        actions={
          <a href="/admin/contractors/new" style={{
            padding:'8px 16px',background:B.accent,color:'#fff',borderRadius:8,
            fontSize:13,fontWeight:600,textDecoration:'none',
          }}>+ Add contractor</a>
        }
      />
      <main style={{flex:1,padding:'28px 32px',background:B.bg}}>
        <div style={{background:B.surface,border:`1px solid ${B.border}`,borderRadius:12,overflow:'hidden'}}>
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead>
              <tr style={{borderBottom:`1px solid ${B.border}`,background:B.bg}}>
                {['Contractor','Client','Rate','Status','Actions'].map(h=>(
                  <th key={h} style={{
                    padding:'12px 18px',textAlign:'left',fontSize:11,fontWeight:700,
                    textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {CONTRACTORS.map((c,i)=>(
                <tr key={c.id} style={{borderBottom:i<CONTRACTORS.length-1?`1px solid ${B.faint}`:'none'}}>
                  <td style={{padding:'14px 18px'}}>
                    <div style={{display:'flex',alignItems:'center',gap:10}}>
                      <div style={{
                        width:34,height:34,borderRadius:9,background:c.bg,color:c.col,
                        display:'flex',alignItems:'center',justifyContent:'center',
                        fontSize:11,fontWeight:700,flexShrink:0,
                      }}>{c.initials}</div>
                      <div>
                        <div style={{fontSize:14,fontWeight:600,color:B.text}}>{c.name}</div>
                        <div style={{fontSize:12,color:B.dim}}>contractor</div>
                      </div>
                    </div>
                  </td>
                  <td style={{padding:'14px 18px',fontSize:13.5,color:B.mid}}>{c.client}</td>
                  <td style={{padding:'14px 18px',fontFamily:"'DM Mono',monospace",fontSize:13.5,color:B.text}}>
                    ${c.rate}/hr
                  </td>
                  <td style={{padding:'14px 18px'}}>
                    <span style={{
                      fontSize:12,fontWeight:600,padding:'3px 10px',borderRadius:100,
                      ...STATUS_STYLE[c.status]||{bg:B.faint,color:B.dim},
                    }}>{c.status}</span>
                  </td>
                  <td style={{padding:'14px 18px'}}>
                    <div style={{display:'flex',gap:8}}>
                      <a href={`/admin/contractors/${c.id}`} style={{
                        fontSize:12.5,color:B.accent,fontWeight:600,textDecoration:'none',
                      }}>View</a>
                      <a href={`/admin/timesheets?contractor=${c.id}`} style={{
                        fontSize:12.5,color:B.dim,fontWeight:500,textDecoration:'none',
                      }}>Upload timesheet</a>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </>
  )
}
