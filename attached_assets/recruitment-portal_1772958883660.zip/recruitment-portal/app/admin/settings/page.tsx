'use client'
// app/admin/settings/page.tsx
import { useState, useEffect } from 'react'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

type Tab = 'branding'|'company'|'payroll'|'xero'|'portal'|'users'

const TABS: {id:Tab, label:string, icon:string}[] = [
  {id:'branding', label:'Branding',  icon:'🎨'},
  {id:'company',  label:'Company',   icon:'🏢'},
  {id:'payroll',  label:'Payroll',   icon:'💳'},
  {id:'xero',     label:'Xero',      icon:'🔗'},
  {id:'portal',   label:'Portal',    icon:'🔒'},
  {id:'users',    label:'Users',     icon:'👤'},
]

const Input = ({label, value, onChange, type='text', hint}:{label:string,value:string,onChange:(v:string)=>void,type?:string,hint?:string}) => (
  <div>
    <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>{label}</label>
    <input
      type={type} value={value} onChange={e=>onChange(e.target.value)}
      style={{width:'100%',padding:'10px 13px',fontFamily:"'DM Sans',sans-serif",fontSize:14,border:`1.5px solid ${B.border}`,borderRadius:9,color:B.text,outline:'none',background:B.surface,boxSizing:'border-box'}}
      onFocus={e=>e.target.style.borderColor=B.accent}
      onBlur={e=>e.target.style.borderColor=B.border}
    />
    {hint && <div style={{fontSize:12,color:B.sub,marginTop:5}}>{hint}</div>}
  </div>
)

const Toggle = ({label, desc, value, onChange}:{label:string,desc?:string,value:boolean,onChange:(v:boolean)=>void}) => (
  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'13px 0',borderBottom:`1px solid ${B.faint}`}}>
    <div>
      <div style={{fontSize:14,fontWeight:500,color:B.text}}>{label}</div>
      {desc && <div style={{fontSize:12.5,color:B.dim,marginTop:2}}>{desc}</div>}
    </div>
    <button
      onClick={()=>onChange(!value)}
      style={{
        width:44,height:24,borderRadius:12,border:'none',cursor:'pointer',
        background:value?B.green:B.border,
        position:'relative',transition:'background .18s',flexShrink:0,
      }}
    >
      <span style={{
        position:'absolute',top:3,left:value?22:3,width:18,height:18,
        borderRadius:'50%',background:'#fff',
        boxShadow:'0 1px 4px rgba(0,0,0,.2)',transition:'left .18s',
      }}/>
    </button>
  </div>
)

export default function SettingsPage() {
  const [tab,     setTab]    = useState<Tab>('branding')
  const [saved,   setSaved]  = useState(false)
  const [xeroOrg, setXeroOrg] = useState<string|null>(null)

  // Check for Xero connection result from URL params
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get('xero') === 'connected') setXeroOrg(params.get('org') || 'Connected')
  }, [])

  // Settings state
  const [branding, setBranding] = useState({
    agencyName: 'Your Agency Name', accentColor: '#2563eb',
    logoUrl: '', faviconUrl: '', primaryEmail: 'admin@youragency.com.au',
  })
  const [company, setCompany] = useState({
    abn: '', acn: '', registeredName: '', address: '',
    suburb: '', state: 'NSW', postcode: '', phone: '',
  })
  const [payroll, setPayroll] = useState({
    superRate: '11.5', paymentTermsDays: '14',
    defaultPayCalendar: 'MONTHLY', financialYearEnd: '30 June',
    stpEnabled: true, autoSuperCalc: true,
  })
  const [portal, setPortal] = useState({
    contractorSelfService: true, contractorUpload: false,
    mfaRequired: false, sessionTimeoutMinutes: '60',
  })

  const handleSave = async () => {
    // In production: POST /api/settings with all settings
    await new Promise(r => setTimeout(r, 600))
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  return (
    <>
      <TopBar title="Settings" subtitle="Portal configuration"
        actions={
          <button onClick={handleSave} className="btn btn-accent btn-sm" style={{padding:'8px 18px'}}>
            {saved ? '✓ Saved' : 'Save changes'}
          </button>
        }
      />

      <main style={{flex:1, padding:'28px 32px', background:B.bg}}>
        <div style={{display:'grid', gridTemplateColumns:'200px 1fr', gap:20, alignItems:'start'}}>

          {/* Sidebar nav */}
          <div className="card" style={{overflow:'hidden'}}>
            {TABS.map(t => (
              <button key={t.id} onClick={()=>setTab(t.id)} style={{
                width:'100%', padding:'11px 16px', border:'none', cursor:'pointer',
                fontFamily:"'DM Sans',sans-serif", fontSize:13.5, textAlign:'left',
                display:'flex', alignItems:'center', gap:10,
                background: tab===t.id ? B.aP : 'transparent',
                color:      tab===t.id ? B.accent : B.dim,
                fontWeight: tab===t.id ? 600 : 400,
                borderRight: tab===t.id ? `3px solid ${B.accent}` : '3px solid transparent',
                transition:'all .12s',
              }}>
                <span style={{fontSize:16}}>{t.icon}</span>
                {t.label}
              </button>
            ))}
          </div>

          {/* Content panel */}
          <div className="card" style={{padding:'28px 30px'}}>

            {/* Branding */}
            {tab==='branding' && (
              <div style={{display:'flex', flexDirection:'column', gap:18}}>
                <div>
                  <h2 style={{fontSize:16,fontWeight:700,color:B.text,marginBottom:4}}>Branding</h2>
                  <p style={{fontSize:13.5,color:B.dim}}>Customise the portal name and colours for your agency.</p>
                </div>
                <Input label="Agency name" value={branding.agencyName} onChange={v=>setBranding(b=>({...b,agencyName:v}))} hint="Shown in the portal header and emails"/>
                <Input label="Primary email" value={branding.primaryEmail} onChange={v=>setBranding(b=>({...b,primaryEmail:v}))} type="email" hint="Used as reply-to on outgoing notifications"/>
                <div>
                  <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>Accent colour</label>
                  <div style={{display:'flex', alignItems:'center', gap:10}}>
                    <input type="color" value={branding.accentColor} onChange={e=>setBranding(b=>({...b,accentColor:e.target.value}))}
                      style={{width:44,height:44,padding:3,borderRadius:9,border:`1.5px solid ${B.border}`,cursor:'pointer'}}/>
                    <span style={{fontFamily:"'DM Mono',monospace",fontSize:13,color:B.dim}}>{branding.accentColor}</span>
                    <div style={{width:24,height:24,borderRadius:6,background:branding.accentColor}}/>
                  </div>
                  <div style={{fontSize:12,color:B.sub,marginTop:5}}>Used for buttons, links, and active nav items throughout the portal.</div>
                </div>
                <Input label="Logo URL" value={branding.logoUrl} onChange={v=>setBranding(b=>({...b,logoUrl:v}))} hint="Hosted image URL — recommended 200×50px SVG or PNG"/>
              </div>
            )}

            {/* Company */}
            {tab==='company' && (
              <div style={{display:'flex', flexDirection:'column', gap:18}}>
                <div>
                  <h2 style={{fontSize:16,fontWeight:700,color:B.text,marginBottom:4}}>Company details</h2>
                  <p style={{fontSize:13.5,color:B.dim}}>Used on invoices, payslips, and STP submissions.</p>
                </div>
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
                  <Input label="ABN" value={company.abn} onChange={v=>setCompany(c=>({...c,abn:v}))} hint="e.g. 12 345 678 901"/>
                  <Input label="ACN" value={company.acn} onChange={v=>setCompany(c=>({...c,acn:v}))} hint="Optional"/>
                  <Input label="Registered business name" value={company.registeredName} onChange={v=>setCompany(c=>({...c,registeredName:v}))}/>
                  <Input label="Phone" value={company.phone} onChange={v=>setCompany(c=>({...c,phone:v}))} type="tel"/>
                </div>
                <Input label="Street address" value={company.address} onChange={v=>setCompany(c=>({...c,address:v}))}/>
                <div style={{display:'grid', gridTemplateColumns:'1fr auto auto', gap:12}}>
                  <Input label="Suburb" value={company.suburb} onChange={v=>setCompany(c=>({...c,suburb:v}))}/>
                  <div>
                    <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>State</label>
                    <select value={company.state} onChange={e=>setCompany(c=>({...c,state:e.target.value}))}
                      style={{padding:'10px 13px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,background:B.surface}}>
                      {['NSW','VIC','QLD','SA','WA','TAS','ACT','NT'].map(s=><option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <Input label="Postcode" value={company.postcode} onChange={v=>setCompany(c=>({...c,postcode:v}))}/>
                </div>
              </div>
            )}

            {/* Payroll */}
            {tab==='payroll' && (
              <div style={{display:'flex', flexDirection:'column', gap:18}}>
                <div>
                  <h2 style={{fontSize:16,fontWeight:700,color:B.text,marginBottom:4}}>Payroll settings</h2>
                  <p style={{fontSize:13.5,color:B.dim}}>Defaults applied to all pay runs and new contractors.</p>
                </div>
                <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
                  <Input label="Superannuation rate (%)" value={payroll.superRate} onChange={v=>setPayroll(p=>({...p,superRate:v}))} hint="Currently 11.5% (FY2025–26)"/>
                  <Input label="Invoice payment terms (days)" value={payroll.paymentTermsDays} onChange={v=>setPayroll(p=>({...p,paymentTermsDays:v}))} hint="e.g. 14 = net 14 days"/>
                </div>
                <div>
                  <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>Default pay calendar</label>
                  <div style={{display:'flex', gap:8}}>
                    {['WEEKLY','FORTNIGHTLY','MONTHLY'].map(v=>(
                      <button key={v} onClick={()=>setPayroll(p=>({...p,defaultPayCalendar:v}))} style={{
                        flex:1,padding:'10px',borderRadius:9,border:`1.5px solid ${payroll.defaultPayCalendar===v?B.accent:B.border}`,
                        background:payroll.defaultPayCalendar===v?B.aP:B.surface,
                        color:payroll.defaultPayCalendar===v?B.accent:B.dim,
                        fontFamily:"'DM Sans',sans-serif",fontSize:13,fontWeight:600,cursor:'pointer',
                        transition:'all .13s',
                      }}>{v.charAt(0)+v.slice(1).toLowerCase()}</button>
                    ))}
                  </div>
                </div>
                <div style={{marginTop:4}}>
                  <Toggle label="STP Phase 2 enabled" desc="Lodge Single Touch Payroll with ATO on each pay run" value={payroll.stpEnabled} onChange={v=>setPayroll(p=>({...p,stpEnabled:v}))}/>
                  <Toggle label="Auto-calculate super" desc="Compute SGC contribution automatically from gross earnings" value={payroll.autoSuperCalc} onChange={v=>setPayroll(p=>({...p,autoSuperCalc:v}))}/>
                </div>
              </div>
            )}

            {/* Xero */}
            {tab==='xero' && (
              <div style={{display:'flex', flexDirection:'column', gap:20}}>
                <div>
                  <h2 style={{fontSize:16,fontWeight:700,color:B.text,marginBottom:4}}>Xero connection</h2>
                  <p style={{fontSize:13.5,color:B.dim}}>Connect your Xero organisation to enable invoicing, payroll, and STP.</p>
                </div>

                {xeroOrg ? (
                  <div style={{padding:'18px 20px',background:B.gP,border:`1px solid ${B.gB}`,borderRadius:12}}>
                    <div style={{fontSize:15,fontWeight:700,color:B.green,marginBottom:4}}>✓ Connected to Xero</div>
                    <div style={{fontSize:13.5,color:B.mid,marginBottom:12}}>Organisation: <strong>{xeroOrg}</strong></div>
                    <a href="/api/xero/auth" style={{fontSize:13,color:B.dim,textDecoration:'none'}}>Reconnect / switch organisation →</a>
                  </div>
                ) : (
                  <div style={{padding:'20px',background:B.faint,border:`1px solid ${B.border}`,borderRadius:12,textAlign:'center'}}>
                    <div style={{fontSize:28,marginBottom:10}}>🔗</div>
                    <div style={{fontSize:15,fontWeight:600,color:B.text,marginBottom:6}}>Xero not connected</div>
                    <div style={{fontSize:13.5,color:B.dim,marginBottom:16}}>Connect Xero to enable invoicing, payroll filing, and STP Phase 2 lodgement.</div>
                    <a href="/api/xero/auth" style={{
                      display:'inline-flex',alignItems:'center',gap:8,
                      padding:'11px 24px',background:B.accent,color:'#fff',
                      borderRadius:9,textDecoration:'none',fontSize:14,fontWeight:600,
                    }}>Connect Xero →</a>
                  </div>
                )}

                <div style={{padding:'16px 18px',background:B.bg,border:`1px solid ${B.border}`,borderRadius:10}}>
                  <div style={{fontSize:13,fontWeight:700,color:B.text,marginBottom:8}}>What Xero is used for</div>
                  {[
                    ['Invoicing','Create and email invoices to client companies from approved timesheets'],
                    ['AU Payroll','Push pay runs, generate payslips, manage employee records'],
                    ['STP Phase 2','Lodge payroll data directly with the ATO each pay period'],
                    ['Contacts','Sync client companies as Xero contacts for invoice recipients'],
                  ].map(([k,v])=>(
                    <div key={k} style={{display:'flex',gap:10,padding:'8px 0',borderBottom:`1px solid ${B.faint}`}}>
                      <span style={{fontSize:13,color:B.green,flexShrink:0}}>✓</span>
                      <div><strong style={{fontSize:13,color:B.text}}>{k}</strong><span style={{fontSize:13,color:B.dim}}> — {v}</span></div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Portal */}
            {tab==='portal' && (
              <div style={{display:'flex', flexDirection:'column', gap:8}}>
                <div style={{marginBottom:10}}>
                  <h2 style={{fontSize:16,fontWeight:700,color:B.text,marginBottom:4}}>Portal access</h2>
                  <p style={{fontSize:13.5,color:B.dim}}>Control what contractors can do in the self-service portal.</p>
                </div>
                <Toggle label="Contractor self-service portal" desc="Contractors can log in to view payslips, messages, and timesheets" value={portal.contractorSelfService} onChange={v=>setPortal(p=>({...p,contractorSelfService:v}))}/>
                <Toggle label="Contractor timesheet upload" desc="Allow contractors to upload their own timesheets (admin still reviews)" value={portal.contractorUpload} onChange={v=>setPortal(p=>({...p,contractorUpload:v}))}/>
                <Toggle label="Require MFA for admins" desc="Admins and consultants must use two-factor authentication" value={portal.mfaRequired} onChange={v=>setPortal(p=>({...p,mfaRequired:v}))}/>
                <div style={{paddingTop:8}}>
                  <Input label="Admin session timeout (minutes)" value={portal.sessionTimeoutMinutes} onChange={v=>setPortal(p=>({...p,sessionTimeoutMinutes:v}))} hint="Admins are signed out after this period of inactivity"/>
                </div>
              </div>
            )}

            {/* Users */}
            {tab==='users' && (
              <div>
                <div style={{marginBottom:16}}>
                  <h2 style={{fontSize:16,fontWeight:700,color:B.text,marginBottom:4}}>Admin users</h2>
                  <p style={{fontSize:13.5,color:B.dim}}>Manage who has access to the admin portal.</p>
                </div>
                <div style={{display:'flex', flexDirection:'column', gap:8}}>
                  {[
                    {name:'Sarah Chen',  email:'sarah@agency.com.au',  role:'Admin',      initials:'SC'},
                    {name:'Marcus Webb', email:'marcus@agency.com.au', role:'Consultant', initials:'MW'},
                  ].map(u=>(
                    <div key={u.email} style={{display:'flex',alignItems:'center',gap:12,padding:'13px 16px',background:B.bg,borderRadius:10,border:`1px solid ${B.border}`}}>
                      <div style={{width:36,height:36,borderRadius:9,background:B.aP,color:B.accent,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700,flexShrink:0}}>{u.initials}</div>
                      <div style={{flex:1}}>
                        <div style={{fontSize:14,fontWeight:600,color:B.text}}>{u.name}</div>
                        <div style={{fontSize:12.5,color:B.dim}}>{u.email}</div>
                      </div>
                      <span style={{fontSize:12,fontWeight:600,padding:'3px 10px',borderRadius:100,background:u.role==='Admin'?B.aP:B.faint,color:u.role==='Admin'?B.accent:B.dim,border:`1px solid ${u.role==='Admin'?B.aBd:B.border}`}}>{u.role}</span>
                    </div>
                  ))}
                  <button className="btn btn-ghost btn-sm" style={{marginTop:4,width:'fit-content'}}>+ Invite user</button>
                </div>
              </div>
            )}

          </div>
        </div>
      </main>
    </>
  )
}
