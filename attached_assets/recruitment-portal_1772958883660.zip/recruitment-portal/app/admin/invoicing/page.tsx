'use client'
// app/admin/invoicing/page.tsx
import { useState } from 'react'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

const fmt = (n:number) => '$'+n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})

const STATUS_STYLE: Record<string,{bg:string,c:string}> = {
  DRAFT:      {bg:B.faint, c:B.dim   },
  AUTHORISED: {bg:B.aP,   c:B.accent },
  SENT:       {bg:B.aLP,  c:B.amber  },
  PAID:       {bg:B.gP,   c:B.green  },
  OVERDUE:    {bg:B.rP,   c:B.red    },
  VOIDED:     {bg:B.faint, c:B.sub   },
}

interface Invoice {
  id:string; number:string; contractor:string; initials:string; col:string; bg:string
  client:string; period:string; hours:number; rate:number; amount:number
  status:keyof typeof STATUS_STYLE; dueDate:string; sentTo?:string; xeroId?:string
}

const SEED: Invoice[] = [
  {id:'i1',number:'INV-0047',contractor:'Alex Rivera',initials:'AR',col:'#2563eb',bg:'#eff6ff',client:'Client A',period:'March 2026',   hours:172,rate:120,amount:20640,status:'AUTHORISED',dueDate:'15 Apr 2026'},
  {id:'i2',number:'INV-0046',contractor:'Jordan Kim',  initials:'JK',col:'#7c3aed',bg:'#f5f3ff',client:'Client B',period:'March 2026',   hours:164,rate:95, amount:15580,status:'SENT',      dueDate:'15 Apr 2026',sentTo:'accounts@clientb.com.au'},
  {id:'i3',number:'INV-0039',contractor:'Alex Rivera',initials:'AR',col:'#2563eb',bg:'#eff6ff',client:'Client A',period:'February 2026',hours:160,rate:120,amount:19200,status:'PAID',      dueDate:'14 Mar 2026'},
  {id:'i4',number:'INV-0038',contractor:'Jordan Kim',  initials:'JK',col:'#7c3aed',bg:'#f5f3ff',client:'Client B',period:'February 2026',hours:152,rate:95, amount:14440,status:'PAID',      dueDate:'14 Mar 2026'},
  {id:'i5',number:'INV-0031',contractor:'Alex Rivera',initials:'AR',col:'#2563eb',bg:'#eff6ff',client:'Client A',period:'January 2026', hours:144,rate:120,amount:17280,status:'OVERDUE',   dueDate:'14 Feb 2026'},
]

// Approved timesheets not yet invoiced
const PENDING = [
  {id:'p1',contractor:'Sam Okafor',initials:'SO',col:'#059669',bg:'#ecfdf5',client:'Client C',period:'March 2026',hours:158,rate:105,xeroContactId:'xero-c3'},
]

export default function InvoicingPage() {
  const [invoices, setInvoices] = useState<Invoice[]>(SEED)
  const [creating, setCreating] = useState<string|null>(null)
  const [toast,    setToast]    = useState<string|null>(null)
  const [filter,   setFilter]   = useState<string>('all')

  const toast_ = (msg:string) => { setToast(msg); setTimeout(()=>setToast(null),3200) }

  const handleCreate = async (p: typeof PENDING[0]) => {
    setCreating(p.id)
    const res = await fetch('/api/xero/invoices', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({versionId:'demo-version-id', sendEmail:false}),
    }).catch(()=>null)

    // Optimistic update for demo
    const num = 'INV-'+(1000+invoices.length+1)
    setInvoices(prev=>[{
      id:'new-'+p.id, number:num, contractor:p.contractor, initials:p.initials,
      col:p.col, bg:p.bg, client:p.client, period:p.period, hours:p.hours,
      rate:p.rate, amount:p.hours*p.rate, status:'AUTHORISED',
      dueDate: new Date(Date.now()+14*86400000).toLocaleDateString('en-AU',{day:'numeric',month:'short',year:'numeric'}),
    }, ...prev])
    setCreating(null)
    toast_(`✓ ${num} created in Xero — ${p.contractor} · ${fmt(p.hours*p.rate)}`)
  }

  const handleSend = async (inv: Invoice) => {
    setCreating(inv.id)
    await new Promise(r=>setTimeout(r,900))
    setInvoices(prev=>prev.map(i=>i.id===inv.id?{...i,status:'SENT',sentTo:'accounts@client.com.au'}:i))
    setCreating(null)
    toast_(`✓ ${inv.number} emailed via Xero`)
  }

  const filtered = filter==='all' ? invoices : invoices.filter(i=>i.status===filter)

  const totalOutstanding = invoices.filter(i=>['AUTHORISED','SENT','OVERDUE'].includes(i.status)).reduce((s,i)=>s+i.amount,0)
  const totalOverdue     = invoices.filter(i=>i.status==='OVERDUE').reduce((s,i)=>s+i.amount,0)
  const totalPaid        = invoices.filter(i=>i.status==='PAID').reduce((s,i)=>s+i.amount,0)

  return (
    <>
      <TopBar title="Invoicing" subtitle="Create and manage client invoices via Xero"/>
      <main style={{flex:1, padding:'28px 32px', background:B.bg}}>

        {/* KPI strip */}
        <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:16, marginBottom:24}}>
          {[
            ['Outstanding', fmt(totalOutstanding), B.amber,   `${invoices.filter(i=>['AUTHORISED','SENT','OVERDUE'].includes(i.status)).length} invoices`],
            ['Overdue',     fmt(totalOverdue),     B.red,     `${invoices.filter(i=>i.status==='OVERDUE').length} invoices`],
            ['Paid (all time)', fmt(totalPaid),    B.green,   `${invoices.filter(i=>i.status==='PAID').length} invoices`],
          ].map(([k,v,c,sub])=>(
            <div key={k as string} style={{background:B.surface,border:`1px solid ${B.border}`,borderRadius:12,padding:'18px 20px'}}>
              <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:B.dim,marginBottom:8}}>{k}</div>
              <div style={{fontFamily:"'DM Mono',monospace",fontSize:24,fontWeight:700,color:c as string,marginBottom:4}}>{v}</div>
              <div style={{fontSize:12,color:B.sub}}>{sub}</div>
            </div>
          ))}
        </div>

        {/* Pending invoices — approved but not yet invoiced */}
        {PENDING.length>0 && (
          <div style={{marginBottom:20,padding:'16px 18px',background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:12}}>
            <div style={{fontSize:13,fontWeight:700,color:B.amber,marginBottom:10}}>⚠ {PENDING.length} approved timesheet{PENDING.length>1?'s':''} ready to invoice</div>
            {PENDING.map(p=>(
              <div key={p.id} style={{display:'flex',alignItems:'center',gap:12,padding:'10px 0',borderTop:`1px solid ${B.aLB}`}}>
                <div style={{width:30,height:30,borderRadius:8,background:p.bg,color:p.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,flexShrink:0}}>{p.initials}</div>
                <div style={{flex:1}}>
                  <span style={{fontSize:13.5,fontWeight:600,color:B.text}}>{p.contractor}</span>
                  <span style={{fontSize:13,color:B.dim}}> · {p.client} · {p.period} · {p.hours}h · {fmt(p.hours*p.rate)}</span>
                </div>
                <button onClick={()=>handleCreate(p)} disabled={creating===p.id} style={{
                  padding:'7px 16px',borderRadius:8,border:`1.5px solid ${B.accent}`,
                  background:B.aP,color:B.accent,fontSize:13,fontWeight:600,
                  fontFamily:"'DM Sans',sans-serif",cursor:'pointer',
                }}>
                  {creating===p.id ? 'Creating…' : '🧾 Create invoice'}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Invoice table */}
        <div className="card" style={{overflow:'hidden'}}>
          {/* Filter bar */}
          <div style={{padding:'12px 18px',borderBottom:`1px solid ${B.faint}`,background:B.bg,display:'flex',gap:6,flexWrap:'wrap'}}>
            {[['all','All'],['AUTHORISED','Authorised'],['SENT','Sent'],['OVERDUE','Overdue'],['PAID','Paid']].map(([v,l])=>(
              <button key={v} onClick={()=>setFilter(v)} style={{
                padding:'5px 13px',borderRadius:100,border:'none',cursor:'pointer',
                fontFamily:"'DM Sans',sans-serif",fontSize:12.5,fontWeight:600,
                background:filter===v?B.accent:B.surface,
                color:filter===v?'#fff':B.dim,
                border:`1.5px solid ${filter===v?B.accent:B.border}`,
                transition:'all .12s',
              }}>{l}</button>
            ))}
          </div>

          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead>
              <tr style={{background:B.bg,borderBottom:`1px solid ${B.border}`}}>
                {['Invoice','Contractor','Period','Amount','Status','Due',''].map(h=>(
                  <th key={h} style={{padding:'11px 16px',textAlign:'left',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((inv,i)=>{
                const sp = STATUS_STYLE[inv.status]||{bg:B.faint,c:B.dim}
                return (
                  <tr key={inv.id} style={{borderBottom:i<filtered.length-1?`1px solid ${B.faint}`:'none'}}>
                    <td style={{padding:'13px 16px'}}>
                      <span style={{fontFamily:"'DM Mono',monospace",fontSize:13.5,color:B.accent,fontWeight:600}}>{inv.number}</span>
                    </td>
                    <td style={{padding:'13px 16px'}}>
                      <div style={{display:'flex',alignItems:'center',gap:8}}>
                        <div style={{width:26,height:26,borderRadius:7,background:inv.bg,color:inv.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,flexShrink:0}}>{inv.initials}</div>
                        <div>
                          <div style={{fontSize:13.5,fontWeight:500,color:B.text}}>{inv.contractor}</div>
                          <div style={{fontSize:11.5,color:B.dim}}>{inv.client}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{padding:'13px 16px',fontSize:13.5,color:B.mid}}>{inv.period}</td>
                    <td style={{padding:'13px 16px',fontFamily:"'DM Mono',monospace",fontSize:13.5,fontWeight:600,color:B.text}}>{fmt(inv.amount)}</td>
                    <td style={{padding:'13px 16px'}}>
                      <span style={{fontSize:12,fontWeight:600,padding:'3px 9px',borderRadius:100,...sp}}>{inv.status}</span>
                    </td>
                    <td style={{padding:'13px 16px',fontSize:13,color:inv.status==='OVERDUE'?B.red:B.dim,fontWeight:inv.status==='OVERDUE'?600:400}}>{inv.dueDate}</td>
                    <td style={{padding:'13px 16px'}}>
                      <div style={{display:'flex',gap:6}}>
                        {inv.status==='AUTHORISED' && (
                          <button onClick={()=>handleSend(inv)} disabled={creating===inv.id} style={{padding:'5px 12px',borderRadius:7,border:`1.5px solid ${B.aBd}`,background:B.aP,color:B.accent,fontSize:12,fontWeight:600,fontFamily:"'DM Sans',sans-serif",cursor:'pointer'}}>
                            {creating===inv.id?'Sending…':'📧 Send'}
                          </button>
                        )}
                        {inv.xeroId && (
                          <a href={`https://go.xero.com/AccountsReceivable/Edit.aspx?InvoiceID=${inv.xeroId}`} target="_blank" rel="noreferrer" style={{padding:'5px 12px',borderRadius:7,border:`1.5px solid ${B.border}`,background:B.surface,color:B.dim,fontSize:12,fontWeight:600,textDecoration:'none'}}>Xero →</a>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </main>

      {toast && (
        <div style={{position:'fixed',bottom:24,right:24,zIndex:999,background:B.text,color:'#fff',padding:'12px 22px',borderRadius:10,fontWeight:600,fontSize:13,boxShadow:'0 4px 16px rgba(0,0,0,.18)'}}>{toast}</div>
      )}
    </>
  )
}
