'use client'
// app/auth/login/page.tsx
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'
import { B } from '@/lib/design'

export default function LoginPage() {
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [loading,  setLoading]  = useState(false)
  const [error,    setError]    = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) { setError(error.message); setLoading(false); return }
    router.push('/admin/dashboard')
    router.refresh()
  }

  return (
    <div style={{
      minHeight:'100vh', background:B.bg, display:'flex',
      alignItems:'center', justifyContent:'center', fontFamily:"'DM Sans',sans-serif",
    }}>
      <div style={{
        background:B.surface, border:`1px solid ${B.border}`, borderRadius:16,
        padding:'44px 48px', width:'100%', maxWidth:420,
        boxShadow:'0 4px 24px rgba(0,0,0,.08)',
      }}>
        {/* Logo mark */}
        <div style={{
          width:44,height:44,borderRadius:12,background:B.accent,
          display:'flex',alignItems:'center',justifyContent:'center',
          fontSize:20,marginBottom:20,
        }}>🏢</div>

        <h1 style={{fontSize:22,fontWeight:700,color:B.text,marginBottom:4}}>Portal login</h1>
        <p style={{fontSize:14,color:B.dim,marginBottom:28}}>Admin &amp; consultant access</p>

        {error && (
          <div style={{
            padding:'10px 14px',background:B.rP,border:`1px solid ${B.rB}`,
            borderRadius:8,fontSize:13,color:B.red,marginBottom:16,
          }}>{error}</div>
        )}

        <form onSubmit={handleLogin}>
          <div style={{marginBottom:14}}>
            <label style={{display:'block',fontSize:12,fontWeight:600,color:B.dim,marginBottom:6,textTransform:'uppercase',letterSpacing:'.06em'}}>
              Email
            </label>
            <input
              type="email" value={email} onChange={e=>setEmail(e.target.value)} required
              placeholder="admin@yourcompany.com.au"
              style={{
                width:'100%',padding:'10px 13px',fontFamily:"'DM Sans',sans-serif",
                fontSize:14,border:`1.5px solid ${B.border}`,borderRadius:9,
                color:B.text,outline:'none',background:B.surface,boxSizing:'border-box',
              }}
              onFocus={e=>e.target.style.borderColor=B.accent}
              onBlur={e=>e.target.style.borderColor=B.border}
            />
          </div>

          <div style={{marginBottom:22}}>
            <label style={{display:'block',fontSize:12,fontWeight:600,color:B.dim,marginBottom:6,textTransform:'uppercase',letterSpacing:'.06em'}}>
              Password
            </label>
            <input
              type="password" value={password} onChange={e=>setPassword(e.target.value)} required
              placeholder="••••••••"
              style={{
                width:'100%',padding:'10px 13px',fontFamily:"'DM Sans',sans-serif",
                fontSize:14,border:`1.5px solid ${B.border}`,borderRadius:9,
                color:B.text,outline:'none',background:B.surface,boxSizing:'border-box',
              }}
              onFocus={e=>e.target.style.borderColor=B.accent}
              onBlur={e=>e.target.style.borderColor=B.border}
            />
          </div>

          <button
            type="submit" disabled={loading}
            style={{
              width:'100%',padding:'12px',background:B.accent,color:'#fff',
              border:'none',borderRadius:9,fontSize:15,fontWeight:600,
              fontFamily:"'DM Sans',sans-serif",cursor:loading?'not-allowed':'pointer',
              opacity:loading?0.7:1,transition:'all .15s',
            }}
          >
            {loading ? 'Signing in…' : 'Sign in →'}
          </button>
        </form>

        <p style={{fontSize:12.5,color:B.sub,textAlign:'center',marginTop:20}}>
          Contractor? <a href="/portal/login" style={{color:B.accent,fontWeight:600}}>Log in to contractor portal →</a>
        </p>
      </div>
    </div>
  )
}
