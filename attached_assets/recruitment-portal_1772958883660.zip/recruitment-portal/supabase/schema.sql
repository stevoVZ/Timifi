-- =============================================================================
-- Recruitment Portal — Supabase Schema
-- Run in: Supabase Dashboard → SQL Editor
-- Order matters — run top to bottom in one shot
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =============================================================================
-- ENUMS
-- =============================================================================

CREATE TYPE user_role             AS ENUM ('admin', 'consultant', 'contractor');
CREATE TYPE contractor_status     AS ENUM ('ACTIVE', 'PENDING_SETUP', 'OFFBOARDED');
CREATE TYPE clearance_level       AS ENUM ('NONE', 'BASELINE', 'NV1', 'NV2', 'PV');
CREATE TYPE employment_type       AS ENUM ('FULLTIME', 'PARTTIME', 'CASUAL', 'LABOURHIRE');
CREATE TYPE income_type           AS ENUM ('SALARY', 'LABOURHIRE');
CREATE TYPE pay_calendar          AS ENUM ('WEEKLY', 'FORTNIGHTLY', 'MONTHLY');
CREATE TYPE timesheet_status      AS ENUM ('DRAFT', 'SUBMITTED', 'APPROVED', 'REJECTED');
CREATE TYPE invoice_status        AS ENUM ('DRAFT', 'AUTHORISED', 'SENT', 'PAID', 'VOIDED', 'OVERDUE');
CREATE TYPE pay_run_status        AS ENUM ('DRAFT', 'PROCESSING', 'FILED', 'ERROR');
CREATE TYPE stp_status            AS ENUM ('PENDING', 'SUBMITTED', 'ATO_ACCEPTED', 'ATO_REJECTED');
CREATE TYPE notification_priority AS ENUM ('URGENT', 'HIGH', 'MEDIUM', 'LOW');
CREATE TYPE notification_type     AS ENUM ('PAYRUN', 'STP', 'INVOICE', 'TIMESHEET', 'SUPER', 'XERO', 'CLEARANCE', 'SYSTEM');
CREATE TYPE intake_source         AS ENUM ('email', 'walk-in', 'post', 'other');
CREATE TYPE period_type           AS ENUM ('weekly', 'fortnightly', 'monthly');

-- =============================================================================
-- PROFILES (extends auth.users)
-- =============================================================================

CREATE TABLE profiles (
  id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role        user_role    NOT NULL DEFAULT 'contractor',
  full_name   TEXT         NOT NULL,
  email       TEXT         NOT NULL UNIQUE,
  phone       TEXT,
  avatar_url  TEXT,
  mfa_enabled BOOLEAN      NOT NULL DEFAULT FALSE,
  last_login  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles: own row"    ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "profiles: admin all"  ON profiles FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "profiles: insert own" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- =============================================================================
-- CONTRACTORS
-- =============================================================================

CREATE TABLE contractors (
  id                  UUID          PRIMARY KEY DEFAULT uuid_generate_v4(),
  profile_id          UUID          REFERENCES profiles(id) ON DELETE SET NULL,
  first_name          TEXT          NOT NULL,
  last_name           TEXT          NOT NULL,
  date_of_birth       DATE,
  gender              CHAR(1),
  email               TEXT          NOT NULL UNIQUE,
  phone               TEXT,
  address_line1       TEXT,
  suburb              TEXT,
  state               CHAR(3),
  postcode            TEXT,
  status              contractor_status NOT NULL DEFAULT 'PENDING_SETUP',
  clearance_level     clearance_level   NOT NULL DEFAULT 'NONE',
  clearance_expiry    DATE,
  employment_type     employment_type   NOT NULL DEFAULT 'LABOURHIRE',
  income_type         income_type       NOT NULL DEFAULT 'LABOURHIRE',
  pay_frequency       pay_calendar      NOT NULL DEFAULT 'MONTHLY',
  start_date          DATE,
  end_date            DATE,
  job_title           TEXT,
  client_name         TEXT,
  hourly_rate         NUMERIC(10,2),
  -- Contract hours per year (used for utilisation tracking)
  contract_hours_pa   INTEGER           NOT NULL DEFAULT 2000,
  xero_employee_id    TEXT          UNIQUE,
  xero_contact_id     TEXT          UNIQUE,
  accent_colour       TEXT          DEFAULT '#2563eb',
  notes               TEXT,
  created_by          UUID          REFERENCES profiles(id),
  created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

ALTER TABLE contractors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "contractors: admin_consultant read"  ON contractors FOR SELECT USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "contractors: admin_consultant write" ON contractors FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "contractors: own row"                ON contractors FOR SELECT USING (profile_id = auth.uid());

-- =============================================================================
-- TAX DECLARATIONS
-- =============================================================================

CREATE TABLE tax_declarations (
  id                      UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id           UUID        NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  tfn_encrypted           BYTEA,
  tfn_exemption           TEXT,
  residency_status        TEXT        NOT NULL DEFAULT 'RESIDENT',
  tax_scale               TEXT        NOT NULL DEFAULT 'REGULAR',
  tax_free_threshold      BOOLEAN     NOT NULL DEFAULT TRUE,
  help_debt               BOOLEAN     NOT NULL DEFAULT FALSE,
  sl_repayment            BOOLEAN     NOT NULL DEFAULT FALSE,
  foreign_tax_credit      BOOLEAN     NOT NULL DEFAULT FALSE,
  xero_tax_declaration_id TEXT,
  effective_from          DATE        NOT NULL DEFAULT CURRENT_DATE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE tax_declarations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tax_declarations: admin only" ON tax_declarations FOR ALL USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');

-- =============================================================================
-- BANK ACCOUNTS
-- =============================================================================

CREATE TABLE bank_accounts (
  id                   UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id        UUID        NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  account_name         TEXT        NOT NULL,
  bank_name            TEXT,
  bsb_encrypted        BYTEA       NOT NULL,
  account_encrypted    BYTEA       NOT NULL,
  bsb_masked           TEXT        NOT NULL,
  account_masked       TEXT        NOT NULL,
  xero_bank_account_id TEXT,
  is_primary           BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE bank_accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "bank_accounts: admin only"        ON bank_accounts FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "bank_accounts: contractor masked" ON bank_accounts FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- =============================================================================
-- SUPER MEMBERSHIPS
-- =============================================================================

CREATE TABLE super_memberships (
  id                       UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id            UUID        NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  fund_type                TEXT        NOT NULL DEFAULT 'REGULATED',
  fund_name                TEXT        NOT NULL,
  fund_abn                 TEXT,
  member_number            TEXT,
  usi                      TEXT,
  smsf_bsb                 TEXT,
  smsf_account             TEXT,
  smsf_electronic_id       TEXT,
  xero_super_membership_id TEXT,
  contribution_rate        NUMERIC(5,4) NOT NULL DEFAULT 0.1150,
  is_active                BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE super_memberships ENABLE ROW LEVEL SECURITY;
CREATE POLICY "super: admin_consultant" ON super_memberships FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "super: contractor own"   ON super_memberships FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- =============================================================================
-- TIMESHEETS  (master record — one per contractor per month)
-- =============================================================================

CREATE TABLE timesheets (
  id              UUID             PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id   UUID             NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  year            SMALLINT         NOT NULL,
  month           SMALLINT         NOT NULL CHECK (month BETWEEN 1 AND 12),
  total_hours     NUMERIC(6,2)     NOT NULL DEFAULT 0,
  gross_value     NUMERIC(10,2)    NOT NULL DEFAULT 0,
  status          timesheet_status NOT NULL DEFAULT 'DRAFT',
  notes           TEXT,
  submitted_at    TIMESTAMPTZ,
  submitted_by    UUID             REFERENCES profiles(id),
  reviewed_at     TIMESTAMPTZ,
  reviewed_by     UUID             REFERENCES profiles(id),
  rejection_reason TEXT,
  pay_run_id      UUID,
  exported_at     TIMESTAMPTZ,
  xero_timesheet_id TEXT,
  created_at      TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  UNIQUE (contractor_id, year, month)
);

ALTER TABLE timesheets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "timesheets: admin_consultant all" ON timesheets FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "timesheets: contractor own"       ON timesheets FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- =============================================================================
-- TIMESHEET VERSIONS (every uploaded PDF — the AI scan result + audit chain)
-- =============================================================================

CREATE TABLE timesheet_versions (
  id                    UUID             PRIMARY KEY DEFAULT uuid_generate_v4(),
  timesheet_id          UUID             REFERENCES timesheets(id) ON DELETE CASCADE,
  contractor_id         UUID             NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  year                  SMALLINT         NOT NULL,
  month                 SMALLINT         NOT NULL CHECK (month BETWEEN 1 AND 12),
  version_number        SMALLINT         NOT NULL DEFAULT 1,

  -- File
  file_name             TEXT             NOT NULL,
  file_size             TEXT,
  storage_path          TEXT,            -- Supabase Storage path to original PDF
  is_batch              BOOLEAN          NOT NULL DEFAULT FALSE,
  batch_file_count      SMALLINT         NOT NULL DEFAULT 1,

  -- Hours (aggregated for batch)
  total_hours           NUMERIC(6,2)     NOT NULL DEFAULT 0,
  regular_hours         NUMERIC(6,2)     NOT NULL DEFAULT 0,
  overtime_hours        NUMERIC(6,2)     NOT NULL DEFAULT 0,

  -- AI scan results
  scan_confidence       SMALLINT,        -- 0-100
  scan_format           TEXT,
  scan_period           TEXT,
  scan_warnings         JSONB            NOT NULL DEFAULT '[]',
  scan_daily_breakdown  JSONB            NOT NULL DEFAULT '[]',
  scan_weekly_breakdown JSONB            NOT NULL DEFAULT '[]',

  -- Sub-timesheets for batch uploads
  sub_timesheets        JSONB            NOT NULL DEFAULT '[]',

  -- Status & workflow
  status                timesheet_status NOT NULL DEFAULT 'SUBMITTED',
  rejection_reason      TEXT,
  rejected_at           TIMESTAMPTZ,
  rejected_by           UUID             REFERENCES profiles(id),
  approved_at           TIMESTAMPTZ,
  approved_by           UUID             REFERENCES profiles(id),
  restorable            BOOLEAN          NOT NULL DEFAULT FALSE,

  -- Admin intake provenance
  uploaded_by           TEXT             NOT NULL,
  uploaded_by_role      TEXT             NOT NULL,
  intake_source         intake_source    NOT NULL DEFAULT 'email',
  intake_sender_email   TEXT,
  intake_received_date  DATE             NOT NULL DEFAULT CURRENT_DATE,
  intake_notes          TEXT,

  -- Month boundary
  boundary_alloc        TEXT,            -- 'current' | 'next' | 'split' | null

  -- Xero (set when invoice created)
  xero_invoice_id       TEXT,

  created_at            TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ      NOT NULL DEFAULT NOW()
);

ALTER TABLE timesheet_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tsv: admin_consultant all" ON timesheet_versions FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "tsv: contractor own"       ON timesheet_versions FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- =============================================================================
-- INVOICES
-- =============================================================================

CREATE TABLE invoices (
  id                UUID           PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id     UUID           NOT NULL REFERENCES contractors(id) ON DELETE RESTRICT,
  timesheet_id      UUID           REFERENCES timesheets(id),
  version_id        UUID           REFERENCES timesheet_versions(id),
  year              SMALLINT       NOT NULL,
  month             SMALLINT       NOT NULL CHECK (month BETWEEN 1 AND 12),
  invoice_number    TEXT           UNIQUE,
  amount_excl_gst   NUMERIC(10,2)  NOT NULL,
  gst_amount        NUMERIC(10,2)  NOT NULL DEFAULT 0,
  amount_incl_gst   NUMERIC(10,2)  NOT NULL,
  hours             NUMERIC(6,2),
  hourly_rate       NUMERIC(10,2),
  description       TEXT,
  issue_date        DATE,
  due_date          DATE,
  paid_date         DATE,
  status            invoice_status NOT NULL DEFAULT 'DRAFT',
  xero_invoice_id   TEXT           UNIQUE,
  xero_invoice_url  TEXT,
  attachment_path   TEXT,
  sent_at           TIMESTAMPTZ,
  sent_to           TEXT,
  days_overdue      SMALLINT GENERATED ALWAYS AS (
    CASE WHEN status = 'OVERDUE' AND due_date IS NOT NULL
         THEN GREATEST(0, (CURRENT_DATE - due_date)::INT)
         ELSE 0 END
  ) STORED,
  created_by        UUID           REFERENCES profiles(id),
  created_at        TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "invoices: admin_consultant all" ON invoices FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "invoices: contractor own"       ON invoices FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- =============================================================================
-- PAY RUNS
-- =============================================================================

CREATE TABLE pay_runs (
  id              UUID           PRIMARY KEY DEFAULT uuid_generate_v4(),
  pay_run_ref     TEXT           UNIQUE NOT NULL,
  year            SMALLINT       NOT NULL,
  month           SMALLINT       NOT NULL CHECK (month BETWEEN 1 AND 12),
  pay_date        DATE,
  status          pay_run_status NOT NULL DEFAULT 'DRAFT',
  total_gross     NUMERIC(12,2)  NOT NULL DEFAULT 0,
  total_payg      NUMERIC(12,2)  NOT NULL DEFAULT 0,
  total_super     NUMERIC(12,2)  NOT NULL DEFAULT 0,
  total_net       NUMERIC(12,2)  NOT NULL DEFAULT 0,
  employee_count  SMALLINT       NOT NULL DEFAULT 0,
  xero_pay_run_id TEXT           UNIQUE,
  stp_status      stp_status,
  stp_ref         TEXT,
  stp_submitted_at TIMESTAMPTZ,
  stp_ato_response JSONB,
  filed_by        UUID           REFERENCES profiles(id),
  filed_at        TIMESTAMPTZ,
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  UNIQUE (year, month)
);

ALTER TABLE pay_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pay_runs: admin write"         ON pay_runs FOR INSERT UPDATE DELETE USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "pay_runs: admin_consultant read" ON pay_runs FOR SELECT             USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));

-- =============================================================================
-- PAY RUN LINES
-- =============================================================================

CREATE TABLE pay_run_lines (
  id               UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  pay_run_id       UUID        NOT NULL REFERENCES pay_runs(id) ON DELETE CASCADE,
  contractor_id    UUID        NOT NULL REFERENCES contractors(id),
  timesheet_id     UUID        REFERENCES timesheets(id),
  version_id       UUID        REFERENCES timesheet_versions(id),
  hours            NUMERIC(6,2)  NOT NULL,
  hourly_rate      NUMERIC(10,2) NOT NULL,
  gross_earnings   NUMERIC(10,2) NOT NULL,
  payg_withholding NUMERIC(10,2) NOT NULL,
  help_repayment   NUMERIC(10,2) NOT NULL DEFAULT 0,
  net_pay          NUMERIC(10,2) NOT NULL,
  super_amount     NUMERIC(10,2) NOT NULL,
  super_rate       NUMERIC(5,4)  NOT NULL DEFAULT 0.1150,
  xero_payslip_id  TEXT,
  notes            TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (pay_run_id, contractor_id)
);

ALTER TABLE pay_run_lines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "prl: admin_consultant" ON pay_run_lines FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "prl: contractor own"   ON pay_run_lines FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- =============================================================================
-- AUDIT LOG (append-only)
-- =============================================================================

CREATE TABLE audit_log (
  id          BIGSERIAL   PRIMARY KEY,
  user_id     UUID        REFERENCES profiles(id) ON DELETE SET NULL,
  user_name   TEXT,
  user_role   user_role,
  action      TEXT        NOT NULL,
  target_type TEXT,
  target_id   UUID,
  metadata    JSONB,
  ip_address  INET,
  user_agent  TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "audit: admin read"    ON audit_log FOR SELECT USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "audit: server insert" ON audit_log FOR INSERT WITH CHECK (TRUE);
REVOKE UPDATE, DELETE ON audit_log FROM authenticated;
REVOKE UPDATE, DELETE ON audit_log FROM anon;

-- =============================================================================
-- NOTIFICATIONS
-- =============================================================================

CREATE TABLE notifications (
  id            UUID                  PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id       UUID                  NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type          notification_type     NOT NULL,
  priority      notification_priority NOT NULL DEFAULT 'MEDIUM',
  title         TEXT                  NOT NULL,
  body          TEXT,
  action_label  TEXT,
  action_route  TEXT,
  contractor_id UUID                  REFERENCES contractors(id)  ON DELETE CASCADE,
  invoice_id    UUID                  REFERENCES invoices(id)     ON DELETE CASCADE,
  pay_run_id    UUID                  REFERENCES pay_runs(id)     ON DELETE CASCADE,
  timesheet_id  UUID                  REFERENCES timesheets(id)   ON DELETE CASCADE,
  read          BOOLEAN               NOT NULL DEFAULT FALSE,
  read_at       TIMESTAMPTZ,
  dismissed     BOOLEAN               NOT NULL DEFAULT FALSE,
  created_at    TIMESTAMPTZ           NOT NULL DEFAULT NOW()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notif: own"       ON notifications FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "notif: mark read" ON notifications FOR UPDATE USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- =============================================================================
-- DOCUMENTS
-- =============================================================================

CREATE TABLE documents (
  id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id UUID        NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  type          TEXT        NOT NULL,
  name          TEXT        NOT NULL,
  storage_path  TEXT        NOT NULL,
  file_size     INTEGER,
  mime_type     TEXT,
  uploaded_by   UUID        REFERENCES profiles(id),
  pay_run_id    UUID        REFERENCES pay_runs(id),
  expires_at    DATE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "docs: admin_consultant all" ON documents FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "docs: contractor own"       ON documents FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- =============================================================================
-- XERO TOKENS (service role only — no client access)
-- =============================================================================

CREATE TABLE xero_tokens (
  id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  tenant_id     TEXT        NOT NULL UNIQUE,
  tenant_name   TEXT,
  access_token  TEXT        NOT NULL,
  refresh_token TEXT        NOT NULL,
  expires_at    TIMESTAMPTZ NOT NULL,
  scope         TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE xero_tokens ENABLE ROW LEVEL SECURITY;
CREATE POLICY "xero_tokens: deny all" ON xero_tokens FOR ALL USING (FALSE);

-- =============================================================================
-- WEBHOOK EVENTS
-- =============================================================================

CREATE TABLE webhook_events (
  id           BIGSERIAL   PRIMARY KEY,
  source       TEXT        NOT NULL DEFAULT 'XERO',
  event_type   TEXT        NOT NULL,
  resource_id  TEXT,
  payload      JSONB,
  processed    BOOLEAN     NOT NULL DEFAULT FALSE,
  processed_at TIMESTAMPTZ,
  error        TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE webhook_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "webhook: admin read" ON webhook_events FOR SELECT USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');

-- =============================================================================
-- TRIGGERS
-- =============================================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'profiles','contractors','tax_declarations','bank_accounts','super_memberships',
    'timesheets','timesheet_versions','invoices','pay_runs','pay_run_lines','xero_tokens'
  ] LOOP
    EXECUTE format(
      'CREATE TRIGGER trg_updated_at BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION update_updated_at()', t
    );
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Auto invoice number
CREATE OR REPLACE FUNCTION generate_invoice_number()
RETURNS TRIGGER AS $$
DECLARE last_num INTEGER;
BEGIN
  SELECT COALESCE(MAX(CAST(SUBSTRING(invoice_number FROM 5) AS INTEGER)), 0)
  INTO last_num FROM invoices WHERE invoice_number LIKE 'INV-%';
  NEW.invoice_number = 'INV-' || LPAD((last_num + 1)::TEXT, 4, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_invoice_number
BEFORE INSERT ON invoices
FOR EACH ROW WHEN (NEW.invoice_number IS NULL)
EXECUTE FUNCTION generate_invoice_number();

-- Mark overdue invoices (schedule this via Supabase Edge Functions or pg_cron)
CREATE OR REPLACE FUNCTION update_overdue_invoices()
RETURNS VOID AS $$
BEGIN
  UPDATE invoices SET status = 'OVERDUE'
  WHERE status IN ('AUTHORISED','SENT') AND due_date < CURRENT_DATE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =============================================================================
-- INDEXES
-- =============================================================================

CREATE INDEX idx_contractors_status       ON contractors(status);
CREATE INDEX idx_contractors_profile      ON contractors(profile_id);
CREATE INDEX idx_timesheets_contractor    ON timesheets(contractor_id);
CREATE INDEX idx_timesheets_period        ON timesheets(year, month);
CREATE INDEX idx_timesheets_status        ON timesheets(status);
CREATE INDEX idx_tsv_contractor           ON timesheet_versions(contractor_id);
CREATE INDEX idx_tsv_period               ON timesheet_versions(year, month);
CREATE INDEX idx_tsv_status               ON timesheet_versions(status);
CREATE INDEX idx_tsv_timesheet            ON timesheet_versions(timesheet_id);
CREATE INDEX idx_invoices_contractor      ON invoices(contractor_id);
CREATE INDEX idx_invoices_status          ON invoices(status);
CREATE INDEX idx_invoices_xero            ON invoices(xero_invoice_id);
CREATE INDEX idx_pay_run_lines_run        ON pay_run_lines(pay_run_id);
CREATE INDEX idx_audit_log_user           ON audit_log(user_id);
CREATE INDEX idx_audit_log_target         ON audit_log(target_type, target_id);
CREATE INDEX idx_notifications_user       ON notifications(user_id, read, created_at DESC);

-- =============================================================================
-- STORAGE BUCKETS
-- Uncomment and run in Supabase SQL Editor after creating buckets in dashboard
-- =============================================================================

-- INSERT INTO storage.buckets (id, name, public) VALUES
--   ('timesheets', 'timesheets', FALSE),
--   ('payslips',   'payslips',   FALSE),
--   ('documents',  'documents',  FALSE),
--   ('avatars',    'avatars',    TRUE);

-- =============================================================================
-- DEV SEED — create auth user in dashboard first, paste their UUID below
-- =============================================================================

-- INSERT INTO profiles (id, role, full_name, email)
-- VALUES ('PASTE-YOUR-AUTH-USER-UUID-HERE', 'admin', 'Sarah Chen', 'admin@yourportal.com.au');
