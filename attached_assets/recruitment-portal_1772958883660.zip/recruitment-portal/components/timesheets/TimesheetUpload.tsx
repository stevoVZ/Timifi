'use client'
// components/timesheets/TimesheetUpload.tsx
// Full timesheet upload system — multi-file, multi-contractor, month boundary aware
import { useState, useEffect, useRef, useCallback } from "react";

/* ─── Design tokens (matches portal system) ──────────────────────────────── */
const B = {
  bg:"#f4f5f7", surface:"#ffffff", border:"#e5e7eb", faint:"#f0f1f3",
  text:"#111827", mid:"#374151", dim:"#6b7280", sub:"#9ca3af",
  accent:"#2563eb", aP:"#eff6ff", aBd:"#bfdbfe",
  green:"#16a34a", gP:"#f0fdf4", gB:"#bbf7d0",
  amber:"#b45309", aLP:"#fffbeb", aLB:"#fde68a",
  red:"#dc2626",   rP:"#fef2f2", rB:"#fecaca",
  purple:"#7c3aed",purP:"#f5f3ff",purB:"#ddd6fe",
  sdw:"0 1px 2px rgba(0,0,0,.04),0 2px 8px rgba(0,0,0,.04)",
  sdwMd:"0 2px 8px rgba(0,0,0,.07),0 8px 28px rgba(0,0,0,.08)",
  sdwLg:"0 4px 16px rgba(0,0,0,.1),0 16px 48px rgba(0,0,0,.12)",
};

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:${B.bg};font-family:'DM Sans',sans-serif;color:${B.text};-webkit-font-smoothing:antialiased}
@keyframes up{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
@keyframes in{from{opacity:0}to{opacity:1}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.2}}
@keyframes beam{from{background-position:200% 0}to{background-position:-200% 0}}
.u{animation:up .38s cubic-bezier(.22,.68,0,1.2) both}
.fi{animation:in .24s ease both}
.spin{animation:spin .8s linear infinite}
.pulse{animation:pulse 1.8s ease-in-out infinite}
.card{background:${B.surface};border:1px solid ${B.border};border-radius:12px;box-shadow:${B.sdw}}
.inner{background:${B.bg};border:1px solid ${B.border};border-radius:8px}
.btn{font-family:'DM Sans',sans-serif;font-weight:600;cursor:pointer;border-radius:8px;transition:all .15s;display:inline-flex;align-items:center;justify-content:center;gap:7px;border:none;font-size:13px}
.btn-accent{background:${B.accent};color:#fff;padding:10px 20px}
.btn-accent:hover{filter:brightness(.9);transform:translateY(-1px)}
.btn-ghost{background:transparent;border:1.5px solid ${B.border};color:${B.dim};padding:9px 16px}
.btn-ghost:hover{border-color:${B.accent};color:${B.accent}}
.btn-sm{padding:6px 12px;font-size:12px;border-radius:7px}
.btn-danger{background:${B.rP};border:1.5px solid ${B.rB};color:${B.red};padding:9px 16px}
.btn-danger:hover{background:${B.red};color:#fff}
.btn-green{background:${B.gP};border:1.5px solid ${B.gB};color:${B.green};padding:9px 16px}
.btn-green:hover{background:${B.green};color:#fff}
.mono{font-family:'DM Mono',monospace}
.lbl{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:${B.dim}}
hr.hr{border:none;border-top:1px solid ${B.faint}}
.pill{font-size:11px;font-weight:600;padding:3px 9px;border-radius:100px;white-space:nowrap}
.skel{background:linear-gradient(90deg,${B.border} 25%,${B.faint} 50%,${B.border} 75%);background-size:400%;animation:beam 1.4s linear infinite;border-radius:6px}
.tab{background:none;border:none;border-bottom:2px solid transparent;padding:9px 16px;font-size:13.5px;font-family:'DM Sans',sans-serif;cursor:pointer;transition:all .12s;margin-bottom:-1px}
.tab.on{border-bottom-color:${B.accent};color:${B.accent};font-weight:600}
.tab:not(.on){color:${B.dim}}
.tab:not(.on):hover{color:${B.text}}
`;

/* ─── Helpers ─────────────────────────────────────────────────────────────── */
const MONTHS=["January","February","March","April","May","June","July","August","September","October","November","December"];
const NOW=new Date(), CY=NOW.getFullYear(), CM=NOW.getMonth();
const fmt=n=>`$${Number(n||0).toLocaleString("en-AU",{minimumFractionDigits:2,maximumFractionDigits:2})}`;
const uid=()=>Math.random().toString(36).slice(2,8).toUpperCase();
const ts=()=>new Date().toLocaleString("en-AU",{day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"});

/* ─── Seed data: existing timesheet versions ─────────────────────────────── */
const CONTRACTORS=[
  {id:"c1",name:"Alex Rivera",  initials:"AR",col:"#2563eb",bg:"#eff6ff",rate:120,client:"Client A",contractHours:2000, email:"alex.rivera@email.com"},
  {id:"c2",name:"Jordan Kim",   initials:"JK",col:"#7c3aed",bg:"#f5f3ff",rate:95, client:"Client B",contractHours:2000, email:"jordan.kim@email.com"},
  {id:"c3",name:"Sam Okafor",   initials:"SO",col:"#059669",bg:"#ecfdf5",rate:105,client:"Client C",contractHours:1800, email:"sam.okafor@email.com"},
];

// Version history seed — Alex has 2 versions this month (rejected then resubmit)
const INITIAL_HISTORY = {
  "c1": {
    [`${CM}-${CY}`]: [
      {
        versionId:"v1",version:1,contractorId:"c1",m:CM,y:CY,
        uploadedAt:"01 Mar 2026, 09:14 AM",
        fileName:"timesheet_alex_march_v1.pdf",
        fileSize:"142 KB",
        format:"Standard",
        status:"REJECTED",
        hours:185,
        uploadedBy:"Sarah Chen", uploadedByRole:"Payroll Admin",
        intakeSource:"email", intakeSenderEmail:"alex.rivera@email.com",
        intakeReceivedDate:"2026-03-01", intakeNotes:"",
        extractedData:{
          totalHours:185, regularHours:152, overtimeHours:33,
          period:`1–28 ${MONTHS[CM]} ${CY}`,
          weeks:[{wk:"Week 1",h:44},{wk:"Week 2",h:48},{wk:"Week 3",h:52},{wk:"Week 4",h:41}],
          notes:"Includes public holiday Monday 3 March",
          warnings:["Overtime hours (33) exceed engagement limit of 20 per month"],
          confidence:94,
        },
        rejectionReason:"Overtime hours exceed agreed limit of 20h/month. Please correct week 3.",
        rejectedAt:"01 Mar 2026, 02:31 PM",
        rejectedBy:"Sarah Chen",
        restorable:false,
      },
      {
        versionId:"v2",version:2,contractorId:"c1",m:CM,y:CY,
        uploadedAt:"03 Mar 2026, 08:55 AM",
        fileName:"timesheet_alex_march_v2.pdf",
        fileSize:"138 KB",
        format:"Standard",
        status:"SUBMITTED",
        hours:168,
        uploadedBy:"Sarah Chen", uploadedByRole:"Payroll Admin",
        intakeSource:"email", intakeSenderEmail:"alex.rivera@email.com",
        intakeReceivedDate:"2026-03-03", intakeNotes:"Contractor called to confirm corrections before re-sending.",
        extractedData:{
          totalHours:168, regularHours:152, overtimeHours:16,
          period:`1–28 ${MONTHS[CM]} ${CY}`,
          weeks:[{wk:"Week 1",h:44},{wk:"Week 2",h:48},{wk:"Week 3",h:36},{wk:"Week 4",h:40}],
          notes:"Corrected week 3 to comply with engagement limit",
          warnings:[],
          confidence:97,
        },
        rejectionReason:null, rejectedAt:null, rejectedBy:null,
        restorable:false,
      },
    ]
  },
  "c2": {
    [`${CM-1}-${CY}`]: [
      {
        versionId:"va",version:1,contractorId:"c2",m:CM-1,y:CY,
        uploadedAt:"01 Feb 2026, 10:22 AM",
        fileName:"jordan_feb_timesheet.pdf",
        fileSize:"189 KB",
        format:"Custom Template",
        status:"APPROVED",
        hours:168,
        uploadedBy:"Marcus Webb", uploadedByRole:"Consultant",
        intakeSource:"walk-in", intakeSenderEmail:"jordan.kim@email.com",
        intakeReceivedDate:"2026-02-01", intakeNotes:"Jordan dropped off in person, signed copy retained on file.",
        extractedData:{
          totalHours:168, regularHours:168, overtimeHours:0,
          period:`1–28 ${MONTHS[CM-1]} ${CY}`,
          weeks:[{wk:"Week 1",h:40},{wk:"Week 2",h:44},{wk:"Week 3",h:42},{wk:"Week 4",h:42}],
          notes:null, warnings:[], confidence:91,
        },
        rejectionReason:null, rejectedAt:null, rejectedBy:null,
        restorable:true,
        approvedAt:"02 Feb 2026, 11:05 AM",
        approvedBy:"Sarah Chen",
      }
    ]
  }
};

/* ─── Status display ─────────────────────────────────────────────────────── */
const SM={
  SUBMITTED:{col:B.amber, bg:B.aLP,  bd:B.aLB,  label:"Pending Review"},
  APPROVED: {col:B.green, bg:B.gP,   bd:B.gB,   label:"Approved"},
  REJECTED: {col:B.red,   bg:B.rP,   bd:B.rB,   label:"Returned"},
  DRAFT:    {col:B.dim,   bg:B.bg,   bd:B.border,label:"Draft"},
  SCANNING: {col:B.purple,bg:B.purP, bd:B.purB,  label:"Scanning"},
};

/* ─── Duplicate action rules ─────────────────────────────────────────────── */
const getDuplicateAction = (existingStatus) => ({
  DRAFT:     {allow:true,  warn:false, msg:null},
  REJECTED:  {allow:true,  warn:false, msg:"Previous version was returned. Your new upload will become version {n}."},
  SUBMITTED: {allow:true,  warn:true,  msg:"A timesheet for this period is already awaiting review. Uploading will replace it and restart the review. Are you sure?"},
  APPROVED:  {allow:false, warn:true,  msg:"This timesheet has already been approved and may have been included in a pay run. Contact an admin to unlock this period before resubmitting."},
})[existingStatus] || {allow:true, warn:false, msg:null};

/* ═══════════════════════════════════════════════════════════════════════════
   ROOT
═══════════════════════════════════════════════════════════════════════════ */
export default function TimesheetUploadSystem() {
  const [history, setHistory]   = useState(INITIAL_HISTORY);
  const [view,    setView]      = useState("upload"); // upload | history | detail
  const [selC,    setSelC]      = useState("c1");
  const [selM,    setSelM]      = useState(CM);
  const [selY,    setSelY]      = useState(CY);
  const [detailV, setDetailV]   = useState(null);  // version object to inspect
  const [toast,   setToast]     = useState(null);

  const toast_=(msg,type="ok")=>{setToast({msg,type});setTimeout(()=>setToast(null),3200);};

  // Get versions for current contractor+period
  const periodKey = `${selM}-${selY}`;
  const versions  = history[selC]?.[periodKey] || [];
  const latest    = versions[versions.length-1];
  const dupAction = latest ? getDuplicateAction(latest.status) : null;

  const addVersion = (newVer, cId=selC) => {
    const pk = `${selM}-${selY}`;
    setHistory(h=>{
      const existing = h[cId]?.[pk] || [];
      return {
        ...h,
        [cId]: {
          ...(h[cId]||{}),
          [pk]: [...existing, {...newVer, version: existing.length+1}]
        }
      };
    });
  };

  const restoreVersion = (versionId) => {
    const ver = versions.find(v=>v.versionId===versionId);
    if (!ver) return;
    const restored = {
      ...ver,
      versionId:"v"+uid(),
      version: versions.length+1,
      uploadedAt: ts(),
      status:"SUBMITTED",
      fileName:`restored_from_v${ver.version}_${ver.fileName}`,
      rejectionReason:null, rejectedAt:null, rejectedBy:null,
      approvedAt:null, approvedBy:null,
      restorable:false,
    };
    addVersion(restored);
    toast_(`✓ Version ${ver.version} restored and resubmitted`);
    setView("history");
  };

  const contractor = CONTRACTORS.find(c=>c.id===selC);

  return (
    <div style={{minHeight:"100vh",background:B.bg,padding:"32px 40px"}}>

      {/* Header */}
      <div style={{marginBottom:28}}>
        <h1 style={{fontSize:26,fontWeight:700,color:B.text,letterSpacing:"-0.4px",marginBottom:4}}>Timesheet Submissions</h1>
        <p style={{fontSize:14,color:B.dim}}>AI-assisted scanning · Duplicate detection · Full version history</p>
      </div>

      {/* Controls row */}
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:24,flexWrap:"wrap"}}>
        {/* Contractor picker */}
        <div>
          <div className="lbl" style={{marginBottom:5}}>Contractor</div>
          <div style={{display:"flex",gap:6}}>
            {CONTRACTORS.map(c=>(
              <button key={c.id} onClick={()=>{setSelC(c.id);setView("upload");}} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 14px",borderRadius:9,background:selC===c.id?c.bg:B.surface,border:`1.5px solid ${selC===c.id?c.col+"40":B.border}`,cursor:"pointer",fontFamily:"'DM Sans',sans-serif",transition:"all .13s"}}>
                <div style={{width:24,height:24,borderRadius:6,background:c.bg,color:c.col,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,border:`1px solid ${c.col}25`}}>{c.initials}</div>
                <span style={{fontSize:13,fontWeight:selC===c.id?600:400,color:selC===c.id?c.col:B.mid}}>{c.name.split(" ")[0]}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Period picker */}
        <div>
          <div className="lbl" style={{marginBottom:5}}>Period</div>
          <div style={{display:"flex",gap:6}}>
            {[CM,CM-1,CM-2].map(m=>(
              <button key={m} onClick={()=>{setSelM(m);setView("upload");}} style={{padding:"8px 14px",borderRadius:9,background:selM===m?B.accent:B.surface,border:`1.5px solid ${selM===m?B.accent:B.border}`,cursor:"pointer",fontFamily:"'DM Sans',sans-serif",fontSize:13,fontWeight:selM===m?600:400,color:selM===m?"#fff":B.mid,transition:"all .13s"}}>
                {MONTHS[m].slice(0,3)} {CY}
              </button>
            ))}
          </div>
        </div>

        {/* View tabs */}
        <div style={{marginLeft:"auto",display:"flex",gap:8}}>
          {[["upload","Upload"],["history","Version History"+(versions.length>0?` (${versions.length})`:"")] ].map(([id,label])=>(
            <button key={id} onClick={()=>setView(id)} style={{padding:"9px 18px",borderRadius:9,background:view===id?B.text:B.surface,border:`1px solid ${view===id?B.text:B.border}`,cursor:"pointer",fontFamily:"'DM Sans',sans-serif",fontSize:13,fontWeight:view===id?600:400,color:view===id?"#fff":B.mid,transition:"all .14s"}}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Views ── */}
      {view==="upload" && (
        <UploadView
          contractor={contractor}
          period={{m:selM,y:selY}}
          versions={versions}
          dupAction={dupAction}
          latest={latest}
          onSubmit={addVersion}
          toast_={toast_}
        />
      )}

      {view==="history" && (
        <HistoryView
          contractor={contractor}
          period={{m:selM,y:selY}}
          versions={versions}
          onRestore={restoreVersion}
          onInspect={v=>{setDetailV(v);setView("detail");}}
          toast_={toast_}
        />
      )}

      {view==="detail" && detailV && (
        <DetailView
          version={detailV}
          contractor={contractor}
          allVersions={versions}
          onBack={()=>setView("history")}
          onRestore={restoreVersion}
          toast_={toast_}
        />
      )}

      {toast&&<div className="u" style={{position:"fixed",bottom:24,right:24,zIndex:999,background:toast.type==="err"?B.red:toast.type==="warn"?B.amber:B.text,color:"#fff",padding:"12px 22px",borderRadius:10,fontWeight:600,fontSize:13,boxShadow:B.sdwLg}}>{toast.msg}</div>}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   UPLOAD VIEW  —  multi-file · multi-contractor · month boundary aware
═══════════════════════════════════════════════════════════════════════════ */
const CURRENT_ADMIN = { name:"Sarah Chen", initials:"SC", role:"Payroll Admin" };

// Demo data: week 4 deliberately spans the month boundary (31 Mar – 4 Apr)
const DEMO_WEEKS = [
  { label:"Week 1 (3–7 Mar)",    h:42, days:[8,8,10,8,8], ot:2, dates:["3 Mar","4 Mar","5 Mar","6 Mar","7 Mar"] },
  { label:"Week 2 (10–14 Mar)",  h:44, days:[8,9,9,10,8], ot:4, dates:["10 Mar","11 Mar","12 Mar","13 Mar","14 Mar"] },
  { label:"Week 3 (17–21 Mar)",  h:40, days:[8,8,8,8,8],  ot:0, dates:["17 Mar","18 Mar","19 Mar","20 Mar","21 Mar"] },
  { label:"Week 4 (31 Mar–4 Apr)",h:38, days:[8,8,7,8,7], ot:0, dates:["31 Mar","1 Apr","2 Apr","3 Apr","4 Apr"] },
];
// Demo contractors names for multi-contractor mode simulation
const DEMO_NAMES = ["Alex Rivera","Jordan Kim","Sam Okafor","Alex Rivera"];

function buildDemoResult(f, period, contractor, idx=0) {
  const wk    = DEMO_WEEKS[idx % DEMO_WEEKS.length];
  const isW   = idx < 4;
  const total = isW ? wk.h : DEMO_WEEKS.reduce((s,w)=>s+w.h,0);
  const ot    = isW ? wk.ot : DEMO_WEEKS.reduce((s,w)=>s+w.ot,0);
  return {
    contractorName: DEMO_NAMES[idx % DEMO_NAMES.length],
    period: isW ? wk.label : `1–28 ${MONTHS[period.m]} ${period.y}`,
    periodType: isW ? "weekly" : "monthly",
    totalHours:total, regularHours:total-ot, overtimeHours:ot,
    weeks: isW ? [{wk:wk.label,h:wk.h}] : DEMO_WEEKS.map((w,i)=>({wk:`Week ${i+1}`,h:w.h})),
    dailyBreakdown: (isW ? wk.dates : DEMO_WEEKS.flatMap(w=>w.dates)).map((date,i)=>({
      date, hours: isW ? (wk.days[i]||8) : 8, description:"Development",
    })),
    notes: idx===0 ? "Approved by team lead J. Smith" : null,
    format: ["Standard Weekly Grid","Custom Template","Daily Log Format","Standard Weekly Grid"][idx%4],
    confidence: 88+(idx%3)*3,
    warnings: ot>8?[`Overtime (${ot}h) exceeds typical weekly limit`]:[],
    missingFields:[],
    detectedRate:contractor.rate, detectedClientName:contractor.client,
    fileName:f.name, fileSize:(f.size/1024).toFixed(0)+" KB", scannedAt:ts(),
  };
}

async function scanSinglePDF(file, period, contractor, queueIdx) {
  try {
    const b64 = await new Promise((res,rej)=>{
      const r=new FileReader();
      r.onload=()=>res(r.result.split(",")[1]);
      r.onerror=()=>rej(new Error("fail"));
      r.readAsDataURL(file);
    });
    const prompt=`You are a timesheet parser for an Australian labour hire agency.
Analyse this PDF. It may be a weekly, fortnightly or monthly timesheet.

Return ONLY valid JSON — no markdown, no preamble:
{
  "contractorName":"string or null",
  "period":"pay period covered by THIS doc, e.g. 'Week 1: 3–7 Mar 2026' or '1-28 March 2026'",
  "periodType":"weekly|fortnightly|monthly",
  "totalHours":number,"regularHours":number,"overtimeHours":number,
  "weeks":[{"wk":"string","h":number}],
  "dailyBreakdown":[{"date":"DD Mon","hours":number,"description":"string or null"}],
  "notes":"string or null",
  "format":"template description",
  "confidence":0-100,
  "warnings":["array"],
  "missingFields":["array"],
  "detectedRate":number|null,
  "detectedClientName":"string or null"
}`;
    const resp = await fetch("https://api.anthropic.com/v1/messages",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,
        messages:[{role:"user",content:[
          {type:"document",source:{type:"base64",media_type:"application/pdf",data:b64}},
          {type:"text",text:prompt}
        ]}]})
    });
    const data=await resp.json();
    if(data.error) throw new Error(data.error.message);
    const txt=data.content?.find(b=>b.type==="text")?.text||"";
    const parsed=JSON.parse(txt.replace(/```json|```/g,"").trim());
    return {...parsed,fileName:file.name,fileSize:(file.size/1024).toFixed(0)+" KB",scannedAt:ts()};
  } catch {
    return buildDemoResult(file,period,contractor,queueIdx);
  }
}

// ── Month boundary detection ────────────────────────────────────────────────
function detectMonthBoundary(result) {
  if (!result?.dailyBreakdown?.length) return null;
  const hoursByMonth={};
  result.dailyBreakdown.forEach(d=>{
    const parts=(d.date||"").split(" ");
    if(parts.length<2) return;
    const mIdx=MONTHS.findIndex(m=>m.slice(0,3).toLowerCase()===parts[1].toLowerCase());
    if(mIdx<0) return;
    hoursByMonth[mIdx]=(hoursByMonth[mIdx]||0)+(d.hours||0);
  });
  const months=Object.keys(hoursByMonth).map(Number);
  if(months.length<2) return null;
  months.sort((a,b)=>a-b);
  return { months, hoursByMonth };
}

// ── Fuzzy contractor name matching ─────────────────────────────────────────
function matchContractor(detectedName) {
  if(!detectedName) return {contractor:null,confidence:0};
  const norm=s=>s.toLowerCase().replace(/[^a-z ]/g,"").trim();
  const dn=norm(detectedName);
  let best=null,bestScore=0;
  CONTRACTORS.forEach(c=>{
    const cn=norm(c.name);
    if(cn===dn){best=c;bestScore=100;return;}
    const dp=dn.split(" ").filter(Boolean);
    const cp=cn.split(" ").filter(Boolean);
    const hits=dp.filter(p=>cp.some(q=>q.startsWith(p)||p.startsWith(q))).length;
    const score=Math.round((hits/Math.max(dp.length,cp.length))*85);
    if(score>bestScore){best=c;bestScore=score;}
  });
  return {contractor: bestScore>=40?best:null, confidence:bestScore};
}

// ── Build version record (shared between single + multi) ───────────────────
function buildVersionRecord(c, items, period, totalH, regularH, overtimeH, intake, existingVersions) {
  return {
    versionId:"v"+uid(),
    version: existingVersions.length+1,
    contractorId:c.id,
    m:period.m, y:period.y,
    uploadedAt:ts(),
    fileName: items.length===1 ? items[0].result.fileName : `Batch (${items.length} files)`,
    fileSize: items.map(i=>i.result.fileSize).join(" + "),
    format: items.length===1 ? items[0].result.format : `Mixed (${items.length} documents)`,
    status:"SUBMITTED",
    hours:totalH,
    isBatch: items.length>1,
    batchFileCount: items.length,
    uploadedBy:CURRENT_ADMIN.name, uploadedByRole:CURRENT_ADMIN.role,
    intakeSource:intake.source, intakeSenderEmail:intake.senderEmail,
    intakeReceivedDate:intake.receivedDate, intakeNotes:intake.notes,
    subTimesheets: items.map((item,i)=>({
      idx:i+1,
      fileName:item.result.fileName, fileSize:item.result.fileSize,
      period:item.result.period, periodType:item.result.periodType||"unknown",
      totalHours:item.result.totalHours, regularHours:item.result.regularHours,
      overtimeHours:item.result.overtimeHours, format:item.result.format,
      confidence:item.result.confidence, warnings:item.result.warnings||[],
      weeks:item.result.weeks||[], dailyBreakdown:item.result.dailyBreakdown||[],
      notes:item.result.notes, detectedRate:item.result.detectedRate,
      detectedClient:item.result.detectedClientName,
      boundaryAlloc:item.boundaryAlloc||null,
    })),
    extractedData:{
      totalHours:totalH, regularHours:regularH, overtimeHours:overtimeH,
      period: items.length===1
        ? items[0].result.period
        : `${items[0].result.period} … ${items[items.length-1].result.period}`,
      weeks:items.flatMap(i=>i.result.weeks||[]),
      notes:items.map(i=>i.result.notes).filter(Boolean).join("; ")||null,
      warnings:items.flatMap(i=>i.result.warnings||[]),
      confidence:Math.round(items.reduce((s,i)=>s+(i.result.confidence||0),0)/items.length),
      dailyBreakdown:items.flatMap(i=>i.result.dailyBreakdown||[]),
      format:items.length===1?items[0].result.format:`Batch (${items.length} documents)`,
      detectedRate:c.rate, detectedClient:c.client,
    },
    rejectionReason:null,rejectedAt:null,rejectedBy:null,
    approvedAt:null,approvedBy:null,restorable:false,
  };
}

/* ─────────────────────────────────────────────────────────────────────────── */
function UploadView({contractor, period, versions, dupAction, latest, onSubmit, toast_}) {
  const [mode,       setMode]      = useState("single"); // "single"|"multi"
  const [queue,      setQueue]     = useState([]);
  const [dragOver,   setDragOver]  = useState(false);
  const [submitting, setSubmitting]= useState(false);
  const [submitted,  setSubmitted] = useState(null);
  const [dupWarning, setDupWarning]= useState(false);
  const [expandedId, setExpandedId]= useState(null);
  const [previewId,  setPreviewId] = useState(null);

  const [intake, setIntake] = useState({
    source:"email", senderEmail:contractor.email||"",
    receivedDate:new Date().toISOString().slice(0,10), notes:"",
  });
  useEffect(()=>setIntake(i=>({...i,senderEmail:contractor.email||""})),[contractor.id]);

  const fileRef = useRef();
  const updItem = (id,patch) => setQueue(q=>q.map(i=>i.id===id?{...i,...patch}:i));

  // ── Derived state ──────────────────────────────────────────────────────────
  const activeQueue    = queue.filter(i=>!i.excluded);
  const doneActive     = activeQueue.filter(i=>i.status==="done"&&i.result);
  const allDone        = activeQueue.length>0 && activeQueue.every(i=>i.status==="done"||i.status==="error");
  const anyScanning    = queue.some(i=>i.status==="scanning");
  const pendingBoundary= doneActive.filter(i=>i.boundary && !i.boundaryAlloc);

  // In multi mode: need all done items to have a confirmed contractor
  const unassigned = mode==="multi"
    ? doneActive.filter(i=>!i.confirmedContractorId)
    : [];

  // Conflict check (same contractor + overlapping period, single mode only)
  const conflicts=[];
  if(mode==="single") {
    activeQueue.forEach((a,i)=>activeQueue.forEach((b,j)=>{
      if(j<=i||!a.result||!b.result) return;
      if(periodsOverlap(a.result.period,b.result.period)) conflicts.push([a.id,b.id]);
    }));
  }
  const conflictIds=new Set(conflicts.flat());

  // Effective hours per item (respects boundary allocation)
  const effectiveHours = (item) => {
    if(!item.boundary||!item.boundaryAlloc||item.boundaryAlloc==="all") return item.result?.totalHours||0;
    const hbm = item.result?.hoursByMonth||{};
    if(item.boundaryAlloc==="current") return hbm[period.m]||0;
    if(item.boundaryAlloc==="next") return Object.entries(hbm).filter(([m])=>Number(m)!==period.m).reduce((s,[,h])=>s+h,0);
    return item.result?.totalHours||0; // "split" = all go in, carry-forward logged in notes
  };

  const batchHours    = doneActive.reduce((s,i)=>s+effectiveHours(i),0);
  const batchRegular  = doneActive.reduce((s,i)=>s+(i.result?.regularHours||0),0);
  const batchOvertime = doneActive.reduce((s,i)=>s+(i.result?.overtimeHours||0),0);
  const batchWarnings = doneActive.flatMap(i=>i.result?.warnings||[]);

  // Multi mode: group by confirmed contractor
  const byContractor = {};
  if(mode==="multi") {
    doneActive.forEach(item=>{
      const cId=item.confirmedContractorId;
      if(!cId) return;
      if(!byContractor[cId]) byContractor[cId]=[];
      byContractor[cId].push(item);
    });
  }

  // ── Add files ──────────────────────────────────────────────────────────────
  const addFiles = (files) => {
    const pdfs=Array.from(files).filter(f=>f.type==="application/pdf");
    if(pdfs.length<files.length) toast_("Non-PDF files skipped","warn");
    if(!pdfs.length) return;
    pdfs.forEach((f,fi)=>{
      const id=uid();
      const reader=new FileReader();
      reader.onload=e=>updItem(id,{pdfBytes:e.target.result});
      reader.readAsArrayBuffer(f);
      const qIdx=queue.length+fi;
      setQueue(q=>[...q,{
        id, file:f, pdfBytes:null, status:"scanning", result:null, excluded:false,
        boundary:null, boundaryAlloc:null,
        matchedContractor:null, matchConfidence:0,
        confirmedContractorId: mode==="single" ? contractor.id : null,
      }]);
      scanSinglePDF(f,period,contractor,qIdx).then(result=>{
        const boundary=detectMonthBoundary(result);
        if(boundary) result.hoursByMonth=boundary.hoursByMonth;
        const match=mode==="multi" ? matchContractor(result.contractorName) : null;
        updItem(id,{
          status:"done", result, boundary,
          boundaryAlloc: boundary ? null : "all", // no boundary = no choice needed
          matchedContractor: match?.contractor||null,
          matchConfidence: match?.confidence||0,
          // Auto-confirm high-confidence matches
          confirmedContractorId: mode==="single" ? contractor.id
            : (match?.confidence>=85 ? match.contractor?.id||null : null),
        });
      }).catch(()=>updItem(id,{status:"error"}));
    });
  };

  const drop=(e)=>{e.preventDefault();setDragOver(false);addFiles(e.dataTransfer.files);};

  // ── Submit ─────────────────────────────────────────────────────────────────
  const handleSubmit = async () => {
    if(mode==="single") {
      if(dupAction?.warn&&!dupWarning){setDupWarning(true);return;}
      if(!dupAction?.allow) return;
    }
    if(!allDone||doneActive.length===0) return;

    setSubmitting(true);
    await new Promise(r=>setTimeout(r,900));

    if(mode==="single") {
      const ver=buildVersionRecord(contractor,doneActive,period,batchHours,batchRegular,batchOvertime,intake,versions);
      onSubmit(ver, contractor.id);
      setSubmitted({mode:"single",contractor,versions:[{contractor,ver,hours:batchHours}]});
      toast_(`✓ ${doneActive.length} file${doneActive.length>1?"s":""} submitted — v${ver.version}`);
    } else {
      const created=[];
      Object.entries(byContractor).forEach(([cId,items])=>{
        const c=CONTRACTORS.find(x=>x.id===cId); if(!c) return;
        const gh=items.reduce((s,i)=>s+effectiveHours(i),0);
        const gr=items.reduce((s,i)=>s+(i.result?.regularHours||0),0);
        const go=items.reduce((s,i)=>s+(i.result?.overtimeHours||0),0);
        const ver=buildVersionRecord(c,items,period,gh,gr,go,intake,[]);
        onSubmit(ver,cId);
        created.push({contractor:c,ver,hours:gh});
      });
      setSubmitted({mode:"multi",versions:created});
      toast_(`✓ Submitted for ${created.length} contractor${created.length>1?"s":""}`);
    }
    setSubmitting(false);
  };

  const resetAll=()=>{setQueue([]);setSubmitted(null);setDupWarning(false);setExpandedId(null);setPreviewId(null);};
  const switchMode=(m)=>{setMode(m);setQueue([]);setDupWarning(false);};

  // ── Mode toggle (always visible at top) ────────────────────────────────────
  const ModeToggle = () => (
    <div style={{display:"flex",gap:0,background:B.bg,border:`1px solid ${B.border}`,borderRadius:9,padding:3,width:"fit-content",marginBottom:16}}>
      {[["single","Single contractor"],["multi","Multiple contractors"]].map(([id,label])=>(
        <button key={id} onClick={()=>switchMode(id)} style={{
          padding:"7px 16px",borderRadius:7,border:"none",cursor:"pointer",
          fontFamily:"'DM Sans',sans-serif",fontSize:13,fontWeight:mode===id?600:400,
          background:mode===id?B.surface:B.bg,
          color:mode===id?B.text:B.dim,
          boxShadow:mode===id?B.sdw:"none",
          transition:"all .15s",
        }}>{label}</button>
      ))}
    </div>
  );

  // ── Success screen ─────────────────────────────────────────────────────────
  if(submitted) {
    return (
      <div className="card u" style={{padding:"44px 52px",maxWidth:580,margin:"0 auto"}}>
        <div style={{width:56,height:56,borderRadius:16,background:B.gP,border:`1px solid ${B.gB}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:28,margin:"0 auto 18px"}}>✓</div>
        <div style={{fontSize:20,fontWeight:700,color:B.text,marginBottom:4,textAlign:"center"}}>
          {submitted.mode==="multi" ? `Submitted for ${submitted.versions.length} contractors` : "Submitted for review"}
        </div>
        <div style={{fontSize:13.5,color:B.dim,marginBottom:22,textAlign:"center"}}>{MONTHS[period.m]} {period.y}</div>

        {/* Per-contractor summary */}
        {submitted.versions.map(({contractor:c,ver,hours})=>(
          <div key={c.id} style={{marginBottom:12,padding:"14px 16px",background:B.bg,borderRadius:10,border:`1px solid ${B.border}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{width:28,height:28,borderRadius:7,background:c.bg,color:c.col,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700}}>{c.initials}</div>
                <span style={{fontSize:13.5,fontWeight:600,color:B.text}}>{c.name}</span>
              </div>
              <div style={{textAlign:"right"}}>
                <span className="mono" style={{fontSize:14,color:B.accent,fontWeight:600}}>{hours}h</span>
                <div style={{fontSize:11.5,color:B.dim}}>{fmt(hours*c.rate)}</div>
              </div>
            </div>
            {ver.subTimesheets.map((s,i)=>(
              <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderTop:`1px solid ${B.faint}`}}>
                <span style={{fontSize:12,color:B.dim}}>{s.fileName} · {s.period}</span>
                <span className="mono" style={{fontSize:12,color:B.mid}}>{s.totalHours}h</span>
              </div>
            ))}
          </div>
        ))}

        <button className="btn btn-ghost" style={{width:"100%",marginTop:8}} onClick={resetAll}>Upload another batch →</button>
      </div>
    );
  }

  // ── Empty state ────────────────────────────────────────────────────────────
  if(queue.length===0) {
    return (
      <div style={{maxWidth:660,margin:"0 auto"}}>
        <ModeToggle/>
        {mode==="single" && latest && <DupBanner latest={latest} dupAction={dupAction} versions={versions} period={period}/>}
        {mode==="multi" && (
          <div style={{padding:"11px 16px",background:B.aP,border:`1px solid ${B.aBd}`,borderRadius:10,marginBottom:12,fontSize:13,color:B.accent}}>
            ℹ Drop PDFs for any contractors — the AI will read each name and match it automatically. You'll confirm before submitting.
          </div>
        )}
        <IntakeForm intake={intake} setIntake={setIntake} contractor={contractor}/>
        <div style={{marginTop:14}}>
          <MultiDropZone dragOver={dragOver} setDragOver={setDragOver} drop={drop} fileRef={fileRef} addFiles={addFiles}/>
        </div>
      </div>
    );
  }

  // ── Queue view ─────────────────────────────────────────────────────────────
  const previewItem = previewId ? queue.find(i=>i.id===previewId) : null;
  return (
    <div style={{display:"grid",gridTemplateColumns:"1fr 380px",gap:16,alignItems:"start"}}>

      {/* ── LEFT: mode toggle + queue ── */}
      <div style={{display:"flex",flexDirection:"column",gap:12}}>
        <ModeToggle/>

        {/* Admin badge */}
        <div style={{display:"flex",alignItems:"center",gap:10,padding:"9px 14px",background:B.surface,border:`1px solid ${B.border}`,borderRadius:10}}>
          <div style={{width:28,height:28,borderRadius:7,background:B.accent,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,flexShrink:0}}>{CURRENT_ADMIN.initials}</div>
          <div style={{flex:1,fontSize:12.5,color:B.dim}}>
            <strong style={{color:B.text}}>{CURRENT_ADMIN.name}</strong>
            {mode==="single" ? <> · uploading on behalf of <strong style={{color:B.text}}>{contractor.name}</strong></>
                             : <> · uploading for multiple contractors</>}
          </div>
        </div>

        {/* Dup banner (single mode) */}
        {mode==="single" && latest && <DupBanner latest={latest} dupAction={dupAction} versions={versions} period={period}/>}

        {/* Conflict warnings */}
        {conflicts.map(([aId,bId],ci)=>{
          const a=queue.find(i=>i.id===aId), b=queue.find(i=>i.id===bId);
          if(!a||!b) return null;
          return (
            <div key={ci} style={{padding:"13px 16px",background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:10}}>
              <div style={{fontSize:13,fontWeight:700,color:B.amber,marginBottom:6}}>⚠ Overlapping periods detected</div>
              <div style={{fontSize:12.5,color:B.mid,marginBottom:10}}>
                <strong>{a.result?.period}</strong> and <strong>{b.result?.period}</strong> cover overlapping dates.
              </div>
              <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
                <button className="btn btn-sm btn-ghost" onClick={()=>{updItem(aId,{excluded:false});updItem(bId,{excluded:false});}}>Keep both</button>
                <button className="btn btn-sm" style={{background:B.rP,border:`1px solid ${B.rB}`,color:B.red}} onClick={()=>updItem(aId,{excluded:true})}>Remove {a.result?.fileName?.slice(0,18)||"File 1"}</button>
                <button className="btn btn-sm" style={{background:B.rP,border:`1px solid ${B.rB}`,color:B.red}} onClick={()=>updItem(bId,{excluded:true})}>Remove {b.result?.fileName?.slice(0,18)||"File 2"}</button>
              </div>
            </div>
          );
        })}

        {/* PDF preview inline */}
        {previewItem?.pdfBytes && (
          <div className="fi">
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
              <span style={{fontSize:13,fontWeight:600,color:B.text}}>{previewItem.file.name}</span>
              <button className="btn btn-ghost btn-sm" onClick={()=>setPreviewId(null)}>Close</button>
            </div>
            <PDFViewer pdfBytes={previewItem.pdfBytes} fileName={previewItem.file.name} scanning={previewItem.status==="scanning"}/>
          </div>
        )}

        {/* Queue cards */}
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {queue.map((item,idx)=>(
            <FileQueueItem
              key={item.id} item={item} idx={idx}
              mode={mode}
              isConflict={conflictIds.has(item.id)}
              expanded={expandedId===item.id}
              previewing={previewId===item.id}
              currentMonth={period.m}
              onToggleExpand={()=>setExpandedId(expandedId===item.id?null:item.id)}
              onPreview={()=>setPreviewId(previewId===item.id?null:item.id)}
              onExclude={()=>updItem(item.id,{excluded:!item.excluded})}
              onRemove={()=>setQueue(q=>q.filter(i=>i.id!==item.id))}
              onBoundaryAlloc={(alloc)=>updItem(item.id,{boundaryAlloc:alloc})}
              onAssignContractor={(cId)=>updItem(item.id,{confirmedContractorId:cId})}
            />
          ))}
        </div>

        <AddMoreZone dragOver={dragOver} setDragOver={setDragOver} drop={drop} fileRef={fileRef} addFiles={addFiles}/>
      </div>

      {/* ── RIGHT: intake + batch summary ── */}
      <div style={{display:"flex",flexDirection:"column",gap:12,position:"sticky",top:24}}>
        <IntakeForm intake={intake} setIntake={setIntake} contractor={contractor} compact/>
        <BatchSummaryPanel
          mode={mode}
          doneActive={doneActive}
          byContractor={byContractor}
          allDone={allDone}
          anyScanning={anyScanning}
          batchHours={batchHours}
          batchRegular={batchRegular}
          batchOvertime={batchOvertime}
          batchValue={batchHours*contractor.rate}
          batchWarnings={batchWarnings}
          contractor={contractor}
          period={period}
          versions={versions}
          dupAction={dupAction}
          dupWarning={dupWarning}
          submitting={submitting}
          conflictCount={conflicts.length}
          pendingBoundary={pendingBoundary.length}
          unassignedCount={unassigned.length}
          onSubmit={handleSubmit}
          onCancelDup={()=>setDupWarning(false)}
        />
      </div>
    </div>
  );
}

/* ─── File queue item (with boundary + contractor assignment) ────────────── */
function FileQueueItem({item,idx,mode,isConflict,expanded,previewing,currentMonth,
  onToggleExpand,onPreview,onExclude,onRemove,onBoundaryAlloc,onAssignContractor}) {

  const r=item.result;
  const confColor=!r?B.dim:r.confidence>=90?B.green:r.confidence>=70?B.amber:B.red;
  const hasBoundary=!!item.boundary && item.status==="done";
  const boundaryPending=hasBoundary && !item.boundaryAlloc;

  return (
    <div className="card fi" style={{
      overflow:"hidden",
      opacity:item.excluded?0.45:1,
      border:`1px solid ${
        item.excluded?B.border
        :boundaryPending?B.purB
        :(isConflict&&!item.excluded)?B.aLB
        :item.status==="done"?B.gB:B.border
      }`,
      transition:"opacity .2s,border-color .2s",
    }}>
      {/* Row header */}
      <div style={{padding:"12px 14px",display:"flex",alignItems:"center",gap:10}}>
        <div style={{
          width:26,height:26,borderRadius:7,flexShrink:0,fontSize:11,fontWeight:700,
          background:item.excluded?B.bg:boundaryPending?B.purP:item.status==="done"?B.gP:item.status==="scanning"?B.purP:B.bg,
          color:item.excluded?B.sub:boundaryPending?B.purple:item.status==="done"?B.green:item.status==="scanning"?B.purple:B.dim,
          border:`1px solid ${item.excluded?B.border:boundaryPending?B.purB:item.status==="done"?B.gB:item.status==="scanning"?B.purB:B.border}`,
          display:"flex",alignItems:"center",justifyContent:"center",
        }}>
          {item.status==="scanning"?<Spinner col={B.purple}/>:item.excluded?"–":idx+1}
        </div>

        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:13,fontWeight:600,color:item.excluded?B.dim:B.text,
            whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",
            textDecoration:item.excluded?"line-through":"none"}}>
            {item.file.name}
          </div>
          <div style={{fontSize:11.5,color:B.dim,marginTop:1}}>
            {(item.file.size/1024).toFixed(0)} KB
            {item.status==="scanning" && <span style={{color:B.purple,fontWeight:600}}> · Scanning…</span>}
            {r && !item.excluded && <span> · <strong style={{color:confColor}}>{r.totalHours}h</strong> · {r.period}</span>}
            {hasBoundary && !item.excluded && <span style={{color:B.purple,fontWeight:600}}> · ⚠ spans months</span>}
            {item.status==="error" && <span style={{color:B.red}}> · Scan failed</span>}
          </div>
        </div>

        <div style={{display:"flex",gap:5,flexShrink:0,alignItems:"center"}}>
          {r&&!item.excluded&&<button className="btn btn-sm btn-ghost" onClick={onPreview}>{previewing?"Close":"Preview"}</button>}
          {r&&!item.excluded&&<button className="btn btn-sm btn-ghost" onClick={onToggleExpand}>{expanded?"▲":"▼"}</button>}
          <button className="btn btn-sm" onClick={onExclude}
            style={{background:item.excluded?B.gP:B.aLP,border:`1px solid ${item.excluded?B.gB:B.aLB}`,color:item.excluded?B.green:B.amber}}>
            {item.excluded?"Include":"Exclude"}
          </button>
          <button className="btn btn-sm" style={{background:B.rP,border:`1px solid ${B.rB}`,color:B.red}} onClick={onRemove}>✕</button>
        </div>
      </div>

      {item.status==="scanning" && (
        <div style={{height:2,overflow:"hidden"}}><div className="skel" style={{height:"100%",width:"100%"}}/></div>
      )}

      {/* ── Contractor assignment row (multi mode) ── */}
      {mode==="multi" && r && !item.excluded && (
        <div style={{padding:"9px 14px",borderTop:`1px solid ${B.faint}`,background:B.bg,display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
          <span style={{fontSize:12,color:B.dim,flexShrink:0}}>Contractor:</span>
          {item.matchedContractor && (
            <div style={{display:"flex",alignItems:"center",gap:6,marginRight:4}}>
              <div style={{width:20,height:20,borderRadius:5,background:item.matchedContractor.bg,color:item.matchedContractor.col,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:700}}>{item.matchedContractor.initials}</div>
              <span style={{fontSize:12.5,fontWeight:600,color:B.text}}>{item.matchedContractor.name}</span>
              <span style={{fontSize:11,padding:"1px 6px",borderRadius:4,
                background:item.matchConfidence>=85?B.gP:item.matchConfidence>=60?B.aLP:B.rP,
                color:item.matchConfidence>=85?B.green:item.matchConfidence>=60?B.amber:B.red,
                border:`1px solid ${item.matchConfidence>=85?B.gB:item.matchConfidence>=60?B.aLB:B.rB}`,
              }}>
                {item.matchConfidence>=85?"✓ Auto-matched":item.matchConfidence>=60?"Low confidence":"No match"}
              </span>
            </div>
          )}
          {!item.matchedContractor && <span style={{fontSize:12.5,color:B.red}}>Not recognised — assign manually:</span>}
          {/* Confirm / reassign */}
          {!item.confirmedContractorId || item.matchConfidence<85 ? (
            <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
              {CONTRACTORS.map(c=>(
                <button key={c.id} onClick={()=>onAssignContractor(c.id)}
                  style={{
                    padding:"3px 10px",borderRadius:6,cursor:"pointer",fontSize:12,fontWeight:600,
                    fontFamily:"'DM Sans',sans-serif",
                    background:item.confirmedContractorId===c.id?c.bg:B.surface,
                    border:`1.5px solid ${item.confirmedContractorId===c.id?c.col+"60":B.border}`,
                    color:item.confirmedContractorId===c.id?c.col:B.dim,
                    transition:"all .12s",
                  }}>{c.name.split(" ")[0]}</button>
              ))}
            </div>
          ) : (
            <button className="btn btn-sm btn-ghost" style={{fontSize:11}} onClick={()=>onAssignContractor(null)}>Change</button>
          )}
        </div>
      )}

      {/* ── Month boundary allocation row ── */}
      {hasBoundary && !item.excluded && (
        <div style={{padding:"11px 14px",borderTop:`1px solid ${B.purB}`,background:B.purP}}>
          <div style={{fontSize:12.5,fontWeight:700,color:B.purple,marginBottom:6}}>
            ⚠ This sheet spans two months
          </div>
          <div style={{fontSize:12,color:B.mid,marginBottom:8}}>
            {Object.entries(item.boundary.hoursByMonth).map(([m,h])=>(
              <span key={m} style={{marginRight:12}}>
                <strong>{MONTHS[Number(m)]}</strong>: {h}h
              </span>
            ))}
          </div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            {[
              ["current",  `Bill all to ${MONTHS[currentMonth]}`],
              ["next",     `Bill all to ${MONTHS[(currentMonth+1)%12]}`],
              ["split",    "Split between months"],
            ].map(([val,label])=>(
              <button key={val} onClick={()=>onBoundaryAlloc(val)}
                style={{
                  padding:"5px 12px",borderRadius:7,cursor:"pointer",fontSize:12,fontWeight:600,
                  fontFamily:"'DM Sans',sans-serif",
                  background:item.boundaryAlloc===val?B.purple:B.surface,
                  border:`1.5px solid ${item.boundaryAlloc===val?"transparent":B.purB}`,
                  color:item.boundaryAlloc===val?"#fff":B.purple,
                  transition:"all .13s",
                }}>{label}</button>
            ))}
          </div>
          {item.boundaryAlloc==="split" && (
            <div style={{marginTop:8,fontSize:12,color:B.purple}}>
              ℹ Both months' hours will be included. The {MONTHS[(currentMonth+1)%12]} portion will be noted as carry-forward in the version record.
            </div>
          )}
          {item.boundaryAlloc==="current" && (
            <div style={{marginTop:8,fontSize:12,color:B.dim}}>
              Only {item.boundary.hoursByMonth[currentMonth]||0}h (in {MONTHS[currentMonth]}) will count toward this invoice.
            </div>
          )}
          {item.boundaryAlloc==="next" && (
            <div style={{marginTop:8,fontSize:12,color:B.dim}}>
              {Object.entries(item.boundary.hoursByMonth).filter(([m])=>Number(m)!==currentMonth).reduce((s,[,h])=>s+h,0)}h will be billed to {MONTHS[(currentMonth+1)%12]}.
            </div>
          )}
        </div>
      )}

      {/* Warnings strip */}
      {r&&!item.excluded&&r.warnings?.length>0&&!expanded&&!hasBoundary&&(
        <div style={{padding:"6px 14px 8px",background:B.aLP,borderTop:`1px solid ${B.aLB}`}}>
          {r.warnings.map((w,i)=><div key={i} style={{fontSize:11.5,color:B.amber}}>⚠ {w}</div>)}
        </div>
      )}

      {/* Expanded detail */}
      {expanded&&r&&!item.excluded&&(
        <div className="fi" style={{padding:"14px",borderTop:`1px solid ${B.faint}`,background:B.bg}}>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:12}}>
            {[["Total",`${r.totalHours}h`,B.accent],["Regular",`${r.regularHours}h`,B.green],["Overtime",`${r.overtimeHours}h`,r.overtimeHours>8?B.red:B.amber]].map(([k,v,c])=>(
              <div key={k} style={{padding:"10px",borderRadius:8,background:B.surface,border:`1px solid ${B.border}`,textAlign:"center"}}>
                <div className="mono" style={{fontSize:17,color:c,marginBottom:2}}>{v}</div>
                <div style={{fontSize:11,color:B.dim}}>{k}</div>
              </div>
            ))}
          </div>
          {[["Period",r.period],["Format",r.format],["Confidence",`${r.confidence}%`],r.notes?["Notes",r.notes]:null].filter(Boolean).map(([k,v])=>(
            <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:`1px solid ${B.faint}`}}>
              <span style={{fontSize:12.5,color:B.dim}}>{k}</span>
              <span style={{fontSize:12.5,color:B.text,fontWeight:500,maxWidth:240,textAlign:"right"}}>{v}</span>
            </div>
          ))}
          {r.weeks?.length>0&&(
            <div style={{marginTop:10}}>
              <div className="lbl" style={{marginBottom:6}}>Weekly breakdown</div>
              {r.weeks.map((w,i)=>{const pct=w.h/Math.max(...r.weeks.map(x=>x.h));return(
                <div key={i} style={{marginBottom:6}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:2}}>
                    <span style={{fontSize:12,color:B.mid}}>{w.wk}</span>
                    <span className="mono" style={{fontSize:12,color:w.h>44?B.red:w.h>40?B.amber:B.green}}>{w.h}h</span>
                  </div>
                  <div style={{height:5,borderRadius:2,background:B.border,overflow:"hidden"}}>
                    <div style={{height:"100%",width:`${pct*100}%`,background:w.h>44?B.red:w.h>40?B.amber:B.accent,borderRadius:2}}/>
                  </div>
                </div>
              );})}
            </div>
          )}
          {r.warnings?.length>0&&(
            <div style={{marginTop:10,padding:"10px 12px",background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:8}}>
              {r.warnings.map((w,i)=><div key={i} style={{fontSize:12.5,color:B.amber,marginBottom:i<r.warnings.length-1?5:0}}>⚠ {w}</div>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ─── Batch summary panel ─────────────────────────────────────────────────── */
function BatchSummaryPanel({mode,doneActive,byContractor,allDone,anyScanning,batchHours,batchRegular,batchOvertime,batchValue,batchWarnings,contractor,period,versions,dupAction,dupWarning,submitting,conflictCount,pendingBoundary,unassignedCount,onSubmit,onCancelDup}) {
  const confAvg=doneActive.length>0?Math.round(doneActive.reduce((s,i)=>s+(i.result?.confidence||0),0)/doneActive.length):0;
  const blockReasons=[];
  if(conflictCount>0)    blockReasons.push(`Resolve ${conflictCount} period conflict${conflictCount>1?"s":""}`);
  if(pendingBoundary>0)  blockReasons.push(`Choose month allocation for ${pendingBoundary} boundary sheet${pendingBoundary>1?"s":""}`);
  if(unassignedCount>0)  blockReasons.push(`Assign ${unassignedCount} unmatched file${unassignedCount>1?"s":""} to a contractor`);
  if(dupAction?.allow===false) blockReasons.push("Period is locked");
  const canSubmit=allDone&&doneActive.length>0&&blockReasons.length===0&&!anyScanning;

  return (
    <div className="card" style={{overflow:"hidden"}}>
      <div style={{padding:"14px 16px",borderBottom:`1px solid ${B.faint}`,background:B.bg}}>
        <div style={{fontSize:13,fontWeight:700,color:B.text}}>
          {mode==="multi"?"Multi-Contractor Batch":"Batch Summary"}
        </div>
        <div style={{fontSize:11.5,color:B.dim,marginTop:1}}>
          {doneActive.length} file{doneActive.length!==1?"s":""} ready · {MONTHS[period.m]} {period.y}
        </div>
      </div>

      <div style={{padding:"16px"}}>
        {anyScanning&&(
          <div style={{display:"flex",alignItems:"center",gap:8,padding:"10px 12px",background:B.purP,border:`1px solid ${B.purB}`,borderRadius:8,marginBottom:12}}>
            <Spinner col={B.purple}/><span style={{fontSize:13,color:B.purple}}>Scanning…</span>
          </div>
        )}

        {/* Multi-mode: per-contractor breakdown */}
        {mode==="multi" && Object.keys(byContractor).length>0 && (
          <div style={{marginBottom:14}}>
            <div className="lbl" style={{marginBottom:8}}>By contractor</div>
            {Object.entries(byContractor).map(([cId,items])=>{
              const c=CONTRACTORS.find(x=>x.id===cId); if(!c) return null;
              const ch=items.reduce((s,i)=>s+(i.result?.totalHours||0),0);
              return (
                <div key={cId} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${B.faint}`}}>
                  <div style={{display:"flex",alignItems:"center",gap:7}}>
                    <div style={{width:22,height:22,borderRadius:6,background:c.bg,color:c.col,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:700}}>{c.initials}</div>
                    <div>
                      <div style={{fontSize:12.5,fontWeight:600,color:B.text}}>{c.name}</div>
                      <div style={{fontSize:11,color:B.dim}}>{items.length} file{items.length>1?"s":""}</div>
                    </div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div className="mono" style={{fontSize:13,color:B.accent,fontWeight:600}}>{ch}h</div>
                    <div style={{fontSize:11,color:B.dim}}>{fmt(ch*c.rate)}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Single mode: file list */}
        {mode==="single" && doneActive.length>0 && (
          <div style={{marginBottom:14}}>
            <div className="lbl" style={{marginBottom:8}}>Files in batch</div>
            {doneActive.map(item=>(
              <div key={item.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"6px 0",borderBottom:`1px solid ${B.faint}`}}>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:12.5,color:B.text,fontWeight:500,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",maxWidth:165}}>{item.result.fileName}</div>
                  <div style={{fontSize:11,color:B.dim}}>{item.result.period}{item.boundaryAlloc&&item.boundary?<span style={{color:B.purple}}> · billed to {item.boundaryAlloc==="current"?MONTHS[period.m]:item.boundaryAlloc==="next"?MONTHS[(period.m+1)%12]:"split"}</span>:""}</div>
                </div>
                <span className="mono" style={{fontSize:13,color:B.accent,fontWeight:600,flexShrink:0}}>{item.result.totalHours}h</span>
              </div>
            ))}
          </div>
        )}

        {/* Totals */}
        {doneActive.length>0 && (
          <>
            <div style={{padding:"12px",background:B.bg,borderRadius:8,marginBottom:12}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                <span style={{fontSize:12.5,color:B.dim}}>Regular</span>
                <span className="mono" style={{fontSize:13,color:B.green}}>{batchRegular}h</span>
              </div>
              {batchOvertime>0&&<div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                <span style={{fontSize:12.5,color:B.dim}}>Overtime</span>
                <span className="mono" style={{fontSize:13,color:batchOvertime>20?B.red:B.amber}}>{batchOvertime}h</span>
              </div>}
              <div style={{display:"flex",justifyContent:"space-between",paddingTop:6,borderTop:`1px solid ${B.border}`}}>
                <span style={{fontSize:13,fontWeight:700,color:B.text}}>Total hours</span>
                <span className="mono" style={{fontSize:15,fontWeight:700,color:B.text}}>{batchHours}h</span>
              </div>
            </div>

            {mode==="single" && (
              <div style={{padding:"12px 14px",background:B.aP,border:`1px solid ${B.aBd}`,borderRadius:8,marginBottom:12,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div>
                  <div style={{fontSize:11,color:B.dim,marginBottom:2}}>Estimated invoice</div>
                  <div className="mono" style={{fontSize:20,color:B.accent,fontWeight:500}}>{fmt(batchValue)}</div>
                </div>
                <div style={{fontSize:11.5,color:B.dim,textAlign:"right"}}>{batchHours}h × ${contractor.rate}/hr</div>
              </div>
            )}

            <div style={{marginBottom:12}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                <span style={{fontSize:12,color:B.dim}}>Avg confidence</span>
                <span className="mono" style={{fontSize:12,color:confAvg>=90?B.green:confAvg>=70?B.amber:B.red}}>{confAvg}%</span>
              </div>
              <div style={{height:4,borderRadius:2,background:B.border,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${confAvg}%`,background:confAvg>=90?B.green:confAvg>=70?B.amber:B.red,borderRadius:2,transition:"width .4s"}}/>
              </div>
            </div>

            {batchWarnings.length>0&&(
              <div style={{padding:"10px 12px",background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:8,marginBottom:12}}>
                {batchWarnings.map((w,i)=><div key={i} style={{fontSize:12.5,color:B.amber,marginBottom:i<batchWarnings.length-1?4:0}}>⚠ {w}</div>)}
              </div>
            )}
          </>
        )}

        {/* Block reasons */}
        {blockReasons.map((r,i)=>(
          <div key={i} style={{padding:"8px 12px",background:i===0&&dupAction?.allow===false?B.rP:B.aLP,border:`1px solid ${i===0&&dupAction?.allow===false?B.rB:B.aLB}`,borderRadius:8,marginBottom:6,fontSize:12.5,color:B.amber}}>
            {dupAction?.allow===false&&i===0?"🔒":i===blockReasons.length-1?"⚠":"⚠"} {r}
          </div>
        ))}

        {/* Dup warn */}
        {dupWarning&&(
          <div style={{padding:"12px 14px",background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:9,marginBottom:12}}>
            <div style={{fontSize:13,fontWeight:700,color:B.amber,marginBottom:6}}>⚠ Replace existing submission?</div>
            <div style={{fontSize:12.5,color:B.mid,marginBottom:10}}>A pending timesheet exists for this period. Uploading will restart the review.</div>
            <div style={{display:"flex",gap:7}}>
              <button className="btn btn-sm" style={{background:B.amber,color:"#fff",border:"none"}} onClick={onSubmit}>Yes, replace</button>
              <button className="btn btn-sm btn-ghost" onClick={onCancelDup}>Cancel</button>
            </div>
          </div>
        )}

        <button className="btn btn-accent" style={{width:"100%",padding:"13px",fontSize:14,opacity:canSubmit?1:0.45}} onClick={onSubmit} disabled={!canSubmit||submitting}>
          {submitting?<><Spinner/> Submitting…</>
           :anyScanning?"Scanning…"
           :doneActive.length===0?"Add files to submit"
           :blockReasons.length>0?"Resolve issues above"
           :mode==="multi"?`Submit for ${Object.keys(byContractor).length} contractor${Object.keys(byContractor).length!==1?"s":""} →`
           :`Submit ${doneActive.length} file${doneActive.length!==1?"s":""} →`}
        </button>
      </div>
    </div>
  );
}

/* ─── Drop zones ─────────────────────────────────────────────────────────── */
function MultiDropZone({dragOver,setDragOver,drop,fileRef,addFiles}) {
  return (
    <div onDragOver={e=>{e.preventDefault();setDragOver(true)}} onDragLeave={()=>setDragOver(false)} onDrop={drop}
      onClick={()=>fileRef.current.click()}
      style={{border:`2px dashed ${dragOver?B.accent:B.border}`,borderRadius:14,padding:"48px 32px",textAlign:"center",background:dragOver?B.aP:B.surface,cursor:"pointer",transition:"all .18s"}}>
      <input ref={fileRef} type="file" accept=".pdf" multiple style={{display:"none"}} onChange={e=>addFiles(e.target.files)}/>
      <div style={{fontSize:44,marginBottom:14}}>📄📄</div>
      <div style={{fontSize:16,fontWeight:600,color:B.text,marginBottom:6}}>Drop one or more PDF timesheets</div>
      <div style={{fontSize:13.5,color:B.dim,marginBottom:18}}>Weekly · fortnightly · monthly · mix freely · click to browse</div>
      <div style={{display:"flex",justifyContent:"center",gap:8,flexWrap:"wrap"}}>
        {["Weekly sheets","Monthly summary","Multiple contractors","Scanned docs"].map(f=>(
          <span key={f} style={{fontSize:11,padding:"3px 10px",borderRadius:5,background:B.bg,border:`1px solid ${B.border}`,color:B.dim}}>{f}</span>
        ))}
      </div>
    </div>
  );
}

function AddMoreZone({dragOver,setDragOver,drop,fileRef,addFiles}) {
  return (
    <div onDragOver={e=>{e.preventDefault();setDragOver(true)}} onDragLeave={()=>setDragOver(false)} onDrop={drop}
      onClick={()=>fileRef.current.click()}
      style={{border:`1.5px dashed ${dragOver?B.accent:B.border}`,borderRadius:10,padding:"14px 20px",display:"flex",alignItems:"center",gap:12,background:dragOver?B.aP:B.surface,cursor:"pointer",transition:"all .15s"}}
      onMouseEnter={e=>e.currentTarget.style.borderColor=B.accent}
      onMouseLeave={e=>{if(!dragOver)e.currentTarget.style.borderColor=B.border;}}>
      <input ref={fileRef} type="file" accept=".pdf" multiple style={{display:"none"}} onChange={e=>addFiles(e.target.files)}/>
      <span style={{fontSize:22}}>＋</span>
      <div>
        <div style={{fontSize:13,fontWeight:600,color:B.mid}}>Add more PDFs to this batch</div>
        <div style={{fontSize:11.5,color:B.sub}}>Drop or click to browse — any format, any contractor</div>
      </div>
    </div>
  );
}

// Demo data varied by file index so each "weekly" PDF looks distinct
const DEMO_WEEKS = [
  { label:"Week 1 (3–7 Mar)",  h:42, days:[8,8,10,8,8],  ot:2  },
  { label:"Week 2 (10–14 Mar)", h:44, days:[8,9,9,10,8], ot:4  },
  { label:"Week 3 (17–21 Mar)", h:40, days:[8,8,8,8,8],  ot:0  },
  { label:"Week 4 (24–28 Mar)", h:38, days:[8,7,8,8,7],  ot:0  },
];

function buildDemoResult(f, period, contractor, idx=0) {
  const wk = DEMO_WEEKS[idx % DEMO_WEEKS.length];
  const isWeekly = idx < 4; // first 4 treated as weekly sheets in demo
  const totalHours = isWeekly ? wk.h : DEMO_WEEKS.reduce((s,w)=>s+w.h,0);
  const regularHours = totalHours - (isWeekly ? wk.ot : DEMO_WEEKS.reduce((s,w)=>s+w.ot,0));
  const overtimeHours = totalHours - regularHours;

  const weekDates = ["3 Mar","4 Mar","5 Mar","6 Mar","7 Mar",
                     "10 Mar","11 Mar","12 Mar","13 Mar","14 Mar",
                     "17 Mar","18 Mar","19 Mar","20 Mar","21 Mar",
                     "24 Mar","25 Mar","26 Mar","27 Mar","28 Mar"];
  const startOffset = isWeekly ? idx*5 : 0;
  const count = isWeekly ? 5 : 20;

  return {
    contractorName: contractor.name,
    period: isWeekly ? wk.label : `1–28 ${MONTHS[period.m]} ${period.y}`,
    totalHours, regularHours, overtimeHours,
    weeks: isWeekly
      ? [{ wk: wk.label, h: wk.h }]
      : DEMO_WEEKS.map((w,i)=>({ wk:`Week ${i+1}`, h:w.h })),
    dailyBreakdown: weekDates.slice(startOffset, startOffset+count).map((date,i)=>({
      date, hours: isWeekly ? wk.days[i] || 8 : 8, description:"Development",
    })),
    notes: idx===0 ? "Approved by team lead J. Smith" : null,
    format: idx===0 ? "Standard Weekly Grid"
          : idx===1 ? "Custom Template (Landscape)"
          : idx===2 ? "Daily Log Format"
          : "Standard Weekly Grid",
    confidence: 88 + (idx % 3)*3,
    warnings: overtimeHours > 8 ? [`Overtime hours (${overtimeHours}h) exceed typical weekly limit`] : [],
    missingFields: [],
    detectedRate: contractor.rate,
    detectedClientName: contractor.client,
    fileName: f.name,
    fileSize: (f.size/1024).toFixed(0)+" KB",
    scannedAt: ts(),
  };
}

async function scanSinglePDF(file, period, contractor, queueIdx) {
  try {
    const b64 = await new Promise((res,rej)=>{
      const r=new FileReader();
      r.onload=()=>res(r.result.split(",")[1]);
      r.onerror=()=>rej(new Error("Read failed"));
      r.readAsDataURL(file);
    });

    const prompt = `You are a timesheet parser for an Australian labour hire agency.
Analyse this PDF timesheet document carefully and extract all data.
This may be a weekly or monthly timesheet — determine which from the content.

Return ONLY valid JSON in exactly this shape — no markdown, no preamble:
{
  "contractorName": "string or null",
  "period": "string describing the pay period covered by THIS document (e.g. 'Week 1: 3–7 Mar 2026' or '1-28 March 2026')",
  "periodType": "weekly" or "fortnightly" or "monthly",
  "totalHours": number,
  "regularHours": number,
  "overtimeHours": number,
  "weeks": [{"wk":"Week 1","h":number}, ...],
  "dailyBreakdown": [{"date":"DD Mon","hours":number,"description":"string or null"}],
  "notes": "any notes on the timesheet or null",
  "format": "describe the format/template used",
  "confidence": number 0-100,
  "warnings": ["array of anomalies"],
  "missingFields": ["array of missing expected fields"],
  "detectedRate": number or null,
  "detectedClientName": "string or null"
}`;

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        model:"claude-sonnet-4-20250514",
        max_tokens:1000,
        messages:[{role:"user",content:[
          {type:"document",source:{type:"base64",media_type:"application/pdf",data:b64}},
          {type:"text",text:prompt}
        ]}]
      })
    });
    const data = await response.json();
    if (data.error) throw new Error(data.error.message);
    const text = data.content?.find(b=>b.type==="text")?.text||"";
    const parsed = JSON.parse(text.replace(/```json|```/g,"").trim());
    return { ...parsed, fileName:file.name, fileSize:(file.size/1024).toFixed(0)+" KB", scannedAt:ts() };
  } catch {
    return buildDemoResult(file, period, contractor, queueIdx);
  }
}

// Detect date-range overlap between two period strings (heuristic)
function periodsOverlap(a, b) {
  if (!a || !b) return false;
  const monthNames = MONTHS.map(m=>m.toLowerCase());
  const extract = s => {
    const lower = s.toLowerCase();
    const m = monthNames.findIndex(mn=>lower.includes(mn));
    const nums = s.match(/\d+/g)?.map(Number)||[];
    return { month:m, nums };
  };
  const pa = extract(a), pb = extract(b);
  if (pa.month === -1 || pb.month === -1) return false;
  if (pa.month !== pb.month) return false;
  // Same month — likely overlap unless one is clearly a different week
  const rangeA = pa.nums.slice(0,2), rangeB = pb.nums.slice(0,2);
  if (rangeA.length < 2 || rangeB.length < 2) return true; // can't tell, flag it
  const [s1,e1] = rangeA, [s2,e2] = rangeB;
  return s1 <= e2 && s2 <= e1;
}

function UploadView({contractor,period,versions,dupAction,latest,onSubmit,toast_}) {
  // ── Queue: array of { id, file, pdfBytes, status:'idle'|'scanning'|'done'|'error', result, excluded }
  const [queue,      setQueue]     = useState([]);
  const [dragOver,   setDragOver]  = useState(false);
  const [submitting, setSubmitting]= useState(false);
  const [submitted,  setSubmitted] = useState(null); // version object after submit
  const [dupWarning, setDupWarning]= useState(false);
  const [expandedId, setExpandedId]= useState(null); // which queue item is expanded
  const [previewId,  setPreviewId] = useState(null); // which item shows PDF viewer

  const [intake, setIntake] = useState({
    source:"email", senderEmail:contractor.email||"",
    receivedDate:new Date().toISOString().slice(0,10), notes:"",
  });
  useEffect(()=>{ setIntake(i=>({...i,senderEmail:contractor.email||""})); },[contractor.id]);

  const fileRef = useRef();

  // ── Helpers ────────────────────────────────────────────────────────────────
  const updItem = (id, patch) =>
    setQueue(q=>q.map(item=>item.id===id ? {...item,...patch} : item));

  const activeQueue = queue.filter(item=>!item.excluded);
  const allDone     = activeQueue.length > 0 && activeQueue.every(i=>i.status==="done"||i.status==="error");
  const anyScanning = queue.some(i=>i.status==="scanning");

  // Conflict detection — run whenever results change
  const conflicts = [];
  activeQueue.forEach((a,i)=>{
    activeQueue.forEach((b,j)=>{
      if (j<=i) return;
      if (a.result && b.result && periodsOverlap(a.result.period, b.result.period)) {
        conflicts.push([a.id, b.id]);
      }
    });
  });
  const conflictIds = new Set(conflicts.flat());

  // Batch totals (only active, done items)
  const doneActive = activeQueue.filter(i=>i.status==="done" && i.result);
  const batchHours    = doneActive.reduce((s,i)=>s+(i.result.totalHours||0),0);
  const batchRegular  = doneActive.reduce((s,i)=>s+(i.result.regularHours||0),0);
  const batchOvertime = doneActive.reduce((s,i)=>s+(i.result.overtimeHours||0),0);
  const batchValue    = batchHours * contractor.rate;
  const batchWarnings = doneActive.flatMap(i=>i.result.warnings||[]);

  // ── Add files ──────────────────────────────────────────────────────────────
  const addFiles = (files) => {
    const pdfs = Array.from(files).filter(f=>f.type==="application/pdf");
    if (pdfs.length < files.length) toast_("Non-PDF files were skipped — PDF only","warn");
    if (!pdfs.length) return;

    pdfs.forEach((f, fi) => {
      const id = uid();
      // Read bytes for viewer
      const reader = new FileReader();
      reader.onload = e => {
        updItem(id, { pdfBytes: e.target.result });
      };
      reader.readAsArrayBuffer(f);

      const newItem = { id, file:f, pdfBytes:null, status:"scanning", result:null, excluded:false };
      setQueue(q=>[...q, newItem]);

      // Auto-scan immediately
      const queueIdx = queue.length + fi;
      scanSinglePDF(f, period, contractor, queueIdx).then(result=>{
        updItem(id, { status:"done", result });
      }).catch(()=>{
        updItem(id, { status:"error", result:null });
      });
    });
  };

  const drop = (e) => { e.preventDefault(); setDragOver(false); addFiles(e.dataTransfer.files); };

  // ── Submit batch ───────────────────────────────────────────────────────────
  const handleSubmit = async () => {
    if (dupAction?.warn && !dupWarning) { setDupWarning(true); return; }
    if (!dupAction?.allow) return;
    if (!allDone || doneActive.length===0) return;

    setSubmitting(true);
    await new Promise(r=>setTimeout(r,900));

    const fileNames = doneActive.map(i=>i.result.fileName).join(", ");
    const newVer = {
      versionId:"v"+uid(),
      version: versions.length+1,
      contractorId: contractor.id,
      m:period.m, y:period.y,
      uploadedAt: ts(),
      fileName: doneActive.length===1 ? doneActive[0].result.fileName : `Batch (${doneActive.length} files)`,
      fileSize: doneActive.map(i=>i.result.fileSize).join(" + "),
      format: doneActive.length===1 ? doneActive[0].result.format : `Mixed (${doneActive.length} documents)`,
      status:"SUBMITTED",
      hours: batchHours,
      isBatch: doneActive.length > 1,
      batchFileCount: doneActive.length,
      // Intake
      uploadedBy: CURRENT_ADMIN.name,
      uploadedByRole: CURRENT_ADMIN.role,
      intakeSource: intake.source,
      intakeSenderEmail: intake.senderEmail,
      intakeReceivedDate: intake.receivedDate,
      intakeNotes: intake.notes,
      // Sub-timesheets (individual PDFs)
      subTimesheets: doneActive.map((item,i)=>({
        idx: i+1,
        fileName: item.result.fileName,
        fileSize: item.result.fileSize,
        period: item.result.period,
        periodType: item.result.periodType||"unknown",
        totalHours: item.result.totalHours,
        regularHours: item.result.regularHours,
        overtimeHours: item.result.overtimeHours,
        format: item.result.format,
        confidence: item.result.confidence,
        warnings: item.result.warnings||[],
        weeks: item.result.weeks||[],
        dailyBreakdown: item.result.dailyBreakdown||[],
        notes: item.result.notes,
        detectedRate: item.result.detectedRate,
        detectedClient: item.result.detectedClientName,
      })),
      // Aggregated extracted data
      extractedData:{
        totalHours:    batchHours,
        regularHours:  batchRegular,
        overtimeHours: batchOvertime,
        period: doneActive.length===1
          ? doneActive[0].result.period
          : `${doneActive[0].result.period} … ${doneActive[doneActive.length-1].result.period}`,
        weeks: doneActive.flatMap(i=>i.result.weeks||[]),
        notes: doneActive.map(i=>i.result.notes).filter(Boolean).join("; ")||null,
        warnings: batchWarnings,
        confidence: Math.round(doneActive.reduce((s,i)=>s+(i.result.confidence||0),0)/doneActive.length),
        dailyBreakdown: doneActive.flatMap(i=>i.result.dailyBreakdown||[]),
        format: doneActive.length===1 ? doneActive[0].result.format : `Batch (${doneActive.length} documents)`,
        detectedRate: contractor.rate,
        detectedClient: contractor.client,
      },
      rejectionReason:null,rejectedAt:null,rejectedBy:null,
      approvedAt:null,approvedBy:null,restorable:false,
    };

    onSubmit(newVer);
    setSubmitting(false);
    setSubmitted(newVer);
    toast_(`✓ Batch of ${doneActive.length} file${doneActive.length>1?"s":""} submitted — v${newVer.version}`);
  };

  const resetAll = () => {
    setQueue([]); setSubmitted(null); setDupWarning(false);
    setExpandedId(null); setPreviewId(null);
  };

  // ── Submitted success ──────────────────────────────────────────────────────
  if (submitted) {
    return (
      <div className="card u" style={{padding:"44px 52px",maxWidth:560,margin:"0 auto"}}>
        <div style={{width:56,height:56,borderRadius:16,background:B.gP,border:`1px solid ${B.gB}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:28,margin:"0 auto 18px"}}>✓</div>
        <div style={{fontSize:20,fontWeight:700,color:B.text,marginBottom:4,textAlign:"center"}}>
          {submitted.isBatch ? `${submitted.batchFileCount} timesheets submitted` : "Timesheet submitted"}
        </div>
        <div style={{fontSize:13.5,color:B.dim,marginBottom:24,textAlign:"center"}}>
          Version {submitted.version} · {contractor.name} · {MONTHS[period.m]} {period.y}
        </div>

        {/* Per-file summary */}
        <div style={{marginBottom:18}}>
          {submitted.subTimesheets.map((s,i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${B.faint}`}}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:14}}>📄</span>
                <div>
                  <div style={{fontSize:13,fontWeight:500,color:B.text}}>{s.fileName}</div>
                  <div style={{fontSize:11.5,color:B.dim}}>{s.period}</div>
                </div>
              </div>
              <span className="mono" style={{fontSize:14,color:B.accent,fontWeight:600}}>{s.totalHours}h</span>
            </div>
          ))}
          <div style={{display:"flex",justifyContent:"space-between",padding:"10px 0 0"}}>
            <span style={{fontSize:13.5,fontWeight:700,color:B.text}}>Total</span>
            <span className="mono" style={{fontSize:16,fontWeight:700,color:B.accent}}>{submitted.hours}h · {fmt(submitted.hours*contractor.rate)}</span>
          </div>
        </div>

        <div style={{background:B.bg,borderRadius:9,padding:"12px 14px",marginBottom:20,display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:6}}>
          {[
            ["Received via", SOURCE_LABEL[intake.source]||intake.source],
            ["Uploaded by",  `${CURRENT_ADMIN.name}`],
            ["Date",         intake.receivedDate],
          ].map(([k,v])=>(
            <div key={k}>
              <div style={{fontSize:11,color:B.dim}}>{k}</div>
              <div style={{fontSize:12.5,fontWeight:600,color:B.text}}>{v}</div>
            </div>
          ))}
        </div>
        <button className="btn btn-ghost" style={{width:"100%"}} onClick={resetAll}>Upload another batch →</button>
      </div>
    );
  }

  // ── Empty state ────────────────────────────────────────────────────────────
  if (queue.length===0) {
    return (
      <div style={{maxWidth:640,margin:"0 auto"}}>
        {latest && <DupBanner latest={latest} dupAction={dupAction} versions={versions} period={period}/>}
        <IntakeForm intake={intake} setIntake={setIntake} contractor={contractor}/>
        <div style={{marginTop:16}}>
          <MultiDropZone dragOver={dragOver} setDragOver={setDragOver} drop={drop} fileRef={fileRef} addFiles={addFiles}/>
        </div>
      </div>
    );
  }

  // ── Queue view — files present ─────────────────────────────────────────────
  const previewItem = previewId ? queue.find(i=>i.id===previewId) : null;

  return (
    <div style={{display:"grid",gridTemplateColumns:"1fr 380px",gap:16,alignItems:"start"}}>

      {/* ── LEFT: queue + add-more ── */}
      <div style={{display:"flex",flexDirection:"column",gap:12}}>

        {/* Admin badge */}
        <div style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",background:B.surface,border:`1px solid ${B.border}`,borderRadius:10}}>
          <div style={{width:30,height:30,borderRadius:8,background:B.accent,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,flexShrink:0}}>{CURRENT_ADMIN.initials}</div>
          <div style={{flex:1,fontSize:13,color:B.dim}}>
            <strong style={{color:B.text}}>{CURRENT_ADMIN.name}</strong> · uploading on behalf of <strong style={{color:B.text}}>{contractor.name}</strong>
          </div>
        </div>

        {/* Duplicate banner */}
        {latest && <DupBanner latest={latest} dupAction={dupAction} versions={versions} period={period}/>}

        {/* Conflict warnings */}
        {conflicts.length>0 && conflicts.map(([aId,bId],ci)=>{
          const a = queue.find(i=>i.id===aId);
          const b = queue.find(i=>i.id===bId);
          if (!a||!b) return null;
          return (
            <div key={ci} style={{padding:"13px 16px",background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:10}}>
              <div style={{fontSize:13,fontWeight:700,color:B.amber,marginBottom:6}}>⚠ Overlapping periods detected</div>
              <div style={{fontSize:12.5,color:B.mid,marginBottom:10}}>
                <strong>{a.result?.period}</strong> and <strong>{b.result?.period}</strong> cover the same dates.
                These may be duplicates. Decide which to include.
              </div>
              <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
                <button className="btn btn-sm btn-ghost" onClick={()=>updItem(aId,{excluded:false})&&updItem(bId,{excluded:false})}>
                  Keep both
                </button>
                <button className="btn btn-sm" style={{background:B.rP,border:`1px solid ${B.rB}`,color:B.red}}
                  onClick={()=>updItem(aId,{excluded:true})}>
                  Remove {a.result?.fileName?.split("/").pop()?.slice(0,20)||"File 1"}
                </button>
                <button className="btn btn-sm" style={{background:B.rP,border:`1px solid ${B.rB}`,color:B.red}}
                  onClick={()=>updItem(bId,{excluded:true})}>
                  Remove {b.result?.fileName?.split("/").pop()?.slice(0,20)||"File 2"}
                </button>
              </div>
            </div>
          );
        })}

        {/* PDF viewer — shown when a file is previewed */}
        {previewItem && previewItem.pdfBytes && (
          <div className="fi">
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
              <span style={{fontSize:13,fontWeight:600,color:B.text}}>{previewItem.file.name}</span>
              <button className="btn btn-ghost btn-sm" onClick={()=>setPreviewId(null)}>Close preview</button>
            </div>
            <PDFViewer pdfBytes={previewItem.pdfBytes} fileName={previewItem.file.name} scanning={previewItem.status==="scanning"}/>
          </div>
        )}

        {/* File queue */}
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {queue.map((item, idx)=>(
            <FileQueueItem
              key={item.id}
              item={item}
              idx={idx}
              isConflict={conflictIds.has(item.id)}
              expanded={expandedId===item.id}
              previewing={previewId===item.id}
              onToggleExpand={()=>setExpandedId(expandedId===item.id ? null : item.id)}
              onPreview={()=>setPreviewId(previewId===item.id ? null : item.id)}
              onExclude={()=>updItem(item.id,{excluded:!item.excluded})}
              onRemove={()=>setQueue(q=>q.filter(i=>i.id!==item.id))}
            />
          ))}
        </div>

        {/* Add more files strip */}
        <AddMoreZone dragOver={dragOver} setDragOver={setDragOver} drop={drop} fileRef={fileRef} addFiles={addFiles}/>
      </div>

      {/* ── RIGHT: intake + batch summary ── */}
      <div style={{display:"flex",flexDirection:"column",gap:12,position:"sticky",top:24}}>
        <IntakeForm intake={intake} setIntake={setIntake} contractor={contractor} compact/>
        <BatchSummaryPanel
          doneActive={doneActive}
          allDone={allDone}
          anyScanning={anyScanning}
          batchHours={batchHours}
          batchRegular={batchRegular}
          batchOvertime={batchOvertime}
          batchValue={batchValue}
          batchWarnings={batchWarnings}
          contractor={contractor}
          period={period}
          versions={versions}
          dupAction={dupAction}
          dupWarning={dupWarning}
          submitting={submitting}
          conflictCount={conflicts.length}
          onSubmit={handleSubmit}
          onCancelDup={()=>setDupWarning(false)}
        />
      </div>
    </div>
  );
}

/* ─── File queue item ─────────────────────────────────────────────────────── */
function FileQueueItem({item,idx,isConflict,expanded,previewing,onToggleExpand,onPreview,onExclude,onRemove}) {
  const r = item.result;
  const confColor = !r ? B.dim : r.confidence>=90?B.green:r.confidence>=70?B.amber:B.red;

  const statusIcon = {
    scanning: <Spinner col={B.purple}/>,
    done:     <span style={{color:B.green,fontSize:14}}>✓</span>,
    error:    <span style={{color:B.red,fontSize:14}}>✗</span>,
    idle:     <span style={{color:B.dim,fontSize:14}}>○</span>,
  }[item.status];

  return (
    <div className="card fi" style={{
      overflow:"hidden",
      opacity: item.excluded ? 0.45 : 1,
      border:`1px solid ${isConflict && !item.excluded ? B.aLB : item.excluded ? B.border : item.status==="done"?B.gB:B.border}`,
      transition:"opacity .2s, border-color .2s",
    }}>
      {/* Row header */}
      <div style={{padding:"12px 14px",display:"flex",alignItems:"center",gap:10}}>
        {/* Index badge */}
        <div style={{
          width:26,height:26,borderRadius:7,flexShrink:0,fontSize:11,fontWeight:700,
          background:item.excluded?B.bg:item.status==="done"?B.gP:item.status==="scanning"?B.purP:B.bg,
          color:item.excluded?B.sub:item.status==="done"?B.green:item.status==="scanning"?B.purple:B.dim,
          border:`1px solid ${item.excluded?B.border:item.status==="done"?B.gB:item.status==="scanning"?B.purB:B.border}`,
          display:"flex",alignItems:"center",justifyContent:"center",
        }}>
          {item.status==="scanning" ? <Spinner col={B.purple}/> : item.excluded ? "–" : idx+1}
        </div>

        {/* File info */}
        <div style={{flex:1,minWidth:0}}>
          <div style={{
            fontSize:13,fontWeight:600,
            color:item.excluded?B.dim:item.status==="done"?B.text:B.mid,
            whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",
            textDecoration:item.excluded?"line-through":"none",
          }}>
            {item.file.name}
          </div>
          <div style={{fontSize:11.5,color:B.dim,marginTop:1}}>
            {(item.file.size/1024).toFixed(0)} KB
            {item.status==="scanning" && <span style={{color:B.purple,fontWeight:600}}> · Scanning…</span>}
            {r && <span> · <strong style={{color:confColor}}>{r.totalHours}h</strong> · {r.period}</span>}
            {item.status==="error" && <span style={{color:B.red}}> · Scan failed</span>}
          </div>
        </div>

        {/* Action buttons */}
        <div style={{display:"flex",gap:5,flexShrink:0,alignItems:"center"}}>
          {r && !item.excluded && (
            <button className="btn btn-sm btn-ghost" onClick={onPreview} title="Preview PDF">
              {previewing ? "Close" : "Preview"}
            </button>
          )}
          {r && !item.excluded && (
            <button className="btn btn-sm btn-ghost" onClick={onToggleExpand} title="Expand details">
              {expanded ? "▲" : "▼"}
            </button>
          )}
          <button
            className="btn btn-sm"
            onClick={onExclude}
            style={{
              background:item.excluded?B.gP:B.aLP,
              border:`1px solid ${item.excluded?B.gB:B.aLB}`,
              color:item.excluded?B.green:B.amber,
            }}
            title={item.excluded?"Re-include in batch":"Exclude from batch"}
          >
            {item.excluded ? "Include" : "Exclude"}
          </button>
          <button className="btn btn-sm" style={{background:B.rP,border:`1px solid ${B.rB}`,color:B.red}} onClick={onRemove} title="Remove">✕</button>
        </div>
      </div>

      {/* Scan progress bar */}
      {item.status==="scanning" && (
        <div style={{height:2,background:B.purB,overflow:"hidden"}}>
          <div className="skel" style={{height:"100%",width:"100%"}}/>
        </div>
      )}

      {/* Warnings strip */}
      {r && !item.excluded && r.warnings?.length>0 && !expanded && (
        <div style={{padding:"6px 14px 8px",background:B.aLP,borderTop:`1px solid ${B.aLB}`}}>
          {r.warnings.map((w,i)=><div key={i} style={{fontSize:11.5,color:B.amber}}>⚠ {w}</div>)}
        </div>
      )}

      {/* Conflict badge */}
      {isConflict && !item.excluded && (
        <div style={{padding:"6px 14px",background:B.aLP,borderTop:`1px solid ${B.aLB}`,fontSize:11.5,color:B.amber,fontWeight:600}}>
          ⚠ Overlapping period — see conflict warning above
        </div>
      )}

      {/* Expanded detail */}
      {expanded && r && !item.excluded && (
        <div className="fi" style={{padding:"14px",borderTop:`1px solid ${B.faint}`,background:B.bg}}>
          {/* Key metrics */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:12}}>
            {[
              ["Total",    `${r.totalHours}h`,    B.accent],
              ["Regular",  `${r.regularHours}h`,  B.green],
              ["Overtime", `${r.overtimeHours}h`, r.overtimeHours>8?B.red:B.amber],
            ].map(([k,v,c])=>(
              <div key={k} style={{padding:"10px",borderRadius:8,background:B.surface,border:`1px solid ${B.border}`,textAlign:"center"}}>
                <div className="mono" style={{fontSize:17,color:c,marginBottom:2}}>{v}</div>
                <div style={{fontSize:11,color:B.dim}}>{k}</div>
              </div>
            ))}
          </div>
          {/* Period + format + confidence */}
          {[["Period",r.period],["Format",r.format],[`Confidence`,`${r.confidence}%`],r.notes?["Notes",r.notes]:null].filter(Boolean).map(([k,v])=>(
            <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:`1px solid ${B.faint}`}}>
              <span style={{fontSize:12.5,color:B.dim}}>{k}</span>
              <span style={{fontSize:12.5,color:B.text,fontWeight:500,maxWidth:240,textAlign:"right"}}>{v}</span>
            </div>
          ))}
          {/* Weekly breakdown bars */}
          {r.weeks?.length>0 && (
            <div style={{marginTop:10}}>
              <div className="lbl" style={{marginBottom:6}}>Weekly breakdown</div>
              {r.weeks.map((w,i)=>{
                const pct=w.h/Math.max(...r.weeks.map(x=>x.h));
                return (
                  <div key={i} style={{marginBottom:6}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:2}}>
                      <span style={{fontSize:12,color:B.mid}}>{w.wk}</span>
                      <span className="mono" style={{fontSize:12,color:w.h>44?B.red:w.h>40?B.amber:B.green}}>{w.h}h</span>
                    </div>
                    <div style={{height:5,borderRadius:2,background:B.border,overflow:"hidden"}}>
                      <div style={{height:"100%",width:`${pct*100}%`,background:w.h>44?B.red:w.h>40?B.amber:B.accent,borderRadius:2}}/>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          {/* Warnings detail */}
          {r.warnings?.length>0 && (
            <div style={{marginTop:10,padding:"10px 12px",background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:8}}>
              {r.warnings.map((w,i)=><div key={i} style={{fontSize:12.5,color:B.amber,marginBottom:i<r.warnings.length-1?5:0}}>⚠ {w}</div>)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ─── Batch summary right panel ───────────────────────────────────────────── */
function BatchSummaryPanel({doneActive,allDone,anyScanning,batchHours,batchRegular,batchOvertime,batchValue,batchWarnings,contractor,period,versions,dupAction,dupWarning,submitting,conflictCount,onSubmit,onCancelDup}) {

  const canSubmit = allDone && doneActive.length>0 && (dupAction?.allow!==false) && conflictCount===0;
  const confAvg = doneActive.length>0
    ? Math.round(doneActive.reduce((s,i)=>s+(i.result?.confidence||0),0)/doneActive.length)
    : 0;

  return (
    <div className="card" style={{overflow:"hidden"}}>
      {/* Header */}
      <div style={{padding:"14px 16px",borderBottom:`1px solid ${B.faint}`,background:B.bg}}>
        <div style={{fontSize:13,fontWeight:700,color:B.text}}>Batch Summary</div>
        <div style={{fontSize:11.5,color:B.dim,marginTop:1}}>
          {doneActive.length} of {doneActive.length + (anyScanning?1:0)} file{doneActive.length!==1?"s":""} ready · {MONTHS[period.m]} {period.y}
        </div>
      </div>

      <div style={{padding:"16px"}}>
        {/* Scanning state */}
        {anyScanning && (
          <div style={{display:"flex",alignItems:"center",gap:8,padding:"10px 12px",background:B.purP,border:`1px solid ${B.purB}`,borderRadius:8,marginBottom:12}}>
            <Spinner col={B.purple}/>
            <span style={{fontSize:13,color:B.purple}}>Scanning files…</span>
          </div>
        )}

        {/* Per-file rows */}
        {doneActive.length>0 && (
          <div style={{marginBottom:14}}>
            <div className="lbl" style={{marginBottom:8}}>Files in batch</div>
            {doneActive.map((item,i)=>(
              <div key={item.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"7px 0",borderBottom:`1px solid ${B.faint}`}}>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:12.5,color:B.text,fontWeight:500,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",maxWidth:160}}>{item.result.fileName}</div>
                  <div style={{fontSize:11,color:B.dim}}>{item.result.period}</div>
                </div>
                <span className="mono" style={{fontSize:13,color:B.accent,fontWeight:600,flexShrink:0}}>{item.result.totalHours}h</span>
              </div>
            ))}
          </div>
        )}

        {/* Totals */}
        {doneActive.length>0 && (
          <>
            <div style={{padding:"12px",background:B.bg,borderRadius:8,marginBottom:12}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                <span style={{fontSize:12.5,color:B.dim}}>Regular hours</span>
                <span className="mono" style={{fontSize:13,color:B.green}}>{batchRegular}h</span>
              </div>
              {batchOvertime>0&&<div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                <span style={{fontSize:12.5,color:B.dim}}>Overtime hours</span>
                <span className="mono" style={{fontSize:13,color:batchOvertime>20?B.red:B.amber}}>{batchOvertime}h</span>
              </div>}
              <div style={{display:"flex",justifyContent:"space-between",paddingTop:6,borderTop:`1px solid ${B.border}`}}>
                <span style={{fontSize:13,fontWeight:700,color:B.text}}>Total hours</span>
                <span className="mono" style={{fontSize:15,fontWeight:700,color:B.text}}>{batchHours}h</span>
              </div>
            </div>

            {/* Invoice value */}
            <div style={{padding:"12px 14px",background:B.aP,border:`1px solid ${B.aBd}`,borderRadius:8,marginBottom:12,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{fontSize:11,color:B.dim,marginBottom:2}}>Estimated invoice value</div>
                <div className="mono" style={{fontSize:20,color:B.accent,fontWeight:500}}>{fmt(batchValue)}</div>
              </div>
              <div style={{fontSize:11.5,color:B.dim,textAlign:"right"}}>
                {batchHours}h × ${contractor.rate}/hr
              </div>
            </div>

            {/* Avg confidence */}
            <div style={{marginBottom:12}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                <span style={{fontSize:12,color:B.dim}}>Avg scan confidence</span>
                <span className="mono" style={{fontSize:12,color:confAvg>=90?B.green:confAvg>=70?B.amber:B.red}}>{confAvg}%</span>
              </div>
              <div style={{height:4,borderRadius:2,background:B.border,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${confAvg}%`,background:confAvg>=90?B.green:confAvg>=70?B.amber:B.red,borderRadius:2,transition:"width .4s"}}/>
              </div>
            </div>

            {/* Warnings */}
            {batchWarnings.length>0 && (
              <div style={{padding:"10px 12px",background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:8,marginBottom:12}}>
                {batchWarnings.map((w,i)=><div key={i} style={{fontSize:12.5,color:B.amber,marginBottom:i<batchWarnings.length-1?4:0}}>⚠ {w}</div>)}
              </div>
            )}

            {/* Conflict blocker */}
            {conflictCount>0 && (
              <div style={{padding:"10px 12px",background:B.rP,border:`1px solid ${B.rB}`,borderRadius:8,marginBottom:12,fontSize:12.5,color:B.red}}>
                🚫 Resolve {conflictCount} overlapping period conflict{conflictCount>1?"s":""} before submitting.
              </div>
            )}
          </>
        )}

        {/* Dup warn dialog */}
        {dupWarning && (
          <div style={{padding:"12px 14px",background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:9,marginBottom:12}}>
            <div style={{fontSize:13,fontWeight:700,color:B.amber,marginBottom:6}}>⚠ Replace existing submission?</div>
            <div style={{fontSize:12.5,color:B.mid,marginBottom:10}}>A timesheet for this period is already awaiting review. Uploading will restart the review process.</div>
            <div style={{display:"flex",gap:7}}>
              <button className="btn btn-sm" style={{background:B.amber,color:"#fff",border:"none"}} onClick={onSubmit}>Yes, replace</button>
              <button className="btn btn-sm btn-ghost" onClick={onCancelDup}>Cancel</button>
            </div>
          </div>
        )}

        {/* Locked */}
        {dupAction?.allow===false && (
          <div style={{padding:"10px 12px",background:B.rP,border:`1px solid ${B.rB}`,borderRadius:8,marginBottom:12,fontSize:12.5,color:B.red}}>
            🔒 Period locked — contact an admin to unlock before resubmitting.
          </div>
        )}

        {/* Submit */}
        <button
          className="btn btn-accent"
          style={{width:"100%",padding:"13px",fontSize:14,opacity:canSubmit?1:0.45}}
          onClick={onSubmit}
          disabled={!canSubmit||submitting}
        >
          {submitting ? <><Spinner/> Submitting…</>
           : anyScanning ? "Scanning…"
           : doneActive.length===0 ? "Add files to submit"
           : conflictCount>0 ? "Resolve conflicts first"
           : dupAction?.allow===false ? "Period locked"
           : `Submit ${doneActive.length} file${doneActive.length!==1?"s":""} →`}
        </button>

        {!allDone && doneActive.length>0 && !anyScanning && (
          <div style={{marginTop:8,fontSize:11.5,color:B.dim,textAlign:"center"}}>
            Some files are still processing
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Multi-file drop zone (empty state) ─────────────────────────────────── */
function MultiDropZone({dragOver,setDragOver,drop,fileRef,addFiles}) {
  return (
    <div
      onDragOver={e=>{e.preventDefault();setDragOver(true)}}
      onDragLeave={()=>setDragOver(false)}
      onDrop={drop}
      onClick={()=>fileRef.current.click()}
      style={{
        border:`2px dashed ${dragOver?B.accent:B.border}`,
        borderRadius:14,padding:"52px 32px",textAlign:"center",
        background:dragOver?B.aP:B.surface,cursor:"pointer",transition:"all .18s",
      }}
    >
      <input ref={fileRef} type="file" accept=".pdf" multiple style={{display:"none"}} onChange={e=>addFiles(e.target.files)}/>
      <div style={{fontSize:44,marginBottom:14}}>📄📄</div>
      <div style={{fontSize:16,fontWeight:600,color:B.text,marginBottom:6}}>Drop one or more PDF timesheets</div>
      <div style={{fontSize:13.5,color:B.dim,marginBottom:18}}>Weekly · fortnightly · monthly — mix freely · or click to browse</div>
      <div style={{display:"flex",justifyContent:"center",gap:8,flexWrap:"wrap"}}>
        {["Weekly sheets","Monthly summary","Fortnightly","Custom template","Scanned docs"].map(f=>(
          <span key={f} style={{fontSize:11,padding:"3px 10px",borderRadius:5,background:B.bg,border:`1px solid ${B.border}`,color:B.dim}}>{f}</span>
        ))}
      </div>
    </div>
  );
}

/* ─── Add-more strip (compact, shown when queue has files) ───────────────── */
function AddMoreZone({dragOver,setDragOver,drop,fileRef,addFiles}) {
  return (
    <div
      onDragOver={e=>{e.preventDefault();setDragOver(true)}}
      onDragLeave={()=>setDragOver(false)}
      onDrop={drop}
      onClick={()=>fileRef.current.click()}
      style={{
        border:`1.5px dashed ${dragOver?B.accent:B.border}`,
        borderRadius:10,padding:"14px 20px",
        display:"flex",alignItems:"center",gap:12,
        background:dragOver?B.aP:B.surface,cursor:"pointer",transition:"all .15s",
      }}
      onMouseEnter={e=>e.currentTarget.style.borderColor=B.accent}
      onMouseLeave={e=>{ if(!dragOver) e.currentTarget.style.borderColor=B.border; }}
    >
      <input ref={fileRef} type="file" accept=".pdf" multiple style={{display:"none"}} onChange={e=>addFiles(e.target.files)}/>
      <span style={{fontSize:22}}>＋</span>
      <div>
        <div style={{fontSize:13,fontWeight:600,color:B.mid}}>Add more PDFs to this batch</div>
        <div style={{fontSize:11.5,color:B.sub}}>Drop here or click to browse — any format accepted</div>
      </div>
    </div>
  );
}

/* ─── Intake Form — how did this timesheet arrive? ───────────────────────── */
const SOURCE_OPTIONS = [
  { id:"email",    icon:"✉️",  label:"Email"    },
  { id:"walk-in",  icon:"🚶",  label:"Walk-in"  },
  { id:"post",     icon:"📮",  label:"Post/Fax" },
  { id:"other",    icon:"📎",  label:"Other"    },
];

function IntakeForm({intake, setIntake, contractor, compact=false}) {
  const [open, setOpen] = useState(!compact);
  const upd = (k,v) => setIntake(i=>({...i,[k]:v}));
  const sourceLabel = SOURCE_OPTIONS.find(s=>s.id===intake.source)?.label || intake.source;

  if (compact && !open) {
    return (
      <div
        onClick={()=>setOpen(true)}
        style={{padding:"11px 14px",background:B.surface,border:`1px solid ${B.border}`,borderRadius:10,cursor:"pointer",display:"flex",alignItems:"center",gap:10,transition:"border-color .13s"}}
        onMouseEnter={e=>e.currentTarget.style.borderColor=B.accent}
        onMouseLeave={e=>e.currentTarget.style.borderColor=B.border}
      >
        <span style={{fontSize:16}}>{SOURCE_OPTIONS.find(s=>s.id===intake.source)?.icon}</span>
        <div style={{flex:1}}>
          <div style={{fontSize:12,color:B.dim}}>Received via</div>
          <div style={{fontSize:13,fontWeight:600,color:B.text}}>
            {sourceLabel}{intake.senderEmail ? ` · ${intake.senderEmail}` : ""}
            {intake.receivedDate ? ` · ${intake.receivedDate}` : ""}
          </div>
        </div>
        <span style={{fontSize:11.5,color:B.accent,fontWeight:600}}>Edit</span>
      </div>
    );
  }

  return (
    <div className="card" style={{overflow:"hidden"}}>
      {/* Header */}
      <div style={{padding:"13px 16px",borderBottom:`1px solid ${B.faint}`,background:B.bg,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div>
          <div style={{fontSize:13,fontWeight:700,color:B.text}}>Intake Details</div>
          <div style={{fontSize:11.5,color:B.dim,marginTop:1}}>
            Uploading on behalf of <strong>{contractor.name}</strong> · logged against {CURRENT_ADMIN.name}
          </div>
        </div>
        {compact && <button className="btn btn-ghost btn-sm" onClick={()=>setOpen(false)}>Done</button>}
      </div>

      <div style={{padding:"16px"}}>
        {/* Source selector */}
        <div style={{marginBottom:14}}>
          <div className="lbl" style={{marginBottom:8}}>How was it received?</div>
          <div style={{display:"flex",gap:7}}>
            {SOURCE_OPTIONS.map(s=>(
              <button
                key={s.id}
                onClick={()=>upd("source",s.id)}
                style={{
                  flex:1, padding:"9px 6px", borderRadius:9, cursor:"pointer",
                  fontFamily:"'DM Sans',sans-serif", fontSize:12.5, fontWeight:600,
                  border:`1.5px solid ${intake.source===s.id?B.accent:B.border}`,
                  background:intake.source===s.id?B.aP:B.surface,
                  color:intake.source===s.id?B.accent:B.dim,
                  display:"flex", flexDirection:"column", alignItems:"center", gap:4,
                  transition:"all .13s",
                }}
              >
                <span style={{fontSize:18}}>{s.icon}</span>
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Sender email */}
        <div style={{marginBottom:12}}>
          <div className="lbl" style={{marginBottom:6}}>
            {intake.source==="email" ? "Sender email address" : intake.source==="walk-in" ? "Contractor confirmed in person" : intake.source==="post" ? "Sender address / reference" : "Notes on source"}
          </div>
          <input
            value={intake.senderEmail}
            onChange={e=>upd("senderEmail",e.target.value)}
            placeholder={intake.source==="email" ? contractor.email || "contractor@email.com" : "optional"}
            style={{
              width:"100%", padding:"9px 12px", fontFamily:"'DM Sans',sans-serif",
              fontSize:13, border:`1.5px solid ${B.border}`, borderRadius:8,
              color:B.text, outline:"none", background:B.surface,
            }}
            onFocus={e=>e.target.style.borderColor=B.accent}
            onBlur={e=>e.target.style.borderColor=B.border}
          />
        </div>

        {/* Received date */}
        <div style={{marginBottom:12}}>
          <div className="lbl" style={{marginBottom:6}}>Date received</div>
          <input
            type="date"
            value={intake.receivedDate}
            onChange={e=>upd("receivedDate",e.target.value)}
            style={{
              width:"100%", padding:"9px 12px", fontFamily:"'DM Sans',sans-serif",
              fontSize:13, border:`1.5px solid ${B.border}`, borderRadius:8,
              color:B.text, outline:"none", background:B.surface,
            }}
            onFocus={e=>e.target.style.borderColor=B.accent}
            onBlur={e=>e.target.style.borderColor=B.border}
          />
        </div>

        {/* Internal notes */}
        <div>
          <div className="lbl" style={{marginBottom:6}}>Internal notes <span style={{fontWeight:400,textTransform:"none",letterSpacing:0}}>(optional)</span></div>
          <textarea
            value={intake.notes}
            onChange={e=>upd("notes",e.target.value)}
            placeholder="e.g. Contractor called to confirm hours, original PDF had smudged signature…"
            rows={2}
            style={{
              width:"100%", padding:"9px 12px", fontFamily:"'DM Sans',sans-serif",
              fontSize:13, border:`1.5px solid ${B.border}`, borderRadius:8,
              color:B.text, outline:"none", background:B.surface,
              resize:"vertical", lineHeight:1.5,
            }}
            onFocus={e=>e.target.style.borderColor=B.accent}
            onBlur={e=>e.target.style.borderColor=B.border}
          />
        </div>
      </div>
    </div>
  );
}

/* ─── Extracted sub-components for cleaner UploadView ───────────────────── */

function DupBanner({latest,dupAction,versions,period}) {
  return (
    <div style={{marginBottom:4,padding:"12px 15px",borderRadius:10,
      background: dupAction?.allow===false ? B.rP : dupAction?.warn ? B.aLP : B.gP,
      border:`1px solid ${dupAction?.allow===false ? B.rB : dupAction?.warn ? B.aLB : B.gB}`}}>
      <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
        <span>{dupAction?.allow===false?"🔒":dupAction?.warn?"⚠":"ℹ"}</span>
        <span style={{fontSize:13.5,fontWeight:600,color:dupAction?.allow===false?B.red:dupAction?.warn?B.amber:B.green}}>
          {dupAction?.allow===false ? "Period locked" : dupAction?.warn ? "Duplicate detected" : `Version ${latest.version} already submitted`}
        </span>
        <span style={{marginLeft:"auto"}}><Pill status={latest.status}/></span>
      </div>
      <p style={{fontSize:12.5,color:B.mid,lineHeight:1.55,marginLeft:22}}>
        {dupAction?.msg?.replace("{n}",versions.length+1) || `${MONTHS[period.m]} ${period.y} has ${versions.length} version${versions.length>1?"s":""}.`}
      </p>
    </div>
  );
}

function DropZone({dragOver,setDragOver,drop,fileRef,file,handleFile,reset}) {
  return (
    <div
      onDragOver={e=>{e.preventDefault();setDragOver(true)}}
      onDragLeave={()=>setDragOver(false)}
      onDrop={drop}
      onClick={()=>fileRef.current.click()}
      style={{
        border:`2px dashed ${dragOver?B.accent:B.border}`,
        borderRadius:14, padding:"52px 32px", textAlign:"center",
        background:dragOver?B.aP:B.surface,
        cursor:"pointer", transition:"all .18s",
      }}
    >
      <input ref={fileRef} type="file" accept=".pdf" style={{display:"none"}} onChange={e=>handleFile(e.target.files[0])}/>
      <div style={{fontSize:42,marginBottom:14}}>📄</div>
      <div style={{fontSize:16,fontWeight:600,color:B.text,marginBottom:6}}>Drop PDF timesheet here</div>
      <div style={{fontSize:13.5,color:B.dim,marginBottom:18}}>or click to browse · PDF only</div>
      <div style={{display:"flex",justifyContent:"center",gap:8,flexWrap:"wrap"}}>
        {["Standard weekly grid","Scanned document","Custom template","Landscape format"].map(f=>(
          <span key={f} style={{fontSize:11,padding:"3px 9px",borderRadius:5,background:B.bg,border:`1px solid ${B.border}`,color:B.dim}}>{f}</span>
        ))}
      </div>
    </div>
  );
}

/* ─── PDF Viewer — canvas-based via PDF.js (ArrayBuffer, no blob URL) ────── */
function PDFViewer({pdfBytes, fileName, scanning}) {
  const [pages,    setPages]    = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState(null);
  const [numPages, setNumPages] = useState(0);
  const [page,     setPage]     = useState(1);

  const loadPdfJs = () => new Promise((resolve, reject) => {
    if (window.pdfjsLib) { resolve(window.pdfjsLib); return; }
    const script = document.createElement("script");
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js";
    script.onload = () => {
      window.pdfjsLib.GlobalWorkerOptions.workerSrc =
        "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
      resolve(window.pdfjsLib);
    };
    script.onerror = () => reject(new Error("Failed to load PDF.js"));
    document.head.appendChild(script);
  });

  useEffect(() => {
    if (!pdfBytes) return;
    let cancelled = false;
    setLoading(true); setError(null); setPages([]); setPage(1);

    (async () => {
      try {
        const pdfjsLib = await loadPdfJs();
        // Pass a copy of the ArrayBuffer — PDF.js takes ownership and detaches it
        const pdf = await pdfjsLib.getDocument({ data: pdfBytes.slice(0) }).promise;
        if (cancelled) return;
        setNumPages(pdf.numPages);

        for (let i = 1; i <= pdf.numPages; i++) {
          if (cancelled) break;
          const pg     = await pdf.getPage(i);
          const vp     = pg.getViewport({ scale: 1.6 });
          const canvas = document.createElement("canvas");
          canvas.width  = vp.width;
          canvas.height = vp.height;
          await pg.render({ canvasContext: canvas.getContext("2d"), viewport: vp }).promise;
          // Stream pages in as they render
          if (!cancelled) setPages(prev => [...prev, canvas.toDataURL("image/png")]);
        }
      } catch(e) {
        if (!cancelled) setError(e.message || "Failed to render PDF");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, [pdfBytes]);

  const currentPage = pages[page - 1];

  return (
    <div className="card fi" style={{overflow:"hidden",display:"flex",flexDirection:"column",position:"sticky",top:24}}>
      <style>{`@keyframes scanBeam{0%{transform:translateY(-100%)}100%{transform:translateY(800px)}}`}</style>

      {/* Header */}
      <div style={{padding:"13px 16px",borderBottom:`1px solid ${B.faint}`,display:"flex",alignItems:"center",gap:10,background:B.bg,flexShrink:0}}>
        <span style={{fontSize:16}}>📄</span>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:13,fontWeight:600,color:B.text,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{fileName}</div>
          <div style={{fontSize:11,marginTop:1,color:loading?B.dim:error?B.red:B.green}}>
            {loading ? "Rendering pages…" : error ? "Preview error" : `✓ ${numPages} page${numPages!==1?"s":""} loaded`}
          </div>
        </div>
        {scanning && (
          <div style={{display:"flex",alignItems:"center",gap:6,padding:"4px 10px",borderRadius:6,background:B.purP,border:`1px solid ${B.purB}`}}>
            <Spinner col={B.purple}/>
            <span style={{fontSize:11,fontWeight:600,color:B.purple}}>AI reading</span>
          </div>
        )}
      </div>

      {/* Page viewer */}
      <div style={{overflowY:"auto",height:660,background:"#525659",position:"relative"}}>

        {/* Scan beam overlay */}
        {scanning && pages.length > 0 && (
          <div style={{position:"absolute",inset:0,zIndex:3,pointerEvents:"none",overflow:"hidden"}}>
            <div style={{
              position:"absolute",left:0,right:0,height:3,
              background:"linear-gradient(90deg,transparent,rgba(124,58,237,.7),transparent)",
              animation:"scanBeam 1.6s ease-in-out infinite",
              boxShadow:"0 0 12px rgba(124,58,237,.5)",
            }}/>
          </div>
        )}

        {loading && (
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:12}}>
            <Spinner col="#fff"/>
            <span style={{color:"rgba(255,255,255,.6)",fontSize:13}}>Rendering PDF…</span>
          </div>
        )}

        {error && (
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:10,padding:24,textAlign:"center"}}>
            <span style={{fontSize:32}}>⚠</span>
            <div style={{color:"rgba(255,255,255,.8)",fontSize:14,fontWeight:600}}>Could not render PDF</div>
            <div style={{color:"rgba(255,255,255,.5)",fontSize:12,lineHeight:1.6}}>{error}</div>
            <div style={{color:"rgba(255,255,255,.4)",fontSize:11,marginTop:4}}>AI scan is still reading the file separately</div>
          </div>
        )}

        {currentPage && (
          <div style={{padding:"12px",display:"flex",justifyContent:"center"}}>
            <img
              src={currentPage}
              alt={`Page ${page}`}
              style={{
                maxWidth:"100%",display:"block",
                borderRadius:4,
                boxShadow:"0 2px 12px rgba(0,0,0,.4)",
                opacity: scanning ? 0.75 : 1,
                transition:"opacity .3s",
              }}
            />
          </div>
        )}
      </div>

      {/* Page navigation footer */}
      <div style={{padding:"10px 16px",borderTop:`1px solid ${B.faint}`,background:B.bg,display:"flex",justifyContent:"space-between",alignItems:"center",flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <button
            onClick={()=>setPage(p=>Math.max(1,p-1))}
            disabled={page<=1||loading}
            style={{background:"none",border:`1px solid ${B.border}`,borderRadius:6,padding:"4px 10px",cursor:"pointer",fontSize:13,color:B.dim,fontFamily:"'DM Sans',sans-serif",opacity:page<=1?0.3:1}}
          >‹</button>
          <span style={{fontSize:12.5,color:B.dim}}>
            {loading ? "—" : `Page ${page} of ${numPages}`}
          </span>
          <button
            onClick={()=>setPage(p=>Math.min(numPages,p+1))}
            disabled={page>=numPages||loading}
            style={{background:"none",border:`1px solid ${B.border}`,borderRadius:6,padding:"4px 10px",cursor:"pointer",fontSize:13,color:B.dim,fontFamily:"'DM Sans',sans-serif",opacity:page>=numPages?0.3:1}}
          >›</button>
        </div>
        <span style={{fontSize:11.5,color:B.sub}}>Rendered via PDF.js · no server upload</span>
      </div>
    </div>
  );
}

/* ─── Scan preview panel ─────────────────────────────────────────────────── */
function ScanPreview({result,contractor,period,versions,latest,dupAction,confirmed,dupWarning,submitting,onConfirm,onCancelDup,onSubmit,versionNum}) {
  const [tab,setTab] = useState("summary");
  const confColor = result.confidence>=90?B.green:result.confidence>=70?B.amber:B.red;

  return (
    <div className="card fi" style={{overflow:"hidden"}}>
      {/* Top bar */}
      <div style={{padding:"16px 18px",borderBottom:`1px solid ${B.faint}`,background:B.gP}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
          <div>
            <div style={{fontSize:10,fontWeight:700,textTransform:"uppercase",letterSpacing:".07em",color:B.green,marginBottom:3}}>AI Scan Complete</div>
            <div style={{fontSize:13.5,fontWeight:600,color:B.text,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",maxWidth:200}}>{result.fileName}</div>
            <div style={{fontSize:11,color:B.dim,marginTop:1}}>{result.format} · {result.scannedAt}</div>
          </div>
          <div style={{textAlign:"right",flexShrink:0}}>
            <div style={{fontSize:10,color:B.dim,marginBottom:2}}>Confidence</div>
            <div className="mono" style={{fontSize:20,fontWeight:500,color:confColor}}>{result.confidence}%</div>
          </div>
        </div>
        <div style={{height:3,borderRadius:2,background:B.gB,overflow:"hidden"}}>
          <div style={{height:"100%",width:`${result.confidence}%`,background:confColor,borderRadius:2,transition:"width .6s ease"}}/>
        </div>
      </div>

      {/* Warnings */}
      {result.warnings?.length>0 && (
        <div style={{padding:"10px 16px",background:B.aLP,borderBottom:`1px solid ${B.aLB}`}}>
          {result.warnings.map((w,i)=>(
            <div key={i} style={{display:"flex",gap:7,fontSize:12.5,color:B.amber,marginBottom:i<result.warnings.length-1?5:0}}>
              <span style={{flexShrink:0}}>⚠</span><span>{w}</span>
            </div>
          ))}
        </div>
      )}
      {result.missingFields?.length>0 && (
        <div style={{padding:"10px 16px",background:B.rP,borderBottom:`1px solid ${B.rB}`,fontSize:12.5,color:B.red,display:"flex",gap:7}}>
          <span style={{flexShrink:0}}>⚠</span>
          <span>Missing: <strong>{result.missingFields.join(", ")}</strong></span>
        </div>
      )}

      {/* Tabs */}
      <div style={{display:"flex",borderBottom:`1px solid ${B.border}`,overflowX:"auto"}}>
        {[["summary","Summary"],["weekly","Weekly"],["daily","Daily"],["diff",`vs v${latest?.version||"—"}`]].map(([id,label])=>(
          <button key={id} className={`tab ${tab===id?"on":""}`} onClick={()=>setTab(id)} style={{fontSize:12.5,padding:"8px 12px"}}>{label}</button>
        ))}
      </div>

      <div style={{padding:"16px 18px",maxHeight:380,overflowY:"auto"}}>
        {/* Summary tab */}
        {tab==="summary" && (
          <ScanSummaryTab result={result} contractor={contractor}/>
        )}

        {/* Weekly tab */}
        {tab==="weekly" && (
          <div>{result.weeks?.map((w,i)=>{
            const pct=w.h/Math.max(...result.weeks.map(x=>x.h));
            return(
              <div key={i} style={{marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <span style={{fontSize:13,color:B.text}}>{w.wk}</span>
                  <span className="mono" style={{fontSize:13,color:w.h>44?B.red:w.h>40?B.amber:B.green}}>{w.h}h</span>
                </div>
                <div style={{height:6,borderRadius:3,background:B.bg,overflow:"hidden"}}>
                  <div style={{height:"100%",width:`${pct*100}%`,background:w.h>44?B.red:w.h>40?B.amber:B.accent,borderRadius:3}}/>
                </div>
              </div>
            );
          })}
          <div style={{marginTop:12,padding:"10px 13px",background:B.bg,borderRadius:8,display:"flex",justifyContent:"space-between"}}>
            <span className="lbl">Total</span>
            <span className="mono" style={{fontSize:14,fontWeight:500,color:B.text}}>{result.totalHours}h</span>
          </div></div>
        )}

        {/* Daily tab */}
        {tab==="daily" && (
          <div>{result.dailyBreakdown?.length>0 ? result.dailyBreakdown.map((d,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:i<result.dailyBreakdown.length-1?`1px solid ${B.faint}`:"none"}}>
              <span className="mono" style={{fontSize:12,color:B.dim,width:44,flexShrink:0}}>{d.date}</span>
              <div style={{flex:1,height:5,borderRadius:3,background:B.bg,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${(d.hours/12)*100}%`,background:d.hours>10?B.red:d.hours>8?B.amber:B.accent,borderRadius:3}}/>
              </div>
              <span className="mono" style={{fontSize:12.5,color:d.hours>10?B.red:B.text,width:26,textAlign:"right"}}>{d.hours}h</span>
            </div>
          )) : <div style={{textAlign:"center",padding:"24px",color:B.dim,fontSize:13}}>Daily breakdown not available for this format.</div>}</div>
        )}

        {/* Diff tab */}
        {tab==="diff" && (
          <DiffTab current={result} latest={latest} contractor={contractor}/>
        )}
      </div>

      {/* ── Action footer ── */}
      <div style={{padding:"14px 18px",borderTop:`1px solid ${B.faint}`,background:B.bg,display:"flex",flexDirection:"column",gap:10}}>

        {/* Status line */}
        <div style={{fontSize:12.5,color:result.confidence<70?B.amber:result.warnings?.length>0?B.amber:B.green}}>
          {result.confidence<70 ? "⚠ Low confidence — verify manually"
           : result.warnings?.length>0 ? `⚠ ${result.warnings.length} warning${result.warnings.length>1?"s":""} — review above`
           : "✓ Data looks correct — ready to submit"}
        </div>

        {/* Dup confirm */}
        {dupWarning ? (
          <div style={{background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:9,padding:"13px 14px"}}>
            <div style={{fontSize:13,fontWeight:600,color:B.amber,marginBottom:6}}>⚠ Confirm replacement</div>
            <p style={{fontSize:12.5,color:B.mid,lineHeight:1.6,marginBottom:12}}>
              v{latest.version} ({SM[latest.status]?.label}) will be superseded. This becomes v{versionNum}.
            </p>
            <div style={{display:"flex",gap:8}}>
              <button className="btn btn-accent" style={{flex:1,padding:"9px"}} onClick={onSubmit} disabled={submitting}>
                {submitting?<><Spinner/> Submitting…</>:"Confirm →"}
              </button>
              <button className="btn btn-ghost btn-sm" onClick={onCancelDup}>Cancel</button>
            </div>
          </div>
        ) : dupAction?.allow!==false ? (
          <button className="btn btn-accent" style={{width:"100%",padding:"11px",fontSize:13.5}} onClick={onConfirm} disabled={submitting}>
            {submitting?<><Spinner/> Submitting…</>:`Submit v${versionNum} for Review →`}
          </button>
        ) : null}
      </div>
    </div>
  );
}

/* ─── Scan summary tab with contract hours admin input ───────────────────── */
function ScanSummaryTab({result, contractor}) {
  const [contractHours, setContractHours] = useState(contractor.contractHours || 2000);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(String(contractHours));

  const rate = result.detectedRate || contractor.rate;
  const totalHours = result.totalHours;

  // Utilisation: this month's hours as % of monthly contract allocation (annual ÷ 12)
  const monthlyAllocation = contractHours / 12;
  const utilisationPct    = Math.round((totalHours / monthlyAllocation) * 100);
  const utilisationCol    = utilisationPct > 110 ? B.red : utilisationPct > 95 ? B.amber : B.green;

  // YTD projection (simple: this month × 12)
  const ytdProjection = totalHours * 12;
  const ytdPct        = Math.round((ytdProjection / contractHours) * 100);

  const saveHours = () => {
    const n = parseInt(draft);
    if (!isNaN(n) && n > 0) setContractHours(n);
    else setDraft(String(contractHours));
    setEditing(false);
  };

  return (
    <div>
      {/* Scanned fields */}
      {[
        ["Period",    result.period,                              B.text],
        ["Format",    result.format,                             B.dim],
        ["Total Hours", `${totalHours}h`,                        B.text],
        ["Regular",   `${result.regularHours}h`,                 B.green],
        ["Overtime",  `${result.overtimeHours}h`,                result.overtimeHours>20?B.red:B.amber],
        ["Rate",      rate?`$${rate}/hr`:"Not found",            rate?B.text:B.amber],
        ["Client",    result.detectedClientName||"Not found",    result.detectedClientName?B.text:B.amber],
        ["Notes",     result.notes||"None",                      B.dim],
      ].map(([k,v,c])=>(
        <div key={k} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${B.faint}`}}>
          <span style={{fontSize:12.5,color:B.dim}}>{k}</span>
          <span className="mono" style={{fontSize:12.5,color:c,maxWidth:180,textAlign:"right"}}>{v}</span>
        </div>
      ))}

      {/* Contract hours — admin editable */}
      <div style={{marginTop:14,padding:"13px 14px",background:B.bg,border:`1px solid ${B.border}`,borderRadius:9}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
          <div>
            <div style={{fontSize:12,fontWeight:700,color:B.text}}>Contract Hours</div>
            <div style={{fontSize:11,color:B.dim,marginTop:1}}>Admin-defined annual allocation</div>
          </div>
          {editing ? (
            <div style={{display:"flex",alignItems:"center",gap:6}}>
              <input
                value={draft}
                onChange={e=>setDraft(e.target.value)}
                onKeyDown={e=>{if(e.key==="Enter")saveHours();if(e.key==="Escape"){setDraft(String(contractHours));setEditing(false);}}}
                autoFocus
                style={{width:72,padding:"5px 9px",fontFamily:"'DM Mono',monospace",fontSize:13,border:`1.5px solid ${B.accent}`,borderRadius:6,color:B.text,outline:"none",textAlign:"right"}}
              />
              <span style={{fontSize:11,color:B.dim}}>h/yr</span>
              <button className="btn btn-accent btn-sm" onClick={saveHours} style={{padding:"5px 10px"}}>Save</button>
              <button className="btn btn-ghost btn-sm" onClick={()=>{setDraft(String(contractHours));setEditing(false);}} style={{padding:"5px 10px"}}>✕</button>
            </div>
          ) : (
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <span className="mono" style={{fontSize:16,fontWeight:500,color:B.text}}>{contractHours.toLocaleString()}h</span>
              <button className="btn btn-ghost btn-sm" onClick={()=>{setDraft(String(contractHours));setEditing(true);}}>Edit</button>
            </div>
          )}
        </div>

        {/* Utilisation bars */}
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {/* This month */}
          <div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
              <span style={{fontSize:11.5,color:B.dim}}>This month ({totalHours}h of {Math.round(monthlyAllocation)}h allocation)</span>
              <span className="mono" style={{fontSize:11.5,fontWeight:600,color:utilisationCol}}>{utilisationPct}%</span>
            </div>
            <div style={{height:6,borderRadius:3,background:B.border,overflow:"hidden"}}>
              <div style={{height:"100%",width:`${Math.min(utilisationPct,100)}%`,background:utilisationCol,borderRadius:3,transition:"width .5s ease"}}/>
            </div>
            {utilisationPct > 100 && (
              <div style={{fontSize:11,color:B.red,marginTop:3}}>⚠ {utilisationPct-100}% over monthly allocation</div>
            )}
          </div>

          {/* YTD projection */}
          <div>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
              <span style={{fontSize:11.5,color:B.dim}}>Annual projection (at this rate)</span>
              <span className="mono" style={{fontSize:11.5,fontWeight:600,color:ytdPct>105?B.amber:B.dim}}>{ytdProjection.toLocaleString()}h / {contractHours.toLocaleString()}h</span>
            </div>
            <div style={{height:5,borderRadius:3,background:B.border,overflow:"hidden"}}>
              <div style={{height:"100%",width:`${Math.min(ytdPct,100)}%`,background:ytdPct>105?B.amber:B.dim,borderRadius:3,transition:"width .5s ease"}}/>
            </div>
          </div>
        </div>
      </div>

      {/* Estimated value */}
      <div style={{marginTop:10,padding:"12px 14px",background:B.aP,border:`1px solid ${B.aBd}`,borderRadius:8,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontSize:11,color:B.dim,marginBottom:2}}>Estimated invoice value</div>
          <div className="mono" style={{fontSize:20,color:B.accent,fontWeight:500}}>
            ${(totalHours * rate).toLocaleString("en-AU",{minimumFractionDigits:2})}
          </div>
        </div>
        <div style={{fontSize:11.5,color:B.dim,textAlign:"right"}}>
          {totalHours}h × ${rate}/hr
        </div>
      </div>
    </div>
  );
}


function DiffTab({current,latest,contractor}) {
  if (!latest) return <div style={{textAlign:"center",padding:"28px",color:B.dim,fontSize:14}}>No previous version to compare.</div>;

  const prev = latest.extractedData;
  const rows=[
    ["Total Hours",     `${prev.totalHours}h`,                   `${current.totalHours}h`,        prev.totalHours!==current.totalHours],
    ["Regular Hours",   `${prev.regularHours}h`,                 `${current.regularHours}h`,      prev.regularHours!==current.regularHours],
    ["Overtime Hours",  `${prev.overtimeHours}h`,                `${current.overtimeHours}h`,     prev.overtimeHours!==current.overtimeHours],
    ["Format",          prev.format||"—",                        current.format,                  prev.format!==current.format],
    ["Confidence",      `${prev.confidence}%`,                   `${current.confidence}%`,        false],
    ["Warnings",        `${prev.warnings?.length||0}`,           `${current.warnings?.length||0}`,prev.warnings?.length!==current.warnings?.length],
    ["Estimated Value", `$${(prev.totalHours*(prev.detectedRate||contractor.rate)).toLocaleString("en-AU")}`, `$${(current.totalHours*(current.detectedRate||contractor.rate)).toLocaleString("en-AU")}`, prev.totalHours!==current.totalHours],
  ];

  const changed = rows.filter(r=>r[3]).length;

  return (
    <div>
      <div style={{marginBottom:14,padding:"10px 13px",borderRadius:8,background:changed>0?B.aLP:B.gP,border:`1px solid ${changed>0?B.aLB:B.gB}`,fontSize:13,color:changed>0?B.amber:B.green}}>
        {changed===0 ? "✓ No differences detected from previous version" : `${changed} field${changed>1?"s":""} changed from version ${latest.version}`}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:0}}>
        {["Field","v"+latest.version+" (previous)","New upload"].map((h,i)=>(
          <div key={h} className="lbl" style={{padding:"7px 10px",background:B.bg,borderBottom:`1px solid ${B.border}`,textAlign:i>0?"center":"left"}}>{h}</div>
        ))}
        {rows.map(([label,prev,curr,changed],i)=>[
          <div key={label+"k"} style={{padding:"10px 10px",borderBottom:`1px solid ${B.faint}`,fontSize:13,color:B.text,background:changed?B.aLP:"transparent"}}>{label}</div>,
          <div key={label+"p"} className="mono" style={{padding:"10px 10px",borderBottom:`1px solid ${B.faint}`,fontSize:13,color:changed?B.red:B.dim,textAlign:"center",background:changed?B.rP:"transparent",textDecoration:changed?"line-through":"none"}}>{prev}</div>,
          <div key={label+"c"} className="mono" style={{padding:"10px 10px",borderBottom:`1px solid ${B.faint}`,fontSize:13,color:changed?B.green:B.dim,textAlign:"center",background:changed?B.gP:"transparent",fontWeight:changed?600:400}}>{curr}</div>,
        ])}
      </div>
    </div>
  );
}

/* ─── Scanning progress steps ────────────────────────────────────────────── */
function ScanProgress() {
  const [step,setStep] = useState(0);
  const steps=["Reading PDF structure…","Detecting document format…","Extracting hours and dates…","Checking for anomalies…","Calculating totals…"];

  useState(()=>{
    let i=0;
    const t=setInterval(()=>{if(i<steps.length-1){i++;setStep(i);}else{clearInterval(t);}},600);
    return ()=>clearInterval(t);
  });

  return (
    <div style={{padding:"16px 18px",background:B.purP,border:`1px solid ${B.purB}`,borderRadius:10,marginBottom:12}}>
      {steps.map((s,i)=>(
        <div key={s} style={{display:"flex",alignItems:"center",gap:9,padding:"5px 0"}}>
          <span style={{width:16,height:16,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center"}}>
            {i<step ? <span style={{color:B.green,fontSize:12}}>✓</span>
             : i===step ? <Spinner col={B.purple}/>
             : <span style={{width:6,height:6,borderRadius:"50%",background:B.purB,display:"inline-block"}}/>}
          </span>
          <span style={{fontSize:13,color:i<=step?B.text:B.sub,fontWeight:i===step?500:400}}>{s}</span>
        </div>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   HISTORY VIEW
═══════════════════════════════════════════════════════════════════════════ */
function HistoryView({contractor,period,versions,onRestore,onInspect,toast_}) {
  if (versions.length===0) {
    return (
      <div className="card" style={{padding:"56px",textAlign:"center",maxWidth:540,margin:"0 auto"}}>
        <div style={{fontSize:36,marginBottom:12}}>📂</div>
        <div style={{fontSize:18,fontWeight:600,color:B.text,marginBottom:6}}>No submissions yet</div>
        <div style={{fontSize:14,color:B.dim}}>No timesheets found for {contractor.name} in {MONTHS[period.m]} {period.y}.</div>
      </div>
    );
  }

  return (
    <div style={{maxWidth:800}}>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <div style={{width:38,height:38,borderRadius:10,background:contractor.bg,color:contractor.col,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,fontSize:14,border:`1.5px solid ${contractor.col}25`}}>{contractor.initials}</div>
        <div>
          <div style={{fontSize:16,fontWeight:600,color:B.text}}>{contractor.name} — {MONTHS[period.m]} {period.y}</div>
          <div style={{fontSize:13,color:B.dim}}>{versions.length} version{versions.length>1?"s":""} · {contractor.rate && `$${contractor.rate}/hr`}</div>
        </div>
      </div>

      {/* Timeline */}
      <div style={{position:"relative"}}>
        {/* Vertical line */}
        <div style={{position:"absolute",left:19,top:24,bottom:24,width:2,background:B.border,zIndex:0}}/>

        {versions.map((ver,i)=>{
          const sm=SM[ver.status];
          const isLatest=i===versions.length-1;
          const canRestore=ver.status!=="APPROVED"||ver.restorable;
          return (
            <div key={ver.versionId} className="u" style={{display:"flex",gap:14,marginBottom:14,position:"relative",animationDelay:`${i*.06}s`}}>
              {/* Node */}
              <div style={{width:40,height:40,borderRadius:11,background:isLatest?B.text:B.surface,border:`2px solid ${isLatest?B.text:B.border}`,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:700,color:isLatest?"#fff":B.dim,flexShrink:0,zIndex:1}}>v{ver.version}</div>

              {/* Card */}
              <div className="card" style={{flex:1,padding:"16px 20px",borderLeft:`3px solid ${sm.col}`}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                  <div>
                    <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:3}}>
                      <span style={{fontSize:14,fontWeight:600,color:B.text}}>Version {ver.version}</span>
                      {isLatest&&<span style={{fontSize:10,fontWeight:700,padding:"2px 7px",borderRadius:4,background:B.text,color:"#fff"}}>LATEST</span>}
                      <Pill status={ver.status}/>
                    </div>
                    <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
                      <span style={{fontSize:12.5,color:B.dim}}>{ver.uploadedAt} · {ver.fileName}</span>
                      {ver.intakeSource && (
                        <IntakeSourceBadge source={ver.intakeSource}/>
                      )}
                    </div>
                    <div style={{fontSize:12,color:B.sub,marginTop:1}}>
                      {ver.format} · {ver.fileSize}
                      {ver.uploadedBy && <span style={{color:B.dim}}> · uploaded by {ver.uploadedBy}</span>}
                    </div>
                  </div>
                  <div style={{display:"flex",gap:7,flexShrink:0}}>
                    <button className="btn btn-ghost btn-sm" onClick={()=>onInspect(ver)}>Inspect</button>
                    {!isLatest && canRestore && ver.status!=="REJECTED" && (
                      <button className="btn btn-sm" style={{background:B.purP,border:`1px solid ${B.purB}`,color:B.purple}} onClick={()=>onRestore(ver.versionId)}>
                        ↩ Restore
                      </button>
                    )}
                  </div>
                </div>

                {/* Stats row */}
                <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
                  {[
                    [`${ver.hours}h total`,B.text],
                    [`${ver.extractedData?.regularHours}h regular`,B.green],
                    ver.extractedData?.overtimeHours>0?[`${ver.extractedData?.overtimeHours}h overtime`,ver.extractedData?.overtimeHours>20?B.red:B.amber]:null,
                    [`${ver.extractedData?.confidence}% confidence`,ver.extractedData?.confidence>=90?B.green:ver.extractedData?.confidence>=70?B.amber:B.red],
                    ver.extractedData?.warnings?.length>0?[`${ver.extractedData.warnings.length} warning${ver.extractedData.warnings.length>1?"s":""}`,B.amber]:null,
                  ].filter(Boolean).map(([label,col],j)=>(
                    <span key={j} className="mono" style={{fontSize:12,color:col,padding:"3px 8px",borderRadius:5,background:`${col}12`,border:`1px solid ${col}25`}}>{label}</span>
                  ))}
                </div>

                {/* Status detail */}
                {ver.rejectionReason && (
                  <div style={{marginTop:10,padding:"9px 12px",background:B.rP,border:`1px solid ${B.rB}`,borderRadius:8,fontSize:13,color:B.red}}>
                    ↩ <strong>Returned {ver.rejectedAt} by {ver.rejectedBy}:</strong> {ver.rejectionReason}
                  </div>
                )}
                {ver.approvedAt && (
                  <div style={{marginTop:10,padding:"9px 12px",background:B.gP,border:`1px solid ${B.gB}`,borderRadius:8,fontSize:13,color:B.green}}>
                    ✓ <strong>Approved {ver.approvedAt} by {ver.approvedBy}</strong>
                  </div>
                )}

                {/* Diff badge vs previous version */}
                {i>0 && (() => {
                  const prev=versions[i-1];
                  const diff=ver.hours-prev.hours;
                  if(diff===0) return null;
                  return <div style={{marginTop:8,fontSize:12,color:diff>0?B.amber:B.green}}>{diff>0?"↑":"↓"} {Math.abs(diff)}h vs version {prev.version}</div>;
                })()}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════
   DETAIL VIEW — inspect a specific version
═══════════════════════════════════════════════════════════════════════════ */
function DetailView({version,contractor,allVersions,onBack,onRestore,toast_}) {
  const [tab,setTab]=useState("extracted");
  const ed=version.extractedData;
  const sm=SM[version.status];
  const canRestore=version.status!=="APPROVED"||version.restorable;
  const isLatest=allVersions[allVersions.length-1]?.versionId===version.versionId;

  return (
    <div className="fi" style={{maxWidth:780}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:20}}>
        <button className="btn btn-ghost" onClick={onBack}>← History</button>
        <div style={{display:"flex",gap:8}}>
          {!isLatest && canRestore && version.status!=="REJECTED" && (
            <button className="btn btn-sm" style={{background:B.purP,border:`1px solid ${B.purB}`,color:B.purple}} onClick={()=>onRestore(version.versionId)}>
              ↩ Restore this version
            </button>
          )}
          <button className="btn btn-ghost btn-sm" onClick={()=>toast_("Downloading original PDF")}>⬇ Download original PDF</button>
        </div>
      </div>

      {/* Header */}
      <div className="card" style={{padding:"22px 26px",marginBottom:14}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
          <div>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:5}}>
              <div style={{width:36,height:36,borderRadius:10,background:contractor.bg,color:contractor.col,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700,fontSize:13}}>{contractor.initials}</div>
              <div>
                <div style={{fontSize:17,fontWeight:700,color:B.text}}>{contractor.name} — Version {version.version}</div>
                <div style={{fontSize:13,color:B.dim}}>{MONTHS[version.m]} {version.y} · {version.uploadedAt}</div>
              </div>
            </div>
            <div style={{display:"flex",gap:8,marginTop:6}}>
              <Pill status={version.status}/>
              {isLatest&&<span className="pill" style={{background:B.text,color:"#fff"}}>Latest</span>}
              <span style={{fontSize:11,padding:"3px 8px",borderRadius:5,background:B.bg,border:`1px solid ${B.border}`,color:B.dim}}>{version.format}</span>
            </div>
          </div>
          <div style={{textAlign:"right"}}>
            <div style={{fontSize:11,color:B.dim,marginBottom:2}}>Confidence</div>
            <div className="mono" style={{fontSize:26,color:ed.confidence>=90?B.green:ed.confidence>=70?B.amber:B.red}}>{ed.confidence}%</div>
          </div>
        </div>
      </div>

      <div className="card" style={{overflow:"hidden"}}>
        <div style={{display:"flex",borderBottom:`1px solid ${B.border}`,padding:"0 22px"}}>
          {[["extracted","Extracted Data"],["weekly","Weekly Breakdown"],["daily","Daily Log"],["meta","Metadata & Audit"]].map(([id,label])=>(
            <button key={id} className={`tab ${tab===id?"on":""}`} onClick={()=>setTab(id)}>{label}</button>
          ))}
        </div>

        <div style={{padding:"22px"}}>
          {tab==="extracted" && (
            <div>
              {ed.warnings?.length>0&&<div style={{marginBottom:16,padding:"12px 14px",background:B.aLP,border:`1px solid ${B.aLB}`,borderRadius:9}}>{ed.warnings.map((w,i)=><div key={i} style={{fontSize:13,color:B.amber,marginBottom:i<ed.warnings.length-1?6:0}}>⚠ {w}</div>)}</div>}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:16}}>
                {[["Total Hours",`${ed.totalHours}h`,B.text],["Regular",`${ed.regularHours}h`,B.green],["Overtime",`${ed.overtimeHours}h`,ed.overtimeHours>20?B.red:B.amber],["Estimated Value",`$${(ed.totalHours*(ed.detectedRate||contractor.rate)).toLocaleString("en-AU")}`,B.accent]].map(([k,v,c])=>(
                  <div key={k} className="inner" style={{padding:"14px 16px",borderTop:`2px solid ${c}30`}}>
                    <div className="mono" style={{fontSize:22,color:c,marginBottom:3}}>{v}</div>
                    <div style={{fontSize:12,color:B.dim}}>{k}</div>
                  </div>
                ))}
              </div>
              {[["Period",ed.period],["Format",ed.format],["Notes",ed.notes||"None"],["Detected Client",ed.detectedClient||"Not detected"],["Detected Rate",ed.detectedRate?`$${ed.detectedRate}/hr`:"Not detected"]].map(([k,v])=>(
                <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"9px 0",borderBottom:`1px solid ${B.faint}`}}>
                  <span style={{fontSize:13,color:B.dim}}>{k}</span>
                  <span className="mono" style={{fontSize:13,color:B.text,maxWidth:280,textAlign:"right"}}>{v}</span>
                </div>
              ))}
            </div>
          )}

          {tab==="weekly" && (
            <div>{ed.weeks?.map((w,i)=>{const pct=w.h/Math.max(...ed.weeks.map(x=>x.h));return(
              <div key={i} style={{marginBottom:12}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:13.5,color:B.text}}>{w.wk}</span><span className="mono" style={{fontSize:13,color:w.h>44?B.red:w.h>40?B.amber:B.green}}>{w.h}h</span></div>
                <div style={{height:7,borderRadius:3,background:B.bg,overflow:"hidden"}}><div style={{height:"100%",width:`${pct*100}%`,background:w.h>44?B.red:w.h>40?B.amber:B.accent,borderRadius:3}}/></div>
              </div>
            );})}
            <div style={{marginTop:14,padding:"11px 14px",background:B.bg,borderRadius:8,display:"flex",justifyContent:"space-between"}}><span className="lbl">Total</span><span className="mono" style={{fontSize:15,fontWeight:500,color:B.text}}>{ed.totalHours}h</span></div></div>
          )}

          {tab==="daily" && (
            <div>{ed.dailyBreakdown?.length>0?ed.dailyBreakdown.map((d,i)=>(
              <div key={i} style={{display:"flex",alignItems:"center",gap:12,padding:"9px 0",borderBottom:i<ed.dailyBreakdown.length-1?`1px solid ${B.faint}`:"none"}}>
                <span className="mono" style={{fontSize:12.5,color:B.dim,width:50,flexShrink:0}}>{d.date}</span>
                <div style={{flex:1,height:6,borderRadius:3,background:B.bg,overflow:"hidden"}}><div style={{height:"100%",width:`${(d.hours/12)*100}%`,background:d.hours>10?B.red:d.hours>8?B.amber:B.accent,borderRadius:3}}/></div>
                <span className="mono" style={{fontSize:13,color:d.hours>10?B.red:B.text,width:28,textAlign:"right"}}>{d.hours}h</span>
                {d.hours>10&&<span style={{fontSize:10,background:B.rP,color:B.red,padding:"1px 5px",borderRadius:4}}>High</span>}
              </div>
            )):<div style={{textAlign:"center",padding:"24px",color:B.dim,fontSize:14}}>Daily breakdown not available for this format.</div>}</div>
          )}

          {tab==="meta" && (
            <div>
              {/* ── Intake provenance ── */}
              <div style={{marginBottom:20,padding:"16px",background:B.aP,border:`1px solid ${B.aBd}`,borderRadius:10}}>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:12}}>
                  <span style={{fontSize:16}}>
                    {version.intakeSource==="email"?"✉️":version.intakeSource==="walk-in"?"🚶":version.intakeSource==="post"?"📮":"📎"}
                  </span>
                  <div>
                    <p className="lbl" style={{color:B.accent}}>Intake Provenance</p>
                    <div style={{fontSize:11.5,color:B.dim,marginTop:1}}>How this timesheet reached the portal</div>
                  </div>
                </div>
                {[
                  ["Received via",    version.intakeSource ? SOURCE_LABEL[version.intakeSource] : "—"],
                  ["From",            version.intakeSenderEmail || "—"],
                  ["Date received",   version.intakeReceivedDate || "—"],
                  ["Uploaded by",     version.uploadedBy ? `${version.uploadedBy} (${version.uploadedByRole||""})` : "—"],
                  version.intakeNotes ? ["Internal notes", version.intakeNotes] : null,
                ].filter(Boolean).map(([k,v])=>(
                  <div key={k} style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",padding:"7px 0",borderBottom:`1px solid ${B.aBd}`}}>
                    <span style={{fontSize:12.5,color:B.dim,flexShrink:0,marginRight:12}}>{k}</span>
                    <span style={{fontSize:12.5,color:B.text,fontWeight:500,textAlign:"right",wordBreak:"break-word",maxWidth:320}}>{v}</span>
                  </div>
                ))}
              </div>

              {/* ── Upload audit ── */}
              <div style={{marginBottom:20}}>
                <p className="lbl" style={{marginBottom:12}}>Upload Audit</p>
                {[["Version",`v${version.version} of ${allVersions.length}`],["Uploaded",version.uploadedAt],["File Name",version.fileName],["File Size",version.fileSize],["Format Detected",version.format],["Version ID",version.versionId]].map(([k,v])=>(
                  <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"8px 0",borderBottom:`1px solid ${B.faint}`}}>
                    <span style={{fontSize:13,color:B.dim}}>{k}</span>
                    <span className="mono" style={{fontSize:k==="Version ID"?11.5:13,color:B.text}}>{v}</span>
                  </div>
                ))}
              </div>
              {version.rejectionReason&&<div style={{padding:"12px 14px",background:B.rP,border:`1px solid ${B.rB}`,borderRadius:9,marginBottom:12}}><div style={{fontSize:12,fontWeight:600,color:B.red,marginBottom:4}}>Returned by {version.rejectedBy} on {version.rejectedAt}</div><div style={{fontSize:13,color:B.red}}>{version.rejectionReason}</div></div>}
              {version.approvedAt&&<div style={{padding:"12px 14px",background:B.gP,border:`1px solid ${B.gB}`,borderRadius:9}}><div style={{fontSize:12,fontWeight:600,color:B.green,marginBottom:4}}>Approved by {version.approvedBy} on {version.approvedAt}</div><div style={{fontSize:13,color:B.green}}>This version was included in the pay run.</div></div>}
              {!isLatest&&canRestore&&version.status!=="REJECTED"&&<button className="btn btn-sm" style={{marginTop:14,background:B.purP,border:`1px solid ${B.purB}`,color:B.purple}} onClick={()=>onRestore(version.versionId)}>↩ Restore this version as new submission</button>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─── Shared ─────────────────────────────────────────────────────────────── */
const SOURCE_LABEL = { email:"Email", "walk-in":"Walk-in", post:"Post / Fax", other:"Other" };
const SOURCE_ICON  = { email:"✉️", "walk-in":"🚶", post:"📮", other:"📎" };

function IntakeSourceBadge({source}) {
  if (!source) return null;
  return (
    <span style={{
      display:"inline-flex", alignItems:"center", gap:4,
      fontSize:11, fontWeight:600, padding:"2px 7px", borderRadius:5,
      background:B.aP, border:`1px solid ${B.aBd}`, color:B.accent,
    }}>
      {SOURCE_ICON[source]} {SOURCE_LABEL[source]||source}
    </span>
  );
}
function Pill({status}) {
  const sm=SM[status]||{col:B.dim,bg:B.bg,bd:B.border,label:status};
  return <span className="pill" style={{background:sm.bg,color:sm.col,border:`1px solid ${sm.bd}`}}>{sm.label}</span>;
}
function Spinner({col}) {
  return <span className="spin" style={{width:13,height:13,border:`2px solid ${col||"rgba(255,255,255,.3)"}`,borderTop:`2px solid ${col||"#fff"}`,borderRadius:"50%",display:"inline-block",flexShrink:0,opacity:col?.1:1}}/>;
}
