'use client'
// components/layout/TopBar.tsx
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { B } from '@/lib/design'

interface TopBarProps {
  title: string
  subtitle?: string
  actions?: React.ReactNode
}

export default function TopBar({ title, subtitle, actions }: TopBarProps) {
  const router = useRouter()
  const supabase = createClient()

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push('/auth/login')
    router.refresh()
  }

  return (
    <header style={{
      height: 60,
      background: B.surface,
      borderBottom: `1px solid ${B.border}`,
      display: 'flex',
      alignItems: 'center',
      padding: '0 24px',
      gap: 16,
      position: 'sticky',
      top: 0,
      zIndex: 10,
    }}>
      <div style={{flex:1}}>
        <h1 style={{fontSize:16,fontWeight:700,color:B.text,margin:0}}>{title}</h1>
        {subtitle && <p style={{fontSize:12,color:B.dim,margin:0}}>{subtitle}</p>}
      </div>

      {actions && <div style={{display:'flex',gap:8,alignItems:'center'}}>{actions}</div>}

      {/* Admin avatar */}
      <button
        onClick={handleSignOut}
        title="Sign out"
        style={{
          width:34,height:34,borderRadius:9,background:B.accent,
          border:'none',cursor:'pointer',
          display:'flex',alignItems:'center',justifyContent:'center',
          fontSize:12,fontWeight:700,color:'#fff',flexShrink:0,
          fontFamily:"'DM Sans',sans-serif",
          transition:'filter .15s',
        }}
        onMouseEnter={e=>(e.currentTarget.style.filter='brightness(.85)')}
        onMouseLeave={e=>(e.currentTarget.style.filter='brightness(1)')}
      >
        SC
      </button>
    </header>
  )
}
