'use client'
// components/layout/Sidebar.tsx
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { B } from '@/lib/design'

const NAV = [
  { label:'Dashboard',     href:'/admin/dashboard',     icon:'▦',  badge:null },
  { label:'Contractors',   href:'/admin/contractors',   icon:'👤', badge:null },
  { label:'Timesheets',    href:'/admin/timesheets',    icon:'📄', badge:null },
  { label:'Pay Runs',      href:'/admin/payroll',       icon:'💳', badge:null },
  { label:'Invoicing',     href:'/admin/invoicing',     icon:'🧾', badge:null },
  { label:'Notifications', href:'/admin/notifications', icon:'🔔', badge:'notif' },
  { label:'Settings',      href:'/admin/settings',      icon:'⚙️', badge:null },
]

export default function Sidebar() {
  const pathname  = usePathname()
  const supabase  = createClient()
  const [collapsed, setCollapsed] = useState(false)
  const [unread,    setUnread]    = useState(0)
  const [initials,  setInitials]  = useState('SC')

  useEffect(() => {
    supabase
      .from('notifications')
      .select('id', { count: 'exact', head: true })
      .eq('read', false)
      .then(({ count }) => setUnread(count ?? 0))

    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (!user) return
      const { data } = await supabase.from('profiles').select('full_name').eq('id', user.id).single()
      if (data?.full_name) {
        setInitials(data.full_name.split(' ').map((p: string) => p[0]).join('').toUpperCase().slice(0,2))
      }
    })

    const ch = supabase.channel('notif-count')
      .on('postgres_changes', { event:'INSERT', schema:'public', table:'notifications' }, () => setUnread(n => n+1))
      .subscribe()
    return () => { supabase.removeChannel(ch) }
  }, [])

  return (
    <aside style={{
      width: collapsed ? 58 : 220, minHeight:'100vh',
      background:B.surface, borderRight:`1px solid ${B.border}`,
      display:'flex', flexDirection:'column',
      transition:'width .2s cubic-bezier(.22,.68,0,1.2)',
      flexShrink:0, position:'sticky', top:0,
    }}>
      <div style={{
        padding: collapsed ? '18px 0' : '18px 16px',
        borderBottom:`1px solid ${B.faint}`,
        display:'flex', alignItems:'center', gap:10,
        justifyContent: collapsed ? 'center' : 'flex-start',
      }}>
        <div style={{width:32,height:32,borderRadius:9,background:B.accent,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,flexShrink:0}}>🏢</div>
        {!collapsed && <span style={{fontSize:14,fontWeight:700,color:B.text,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>Recruitment</span>}
      </div>

      <nav style={{flex:1,padding:'12px 0',overflowY:'auto'}}>
        {NAV.map(item => {
          const active    = pathname.startsWith(item.href)
          const showBadge = item.badge === 'notif' && unread > 0
          return (
            <Link key={item.href} href={item.href} style={{
              display:'flex', alignItems:'center', gap:10,
              padding: collapsed ? '10px 0' : '10px 14px',
              justifyContent: collapsed ? 'center' : 'flex-start',
              margin:'2px 8px', borderRadius:8, textDecoration:'none',
              background: active ? B.aP : 'transparent',
              color:      active ? B.accent : B.dim,
              fontWeight: active ? 600 : 400,
              fontSize:14, transition:'all .12s', position:'relative',
            }}
            onMouseEnter={e => { if(!active)(e.currentTarget as HTMLElement).style.background=B.faint }}
            onMouseLeave={e => { if(!active)(e.currentTarget as HTMLElement).style.background='transparent' }}
            >
              <span style={{fontSize:16,flexShrink:0,position:'relative'}}>
                {item.icon}
                {showBadge && collapsed && <span style={{position:'absolute',top:-4,right:-4,width:8,height:8,borderRadius:'50%',background:B.red,border:`1.5px solid ${B.surface}`}}/>}
              </span>
              {!collapsed && (
                <>
                  <span style={{whiteSpace:'nowrap',flex:1}}>{item.label}</span>
                  {showBadge && <span style={{fontSize:10,fontWeight:700,padding:'1px 6px',borderRadius:10,background:B.red,color:'#fff',minWidth:18,textAlign:'center'}}>{unread>99?'99+':unread}</span>}
                </>
              )}
            </Link>
          )
        })}
      </nav>

      <div style={{padding:'10px 8px',borderTop:`1px solid ${B.faint}`,display:'flex',flexDirection:'column',gap:4}}>
        {!collapsed && (
          <div style={{display:'flex',alignItems:'center',gap:10,padding:'8px 10px',borderRadius:9,background:B.bg,border:`1px solid ${B.border}`}}>
            <div style={{width:28,height:28,borderRadius:7,background:B.accent,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,color:'#fff',flexShrink:0}}>{initials}</div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:12.5,fontWeight:600,color:B.text}}>Admin</div>
              <div style={{fontSize:11,color:B.dim}}>Portal admin</div>
            </div>
          </div>
        )}
        <button
          onClick={() => setCollapsed(c => !c)}
          style={{width:'100%',padding:'9px',borderRadius:8,border:'none',background:'transparent',cursor:'pointer',fontSize:14,color:B.dim,display:'flex',alignItems:'center',justifyContent:collapsed?'center':'flex-start',gap:8,fontFamily:"'DM Sans',sans-serif",transition:'all .12s'}}
          onMouseEnter={e => (e.currentTarget.style.background=B.faint)}
          onMouseLeave={e => (e.currentTarget.style.background='transparent')}
        >
          <span style={{fontSize:16}}>{collapsed ? '→' : '←'}</span>
          {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </aside>
  )
}
