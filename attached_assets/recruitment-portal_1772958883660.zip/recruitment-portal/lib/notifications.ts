// lib/notifications.ts
import { createServiceClient } from '@/lib/supabase/server'

export type NotificationType = 'PAYRUN'|'STP'|'INVOICE'|'TIMESHEET'|'SUPER'|'XERO'|'CLEARANCE'|'SYSTEM'
export type NotificationPriority = 'URGENT'|'HIGH'|'MEDIUM'|'LOW'

interface SendNotificationParams {
  userId:        string
  type:          NotificationType
  priority?:     NotificationPriority
  title:         string
  body?:         string
  actionLabel?:  string
  actionRoute?:  string
  contractorId?: string
  invoiceId?:    string
  payRunId?:     string
  timesheetId?:  string
}

export async function sendNotification(params: SendNotificationParams): Promise<void> {
  try {
    const supabase = createServiceClient()
    await supabase.from('notifications').insert({
      user_id:       params.userId,
      type:          params.type,
      priority:      params.priority ?? 'MEDIUM',
      title:         params.title,
      body:          params.body         ?? null,
      action_label:  params.actionLabel  ?? null,
      action_route:  params.actionRoute  ?? null,
      contractor_id: params.contractorId ?? null,
      invoice_id:    params.invoiceId    ?? null,
      pay_run_id:    params.payRunId     ?? null,
      timesheet_id:  params.timesheetId  ?? null,
    })
  } catch (err) {
    console.error('[notifications] Failed to send notification:', err)
  }
}
