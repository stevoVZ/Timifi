// lib/xero/invoices.ts
// Server-side only
import { xeroFetch } from './client'

export interface CreateInvoiceParams {
  xeroContactId:  string       // Xero Contact ID for the client company
  invoiceNumber?: string       // e.g. INV-0047 (optional — Xero auto-numbers if omitted)
  description:    string       // line item description
  hours:          number
  hourlyRate:     number
  issueDate:      string       // YYYY-MM-DD
  dueDate:        string       // YYYY-MM-DD
  reference?:     string       // internal ref e.g. "Alex Rivera — March 2026"
}

export interface XeroInvoiceResult {
  xeroInvoiceId:  string
  invoiceNumber:  string
  amountDue:      number
  amountExclGst:  number
  status:         string
  url:            string
}

// ── Create invoice ────────────────────────────────────────────────────────────

export async function createXeroInvoice(params: CreateInvoiceParams): Promise<XeroInvoiceResult> {
  const amountExcl = params.hours * params.hourlyRate
  const gst        = amountExcl * 0.1
  const amountIncl = amountExcl + gst

  const body = {
    Type: 'ACCREC',
    Contact: { ContactID: params.xeroContactId },
    LineAmountTypes: 'EXCLUSIVE',
    InvoiceNumber: params.invoiceNumber,
    Reference: params.reference,
    Date:    params.issueDate,
    DueDate: params.dueDate,
    Status: 'AUTHORISED',
    LineItems: [
      {
        Description: params.description,
        Quantity:    params.hours,
        UnitAmount:  params.hourlyRate,
        AccountCode: '200',           // Sales account — update to match your Xero chart
        TaxType:     'OUTPUT2',       // GST on Income (AU)
      },
    ],
  }

  const res = await xeroFetch('/api.xro/2.0/Invoices', {
    method: 'POST',
    body: JSON.stringify({ Invoices: [body] }),
  })

  if (!res.ok) {
    const err = await res.text()
    throw new Error(`Xero create invoice failed (${res.status}): ${err}`)
  }

  const data = await res.json()
  const inv  = data.Invoices?.[0]
  if (!inv) throw new Error('Xero returned no invoice in response')

  return {
    xeroInvoiceId: inv.InvoiceID,
    invoiceNumber: inv.InvoiceNumber,
    amountDue:     inv.AmountDue,
    amountExclGst: amountExcl,
    status:        inv.Status,
    url:           `https://go.xero.com/AccountsReceivable/Edit.aspx?InvoiceID=${inv.InvoiceID}`,
  }
}

// ── Email invoice to contact ──────────────────────────────────────────────────

export async function emailXeroInvoice(
  xeroInvoiceId: string,
  toEmail?: string
): Promise<void> {
  const res = await xeroFetch(
    `/api.xro/2.0/Invoices/${xeroInvoiceId}/Email`,
    {
      method: 'POST',
      body: JSON.stringify(toEmail ? { EmailAddress: toEmail } : {}),
    }
  )
  if (!res.ok) {
    const err = await res.text()
    throw new Error(`Xero email invoice failed (${res.status}): ${err}`)
  }
}

// ── Get invoice ───────────────────────────────────────────────────────────────

export async function getXeroInvoice(xeroInvoiceId: string) {
  const res = await xeroFetch(`/api.xro/2.0/Invoices/${xeroInvoiceId}`)
  if (!res.ok) throw new Error(`Xero get invoice failed: ${res.status}`)
  const data = await res.json()
  return data.Invoices?.[0] ?? null
}
