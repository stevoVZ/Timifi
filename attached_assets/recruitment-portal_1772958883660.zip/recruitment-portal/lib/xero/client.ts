// lib/xero/client.ts
// Server-side only — never import in client components
import { createServiceClient } from '@/lib/supabase/server'

export interface XeroToken {
  tenantId:     string
  tenantName:   string
  accessToken:  string
  refreshToken: string
  expiresAt:    Date
}

// ── Token storage ────────────────────────────────────────────────────────────

export async function getXeroToken(): Promise<XeroToken | null> {
  const supabase = createServiceClient()
  const { data } = await supabase
    .from('xero_tokens')
    .select('*')
    .order('updated_at', { ascending: false })
    .limit(1)
    .single()
  if (!data) return null
  return {
    tenantId:     data.tenant_id,
    tenantName:   data.tenant_name,
    accessToken:  data.access_token,
    refreshToken: data.refresh_token,
    expiresAt:    new Date(data.expires_at),
  }
}

export async function saveXeroToken(token: XeroToken): Promise<void> {
  const supabase = createServiceClient()
  await supabase.from('xero_tokens').upsert({
    tenant_id:     token.tenantId,
    tenant_name:   token.tenantName,
    access_token:  token.accessToken,
    refresh_token: token.refreshToken,
    expires_at:    token.expiresAt.toISOString(),
    updated_at:    new Date().toISOString(),
  }, { onConflict: 'tenant_id' })
}

// ── Token refresh ─────────────────────────────────────────────────────────────

export async function getValidAccessToken(): Promise<string> {
  const token = await getXeroToken()
  if (!token) throw new Error('Xero not connected. Authorise at /api/xero/auth')

  // Refresh if expiring within 5 minutes
  const fiveMinutes = 5 * 60 * 1000
  if (token.expiresAt.getTime() - Date.now() < fiveMinutes) {
    const refreshed = await refreshXeroToken(token.refreshToken)
    await saveXeroToken(refreshed)
    return refreshed.accessToken
  }
  return token.accessToken
}

async function refreshXeroToken(refreshToken: string): Promise<XeroToken> {
  const credentials = Buffer.from(
    `${process.env.XERO_CLIENT_ID}:${process.env.XERO_CLIENT_SECRET}`
  ).toString('base64')

  const res = await fetch('https://identity.xero.com/connect/token', {
    method: 'POST',
    headers: {
      'Content-Type':  'application/x-www-form-urlencoded',
      'Authorization': `Basic ${credentials}`,
    },
    body: new URLSearchParams({
      grant_type:    'refresh_token',
      refresh_token: refreshToken,
    }),
  })

  if (!res.ok) {
    const err = await res.text()
    throw new Error(`Xero token refresh failed: ${err}`)
  }

  const data = await res.json()
  const existing = await getXeroToken()

  return {
    tenantId:     existing!.tenantId,
    tenantName:   existing!.tenantName,
    accessToken:  data.access_token,
    refreshToken: data.refresh_token,
    expiresAt:    new Date(Date.now() + data.expires_in * 1000),
  }
}

// ── Generic Xero API fetch ────────────────────────────────────────────────────

export async function xeroFetch(
  path: string,
  options: RequestInit = {}
): Promise<Response> {
  const accessToken = await getValidAccessToken()
  const token       = await getXeroToken()

  return fetch(`https://api.xero.com${path}`, {
    ...options,
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Xero-Tenant-Id': token!.tenantId,
      'Content-Type':  'application/json',
      'Accept':        'application/json',
      ...(options.headers || {}),
    },
  })
}
