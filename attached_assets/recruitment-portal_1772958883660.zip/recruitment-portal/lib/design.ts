// lib/design.ts
// Shared design tokens — matches the portal design system
// Import this in any component: import { B, CSS_BASE } from '@/lib/design'

export const B = {
  bg:      "#f4f5f7",
  surface: "#ffffff",
  border:  "#e5e7eb",
  faint:   "#f0f1f3",
  text:    "#111827",
  mid:     "#374151",
  dim:     "#6b7280",
  sub:     "#9ca3af",
  accent:  "#2563eb",
  aP:      "#eff6ff",
  aBd:     "#bfdbfe",
  green:   "#16a34a",
  gP:      "#f0fdf4",
  gB:      "#bbf7d0",
  amber:   "#b45309",
  aLP:     "#fffbeb",
  aLB:     "#fde68a",
  red:     "#dc2626",
  rP:      "#fef2f2",
  rB:      "#fecaca",
  purple:  "#7c3aed",
  purP:    "#f5f3ff",
  purB:    "#ddd6fe",
  sdw:     "0 1px 2px rgba(0,0,0,.04),0 2px 8px rgba(0,0,0,.04)",
  sdwMd:   "0 2px 8px rgba(0,0,0,.07),0 8px 28px rgba(0,0,0,.08)",
  sdwLg:   "0 4px 16px rgba(0,0,0,.1),0 16px 48px rgba(0,0,0,.12)",
} as const

export const FONT_URL =
  "https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap"

export const CSS_BASE = `
@import url('${FONT_URL}');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:${B.bg};font-family:'DM Sans',sans-serif;color:${B.text};-webkit-font-smoothing:antialiased}
@keyframes up{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
@keyframes in{from{opacity:0}to{opacity:1}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.2}}
@keyframes beam{from{background-position:200% 0}to{background-position:-200% 0}}
.u{animation:up .38s cubic-bezier(.22,.68,0,1.2) both}
.fi{animation:in .24s ease both}
.spin{animation:spin .8s linear infinite}
.pulse{animation:pulse 1.8s ease-in-out infinite}
.card{background:${B.surface};border:1px solid ${B.border};border-radius:12px;box-shadow:${B.sdw}}
.inner{background:${B.bg};border:1px solid ${B.border};border-radius:8px}
.btn{font-family:'DM Sans',sans-serif;font-weight:600;cursor:pointer;border-radius:8px;transition:all .15s;display:inline-flex;align-items:center;justify-content:center;gap:7px;border:none;font-size:13px}
.btn-accent{background:${B.accent};color:#fff;padding:10px 20px}
.btn-accent:hover{filter:brightness(.9);transform:translateY(-1px)}
.btn-ghost{background:transparent;border:1.5px solid ${B.border};color:${B.dim};padding:9px 16px}
.btn-ghost:hover{border-color:${B.accent};color:${B.accent}}
.btn-sm{padding:6px 12px;font-size:12px;border-radius:7px}
.btn-danger{background:${B.rP};border:1.5px solid ${B.rB};color:${B.red};padding:9px 16px}
.btn-danger:hover{background:${B.red};color:#fff}
.btn-green{background:${B.gP};border:1.5px solid ${B.gB};color:${B.green};padding:9px 16px}
.btn-green:hover{background:${B.green};color:#fff}
.mono{font-family:'DM Mono',monospace}
.lbl{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:${B.dim}}
hr.hr{border:none;border-top:1px solid ${B.faint}}
.pill{font-size:11px;font-weight:600;padding:3px 9px;border-radius:100px;white-space:nowrap}
.skel{background:linear-gradient(90deg,${B.border} 25%,${B.faint} 50%,${B.border} 75%);background-size:400%;animation:beam 1.4s linear infinite;border-radius:6px}
.tab{background:none;border:none;border-bottom:2px solid transparent;padding:9px 16px;font-size:13.5px;font-family:'DM Sans',sans-serif;cursor:pointer;transition:all .12s;margin-bottom:-1px}
.tab.on{border-bottom-color:${B.accent};color:${B.accent};font-weight:600}
.tab:not(.on){color:${B.dim}}
.tab:not(.on):hover{color:${B.text}}
`
