// lib/audit.ts
// Call from API routes and server actions only — never from client components
import { createServiceClient } from '@/lib/supabase/server'

export type AuditAction =
  | 'LOGIN' | 'LOGOUT'
  | 'VIEW_CONTRACTOR' | 'CREATE_CONTRACTOR' | 'UPDATE_CONTRACTOR'
  | 'VIEW_BANK_DETAILS'
  | 'UPLOAD_TIMESHEET' | 'APPROVE_TIMESHEET' | 'REJECT_TIMESHEET' | 'RESTORE_TIMESHEET'
  | 'CREATE_INVOICE' | 'SEND_INVOICE' | 'VOID_INVOICE'
  | 'FILE_PAY_RUN' | 'SUBMIT_STP'
  | 'XERO_CONNECT' | 'XERO_DISCONNECT'
  | 'SETTINGS_UPDATE'

interface AuditEntry {
  userId?:     string
  userName?:   string
  userRole?:   string
  action:      AuditAction
  targetType?: string
  targetId?:   string
  metadata?:   Record<string, unknown>
  ipAddress?:  string
}

export async function logAudit(entry: AuditEntry): Promise<void> {
  try {
    const supabase = createServiceClient()
    await supabase.from('audit_log').insert({
      user_id:     entry.userId     ?? null,
      user_name:   entry.userName   ?? null,
      user_role:   entry.userRole   ?? null,
      action:      entry.action,
      target_type: entry.targetType ?? null,
      target_id:   entry.targetId   ?? null,
      metadata:    entry.metadata   ?? null,
      ip_address:  entry.ipAddress  ?? null,
    })
  } catch (err) {
    // Audit failures must never crash the main request
    console.error('[audit] Failed to write audit log:', err)
  }
}
