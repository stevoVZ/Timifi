# Recruitment Portal

Labour hire agency management portal — Next.js 14, Supabase, Xero.

## Quick start on Replit

1. **Upload** these files to your Replit project (drag the folder in)
2. **Install dependencies** — open Shell and run:
   ```
   npm install
   ```
3. **Set environment variables** — copy `.env.example` to `.env.local` and fill in your keys:
   - Go to your [Supabase project](https://supabase.com/dashboard) → Settings → API
   - Copy the URL and anon key into `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - In Replit: Secrets tab (🔒) → add each key/value
4. **Run the schema** — paste `supabase-schema.sql` into Supabase SQL Editor and run it
5. **Start the app** — Replit will auto-run `npm run dev`, or press Run

The app starts at port 3000 and redirects to `/admin/dashboard`.

## What's built

| Route | Description |
|-------|-------------|
| `/admin/dashboard` | KPI overview + quick links |
| `/admin/timesheets` | Full timesheet upload system (multi-file, multi-contractor, AI scanning) |
| `/admin/contractors` | Contractor list |
| `/auth/login` | Admin login via Supabase email/password |

## Environment variables

See `.env.example` for the full list. The minimum needed to run:

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
NEXT_PUBLIC_ANTHROPIC_API_KEY=    # for AI timesheet scanning
```

Without Anthropic key, AI scanning falls back to demo data automatically.

## Tech stack

- **Next.js 14** — App Router, Server Components
- **Supabase** — Auth, PostgreSQL, RLS, file storage
- **Xero** — Invoicing, payroll (AU), STP Phase 2
- **Anthropic** — AI PDF timesheet scanning
- **DM Sans / DM Mono** — Typography

## File structure

```
app/
  admin/          ← All admin pages
  auth/login/     ← Login page
  api/            ← API routes (Supabase callback, Xero OAuth)
components/
  layout/         ← Sidebar, TopBar
  timesheets/     ← Full upload system (AI scanning, version history)
lib/
  supabase/       ← Browser + server clients
  design.ts       ← Design tokens (colours, shadows)
```
