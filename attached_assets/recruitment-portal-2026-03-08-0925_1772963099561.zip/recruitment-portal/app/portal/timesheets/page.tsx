'use client'
// app/portal/timesheets/page.tsx
import { useState, useEffect, useRef } from 'react'
import { B } from '@/lib/design'

const MONTHS = ['January','February','March','April','May','June',
                'July','August','September','October','November','December']
const fmt = (n:number) => '$'+n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})
const STATUS_STYLE: Record<string,{bg:string,c:string,label:string,icon:string}> = {
  APPROVED:  {bg:B.gP,   c:B.green, label:'Approved',  icon:'✅'},
  SUBMITTED: {bg:B.aLP,  c:B.amber, label:'In review', icon:'⏳'},
  PENDING:   {bg:B.aLP,  c:B.amber, label:'In review', icon:'⏳'},
  REJECTED:  {bg:B.rP,   c:B.red,   label:'Returned',  icon:'⚠️'},
  DRAFT:     {bg:B.faint,c:B.dim,   label:'Draft',     icon:'📝'},
}
interface WeekRow  { week:string; regular:number; overtime:number; total:number }
interface TSRecord {
  id:string; period:string; year:number; month:number
  hours:number; rate:number; status:string
  submittedDate:string; reviewedDate?:string
  rejectionReason?:string; weeks:WeekRow[]
  intakeSource?:string; reviewer?:string; canResubmit?:boolean
}
interface WeekEntry { label:string; regular:string; overtime:string }

function getWeeksInMonth(year: number, month: number): string[] {
  const weeks: string[] = []
  const d = new Date(year, month - 1, 1)
  while (d.getDay() !== 1) d.setDate(d.getDate() + 1)
  while (weeks.length < 5) {
    const start = new Date(d)
    const end   = new Date(d); end.setDate(end.getDate() + 4)
    const sL = start.toLocaleDateString('en-AU', {day:'numeric', month:'short'})
    const eL = end.toLocaleDateString('en-AU', {day:'numeric', month:'short'})
    weeks.push(`${sL} – ${eL}`)
    d.setDate(d.getDate() + 7)
  }
  return weeks
}

export default function PortalTimesheets() {
  const [expanded,     setExpanded]     = useState<string|null>(null)
  const [timesheets,   setTimesheets]   = useState<TSRecord[]>([])
  const [loading,      setLoading]      = useState(true)
  const [rate,         setRate]         = useState(0)
  const [contractorId, setContractorId] = useState<string|null>(null)
  const [showForm,     setShowForm]     = useState(false)
  const [submitting,   setSubmitting]   = useState(false)
  const [submitDone,   setSubmitDone]   = useState(false)
  const [formError,    setFormError]    = useState<string|null>(null)
  const now = new Date()
  const [selYear,  setSelYear]  = useState(now.getFullYear())
  const [selMonth, setSelMonth] = useState(now.getMonth() + 1)
  const [notes,    setNotes]    = useState('')
  const [weeks,    setWeeks]    = useState<WeekEntry[]>([])
  const [fileName, setFileName] = useState<string|null>(null)
  const [fileData, setFileData] = useState<string|null>(null)
  const [resubmitId, setResubmitId] = useState<string|null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    fetch('/api/auth/me').then(r=>r.ok?r.json():null).then(d=>{
      if (!d?.contractorId) return
      setContractorId(d.contractorId)
      fetch(`/api/contractors/${d.contractorId}`).then(r=>r.ok?r.json():null)
        .then(cd=>{ if(cd?.contractor?.hourly_rate) setRate(Number(cd.contractor.hourly_rate)) }).catch(()=>null)
      fetch(`/api/timesheets?contractorId=${d.contractorId}`).then(r=>r.ok?r.json():null)
        .then(td=>{
          if (!td?.timesheets) return
          setTimesheets(td.timesheets.map((t: Record<string,unknown>)=>({
            id: t.id, period: `${MONTHS[Number(t.month??1)-1]} ${t.year}`,
            year: Number(t.year), month: Number(t.month),
            hours: Number(t.total_hours??0),
            rate: Number((t.contractor as Record<string,unknown>)?.hourly_rate??0),
            status: t.status,
            submittedDate: t.submitted_at ? new Date(t.submitted_at as string).toLocaleDateString('en-AU',{day:'numeric',month:'short',year:'numeric'}) : '—',
            reviewedDate: t.reviewed_at ? new Date(t.reviewed_at as string).toLocaleDateString('en-AU',{day:'numeric',month:'short',year:'numeric'}) : undefined,
            rejectionReason: t.rejection_reason as string|undefined,
            reviewer: t.reviewer_name as string|undefined,
            intakeSource: t.intake_source as string|undefined,
            weeks: (t.week_breakdown as WeekRow[])??[],
            canResubmit: t.status==='REJECTED',
          })))
        }).catch(()=>null)
    }).catch(()=>null).finally(()=>setLoading(false))
  }, [])

  useEffect(()=>{
    const labels = getWeeksInMonth(selYear, selMonth)
    setWeeks(labels.map(l=>({label:l, regular:'', overtime:''})))
  }, [selYear, selMonth])

  const setWeekField = (i:number, field:'regular'|'overtime', val:string) =>
    setWeeks(ws=>ws.map((w,idx)=>idx===i?{...w,[field]:val}:w))

  const totalHours = weeks.reduce((s,w)=>(parseFloat(w.regular)||0)+(parseFloat(w.overtime)||0)+s, 0)
  const estimatedGross = totalHours * rate

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return
    setFileName(file.name)
    const reader = new FileReader()
    reader.onload = ev => setFileData((ev.target?.result as string).split(',')[1]??null)
    reader.readAsDataURL(file)
  }

  const openNewForm = (resubmit?: TSRecord) => {
    if (resubmit) { setSelYear(resubmit.year); setSelMonth(resubmit.month); setResubmitId(resubmit.id) }
    else { setSelYear(now.getFullYear()); setSelMonth(now.getMonth()+1); setResubmitId(null) }
    setNotes(''); setFileName(null); setFileData(null); setFormError(null); setSubmitDone(false); setShowForm(true)
  }

  const handleSubmit = async () => {
    if (totalHours <= 0) { setFormError('Please enter at least some hours.'); return }
    if (!contractorId)   { setFormError('Not authenticated.'); return }
    setSubmitting(true); setFormError(null)
    try {
      const weekBreakdown: WeekRow[] = weeks
        .filter(w=>(parseFloat(w.regular)||0)+(parseFloat(w.overtime)||0)>0)
        .map(w=>({week:w.label, regular:parseFloat(w.regular)||0, overtime:parseFloat(w.overtime)||0, total:(parseFloat(w.regular)||0)+(parseFloat(w.overtime)||0)}))
      const body: Record<string,unknown> = {contractorId, year:selYear, month:selMonth, totalHours, weekBreakdown, intakeSource:'PORTAL', notes:notes.trim()||undefined, resubmitOf:resubmitId??undefined}
      if (fileData && fileName) { body.fileData=fileData; body.fileName=fileName; body.fileType=fileName.endsWith('.pdf')?'application/pdf':'image/jpeg' }
      const res = await fetch('/api/timesheets', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)})
      const data = await res.json()
      if (!res.ok) throw new Error(data.error||'Submission failed')
      setSubmitDone(true)
      const newTs: TSRecord = {
        id: data.timesheet?.id??`tmp-${Date.now()}`, period:`${MONTHS[selMonth-1]} ${selYear}`,
        year:selYear, month:selMonth, hours:totalHours, rate, status:'SUBMITTED',
        submittedDate:new Date().toLocaleDateString('en-AU',{day:'numeric',month:'short',year:'numeric'}),
        weeks:weekBreakdown, intakeSource:'Portal',
      }
      setTimesheets(prev=>[newTs,...prev.filter(t=>t.id!==resubmitId)])
      setTimeout(()=>{setShowForm(false);setSubmitDone(false)}, 1800)
    } catch (err) { setFormError(err instanceof Error?err.message:'Submission failed') }
    setSubmitting(false)
  }

  const monthOptions = Array.from({length:6},(_,i)=>{
    const d = new Date(now.getFullYear(), now.getMonth()-i, 1)
    return {year:d.getFullYear(), month:d.getMonth()+1, label:`${MONTHS[d.getMonth()]} ${d.getFullYear()}`}
  })

  const fieldStyle = {width:80,padding:'6px 10px',border:`1.5px solid ${B.border}`,borderRadius:7,fontFamily:"'DM Mono',monospace",fontSize:13,color:B.text,outline:'none'}

  return (
    <main style={{flex:1,padding:'28px 32px',background:B.bg,maxWidth:860,width:'100%',margin:'0 auto'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:24}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:700,color:B.text,marginBottom:4}}>My timesheets</h1>
          <p style={{fontSize:14,color:B.dim}}>Submit and track your timesheet history.</p>
        </div>
        {!showForm && <button onClick={()=>openNewForm()} className="btn btn-accent" style={{padding:'10px 20px'}}>+ Submit timesheet</button>}
      </div>

      {showForm && (
        <div className="card" style={{padding:'24px 28px',marginBottom:24,animation:'up .28s ease both'}}>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:20}}>
            <h2 style={{fontSize:15,fontWeight:700,color:B.text}}>{resubmitId?'↻ Resubmit timesheet':'+ New timesheet submission'}</h2>
            <button onClick={()=>setShowForm(false)} style={{background:'none',border:'none',fontSize:18,cursor:'pointer',color:B.sub}}>✕</button>
          </div>
          {submitDone ? (
            <div style={{textAlign:'center',padding:'24px 0'}}>
              <div style={{fontSize:40,marginBottom:12}}>✅</div>
              <div style={{fontSize:15,fontWeight:700,color:B.green}}>Timesheet submitted!</div>
              <div style={{fontSize:13,color:B.dim,marginTop:6}}>Your agency will review it within 1 business day.</div>
            </div>
          ) : (<>
            <div style={{marginBottom:18}}>
              <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>Pay period</label>
              <select value={`${selYear}-${selMonth}`} onChange={e=>{const[y,m]=e.target.value.split('-').map(Number);setSelYear(y);setSelMonth(m)}} disabled={!!resubmitId}
                style={{padding:'10px 13px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,background:B.surface}}>
                {monthOptions.map(o=><option key={`${o.year}-${o.month}`} value={`${o.year}-${o.month}`}>{o.label}</option>)}
              </select>
            </div>

            <div style={{marginBottom:18}}>
              <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:8}}>Weekly hours</div>
              <div style={{border:`1px solid ${B.border}`,borderRadius:10,overflow:'hidden'}}>
                <table style={{width:'100%',borderCollapse:'collapse'}}>
                  <thead><tr style={{background:B.bg}}>
                    {['Week','Regular hrs','Overtime hrs','Total'].map(h=>(
                      <th key={h} style={{padding:'8px 14px',textAlign:'left',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.05em',color:B.sub}}>{h}</th>
                    ))}
                  </tr></thead>
                  <tbody>
                    {weeks.map((w,i)=>{
                      const reg=parseFloat(w.regular)||0, ot=parseFloat(w.overtime)||0, tot=reg+ot
                      return (<tr key={i} style={{borderTop:`1px solid ${B.faint}`}}>
                        <td style={{padding:'8px 14px',fontSize:13,color:B.mid,whiteSpace:'nowrap'}}>{w.label}</td>
                        <td style={{padding:'6px 14px'}}>
                          <input type="number" min="0" max="50" step="0.5" value={w.regular} onChange={e=>setWeekField(i,'regular',e.target.value)} placeholder="0"
                            style={fieldStyle} onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}/>
                        </td>
                        <td style={{padding:'6px 14px'}}>
                          <input type="number" min="0" max="40" step="0.5" value={w.overtime} onChange={e=>setWeekField(i,'overtime',e.target.value)} placeholder="0"
                            style={fieldStyle} onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}/>
                        </td>
                        <td style={{padding:'8px 14px',fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:600,color:tot>0?B.text:B.sub}}>{tot>0?`${tot}h`:'—'}</td>
                      </tr>)
                    })}
                    <tr style={{borderTop:`2px solid ${B.border}`,background:B.bg}}>
                      <td style={{padding:'10px 14px',fontSize:13,fontWeight:700,color:B.text}}>Total</td>
                      <td style={{padding:'10px 14px',fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:700,color:B.mid}}>{weeks.reduce((s,w)=>s+(parseFloat(w.regular)||0),0)}h</td>
                      <td style={{padding:'10px 14px',fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:700,color:B.amber}}>
                        {weeks.reduce((s,w)=>s+(parseFloat(w.overtime)||0),0)>0?`${weeks.reduce((s,w)=>s+(parseFloat(w.overtime)||0),0)}h`:'—'}
                      </td>
                      <td style={{padding:'10px 14px',fontFamily:"'DM Mono',monospace",fontSize:14,fontWeight:700,color:totalHours>0?B.accent:B.sub}}>{totalHours>0?`${totalHours}h`:'—'}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              {totalHours>0&&rate>0&&(
                <div style={{marginTop:10,padding:'10px 14px',background:B.gP,border:`1px solid ${B.gB}`,borderRadius:9,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                  <span style={{fontSize:13,color:B.green}}>Estimated gross earnings</span>
                  <span style={{fontFamily:"'DM Mono',monospace",fontSize:15,fontWeight:700,color:B.green}}>{fmt(estimatedGross)}</span>
                </div>
              )}
            </div>

            <div style={{marginBottom:18}}>
              <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>Notes (optional)</label>
              <textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Leave taken, public holidays, notes for your agency…" rows={2}
                style={{width:'100%',padding:'10px 13px',border:`1.5px solid ${B.border}`,borderRadius:9,fontFamily:"'DM Sans',sans-serif",fontSize:13.5,color:B.text,resize:'vertical',outline:'none',boxSizing:'border-box'}}
                onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}/>
            </div>

            <div style={{marginBottom:22}}>
              <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>Supporting document (optional)</label>
              <div onClick={()=>fileRef.current?.click()}
                style={{border:`2px dashed ${fileName?B.green:B.border}`,borderRadius:10,padding:'14px 20px',cursor:'pointer',display:'flex',alignItems:'center',gap:14,background:fileName?B.gP:B.bg,transition:'all .15s'}}>
                <span style={{fontSize:22}}>{fileName?'📄':'📎'}</span>
                <div>
                  <div style={{fontSize:13.5,fontWeight:600,color:fileName?B.green:B.text}}>{fileName??'Click to attach a PDF or image'}</div>
                  <div style={{fontSize:12,color:B.sub,marginTop:2}}>{fileName?'Click to replace':'PDF, JPG or PNG — max 10 MB'}</div>
                </div>
                {fileName&&<button onClick={e=>{e.stopPropagation();setFileName(null);setFileData(null)}} style={{marginLeft:'auto',background:'none',border:'none',cursor:'pointer',fontSize:16,color:B.sub}}>✕</button>}
              </div>
              <input ref={fileRef} type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileChange} style={{display:'none'}}/>
            </div>

            {formError&&<div style={{padding:'11px 14px',background:B.rP,border:`1px solid ${B.rB}`,borderRadius:9,fontSize:13,color:B.red,marginBottom:16}}>⚠ {formError}</div>}

            <div style={{display:'flex',gap:10,justifyContent:'flex-end'}}>
              <button onClick={()=>setShowForm(false)} className="btn btn-ghost">Cancel</button>
              <button onClick={handleSubmit} disabled={submitting||totalHours<=0} className="btn btn-accent"
                style={{opacity:(submitting||totalHours<=0)?.6:1}}>
                {submitting?'Submitting…':resubmitId?'↻ Resubmit':'✓ Submit timesheet'}
              </button>
            </div>
          </>)}
        </div>
      )}

      {loading ? (
        <div style={{display:'flex',flexDirection:'column',gap:10}}>
          {[1,2,3].map(i=>(
            <div key={i} className="card" style={{padding:'20px',height:72}}>
              <div className="skel" style={{height:16,width:'40%',marginBottom:8}}/><div className="skel" style={{height:13,width:'60%'}}/>
            </div>
          ))}
        </div>
      ) : timesheets.length===0&&!showForm ? (
        <div className="card" style={{padding:'48px',textAlign:'center'}}>
          <div style={{fontSize:36,marginBottom:12}}>📄</div>
          <div style={{fontSize:15,fontWeight:600,color:B.text,marginBottom:8}}>No timesheets yet</div>
          <div style={{fontSize:13.5,color:B.dim,marginBottom:20}}>Submit your first timesheet to get started.</div>
          <button onClick={()=>openNewForm()} className="btn btn-accent">+ Submit timesheet</button>
        </div>
      ) : (
        <div style={{display:'flex',flexDirection:'column',gap:10}}>
          {timesheets.map(ts=>{
            const sp = STATUS_STYLE[ts.status]||{bg:B.faint,c:B.dim,label:ts.status,icon:'🔔'}
            const open = expanded===ts.id
            return (
              <div key={ts.id} className="card" style={{overflow:'hidden'}}>
                <button onClick={()=>setExpanded(prev=>prev===ts.id?null:ts.id)}
                  style={{width:'100%',display:'flex',alignItems:'center',gap:16,padding:'16px 20px',border:'none',background:'transparent',cursor:'pointer',fontFamily:"'DM Sans',sans-serif",textAlign:'left'}}>
                  <div style={{flex:1}}>
                    <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:4,flexWrap:'wrap'}}>
                      <span style={{fontSize:15,fontWeight:600,color:B.text}}>{ts.period}</span>
                      <span style={{fontSize:11.5,fontWeight:600,padding:'3px 9px',borderRadius:100,background:sp.bg,color:sp.c}}>{sp.icon} {sp.label}</span>
                    </div>
                    <div style={{fontSize:12.5,color:B.dim}}>
                      Submitted {ts.submittedDate}{ts.reviewedDate&&` · Reviewed ${ts.reviewedDate}`}{ts.reviewer&&` by ${ts.reviewer}`}
                    </div>
                  </div>
                  <div style={{textAlign:'right',flexShrink:0}}>
                    <div style={{fontFamily:"'DM Mono',monospace",fontSize:15,fontWeight:700,color:B.text}}>{ts.hours}h</div>
                    <div style={{fontFamily:"'DM Mono',monospace",fontSize:12.5,color:B.green}}>{fmt(ts.hours*ts.rate)}</div>
                  </div>
                  <span style={{fontSize:13,color:B.sub,transform:open?'rotate(180deg)':'none',transition:'transform .2s',flexShrink:0}}>▼</span>
                </button>
                {open&&(
                  <div style={{borderTop:`1px solid ${B.faint}`,animation:'up .2s ease both'}}>
                    {ts.rejectionReason&&(
                      <div style={{margin:'16px 20px 0',padding:'13px 16px',background:B.rP,border:`1px solid ${B.rB}`,borderRadius:10}}>
                        <div style={{fontSize:12.5,fontWeight:700,color:B.red,marginBottom:5}}>⚠ Returned for correction</div>
                        <div style={{fontSize:13.5,color:B.red,lineHeight:1.55}}>{ts.rejectionReason}</div>
                      </div>
                    )}
                    {ts.weeks.length>0&&(
                      <div style={{padding:'16px 20px'}}>
                        <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:10}}>Weekly breakdown</div>
                        <table style={{width:'100%',borderCollapse:'collapse'}}>
                          <thead><tr style={{background:B.bg}}>
                            {['Week','Regular','Overtime','Total'].map(h=><th key={h} style={{padding:'7px 12px',textAlign:'left',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.sub}}>{h}</th>)}
                          </tr></thead>
                          <tbody>
                            {ts.weeks.map((w,i)=>(
                              <tr key={i} style={{borderTop:`1px solid ${B.faint}`}}>
                                <td style={{padding:'8px 12px',fontSize:13,color:B.text}}>{w.week}</td>
                                <td style={{padding:'8px 12px',fontFamily:"'DM Mono',monospace",fontSize:12.5,color:B.mid}}>{w.regular}h</td>
                                <td style={{padding:'8px 12px',fontFamily:"'DM Mono',monospace",fontSize:12.5,color:w.overtime>0?B.amber:B.sub}}>{w.overtime>0?`${w.overtime}h`:'—'}</td>
                                <td style={{padding:'8px 12px',fontFamily:"'DM Mono',monospace",fontSize:13,fontWeight:600,color:B.text}}>{w.total}h</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                    <div style={{padding:'12px 20px 16px',display:'flex',justifyContent:'space-between',alignItems:'center',borderTop:`1px solid ${B.faint}`,background:B.bg,flexWrap:'wrap',gap:12}}>
                      <div style={{display:'flex',gap:24}}>
                        {[['Rate',fmt(ts.rate)+'/hr'],['Gross',fmt(ts.hours*ts.rate)]].map(([k,v])=>(
                          <div key={k}><div style={{fontSize:11,color:B.sub,marginBottom:2}}>{k}</div><div style={{fontFamily:"'DM Mono',monospace",fontSize:13.5,fontWeight:600,color:B.dim}}>{v}</div></div>
                        ))}
                      </div>
                      {ts.canResubmit&&<button onClick={()=>openNewForm(ts)} className="btn btn-accent btn-sm">↻ Resubmit corrected</button>}
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </main>
  )
}
