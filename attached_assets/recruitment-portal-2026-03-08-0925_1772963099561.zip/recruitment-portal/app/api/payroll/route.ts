// app/api/payroll/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { sendNotification } from '@/lib/notifications'
import { logAudit } from '@/lib/audit'

// Simplified PAYG calculation (ATO weekly tax tables Scale 1 approximation)
function calculatePayg(annualGross: number, claimThreshold = true): number {
  const threshold = claimThreshold ? 18200 : 0
  if (annualGross <= threshold) return 0
  if (annualGross <= 45000) return (annualGross - threshold) * 0.19
  if (annualGross <= 120000) return 5092 + (annualGross - 45000) * 0.325
  if (annualGross <= 180000) return 29467 + (annualGross - 120000) * 0.37
  return 51667 + (annualGross - 180000) * 0.45
}

// GET /api/payroll — list pay runs
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const year   = searchParams.get('year')
    const month  = searchParams.get('month')

    let query = supabase
      .from('pay_runs')
      .select('*, pay_run_lines(count)')
      .order('period_end', { ascending: false })

    if (status) query = query.eq('status', status)
    if (year)   query = query.eq('year', Number(year))
    if (month)  query = query.eq('month', Number(month))

    const { data, error } = await query
    if (error) throw new Error(error.message)
    return NextResponse.json({ payRuns: data })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// POST /api/payroll — create a new pay run with lines
export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body     = await request.json()
    const { year, month, periodStart, periodEnd, paymentDate, superRate = 0.115, createdBy } = body

    if (!year || !month || !periodStart || !periodEnd || !paymentDate) {
      return NextResponse.json({ error: 'year, month, periodStart, periodEnd, paymentDate required' }, { status: 400 })
    }

    // Check for duplicate
    const { data: existing } = await supabase
      .from('pay_runs')
      .select('id')
      .eq('year', year)
      .eq('month', month)
      .neq('status', 'VOIDED')
      .limit(1)

    if (existing && existing.length > 0) {
      return NextResponse.json({ error: `A pay run for ${year}/${month} already exists` }, { status: 409 })
    }

    // Fetch all approved timesheet versions for this period
    const { data: versions, error: vErr } = await supabase
      .from('timesheet_versions')
      .select(`
        id, contractor_id, total_hours, gross_value,
        contractor:contractors(id, hourly_rate, pay_frequency, first_name, last_name)
      `)
      .eq('year', year)
      .eq('month', month)
      .eq('status', 'APPROVED')

    if (vErr) throw new Error(vErr.message)

    // Create the pay run header
    const { data: run, error: runErr } = await supabase
      .from('pay_runs')
      .insert({
        year,
        month,
        period_start:  periodStart,
        period_end:    periodEnd,
        payment_date:  paymentDate,
        super_rate:    superRate,
        status:        'DRAFT',
        created_by:    createdBy ?? null,
      })
      .select()
      .single()

    if (runErr) throw new Error(runErr.message)

    // Build and insert pay run lines
    const lines = (versions ?? []).map((v: Record<string,unknown>) => {
      const c = v.contractor as Record<string,unknown>
      const hours = Number(v.total_hours ?? 0)
      const rate  = Number(c?.hourly_rate ?? 0)
      const gross = hours * rate
      const annualGross = gross * 12 // estimate for PAYG rate band
      const paygAnnual  = calculatePayg(annualGross)
      const payg        = Math.round((paygAnnual / 12) * 100) / 100
      const super_amt   = Math.round(gross * superRate * 100) / 100
      const net         = Math.round((gross - payg) * 100) / 100
      return {
        pay_run_id:     run.id,
        contractor_id:  v.contractor_id,
        version_id:     v.id,
        hours_worked:   hours,
        rate_per_hour:  rate,
        gross_earnings: gross,
        payg_withheld:  payg,
        super_amount:   super_amt,
        net_pay:        net,
        status:         'INCLUDED',
      }
    })

    if (lines.length > 0) {
      const { error: linesErr } = await supabase.from('pay_run_lines').insert(lines)
      if (linesErr) throw new Error(linesErr.message)
    }

    // Totals
    const totals = lines.reduce((acc, l) => ({
      gross: acc.gross + l.gross_earnings,
      payg:  acc.payg  + l.payg_withheld,
      super: acc.super + l.super_amount,
      net:   acc.net   + l.net_pay,
    }), { gross: 0, payg: 0, super: 0, net: 0 })

    await supabase
      .from('pay_runs')
      .update({
        total_gross:  totals.gross,
        total_payg:   totals.payg,
        total_super:  totals.super,
        total_net:    totals.net,
        line_count:   lines.length,
      })
      .eq('id', run.id)

    await logAudit({
      action: 'CREATE_PAY_RUN',
      targetType: 'pay_run',
      targetId: run.id,
      userId: createdBy,
      metadata: { year, month, lineCount: lines.length, ...totals },
    })

    return NextResponse.json({ success: true, payRun: run, lineCount: lines.length, totals }, { status: 201 })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// PATCH /api/payroll — update status (DRAFT → REVIEW → APPROVED → FILED / VOIDED)
export async function PATCH(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { payRunId, status, updatedBy } = await request.json()

    if (!payRunId || !status) {
      return NextResponse.json({ error: 'payRunId and status required' }, { status: 400 })
    }

    const VALID_TRANSITIONS: Record<string, string[]> = {
      DRAFT:    ['REVIEW', 'VOIDED'],
      REVIEW:   ['DRAFT', 'APPROVED', 'VOIDED'],
      APPROVED: ['FILED', 'VOIDED'],
    }

    const { data: run } = await supabase.from('pay_runs').select('status').eq('id', payRunId).single()
    if (!run) return NextResponse.json({ error: 'Pay run not found' }, { status: 404 })

    const allowed = VALID_TRANSITIONS[run.status] ?? []
    if (!allowed.includes(status)) {
      return NextResponse.json({
        error: `Cannot transition from ${run.status} to ${status}`,
      }, { status: 422 })
    }

    await supabase.from('pay_runs').update({ status, updated_by: updatedBy ?? null }).eq('id', payRunId)

    // Notify contractors when approved (payslips available soon)
    if (status === 'APPROVED') {
      const { data: lines } = await supabase
        .from('pay_run_lines')
        .select('contractor_id, contractors(profile_id)')
        .eq('pay_run_id', payRunId)

      for (const line of (lines ?? []) as Record<string,unknown>[]) {
        const c = line.contractors as Record<string,unknown>
        if (c?.profile_id) {
          await sendNotification({
            userId:       c.profile_id as string,
            type:         'SYSTEM',
            priority:     'MEDIUM',
            title:        'Your payslip is being processed',
            body:         'Your pay run has been approved. Your payslip and payment will be ready on your payment date.',
            contractorId: line.contractor_id as string,
          })
        }
      }
    }

    // Accrue leave balances when pay run is FILED
    // Annual leave: 4 weeks / 52 = 0.07692 weeks per week worked
    // Sick/personal leave: 10 days / 52 = 0.19231 days per week
    if (status === 'FILED') {
      const { data: run } = await supabase
        .from('pay_runs')
        .select('year, month, pay_run_lines(contractor_id, hours_worked)')
        .eq('id', payRunId)
        .single()

      if (run) {
        const fy = Number(run.month) >= 7
          ? `${run.year}-${run.year + 1}`
          : `${run.year - 1}-${run.year}`

        for (const line of ((run.pay_run_lines ?? []) as Record<string,unknown>[])) {
          const contractorId = line.contractor_id as string
          const hoursWorked  = Number(line.hours_worked ?? 0)

          // Annual leave accrual: 4 wks/yr = 160h/yr ÷ 52 weeks × weeks worked
          // Approximate: hours_worked / 52 * 4 = hours_worked * 4/52
          const annualLeaveAccrual = Math.round((hoursWorked * (4 / 52)) * 100) / 100

          // Sick leave: 10 days/yr × 7.6h/day = 76h ÷ 52 weeks
          const sickLeaveAccrual = Math.round((hoursWorked * (76 / 2080)) * 100) / 100

          for (const [leaveType, accrualHours] of [
            ['ANNUAL', annualLeaveAccrual],
            ['SICK',   sickLeaveAccrual],
          ] as [string, number][]) {
            // Upsert leave balance
            const { data: existing } = await supabase
              .from('leave_balances')
              .select('id, balance_hours')
              .eq('contractor_id', contractorId)
              .eq('leave_type', leaveType)
              .eq('financial_year', fy)
              .single()

            if (existing) {
              await supabase
                .from('leave_balances')
                .update({
                  accrued_hours:   Number(existing.balance_hours) + accrualHours,
                  last_accrual_at: new Date().toISOString(),
                })
                .eq('id', existing.id)
            } else {
              await supabase.from('leave_balances').insert({
                contractor_id:  contractorId,
                leave_type:     leaveType,
                financial_year: fy,
                accrued_hours:  accrualHours,
                taken_hours:    0,
                last_accrual_at: new Date().toISOString(),
              })
            }
          }
        }
      }
    }

    return NextResponse.json({ success: true, status })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
