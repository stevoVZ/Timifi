// app/api/dashboard/route.ts
// Single endpoint for admin dashboard KPI aggregates
// Returns: contractor counts, timesheet queue, invoice totals, payroll summary, recent activity

import { NextResponse } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'

export async function GET() {
  try {
    const supabase = createServiceClient()
    const now      = new Date()
    const year     = now.getFullYear()
    const month    = now.getMonth() + 1
    const fyStart  = month >= 7 ? `${year}-07-01` : `${year - 1}-07-01`

    // Run all queries in parallel
    const [
      contractorRes,
      timesheetRes,
      invoiceRes,
      payRunRes,
      overdueInvRes,
      ytdBillingsRes,
      recentActivityRes,
    ] = await Promise.all([
      // Contractor counts by status
      supabase
        .from('contractors')
        .select('status')
        .neq('status', 'OFFBOARDED'),

      // Timesheets pending review
      supabase
        .from('timesheets')
        .select('id, status')
        .in('status', ['SUBMITTED', 'PENDING']),

      // Outstanding invoices (AUTHORISED + SENT)
      supabase
        .from('invoices')
        .select('total_amount, status')
        .in('status', ['AUTHORISED', 'SENT', 'OVERDUE'])
        .gte('created_at', `${year - 1}-07-01`),

      // Current month approved timesheets for pay run card
      supabase
        .from('timesheets')
        .select('id, status')
        .eq('year', year)
        .eq('month', month)
        .eq('status', 'APPROVED'),

      // Overdue invoices count
      supabase
        .from('invoices')
        .select('id, total_amount')
        .eq('status', 'OVERDUE'),

      // YTD billings (paid invoices this FY)
      supabase
        .from('invoices')
        .select('total_amount')
        .eq('status', 'PAID')
        .gte('created_at', fyStart),

      // Recent audit log for activity feed
      supabase
        .from('audit_log')
        .select('id, action, target_type, target_id, created_at, metadata, user_id')
        .order('created_at', { ascending: false })
        .limit(8),
    ])

    // Contractor stats
    const contractors = contractorRes.data ?? []
    const activeContractors  = contractors.filter(c => c.status === 'ACTIVE').length
    const pendingContractors = contractors.filter(c => c.status === 'PENDING_SETUP').length

    // Timesheet stats
    const tSheets            = timesheetRes.data ?? []
    const submittedTimesheets = tSheets.filter(t => t.status === 'SUBMITTED').length
    const pendingTimesheets   = tSheets.length

    // Invoice stats
    const invoices           = invoiceRes.data ?? []
    const outstandingAmount  = invoices
      .filter(i => i.status !== 'OVERDUE')
      .reduce((s, i) => s + Number(i.total_amount ?? 0), 0)
    const outstandingCount   = invoices.filter(i => ['AUTHORISED','SENT'].includes(i.status)).length

    const overdueInvs        = overdueInvRes.data ?? []
    const overdueAmount      = overdueInvs.reduce((s, i) => s + Number(i.total_amount ?? 0), 0)
    const overdueCount       = overdueInvs.length

    // Pay run stats
    const approvedThisMonth  = payRunRes.data?.length ?? 0

    // YTD billings
    const ytdBillings        = (ytdBillingsRes.data ?? [])
      .reduce((s, i) => s + Number(i.total_amount ?? 0), 0)

    // Recent activity from audit log
    const activityMap: Record<string, { icon: string; col: string }> = {
      CREATE_TIMESHEET:      { icon: '📄', col: '#b45309' },
      APPROVE_TIMESHEET:     { icon: '✅', col: '#16a34a' },
      REJECT_TIMESHEET:      { icon: '❌', col: '#dc2626' },
      CREATE_INVOICE:        { icon: '🧾', col: '#2563eb' },
      PAY_RUN_FILED:         { icon: '💳', col: '#16a34a' },
      ABA_GENERATED:         { icon: '🏦', col: '#7c3aed' },
      CONTRACTOR_INVITED:    { icon: '✉️', col: '#2563eb' },
      TAX_DECLARATION_SUBMITTED: { icon: '📋', col: '#059669' },
      BANK_ACCOUNT_ADDED:    { icon: '🏦', col: '#059669' },
      UPDATE_CONTRACTOR:     { icon: '👤', col: '#6b7280' },
      PAYSLIPS_GENERATED:    { icon: '📬', col: '#7c3aed' },
      LEAVE_APPROVED:        { icon: '🌿', col: '#16a34a' },
      LEAVE_REJECTED:        { icon: '🚫', col: '#dc2626' },
    }

    const recentActivity = (recentActivityRes.data ?? []).map(a => {
      const meta = activityMap[a.action] ?? { icon: '🔔', col: '#6b7280' }
      const label = a.action
        .replace(/_/g, ' ')
        .toLowerCase()
        .replace(/^\w/, (c: string) => c.toUpperCase())
      return {
        id:     a.id,
        icon:   meta.icon,
        col:    meta.col,
        text:   label,
        time:   new Date(a.created_at).toLocaleDateString('en-AU', {
          day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
        }),
        action: a.action,
        targetType: a.target_type,
        targetId:   a.target_id,
      }
    })

    return NextResponse.json({
      contractors: {
        active:    activeContractors,
        pending:   pendingContractors,
        total:     contractors.length,
      },
      timesheets: {
        submitted: submittedTimesheets,
        pending:   pendingTimesheets,
      },
      invoices: {
        outstandingAmount,
        outstandingCount,
        overdueAmount,
        overdueCount,
      },
      payRun: {
        approvedThisMonth,
        currentMonth: `${['January','February','March','April','May','June','July','August','September','October','November','December'][month-1]} ${year}`,
      },
      ytdBillings,
      recentActivity,
      _generatedAt: now.toISOString(),
    })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
