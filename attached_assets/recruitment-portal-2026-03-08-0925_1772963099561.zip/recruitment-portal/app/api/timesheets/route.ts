// app/api/timesheets/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'
import { sendNotification } from '@/lib/notifications'

// ──────────────────────────────────────────────────────────────────────────────
// GET — list timesheet versions with filters
// ?contractorId=  ?status=  ?year=  ?month=  ?portal=true  ?limit=
// ──────────────────────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { searchParams } = new URL(request.url)
    const contractorId = searchParams.get('contractorId')
    const status       = searchParams.get('status')
    const year         = searchParams.get('year')
    const month        = searchParams.get('month')
    const portal       = searchParams.get('portal') === 'true'
    const limit        = Math.min(Number(searchParams.get('limit') ?? 50), 200)

    let query = supabase
      .from('timesheet_versions')
      .select(`
        id, contractor_id, year, month, total_hours, gross_value, status,
        submitted_at, reviewed_at, rejection_reason, intake_source,
        week_breakdown, period_label,
        reviewer:profiles!reviewed_by(full_name),
        contractor:contractors(id, first_name, last_name, hourly_rate, profile_id)
      `)
      .order('year',  { ascending: false })
      .order('month', { ascending: false })
      .limit(limit)

    if (contractorId) query = query.eq('contractor_id', contractorId)
    if (status)       query = query.eq('status', status)
    if (year)         query = query.eq('year', Number(year))
    if (month)        query = query.eq('month', Number(month))

    if (portal) {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return NextResponse.json({ error: 'Unauthenticated' }, { status: 401 })
      const { data: c } = await supabase.from('contractors').select('id').eq('profile_id', user.id).single()
      if (c) query = query.eq('contractor_id', c.id)
    }

    const { data, error } = await query
    if (error) throw new Error(error.message)

    return NextResponse.json({
      timesheets: (data ?? []).map(t => ({
        ...t,
        reviewer_name: (t.reviewer as Record<string,unknown>)?.full_name ?? null,
      })),
    })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// POST — submit a new timesheet (portal self-service OR admin upload)
// Body: { contractorId, year, month, totalHours, weekBreakdown, intakeSource,
//         notes, resubmitOf, fileData, fileName, fileType,
//         // admin fields:
//         extractedData, uploadedBy, uploadedByRole, intakeSenderEmail }
// ──────────────────────────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body = await request.json()
    const {
      contractorId, year, month, totalHours, weekBreakdown,
      intakeSource, notes, resubmitOf,
      fileData, fileName, fileType,
      // Admin-upload fields (from TimesheetUpload component)
      extractedData, uploadedBy, uploadedByRole,
      intakeSenderEmail, intakeReceivedDate, intakeNotes,
    } = body

    if (!contractorId || !year || !month) {
      return NextResponse.json({ error: 'contractorId, year, month required' }, { status: 400 })
    }

    const hours = Number(totalHours ?? extractedData?.totalHours ?? 0)
    if (hours <= 0) {
      return NextResponse.json({ error: 'totalHours must be > 0' }, { status: 400 })
    }

    // Fetch contractor rate for gross calculation
    const { data: contractor } = await supabase
      .from('contractors').select('hourly_rate, profile_id, first_name, last_name')
      .eq('id', contractorId).single()
    const rate  = Number(contractor?.hourly_rate ?? 0)
    const gross = hours * rate

    const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December']
    const periodLabel = `${MONTHS[Number(month)-1]} ${year}`

    // Get next version number for this contractor+period
    const { data: existing } = await supabase
      .from('timesheet_versions')
      .select('id, version_number')
      .eq('contractor_id', contractorId)
      .eq('year', Number(year))
      .eq('month', Number(month))
      .order('version_number', { ascending: false })
      .limit(1)

    const nextVersion = ((existing?.[0]?.version_number as number) ?? 0) + 1

    // Upsert parent timesheet record
    const { data: tsRecord, error: tsErr } = await supabase
      .from('timesheets')
      .upsert({
        contractor_id: contractorId,
        year:          Number(year),
        month:         Number(month),
        status:        'SUBMITTED',
        total_hours:   hours,
        gross_value:   gross,
        period_label:  periodLabel,
        submitted_at:  new Date().toISOString(),
        intake_source: intakeSource ?? 'PORTAL',
      }, {
        onConflict: 'contractor_id,year,month',
        ignoreDuplicates: false,
      })
      .select('id')
      .single()

    if (tsErr) throw new Error(`Timesheet upsert: ${tsErr.message}`)

    // Upload file to Supabase Storage if provided
    let fileUrl: string | null = null
    if (fileData && fileName) {
      const buffer      = Buffer.from(fileData, 'base64')
      const storagePath = `${contractorId}/${year}-${String(month).padStart(2,'0')}/v${nextVersion}-${fileName}`
      const { error: uploadErr } = await supabase.storage
        .from('timesheets')
        .upload(storagePath, buffer, { contentType: fileType ?? 'application/pdf', upsert: true })
      if (!uploadErr) fileUrl = storagePath
    }

    // Create version record
    const versionPayload: Record<string,unknown> = {
      timesheet_id:    tsRecord.id,
      contractor_id:   contractorId,
      year:            Number(year),
      month:           Number(month),
      version_number:  nextVersion,
      status:          'SUBMITTED',
      total_hours:     hours,
      gross_value:     gross,
      period_label:    periodLabel,
      week_breakdown:  weekBreakdown ?? extractedData?.weeks ?? null,
      intake_source:   intakeSource ?? 'PORTAL',
      submitted_at:    new Date().toISOString(),
      file_url:        fileUrl,
      notes:           notes ?? intakeNotes ?? null,
      uploaded_by:     uploadedBy ?? null,
      uploaded_by_role: uploadedByRole ?? null,
      intake_sender_email: intakeSenderEmail ?? null,
      intake_received_date: intakeReceivedDate ?? null,
      resubmit_of:     resubmitOf ?? null,
      // Store full extracted data from AI scan
      extracted_data:  extractedData ?? null,
      regular_hours:   weekBreakdown?.reduce((s: number, w: Record<string,unknown>) => s + Number(w.regular ?? 0), 0) ?? null,
      overtime_hours:  weekBreakdown?.reduce((s: number, w: Record<string,unknown>) => s + Number(w.overtime ?? 0), 0) ?? null,
    }

    const { data: version, error: vErr } = await supabase
      .from('timesheet_versions')
      .insert(versionPayload)
      .select()
      .single()

    if (vErr) throw new Error(`Version insert: ${vErr.message}`)

    // Notify admin team of new submission
    const { data: admins } = await supabase
      .from('profiles')
      .select('id')
      .in('role', ['admin', 'consultant'])
      .limit(5)

    for (const admin of admins ?? []) {
      await sendNotification({
        userId:       admin.id,
        type:         'TIMESHEET',
        priority:     'MEDIUM',
        title:        `New timesheet: ${contractor?.first_name} ${contractor?.last_name} — ${periodLabel}`,
        body:         `${hours}h submitted via ${intakeSource ?? 'Portal'}`,
        contractorId,
        link:         '/admin/timesheets',
      }).catch(() => null)
    }

    await logAudit({
      action:     'CREATE_TIMESHEET',
      targetType: 'timesheet_version',
      targetId:   version.id,
      metadata:   { contractorId, year, month, hours, intakeSource, version: nextVersion },
    })

    return NextResponse.json({ timesheet: version, timesheetId: tsRecord.id }, { status: 201 })
  } catch (err: unknown) {
    console.error('[POST /api/timesheets]', err)
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// PATCH — approve or reject a timesheet version
// Body: { versionId, action: 'approve'|'reject', rejectionReason?, reviewerName?, reviewerId? }
// ──────────────────────────────────────────────────────────────────────────────
export async function PATCH(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { versionId, action, rejectionReason, reviewerName, reviewerId } = await request.json()

    if (!versionId || !action) {
      return NextResponse.json({ error: 'versionId and action are required' }, { status: 400 })
    }
    if (!['approve', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'action must be approve or reject' }, { status: 400 })
    }
    if (action === 'reject' && !rejectionReason?.trim()) {
      return NextResponse.json({ error: 'rejectionReason required for rejection' }, { status: 400 })
    }

    const { data: version, error: vErr } = await supabase
      .from('timesheet_versions')
      .select('*, contractor:contractors(id, profile_id, first_name, last_name)')
      .eq('id', versionId)
      .single()

    if (vErr || !version) return NextResponse.json({ error: 'Version not found' }, { status: 404 })
    if (version.status !== 'SUBMITTED') {
      return NextResponse.json({ error: `Cannot ${action} a timesheet in ${version.status} status` }, { status: 422 })
    }

    const now       = new Date().toISOString()
    const newStatus = action === 'approve' ? 'APPROVED' : 'REJECTED'
    const patch: Record<string, unknown> = { status: newStatus }

    if (action === 'approve') {
      patch.approved_at = now
      patch.approved_by = reviewerId ?? null
    } else {
      patch.rejected_at      = now
      patch.rejected_by      = reviewerId ?? null
      patch.rejection_reason = rejectionReason.trim()
    }

    await supabase.from('timesheet_versions').update(patch).eq('id', versionId)

    // Sync parent timesheet status
    if (version.timesheet_id) {
      await supabase.from('timesheets').update({
        status:           newStatus,
        reviewed_at:      now,
        reviewed_by:      reviewerId ?? null,
        rejection_reason: action === 'reject' ? rejectionReason : null,
      }).eq('id', version.timesheet_id)
    }

    await logAudit({
      userId: reviewerId, userName: reviewerName,
      action: action === 'approve' ? 'APPROVE_TIMESHEET' : 'REJECT_TIMESHEET',
      targetType: 'timesheet_version', targetId: versionId,
      metadata: { contractorId: version.contractor_id, month: version.month, year: version.year, reason: rejectionReason },
    })

    const c = version.contractor as Record<string,unknown>
    if (c?.profile_id) {
      await sendNotification({
        userId:       c.profile_id as string,
        type:         'TIMESHEET',
        priority:     action === 'reject' ? 'HIGH' : 'MEDIUM',
        title:        action === 'approve'
          ? `Timesheet approved — ${version.period_label ?? `${version.month}/${version.year}`}`
          : `Timesheet returned — ${version.period_label ?? `${version.month}/${version.year}`}`,
        body:         action === 'reject' ? rejectionReason : 'Your payslip will be ready on your payment date.',
        contractorId: version.contractor_id,
        link:         '/portal/timesheets',
      })
    }

    return NextResponse.json({ success: true, status: newStatus })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
