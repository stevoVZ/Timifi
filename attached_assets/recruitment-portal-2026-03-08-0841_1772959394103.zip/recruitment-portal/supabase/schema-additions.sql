-- =============================================================================
-- Schema additions — run AFTER schema.sql
-- Adds: leave_requests, pay_items, portal_settings, contractor_pay_items
-- =============================================================================

-- New enums
CREATE TYPE leave_type   AS ENUM ('ANNUAL','SICK','LONG_SERVICE','PERSONAL','COMPASSIONATE','UNPAID','PUBLIC_HOLIDAY');
CREATE TYPE leave_status AS ENUM ('PENDING','APPROVED','REJECTED','CANCELLED');

-- =============================================================================
-- PORTAL SETTINGS (single row per portal instance — upsert on id=1)
-- =============================================================================

CREATE TABLE portal_settings (
  id                     INTEGER     PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  -- Branding
  agency_name            TEXT        NOT NULL DEFAULT 'Recruitment Portal',
  accent_color           TEXT        NOT NULL DEFAULT '#2563eb',
  logo_url               TEXT,
  primary_email          TEXT,
  -- Company
  abn                    TEXT,
  acn                    TEXT,
  registered_name        TEXT,
  street_address         TEXT,
  suburb                 TEXT,
  state                  CHAR(3),
  postcode               TEXT,
  phone                  TEXT,
  -- Payroll
  super_rate             NUMERIC(5,4) NOT NULL DEFAULT 0.1150,
  payment_terms_days     SMALLINT    NOT NULL DEFAULT 14,
  default_pay_calendar   pay_calendar NOT NULL DEFAULT 'MONTHLY',
  stp_enabled            BOOLEAN     NOT NULL DEFAULT TRUE,
  auto_super_calc        BOOLEAN     NOT NULL DEFAULT TRUE,
  -- Portal access
  contractor_portal      BOOLEAN     NOT NULL DEFAULT TRUE,
  contractor_upload      BOOLEAN     NOT NULL DEFAULT FALSE,
  mfa_required           BOOLEAN     NOT NULL DEFAULT FALSE,
  session_timeout_mins   SMALLINT    NOT NULL DEFAULT 60,
  -- Meta
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by             UUID        REFERENCES profiles(id)
);

ALTER TABLE portal_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings: admin write" ON portal_settings FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "settings: staff read"  ON portal_settings FOR SELECT USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));

-- Insert default row
INSERT INTO portal_settings (id) VALUES (1) ON CONFLICT DO NOTHING;

-- =============================================================================
-- PAY ITEMS (pay codes / earnings types)
-- =============================================================================

CREATE TABLE pay_items (
  id                UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  code              TEXT        NOT NULL UNIQUE,       -- e.g. "ORDINARY", "OVERTIME_1_5"
  name              TEXT        NOT NULL,
  description       TEXT,
  item_type         TEXT        NOT NULL DEFAULT 'EARNINGS', -- EARNINGS | DEDUCTION | ALLOWANCE | LEAVE
  rate_multiplier   NUMERIC(5,3) NOT NULL DEFAULT 1.000,     -- 1.0 = ordinary, 1.5 = OT, 2.0 = double
  is_active         BOOLEAN     NOT NULL DEFAULT TRUE,
  is_system         BOOLEAN     NOT NULL DEFAULT FALSE,      -- system items cannot be deleted
  xero_payroll_id   TEXT,
  ato_category      TEXT,                                     -- ATO STP2 category code
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE pay_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pay_items: admin write"  ON pay_items FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin');
CREATE POLICY "pay_items: staff read"   ON pay_items FOR SELECT USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));

-- Default system pay items
INSERT INTO pay_items (code, name, description, item_type, rate_multiplier, is_system, ato_category) VALUES
  ('ORDINARY',       'Ordinary time earnings',    'Standard hourly rate',                      'EARNINGS',  1.000, TRUE,  'OrdinaryTimeEarnings'),
  ('OVERTIME_1_5',   'Overtime 1.5×',             'Time and a half',                           'EARNINGS',  1.500, TRUE,  'OvertimeEarnings'),
  ('OVERTIME_2_0',   'Overtime 2.0×',             'Double time',                               'EARNINGS',  2.000, TRUE,  'OvertimeEarnings'),
  ('ALLOWANCE_CAR',  'Car allowance',             'Per km or flat rate car allowance',         'ALLOWANCE', 1.000, FALSE, 'AllowanceTypeOther'),
  ('ALLOWANCE_PHONE','Phone allowance',           'Mobile phone allowance',                    'ALLOWANCE', 1.000, FALSE, 'AllowanceTypeOther'),
  ('ALLOWANCE_MEAL', 'Meal allowance',            'Meal/entertainment allowance',              'ALLOWANCE', 1.000, FALSE, 'AllowanceTypeMeals'),
  ('LEAVE_ANNUAL',   'Annual leave payout',       'Payout of accrued annual leave',            'LEAVE',     1.000, TRUE,  'AnnualLeaveLoading'),
  ('LEAVE_SICK',     'Sick leave',                'Personal/carer leave',                      'LEAVE',     1.000, TRUE,  'PersonalLeaveEarnings'),
  ('PAYG',           'PAYG withholding',          'Income tax withheld',                       'DEDUCTION', 1.000, TRUE,  NULL),
  ('SUPER_SGC',      'Superannuation SGC',        'Superannuation guarantee contribution',     'DEDUCTION', 1.000, TRUE,  NULL)
ON CONFLICT (code) DO NOTHING;

-- =============================================================================
-- LEAVE REQUESTS
-- =============================================================================

CREATE TABLE leave_requests (
  id              UUID           PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id   UUID           NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  leave_type      leave_type     NOT NULL,
  status          leave_status   NOT NULL DEFAULT 'PENDING',
  -- Dates
  start_date      DATE           NOT NULL,
  end_date        DATE           NOT NULL,
  total_days      NUMERIC(4,1)   NOT NULL,
  total_hours     NUMERIC(6,2),
  -- Notes
  reason          TEXT,
  admin_notes     TEXT,
  -- Approval
  reviewed_by     UUID           REFERENCES profiles(id),
  reviewed_at     TIMESTAMPTZ,
  rejection_reason TEXT,
  -- Accrual (for annual leave)
  is_paid         BOOLEAN        NOT NULL DEFAULT TRUE,
  leave_balance_before NUMERIC(6,2),
  leave_balance_after  NUMERIC(6,2),
  -- Xero
  xero_leave_id   TEXT,
  -- Meta
  submitted_by    UUID           REFERENCES profiles(id),
  created_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);

ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "leave: admin_consultant all" ON leave_requests FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "leave: contractor own"       ON leave_requests FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());
CREATE POLICY "leave: contractor request"   ON leave_requests FOR INSERT WITH CHECK ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- =============================================================================
-- LEAVE BALANCES (per contractor per leave type — updated by triggers/API)
-- =============================================================================

CREATE TABLE leave_balances (
  id              UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
  contractor_id   UUID        NOT NULL REFERENCES contractors(id) ON DELETE CASCADE,
  leave_type      leave_type  NOT NULL,
  accrued_hours   NUMERIC(7,2) NOT NULL DEFAULT 0,
  taken_hours     NUMERIC(7,2) NOT NULL DEFAULT 0,
  balance_hours   NUMERIC(7,2) GENERATED ALWAYS AS (accrued_hours - taken_hours) STORED,
  balance_days    NUMERIC(5,1) GENERATED ALWAYS AS (ROUND((accrued_hours - taken_hours) / 7.6, 1)) STORED,
  financial_year  TEXT        NOT NULL,  -- e.g. "2025-26"
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (contractor_id, leave_type, financial_year)
);

ALTER TABLE leave_balances ENABLE ROW LEVEL SECURITY;
CREATE POLICY "lb: admin_consultant" ON leave_balances FOR ALL    USING ((SELECT role FROM profiles WHERE id = auth.uid()) IN ('admin','consultant'));
CREATE POLICY "lb: contractor own"   ON leave_balances FOR SELECT USING ((SELECT profile_id FROM contractors WHERE id = contractor_id) = auth.uid());

-- Seed balances for FY2025-26
INSERT INTO leave_balances (contractor_id, leave_type, accrued_hours, taken_hours, financial_year)
SELECT c.id, 'ANNUAL'::leave_type, 152.0, 0, '2025-26'
FROM contractors c WHERE c.status = 'ACTIVE'
ON CONFLICT DO NOTHING;

-- =============================================================================
-- TRIGGERS — leave + pay items updated_at
-- =============================================================================

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['pay_items','leave_requests','leave_balances','portal_settings'] LOOP
    EXECUTE format(
      'CREATE TRIGGER trg_updated_at_%1$s BEFORE UPDATE ON %1$I FOR EACH ROW EXECUTE FUNCTION update_updated_at()',
      t
    );
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- =============================================================================
-- INDEXES
-- =============================================================================

CREATE INDEX idx_leave_contractor   ON leave_requests(contractor_id);
CREATE INDEX idx_leave_status       ON leave_requests(status);
CREATE INDEX idx_leave_dates        ON leave_requests(start_date, end_date);
CREATE INDEX idx_leave_bal_contractor ON leave_balances(contractor_id);
