'use client'
// components/portal/PortalShell.tsx
import type { ReactNode } from 'react'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { B } from '@/lib/design'

const NAV = [
  { label:'Dashboard', href:'/portal/dashboard', icon:'▦'  },
  { label:'Timesheets',href:'/portal/timesheets', icon:'📄' },
  { label:'Payslips',  href:'/portal/payslips',  icon:'💵' },
  { label:'Messages',  href:'/portal/messages',  icon:'✉️' },
  { label:'Leave',     href:'/portal/leave',     icon:'🏖️' },
]

export default function PortalShell({ children, fullName }: { children: ReactNode; fullName: string }) {
  const pathname = usePathname()
  const router   = useRouter()
  const supabase = createClient()
  const [unread, setUnread] = useState(0)

  const initials = fullName.split(' ').map(p => p[0]).join('').toUpperCase().slice(0,2)

  useEffect(() => {
    // Check unread messages
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (!user) return
      const { count } = await supabase.from('messages').select('id', { count:'exact', head:true }).eq('to_user_id', user.id).eq('read', false)
      setUnread(count ?? 0)
    })
  }, [])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push('/portal/login')
  }

  return (
    <div style={{ display:'flex', flexDirection:'column', minHeight:'100vh', background:B.bg, fontFamily:"'DM Sans',sans-serif" }}>
      {/* Top header */}
      <header style={{
        height:58, background:B.surface, borderBottom:`1px solid ${B.border}`,
        display:'flex', alignItems:'center', padding:'0 24px', gap:16,
        position:'sticky', top:0, zIndex:20,
      }}>
        {/* Logo */}
        <div style={{ display:'flex', alignItems:'center', gap:10, marginRight:8 }}>
          <div style={{ width:30,height:30,borderRadius:8,background:B.accent,display:'flex',alignItems:'center',justifyContent:'center',fontSize:15 }}>🏢</div>
          <span style={{ fontSize:14, fontWeight:700, color:B.text }}>Contractor Portal</span>
        </div>

        {/* Nav */}
        <nav style={{ display:'flex', gap:2, flex:1 }}>
          {NAV.map(item => {
            const active = pathname.startsWith(item.href)
            const isMsgs = item.href.includes('messages')
            return (
              <Link key={item.href} href={item.href} style={{
                display:'flex', alignItems:'center', gap:7,
                padding:'8px 14px', borderRadius:8, textDecoration:'none',
                background: active ? B.aP : 'transparent',
                color:      active ? B.accent : B.dim,
                fontWeight: active ? 600 : 400,
                fontSize:13.5, transition:'all .12s', position:'relative',
              }}
              onMouseEnter={e => { if(!active)(e.currentTarget as HTMLElement).style.background=B.faint }}
              onMouseLeave={e => { if(!active)(e.currentTarget as HTMLElement).style.background='transparent' }}
              >
                <span style={{fontSize:15}}>{item.icon}</span>
                {item.label}
                {isMsgs && unread > 0 && (
                  <span style={{fontSize:10,fontWeight:700,padding:'1px 5px',borderRadius:10,background:B.red,color:'#fff',marginLeft:2}}>{unread}</span>
                )}
              </Link>
            )
          })}
        </nav>

        {/* User */}
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <span style={{ fontSize:13.5, color:B.dim, fontWeight:500 }}>{fullName}</span>
          <button onClick={handleSignOut} style={{
            padding:'7px 14px', borderRadius:8, border:`1.5px solid ${B.border}`,
            background:'transparent', cursor:'pointer', fontSize:12.5,
            color:B.dim, fontFamily:"'DM Sans',sans-serif", fontWeight:600,
            transition:'all .13s',
          }}
          onMouseEnter={e => { (e.currentTarget.style.borderColor=B.red); (e.currentTarget.style.color=B.red) }}
          onMouseLeave={e => { (e.currentTarget.style.borderColor=B.border); (e.currentTarget.style.color=B.dim) }}
          >Sign out</button>
        </div>
      </header>

      {/* Page content */}
      <div style={{ flex:1, display:'flex', flexDirection:'column' }}>
        {children}
      </div>
    </div>
  )
}
