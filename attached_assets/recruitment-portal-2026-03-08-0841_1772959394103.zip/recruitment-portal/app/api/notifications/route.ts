// app/api/notifications/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'

// GET /api/notifications?userId=...&unreadOnly=true
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { searchParams } = new URL(request.url)
    const userId     = searchParams.get('userId')
    const unreadOnly = searchParams.get('unreadOnly') === 'true'
    const countOnly  = searchParams.get('countOnly')  === 'true'

    if (!userId) return NextResponse.json({ error: 'userId required' }, { status: 400 })

    let query = supabase
      .from('notifications')
      .select(countOnly ? 'id' : '*', { count: 'exact', head: countOnly })
      .eq('user_id', userId)
      .eq('dismissed', false)
      .order('created_at', { ascending: false })

    if (unreadOnly) query = query.eq('read', false)

    const { data, count, error } = await query
    if (error) throw new Error(error.message)

    return NextResponse.json(countOnly ? { count } : { notifications: data, count })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// PATCH /api/notifications — mark read / dismiss
export async function PATCH(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body     = await request.json()
    const { notificationId, notificationIds, action, userId } = body

    const ids: string[] = notificationId ? [notificationId] : (notificationIds ?? [])
    if (ids.length === 0 && action !== 'markAllRead') {
      return NextResponse.json({ error: 'notificationId, notificationIds, or markAllRead action required' }, { status: 400 })
    }

    const patch: Record<string, unknown> = {}
    if (action === 'markRead'    || action === 'markAllRead') { patch.read = true; patch.read_at = new Date().toISOString() }
    if (action === 'dismiss')    patch.dismissed = true

    if (action === 'markAllRead' && userId) {
      await supabase.from('notifications').update(patch).eq('user_id', userId).eq('read', false)
    } else {
      await supabase.from('notifications').update(patch).in('id', ids)
    }

    return NextResponse.json({ success: true })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
