// app/api/leave/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { sendNotification } from '@/lib/notifications'
import { logAudit } from '@/lib/audit'

export async function GET(request: NextRequest) {
  try {
    const supabase      = createServiceClient()
    const { searchParams } = new URL(request.url)
    const contractorId  = searchParams.get('contractorId')
    const status        = searchParams.get('status')

    let query = supabase
      .from('leave_requests')
      .select(`
        *,
        contractor:contractors(id, first_name, last_name, email, profile_id)
      `)
      .order('created_at', { ascending: false })

    if (contractorId) query = query.eq('contractor_id', contractorId)
    if (status)       query = query.eq('status', status)

    const { data, error } = await query
    if (error) throw new Error(error.message)
    return NextResponse.json({ requests: data })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body     = await request.json()
    const { contractorId, leaveType, startDate, endDate, totalDays, totalHours, reason, submittedBy } = body

    if (!contractorId || !leaveType || !startDate || !endDate) {
      return NextResponse.json({ error: 'contractorId, leaveType, startDate, endDate are required' }, { status: 400 })
    }

    // Check for date overlap
    const { data: overlap } = await supabase
      .from('leave_requests')
      .select('id')
      .eq('contractor_id', contractorId)
      .in('status', ['PENDING', 'APPROVED'])
      .lte('start_date', endDate)
      .gte('end_date', startDate)
      .limit(1)

    if (overlap && overlap.length > 0) {
      return NextResponse.json({ error: 'Leave request overlaps with an existing request' }, { status: 409 })
    }

    const { data, error } = await supabase
      .from('leave_requests')
      .insert({
        contractor_id: contractorId,
        leave_type:    leaveType,
        start_date:    startDate,
        end_date:      endDate,
        total_days:    totalDays ?? 1,
        total_hours:   totalHours ?? null,
        reason:        reason ?? null,
        submitted_by:  submittedBy ?? null,
        status:        'PENDING',
      })
      .select()
      .single()

    if (error) throw new Error(error.message)

    await logAudit({ action: 'UPDATE_CONTRACTOR', targetType: 'leave_request', targetId: data.id, metadata: { action: 'CREATED', leaveType, startDate, endDate } })

    return NextResponse.json({ request: data }, { status: 201 })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body     = await request.json()
    const { requestId, action, reviewerId, reviewerName, rejectionReason, adminNotes } = body

    if (!requestId || !action) {
      return NextResponse.json({ error: 'requestId and action required' }, { status: 400 })
    }

    const newStatus = action === 'approve' ? 'APPROVED' : action === 'reject' ? 'REJECTED' : 'CANCELLED'

    const { data: req, error: rErr } = await supabase
      .from('leave_requests')
      .update({
        status:           newStatus,
        reviewed_by:      reviewerId ?? null,
        reviewed_at:      new Date().toISOString(),
        rejection_reason: action === 'reject' ? rejectionReason : null,
        admin_notes:      adminNotes ?? null,
      })
      .eq('id', requestId)
      .select('*, contractor:contractors(profile_id, first_name)')
      .single()

    if (rErr) throw new Error(rErr.message)

    // Notify contractor
    if (req.contractor?.profile_id) {
      await sendNotification({
        userId:       req.contractor.profile_id,
        type:         'SYSTEM',
        priority:     action === 'reject' ? 'HIGH' : 'MEDIUM',
        title:        action === 'approve'
          ? `Leave approved — ${req.start_date} to ${req.end_date}`
          : `Leave request returned — ${req.start_date} to ${req.end_date}`,
        body:         action === 'reject' ? rejectionReason : undefined,
        contractorId: req.contractor_id,
      })
    }

    return NextResponse.json({ success: true, status: newStatus })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
