// app/api/contractors/[id]/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'

type Params = { params: { id: string } }

export async function GET(_req: NextRequest, { params }: Params) {
  try {
    const supabase = createServiceClient()
    const { data, error } = await supabase
      .from('contractors')
      .select(`
        *, 
        timesheets(id, year, month, total_hours, gross_value, status),
        invoices(id, invoice_number, year, month, amount_incl_gst, status, due_date),
        leave_balances(leave_type, accrued_hours, taken_hours, balance_hours, balance_days, financial_year)
      `)
      .eq('id', params.id)
      .single()

    if (error || !data) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    return NextResponse.json({ contractor: data })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest, { params }: Params) {
  try {
    const supabase = createServiceClient()
    const body     = await request.json()
    const { updatedBy, ...fields } = body

    // camelCase → snake_case map
    const colMap: Record<string, string> = {
      firstName:       'first_name',
      lastName:        'last_name',
      email:           'email',
      phone:           'phone',
      jobTitle:        'job_title',
      clientName:      'client_name',
      hourlyRate:      'hourly_rate',
      contractHoursPA: 'contract_hours_pa',
      startDate:       'start_date',
      endDate:         'end_date',
      status:          'status',
      clearanceLevel:  'clearance_level',
      clearanceExpiry: 'clearance_expiry',
      suburb:          'suburb',
      state:           'state',
      postcode:        'postcode',
      addressLine1:    'address_line1',
      notes:           'notes',
      xeroEmployeeId:  'xero_employee_id',
      xeroContactId:   'xero_contact_id',
    }

    const patch: Record<string, unknown> = {}
    for (const [camel, snake] of Object.entries(colMap)) {
      if (fields[camel] !== undefined) patch[snake] = fields[camel]
    }

    if (Object.keys(patch).length === 0) {
      return NextResponse.json({ error: 'No valid fields to update' }, { status: 400 })
    }

    const { data, error } = await supabase
      .from('contractors')
      .update(patch)
      .eq('id', params.id)
      .select()
      .single()

    if (error) throw new Error(error.message)

    await logAudit({
      action:     'UPDATE_CONTRACTOR',
      targetType: 'contractor',
      targetId:   params.id,
      userId:     updatedBy,
      metadata:   { fields: Object.keys(patch) },
    })

    return NextResponse.json({ contractor: data })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

export async function DELETE(_req: NextRequest, { params }: Params) {
  try {
    const supabase = createServiceClient()

    // Safety: check no APPROVED timesheets or PAID invoices
    const { data: ts } = await supabase
      .from('timesheets')
      .select('id')
      .eq('contractor_id', params.id)
      .in('status', ['APPROVED', 'SUBMITTED'])
      .limit(1)

    if (ts && ts.length > 0) {
      return NextResponse.json(
        { error: 'Cannot delete contractor with active timesheets. Offboard them instead.' },
        { status: 422 }
      )
    }

    // Soft-delete via status change
    await supabase
      .from('contractors')
      .update({ status: 'OFFBOARDED', end_date: new Date().toISOString().slice(0, 10) })
      .eq('id', params.id)

    await logAudit({ action: 'UPDATE_CONTRACTOR', targetType: 'contractor', targetId: params.id, metadata: { action: 'OFFBOARDED' } })

    return NextResponse.json({ success: true, message: 'Contractor offboarded' })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
