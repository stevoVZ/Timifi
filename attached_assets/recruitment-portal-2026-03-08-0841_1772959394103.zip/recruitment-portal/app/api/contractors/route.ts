// app/api/contractors/route.ts
import { NextResponse, type NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import { logAudit } from '@/lib/audit'

// GET /api/contractors — list all contractors
export async function GET(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')

    let query = supabase
      .from('contractors')
      .select(`
        id, first_name, last_name, email, phone,
        status, job_title, client_name, hourly_rate,
        contract_hours_pa, start_date, end_date,
        clearance_level, clearance_expiry,
        xero_employee_id, xero_contact_id,
        created_at, updated_at,
        profile_id
      `)
      .order('created_at', { ascending: false })

    if (status) query = query.eq('status', status)

    const { data, error } = await query
    if (error) throw new Error(error.message)

    return NextResponse.json({ contractors: data })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}

// POST /api/contractors — create new contractor
export async function POST(request: NextRequest) {
  try {
    const supabase = createServiceClient()
    const body     = await request.json()

    const {
      firstName, lastName, email, phone,
      jobTitle, clientName, hourlyRate, contractHoursPA,
      startDate, endDate, clearanceLevel, clearanceExpiry,
      employmentType, incomeType, payFrequency,
      suburb, state, postcode, addressLine1,
      notes, createdBy,
    } = body

    // Validate required fields
    if (!firstName || !lastName || !email) {
      return NextResponse.json({ error: 'firstName, lastName, and email are required' }, { status: 400 })
    }

    // Check email uniqueness
    const { data: existing } = await supabase
      .from('contractors')
      .select('id')
      .eq('email', email)
      .maybeSingle()

    if (existing) {
      return NextResponse.json({ error: `A contractor with email ${email} already exists` }, { status: 409 })
    }

    const { data, error } = await supabase
      .from('contractors')
      .insert({
        first_name:        firstName,
        last_name:         lastName,
        email:             email.toLowerCase().trim(),
        phone:             phone         ?? null,
        job_title:         jobTitle      ?? null,
        client_name:       clientName    ?? null,
        hourly_rate:       hourlyRate    ?? null,
        contract_hours_pa: contractHoursPA ?? 2000,
        start_date:        startDate     ?? null,
        end_date:          endDate       ?? null,
        clearance_level:   clearanceLevel ?? 'NONE',
        clearance_expiry:  clearanceExpiry ?? null,
        employment_type:   employmentType ?? 'LABOURHIRE',
        income_type:       incomeType    ?? 'LABOURHIRE',
        pay_frequency:     payFrequency  ?? 'MONTHLY',
        address_line1:     addressLine1  ?? null,
        suburb:            suburb        ?? null,
        state:             state         ?? null,
        postcode:          postcode      ?? null,
        notes:             notes         ?? null,
        status:            'PENDING_SETUP',
        created_by:        createdBy     ?? null,
      })
      .select()
      .single()

    if (error) throw new Error(error.message)

    await logAudit({
      action:     'CREATE_CONTRACTOR',
      targetType: 'contractor',
      targetId:   data.id,
      userId:     createdBy,
      metadata:   { name: `${firstName} ${lastName}`, email },
    })

    return NextResponse.json({ contractor: data }, { status: 201 })
  } catch (err: unknown) {
    return NextResponse.json({ error: err instanceof Error ? err.message : 'Unknown' }, { status: 500 })
  }
}
