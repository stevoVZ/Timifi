'use client'
// app/portal/leave/page.tsx
import { useState } from 'react'
import { B } from '@/lib/design'

const LEAVE_TYPE_OPTS = [
  {v:'ANNUAL',       l:'Annual leave',       icon:'🏖️'},
  {v:'SICK',         l:'Personal / sick',    icon:'🏥'},
  {v:'COMPASSIONATE',l:'Compassionate',      icon:'💛'},
  {v:'UNPAID',       l:'Unpaid leave',       icon:'⏸️'},
]

const STATUS_STYLE: Record<string,{bg:string,c:string}> = {
  PENDING:  {bg:B.aLP,  c:B.amber },
  APPROVED: {bg:B.gP,   c:B.green },
  REJECTED: {bg:B.rP,   c:B.red   },
  CANCELLED:{bg:B.faint,c:B.dim   },
}

interface LeaveReq { id:string; leaveType:string; startDate:string; endDate:string; totalDays:number; status:string; reason:string; submittedDate:string }

const HISTORY: LeaveReq[] = [
  {id:'l1',leaveType:'ANNUAL',startDate:'14 Apr 2026',endDate:'18 Apr 2026',totalDays:5,status:'PENDING', reason:'Easter break',submittedDate:'4 Mar 2026'},
  {id:'l2',leaveType:'SICK',  startDate:'3 Mar 2026', endDate:'4 Mar 2026', totalDays:2,status:'APPROVED',reason:'Flu',         submittedDate:'3 Mar 2026'},
  {id:'l3',leaveType:'ANNUAL',startDate:'6 Jan 2026', endDate:'9 Jan 2026', totalDays:4,status:'APPROVED',reason:'New Year',    submittedDate:'18 Dec 2025'},
]

const BALANCES = [
  {label:'Annual leave',  icon:'🏖️', days:19.0, hours:144.4, total:20},
  {label:'Personal/sick', icon:'🏥', days:8.0,  hours:60.8,  total:10},
]

export default function PortalLeave() {
  const [tab,       setTab]       = useState<'history'|'request'>('history')
  const [form,      setForm]      = useState({leaveType:'ANNUAL',startDate:'',endDate:'',reason:''})
  const [submitting,setSubmitting]= useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [history,   setHistory]   = useState<LeaveReq[]>(HISTORY)
  const [errors,    setErrors]    = useState<string[]>([])

  const handleSubmit = async () => {
    const errs: string[] = []
    if (!form.startDate) errs.push('Start date is required')
    if (!form.endDate)   errs.push('End date is required')
    if (form.startDate && form.endDate && form.startDate > form.endDate) errs.push('End date must be after start date')
    if (errs.length) { setErrors(errs); return }
    setErrors([])

    setSubmitting(true)
    await fetch('/api/leave', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        contractorId:'c1', leaveType:form.leaveType,
        startDate:form.startDate, endDate:form.endDate,
        totalDays:1, reason:form.reason,
      }),
    }).catch(()=>null)

    // Optimistic update
    setHistory(prev => [{
      id:'new-'+Date.now(), leaveType:form.leaveType,
      startDate:form.startDate, endDate:form.endDate,
      totalDays:1, status:'PENDING', reason:form.reason,
      submittedDate:'Today',
    }, ...prev])
    setSubmitting(false)
    setSubmitted(true)
    setForm({leaveType:'ANNUAL',startDate:'',endDate:'',reason:''})
    setTab('history')
  }

  return (
    <main style={{flex:1,padding:'28px 32px',background:B.bg,maxWidth:820,width:'100%',margin:'0 auto'}}>
      <div style={{marginBottom:24}}>
        <h1 style={{fontSize:20,fontWeight:700,color:B.text,marginBottom:4}}>Leave</h1>
        <p style={{fontSize:14,color:B.dim}}>View your leave balances and submit requests.</p>
      </div>

      {submitted && (
        <div style={{padding:'12px 16px',background:B.gP,border:`1px solid ${B.gB}`,borderRadius:10,marginBottom:18,fontSize:13.5,color:B.green,fontWeight:600}}>
          ✓ Leave request submitted — your agency will review it shortly.
        </div>
      )}

      {/* Leave balances */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14,marginBottom:24}}>
        {BALANCES.map(b=>(
          <div key={b.label} className="card" style={{padding:'16px 18px'}}>
            <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
              <span style={{fontSize:20}}>{b.icon}</span>
              <span style={{fontSize:13,fontWeight:700,color:B.text}}>{b.label}</span>
            </div>
            <div style={{fontFamily:"'DM Mono',monospace",fontSize:22,fontWeight:700,color:B.accent,marginBottom:4}}>{b.days}d</div>
            <div style={{fontSize:12.5,color:B.dim,marginBottom:8}}>{b.hours}h available</div>
            <div style={{height:7,borderRadius:4,background:B.border,overflow:'hidden'}}>
              <div style={{height:'100%',width:`${Math.round((b.days/b.total)*100)}%`,background:B.accent,borderRadius:4}}/>
            </div>
            <div style={{fontSize:12,color:B.sub,marginTop:5}}>{b.total}d total entitlement</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="card" style={{overflow:'hidden'}}>
        <div style={{display:'flex',borderBottom:`1px solid ${B.border}`,padding:'0 4px'}}>
          {([['history','History'],['request','New request']] as const).map(([v,l])=>(
            <button key={v} onClick={()=>{setTab(v);setSubmitted(false)}} className={`tab${tab===v?' on':''}`}>{l}</button>
          ))}
        </div>

        {/* History */}
        {tab==='history' && (
          <div>
            {history.length===0 ? (
              <div style={{padding:'48px',textAlign:'center',color:B.dim}}>
                <div style={{fontSize:28,marginBottom:10}}>📅</div>
                <div style={{fontSize:14,fontWeight:600,color:B.text}}>No leave requests yet</div>
              </div>
            ) : history.map((r,i)=>{
              const sp = STATUS_STYLE[r.status]||{bg:B.faint,c:B.dim}
              const type = LEAVE_TYPE_OPTS.find(o=>o.v===r.leaveType)
              return (
                <div key={r.id} style={{padding:'14px 18px',borderBottom:i<history.length-1?`1px solid ${B.faint}`:'none',display:'flex',alignItems:'center',gap:12}}>
                  <span style={{fontSize:22,flexShrink:0}}>{type?.icon||'📅'}</span>
                  <div style={{flex:1}}>
                    <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:3}}>
                      <span style={{fontSize:14,fontWeight:600,color:B.text}}>{type?.l||r.leaveType}</span>
                      <span style={{fontSize:11.5,fontWeight:600,padding:'2px 8px',borderRadius:100,...sp}}>{r.status}</span>
                    </div>
                    <div style={{fontSize:13,color:B.dim}}>{r.startDate} → {r.endDate} · {r.totalDays}d{r.reason&&` · "${r.reason}"`}</div>
                    <div style={{fontSize:11.5,color:B.sub,marginTop:2}}>Submitted {r.submittedDate}</div>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* New request */}
        {tab==='request' && (
          <div style={{padding:'22px 24px'}}>
            {errors.length>0 && (
              <div style={{padding:'12px 14px',background:B.rP,border:`1px solid ${B.rB}`,borderRadius:9,marginBottom:14}}>
                {errors.map(e=><div key={e} style={{fontSize:13,color:B.red}}>{e}</div>)}
              </div>
            )}
            <div style={{display:'flex',flexDirection:'column',gap:16,maxWidth:480}}>
              <div>
                <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>Leave type</label>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
                  {LEAVE_TYPE_OPTS.map(o=>(
                    <button key={o.v} onClick={()=>setForm(f=>({...f,leaveType:o.v}))} style={{
                      padding:'10px',borderRadius:9,border:'none',cursor:'pointer',
                      fontFamily:"'DM Sans',sans-serif",fontSize:13,fontWeight:600,
                      display:'flex',alignItems:'center',gap:8,justifyContent:'flex-start',
                      background:form.leaveType===o.v?B.aP:B.faint,
                      color:form.leaveType===o.v?B.accent:B.dim,
                      border:`1.5px solid ${form.leaveType===o.v?B.accent:B.border}`,
                      transition:'all .12s',
                    }}>
                      <span style={{fontSize:18}}>{o.icon}</span>{o.l}
                    </button>
                  ))}
                </div>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
                {[['Start date','startDate'],['End date','endDate']].map(([l,f])=>(
                  <div key={f}>
                    <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>{l}</label>
                    <input type="date" value={(form as Record<string,string>)[f]} onChange={e=>setForm(fr=>({...fr,[f]:e.target.value}))}
                      style={{width:'100%',padding:'10px 12px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,background:B.surface,boxSizing:'border-box',outline:'none'}}
                      onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
                    />
                  </div>
                ))}
              </div>
              <div>
                <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:6}}>Reason (optional)</label>
                <textarea value={form.reason} onChange={e=>setForm(f=>({...f,reason:e.target.value}))} rows={3}
                  placeholder="Brief description of your leave request…"
                  style={{width:'100%',padding:'10px 12px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,background:B.surface,resize:'none',boxSizing:'border-box',outline:'none'}}
                  onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
                />
              </div>
              <button onClick={handleSubmit} disabled={submitting} className="btn btn-accent" style={{padding:'12px',fontSize:14,opacity:submitting?0.7:1,width:'100%'}}>
                {submitting ? 'Submitting…' : '📅 Submit leave request →'}
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
