'use client'
// app/admin/leave/page.tsx
import { useState } from 'react'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

const LEAVE_TYPE_LABEL: Record<string,string> = {
  ANNUAL:'Annual leave', SICK:'Personal / sick', LONG_SERVICE:'Long service',
  PERSONAL:'Personal', COMPASSIONATE:'Compassionate', UNPAID:'Unpaid', PUBLIC_HOLIDAY:'Public holiday',
}
const LEAVE_ICON: Record<string,string> = {
  ANNUAL:'🏖️', SICK:'🏥', LONG_SERVICE:'🎖️', PERSONAL:'👤',
  COMPASSIONATE:'💛', UNPAID:'⏸️', PUBLIC_HOLIDAY:'🏛️',
}

interface LeaveReq {
  id:string; contractor:string; initials:string; col:string; bg:string
  leaveType:string; startDate:string; endDate:string; totalDays:number
  status:string; reason?:string; submittedDate:string
}

interface LeaveBalance {
  contractor:string; initials:string; col:string; bg:string
  annualHours:number; sickHours:number; annualDays:number; sickDays:number
}

const REQUESTS: LeaveReq[] = [
  {id:'l1',contractor:'Jordan Kim',  initials:'JK',col:'#7c3aed',bg:'#f5f3ff',leaveType:'ANNUAL',      startDate:'14 Apr 2026',endDate:'18 Apr 2026',totalDays:5, status:'PENDING',  reason:'School holidays — Easter break',submittedDate:'4 Mar 2026'},
  {id:'l2',contractor:'Alex Rivera', initials:'AR',col:'#2563eb',bg:'#eff6ff',leaveType:'SICK',         startDate:'3 Mar 2026', endDate:'4 Mar 2026', totalDays:2, status:'APPROVED', reason:'Flu',submittedDate:'3 Mar 2026'},
  {id:'l3',contractor:'Alex Rivera', initials:'AR',col:'#2563eb',bg:'#eff6ff',leaveType:'ANNUAL',       startDate:'6 Jan 2026', endDate:'9 Jan 2026', totalDays:4, status:'APPROVED', reason:'New Year break',submittedDate:'18 Dec 2025'},
  {id:'l4',contractor:'Jordan Kim',  initials:'JK',col:'#7c3aed',bg:'#f5f3ff',leaveType:'COMPASSIONATE',startDate:'20 Feb 2026',endDate:'20 Feb 2026',totalDays:1, status:'APPROVED', reason:'Family bereavement',submittedDate:'20 Feb 2026'},
]

const BALANCES: LeaveBalance[] = [
  {contractor:'Alex Rivera',initials:'AR',col:'#2563eb',bg:'#eff6ff',annualHours:144.4,sickHours:60.8,annualDays:19.0,sickDays:8.0},
  {contractor:'Jordan Kim', initials:'JK',col:'#7c3aed',bg:'#f5f3ff',annualHours:152.0,sickHours:76.0,annualDays:20.0,sickDays:10.0},
]

const STATUS_STYLE: Record<string,{bg:string,c:string}> = {
  PENDING:  {bg:B.aLP,  c:B.amber },
  APPROVED: {bg:B.gP,   c:B.green },
  REJECTED: {bg:B.rP,   c:B.red   },
  CANCELLED:{bg:B.faint,c:B.dim   },
}

export default function LeavePage() {
  const [requests,  setRequests]  = useState<LeaveReq[]>(REQUESTS)
  const [filter,    setFilter]    = useState('all')
  const [approving, setApproving] = useState<string|null>(null)
  const [rejectId,  setRejectId]  = useState<string|null>(null)
  const [rejectReason, setRejectReason] = useState('')
  const [toast,     setToast]     = useState<string|null>(null)

  const toast_ = (msg:string) => { setToast(msg); setTimeout(()=>setToast(null),3000) }

  const handleApprove = async (id: string) => {
    setApproving(id)
    const res = await fetch('/api/leave', {
      method:'PATCH', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({requestId:id, action:'approve', reviewerName:'Sarah Chen'}),
    }).catch(()=>null)
    setRequests(prev => prev.map(r => r.id===id ? {...r, status:'APPROVED'} : r))
    setApproving(null)
    toast_('✓ Leave approved')
  }

  const handleReject = async () => {
    if (!rejectId) return
    await fetch('/api/leave', {
      method:'PATCH', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({requestId:rejectId, action:'reject', rejectionReason:rejectReason, reviewerName:'Sarah Chen'}),
    }).catch(()=>null)
    setRequests(prev => prev.map(r => r.id===rejectId ? {...r, status:'REJECTED'} : r))
    setRejectId(null)
    setRejectReason('')
    toast_('Leave request returned')
  }

  const filtered = filter==='all' ? requests : requests.filter(r=>r.status===filter)
  const pending  = requests.filter(r=>r.status==='PENDING').length

  return (
    <>
      <TopBar title="Leave management" subtitle={pending>0?`${pending} pending approval`:'All requests reviewed'}/>
      <main style={{flex:1,padding:'28px 32px',background:B.bg}}>
        <div style={{display:'grid',gridTemplateColumns:'1fr 320px',gap:20,alignItems:'start'}}>

          {/* Left: requests */}
          <div>
            {/* Filter */}
            <div style={{display:'flex',gap:6,marginBottom:16}}>
              {[['all','All'],['PENDING','Pending'],['APPROVED','Approved'],['REJECTED','Rejected']].map(([v,l])=>(
                <button key={v} onClick={()=>setFilter(v)} style={{
                  padding:'7px 15px',borderRadius:100,border:'none',cursor:'pointer',
                  fontFamily:"'DM Sans',sans-serif",fontSize:12.5,fontWeight:600,
                  background:filter===v?B.accent:B.surface,color:filter===v?'#fff':B.dim,
                  border:`1.5px solid ${filter===v?B.accent:B.border}`,transition:'all .12s',
                }}>{l}{v==='PENDING'&&pending>0&&<span style={{marginLeft:5,background:'rgba(255,255,255,.25)',borderRadius:10,padding:'0 5px',fontSize:11}}>{pending}</span>}</button>
              ))}
            </div>

            <div style={{display:'flex',flexDirection:'column',gap:10}}>
              {filtered.length===0 && (
                <div style={{padding:'48px',textAlign:'center',background:B.surface,border:`1px solid ${B.border}`,borderRadius:12,color:B.dim}}>
                  <div style={{fontSize:28,marginBottom:10}}>🏖️</div>
                  <div style={{fontSize:14,fontWeight:600,color:B.text,marginBottom:4}}>No {filter!=='all'?filter.toLowerCase()+' ':''} leave requests</div>
                </div>
              )}

              {filtered.map(req => {
                const sp = STATUS_STYLE[req.status]||{bg:B.faint,c:B.dim}
                return (
                  <div key={req.id} className="card" style={{padding:'16px 18px'}}>
                    <div style={{display:'flex',alignItems:'flex-start',gap:12}}>
                      {/* Type icon */}
                      <div style={{width:40,height:40,borderRadius:10,background:req.bg,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20,flexShrink:0}}>
                        {LEAVE_ICON[req.leaveType]||'📅'}
                      </div>

                      <div style={{flex:1,minWidth:0}}>
                        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4,flexWrap:'wrap'}}>
                          <div style={{width:26,height:26,borderRadius:7,background:req.bg,color:req.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,flexShrink:0}}>{req.initials}</div>
                          <span style={{fontSize:14,fontWeight:600,color:B.text}}>{req.contractor}</span>
                          <span style={{fontSize:11,fontWeight:600,padding:'2px 8px',borderRadius:100,...sp}}>{req.status}</span>
                          <span style={{marginLeft:'auto',fontSize:12,color:B.sub}}>Submitted {req.submittedDate}</span>
                        </div>

                        <div style={{fontSize:13.5,fontWeight:600,color:B.text,marginBottom:4}}>
                          {LEAVE_TYPE_LABEL[req.leaveType]||req.leaveType}
                        </div>
                        <div style={{fontSize:13,color:B.dim,marginBottom:req.reason?6:0}}>
                          {req.startDate} → {req.endDate} · <strong style={{color:B.text}}>{req.totalDays} day{req.totalDays!==1?'s':''}</strong>
                        </div>
                        {req.reason && <div style={{fontSize:13,color:B.mid,fontStyle:'italic'}}>"{req.reason}"</div>}
                      </div>

                      {/* Actions */}
                      {req.status==='PENDING' && (
                        <div style={{display:'flex',gap:6,flexShrink:0}}>
                          <button onClick={()=>handleApprove(req.id)} disabled={approving===req.id} style={{
                            padding:'7px 14px',borderRadius:8,border:`1.5px solid ${B.gB}`,background:B.gP,
                            color:B.green,fontSize:12.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif",cursor:'pointer',
                          }}>
                            {approving===req.id?'…':'✓ Approve'}
                          </button>
                          <button onClick={()=>setRejectId(req.id)} style={{
                            padding:'7px 14px',borderRadius:8,border:`1.5px solid ${B.rB}`,background:B.rP,
                            color:B.red,fontSize:12.5,fontWeight:600,fontFamily:"'DM Sans',sans-serif",cursor:'pointer',
                          }}>✕ Return</button>
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Right: balances */}
          <div className="card" style={{overflow:'hidden'}}>
            <div style={{padding:'14px 16px',borderBottom:`1px solid ${B.faint}`,background:B.bg}}>
              <div style={{fontSize:13,fontWeight:700,color:B.text}}>Leave balances — FY2025–26</div>
            </div>
            {BALANCES.map((b,i)=>(
              <div key={b.contractor} style={{padding:'14px 16px',borderBottom:i<BALANCES.length-1?`1px solid ${B.faint}`:'none'}}>
                <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
                  <div style={{width:28,height:28,borderRadius:8,background:b.bg,color:b.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,flexShrink:0}}>{b.initials}</div>
                  <span style={{fontSize:13.5,fontWeight:600,color:B.text}}>{b.contractor}</span>
                </div>
                {[
                  ['🏖️ Annual leave', b.annualDays, b.annualHours, 20, B.accent],
                  ['🏥 Sick leave',   b.sickDays,   b.sickHours,   10, B.amber],
                ].map(([label, days, hours, maxDays, col])=>(
                  <div key={label as string} style={{marginBottom:10}}>
                    <div style={{display:'flex',justifyContent:'space-between',marginBottom:5}}>
                      <span style={{fontSize:12.5,color:B.dim}}>{label}</span>
                      <span style={{fontFamily:"'DM Mono',monospace",fontSize:12.5,color:col as string,fontWeight:600}}>{days}d ({hours}h)</span>
                    </div>
                    <div style={{height:6,borderRadius:3,background:B.border,overflow:'hidden'}}>
                      <div style={{height:'100%',width:`${Math.min(100,Math.round((days as number/(maxDays as number))*100))}%`,background:col as string,borderRadius:3}}/>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Reject modal */}
      {rejectId && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.45)',zIndex:100,display:'flex',alignItems:'center',justifyContent:'center'}}>
          <div className="card" style={{width:440,padding:'24px 26px',margin:16}}>
            <h3 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:4}}>Return leave request</h3>
            <p style={{fontSize:13.5,color:B.dim,marginBottom:14}}>Provide a reason — this will be sent to the contractor.</p>
            <textarea value={rejectReason} onChange={e=>setRejectReason(e.target.value)} rows={3} placeholder="e.g. Dates clash with project deadline — please propose alternate dates."
              style={{width:'100%',padding:'10px 13px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,resize:'none',color:B.text,outline:'none',boxSizing:'border-box'}}
              onFocus={e=>e.target.style.borderColor=B.red} onBlur={e=>e.target.style.borderColor=B.border}
            />
            <div style={{display:'flex',gap:8,marginTop:14,justifyContent:'flex-end'}}>
              <button onClick={()=>setRejectId(null)} className="btn btn-ghost btn-sm">Cancel</button>
              <button onClick={handleReject} disabled={!rejectReason.trim()} className="btn btn-danger btn-sm">
                Return request
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div style={{position:'fixed',bottom:24,right:24,zIndex:999,background:B.text,color:'#fff',padding:'12px 22px',borderRadius:10,fontWeight:600,fontSize:13,boxShadow:'0 4px 16px rgba(0,0,0,.18)'}}>{toast}</div>
      )}
    </>
  )
}
