'use client'
// app/admin/contractors/page.tsx
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

const CONTRACTORS = [
  {id:'c1',firstName:'Alex',  lastName:'Rivera', initials:'AR',col:'#2563eb',bg:'#eff6ff',email:'alex.rivera@email.com', phone:'0412 345 678',status:'ACTIVE',       jobTitle:'Senior Developer',client:'Client A',hourlyRate:120,contractHoursPA:2000,ytdHours:476,startDate:'15 Jan 2024',clearance:'BASELINE',xero:true },
  {id:'c2',firstName:'Jordan',lastName:'Kim',    initials:'JK',col:'#7c3aed',bg:'#f5f3ff',email:'jordan.kim@email.com',  phone:'0423 456 789',status:'ACTIVE',       jobTitle:'Business Analyst',client:'Client B',hourlyRate:95, contractHoursPA:2000,ytdHours:312,startDate:'1 Mar 2024', clearance:'NONE',    xero:true },
  {id:'c3',firstName:'Sam',   lastName:'Okafor', initials:'SO',col:'#059669',bg:'#ecfdf5',email:'sam.okafor@email.com',  phone:'0434 567 890',status:'PENDING_SETUP',jobTitle:'Project Manager',  client:'Client C',hourlyRate:105,contractHoursPA:1800,ytdHours:0,  startDate:'10 Mar 2026',clearance:'NONE',    xero:false},
]

const fmt = (n:number) => '$'+n.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2})

const STATUS_PILL: Record<string,{bg:string,c:string,label:string}> = {
  ACTIVE:        {bg:B.gP,   c:B.green, label:'Active'       },
  PENDING_SETUP: {bg:B.aLP,  c:B.amber, label:'Pending setup'},
  OFFBOARDED:    {bg:B.faint,c:B.dim,   label:'Offboarded'   },
}

type SortField = 'name'|'rate'|'ytd'|'start'
type SortDir   = 'asc'|'desc'

export default function ContractorsPage() {
  const router = useRouter()
  const [search,    setSearch]    = useState('')
  const [statusFlt, setStatusFlt] = useState('all')
  const [sortField, setSortField] = useState<SortField>('name')
  const [sortDir,   setSortDir]   = useState<SortDir>('asc')

  const toggleSort = (field: SortField) => {
    if (sortField === field) setSortDir(d => d==='asc'?'desc':'asc')
    else { setSortField(field); setSortDir('asc') }
  }
  const sortIcon = (f: SortField) => sortField===f ? (sortDir==='asc'?'↑':'↓') : '↕'

  const filtered = CONTRACTORS
    .filter(c => {
      const q = search.toLowerCase()
      if (q && !`${c.firstName} ${c.lastName} ${c.email} ${c.client} ${c.jobTitle}`.toLowerCase().includes(q)) return false
      if (statusFlt !== 'all' && c.status !== statusFlt) return false
      return true
    })
    .sort((a, b) => {
      let av: string|number = '', bv: string|number = ''
      if (sortField==='name')  { av=`${a.lastName} ${a.firstName}`; bv=`${b.lastName} ${b.firstName}` }
      if (sortField==='rate')  { av=a.hourlyRate; bv=b.hourlyRate }
      if (sortField==='ytd')   { av=a.ytdHours; bv=b.ytdHours }
      if (sortField==='start') { av=a.startDate; bv=b.startDate }
      return av < bv ? (sortDir==='asc'?-1:1) : av > bv ? (sortDir==='asc'?1:-1) : 0
    })

  const activeCount = CONTRACTORS.filter(c=>c.status==='ACTIVE').length
  const totalYtd    = CONTRACTORS.reduce((s,c)=>s+c.ytdHours*c.hourlyRate,0)

  return (
    <>
      <TopBar title="Contractors" subtitle={`${activeCount} active · ${CONTRACTORS.filter(c=>c.status==='PENDING_SETUP').length} pending`}
        actions={<button onClick={()=>router.push('/admin/contractors/new')} className="btn btn-accent btn-sm" style={{padding:'8px 16px'}}>+ Add contractor</button>}
      />
      <main style={{flex:1,padding:'28px 32px',background:B.bg}}>

        {/* KPIs */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:14,marginBottom:24}}>
          {[
            ['Active',      `${activeCount}`,   'contractors',     B.green ],
            ['Pending',     `${CONTRACTORS.filter(c=>c.status==='PENDING_SETUP').length}`,'awaiting setup', B.amber],
            ['YTD billings', fmt(totalYtd),     'all contractors', B.accent],
            ['Avg rate',    `$${Math.round(CONTRACTORS.filter(c=>c.status==='ACTIVE').reduce((s,c)=>s+c.hourlyRate,0)/Math.max(1,activeCount))}/hr`,'active contractors',B.dim],
          ].map(([k,v,sub,c])=>(
            <div key={k as string} className="card" style={{padding:'16px 18px'}}>
              <div style={{fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.07em',color:B.dim,marginBottom:6}}>{k}</div>
              <div style={{fontFamily:"'DM Mono',monospace",fontSize:20,fontWeight:700,color:c as string,marginBottom:3}}>{v}</div>
              <div style={{fontSize:12,color:B.sub}}>{sub}</div>
            </div>
          ))}
        </div>

        {/* Search + filters */}
        <div style={{display:'flex',gap:10,marginBottom:16,alignItems:'center',flexWrap:'wrap'}}>
          <div style={{position:'relative',flex:1,maxWidth:360}}>
            <span style={{position:'absolute',left:11,top:'50%',transform:'translateY(-50%)',color:B.sub,fontSize:14}}>🔍</span>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search name, email, client…"
              style={{width:'100%',padding:'9px 12px 9px 34px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:13.5,color:B.text,outline:'none',background:B.surface,boxSizing:'border-box'}}
              onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
            />
          </div>
          <div style={{display:'flex',gap:6}}>
            {[['all','All'],['ACTIVE','Active'],['PENDING_SETUP','Pending'],['OFFBOARDED','Offboarded']].map(([v,l])=>(
              <button key={v} onClick={()=>setStatusFlt(v)} style={{
                padding:'7px 14px',borderRadius:100,border:'none',cursor:'pointer',
                fontFamily:"'DM Sans',sans-serif",fontSize:12.5,fontWeight:600,
                background:statusFlt===v?B.accent:B.surface,color:statusFlt===v?'#fff':B.dim,
                border:`1.5px solid ${statusFlt===v?B.accent:B.border}`,transition:'all .12s',
              }}>{l}</button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="card" style={{overflow:'hidden'}}>
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead>
              <tr style={{background:B.bg,borderBottom:`1px solid ${B.border}`}}>
                {[['name','Contractor'],['','Client'],['rate','Rate'],['ytd','YTD hours'],['','Status'],['','Xero'],['start','Start'],['','']].map(([f,h])=>(
                  <th key={h} onClick={f?()=>toggleSort(f as SortField):undefined} style={{
                    padding:'11px 16px',textAlign:'left',fontSize:11,fontWeight:700,
                    textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,
                    cursor:f?'pointer':'default',userSelect:'none',whiteSpace:'nowrap',
                  }}>
                    {h}{f?' '+sortIcon(f as SortField):''}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length===0 && (
                <tr><td colSpan={8} style={{padding:'48px',textAlign:'center',color:B.dim,fontSize:14}}>No contractors match your search.</td></tr>
              )}
              {filtered.map((c,i)=>{
                const sp = STATUS_PILL[c.status]||{bg:B.faint,c:B.dim,label:c.status}
                return (
                  <tr key={c.id} style={{borderTop:i>0?`1px solid ${B.faint}`:'none',transition:'background .1s'}}
                    onMouseEnter={e=>(e.currentTarget as HTMLElement).style.background=B.faint}
                    onMouseLeave={e=>(e.currentTarget as HTMLElement).style.background='transparent'}>
                    <td style={{padding:'13px 16px'}}>
                      <div style={{display:'flex',alignItems:'center',gap:10}}>
                        <div style={{width:34,height:34,borderRadius:9,background:c.bg,color:c.col,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:700,flexShrink:0}}>{c.initials}</div>
                        <div>
                          <div style={{fontSize:14,fontWeight:600,color:B.text}}>{c.firstName} {c.lastName}</div>
                          <div style={{fontSize:12,color:B.dim}}>{c.email}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{padding:'13px 16px',fontSize:13.5,color:B.mid}}>{c.client}</td>
                    <td style={{padding:'13px 16px',fontFamily:"'DM Mono',monospace",fontSize:13.5,color:B.text}}>${c.hourlyRate}/hr</td>
                    <td style={{padding:'13px 16px'}}>
                      <div style={{fontFamily:"'DM Mono',monospace",fontSize:13.5,color:B.text}}>{c.ytdHours>0?`${c.ytdHours}h`:'—'}</div>
                      {c.ytdHours>0&&<div style={{fontSize:11.5,color:B.green}}>{fmt(c.ytdHours*c.hourlyRate)}</div>}
                    </td>
                    <td style={{padding:'13px 16px'}}><span style={{fontSize:12,fontWeight:600,padding:'3px 9px',borderRadius:100,background:sp.bg,color:sp.c}}>{sp.label}</span></td>
                    <td style={{padding:'13px 16px'}}>{c.xero?<span style={{fontSize:12,color:B.green,fontWeight:600}}>✓ Linked</span>:<span style={{fontSize:12,color:B.sub}}>—</span>}</td>
                    <td style={{padding:'13px 16px',fontSize:13,color:B.dim,whiteSpace:'nowrap'}}>{c.startDate}</td>
                    <td style={{padding:'13px 16px'}}>
                      <a href={`/admin/contractors/${c.id}`} style={{fontSize:12.5,fontWeight:600,color:B.accent,textDecoration:'none',padding:'5px 12px',borderRadius:7,background:B.aP,border:`1px solid ${B.aBd}`,whiteSpace:'nowrap'}}>View →</a>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </main>
    </>
  )
}
