'use client'
// app/admin/pay-items/page.tsx
import { useState } from 'react'
import TopBar from '@/components/layout/TopBar'
import { B } from '@/lib/design'

interface PayItem {
  id:string; code:string; name:string; description:string
  itemType:string; rateMultiplier:number; isActive:boolean; isSystem:boolean
  atpCategory?:string; xeroPayrollId?:string
}

const TYPE_STYLE: Record<string,{bg:string,c:string}> = {
  EARNINGS:  {bg:B.gP,   c:B.green  },
  DEDUCTION: {bg:B.rP,   c:B.red    },
  ALLOWANCE: {bg:B.aLP,  c:B.amber  },
  LEAVE:     {bg:B.aP,   c:B.accent },
}

const SEED: PayItem[] = [
  {id:'pi1',code:'ORDINARY',      name:'Ordinary time earnings',  description:'Standard hourly rate',              itemType:'EARNINGS',  rateMultiplier:1.000,isActive:true, isSystem:true, atpCategory:'OrdinaryTimeEarnings'},
  {id:'pi2',code:'OVERTIME_1_5',  name:'Overtime 1.5×',           description:'Time and a half',                   itemType:'EARNINGS',  rateMultiplier:1.500,isActive:true, isSystem:true, atpCategory:'OvertimeEarnings'},
  {id:'pi3',code:'OVERTIME_2_0',  name:'Overtime 2.0×',           description:'Double time',                       itemType:'EARNINGS',  rateMultiplier:2.000,isActive:true, isSystem:true, atpCategory:'OvertimeEarnings'},
  {id:'pi4',code:'ALLOWANCE_CAR', name:'Car allowance',           description:'Per km or flat rate car allowance', itemType:'ALLOWANCE', rateMultiplier:1.000,isActive:true, isSystem:false,atpCategory:'AllowanceTypeOther'},
  {id:'pi5',code:'ALLOWANCE_PHONE',name:'Phone allowance',        description:'Mobile phone allowance',            itemType:'ALLOWANCE', rateMultiplier:1.000,isActive:true, isSystem:false,atpCategory:'AllowanceTypeOther'},
  {id:'pi6',code:'ALLOWANCE_MEAL',name:'Meal allowance',          description:'Meal/entertainment allowance',      itemType:'ALLOWANCE', rateMultiplier:1.000,isActive:false,isSystem:false,atpCategory:'AllowanceTypeMeals'},
  {id:'pi7',code:'LEAVE_ANNUAL',  name:'Annual leave payout',     description:'Payout of accrued annual leave',    itemType:'LEAVE',     rateMultiplier:1.000,isActive:true, isSystem:true, atpCategory:'AnnualLeaveLoading'},
  {id:'pi8',code:'LEAVE_SICK',    name:'Sick leave',              description:'Personal/carer leave',              itemType:'LEAVE',     rateMultiplier:1.000,isActive:true, isSystem:true, atpCategory:'PersonalLeaveEarnings'},
  {id:'pi9',code:'PAYG',          name:'PAYG withholding',        description:'Income tax withheld',               itemType:'DEDUCTION', rateMultiplier:1.000,isActive:true, isSystem:true},
  {id:'pi10',code:'SUPER_SGC',    name:'Superannuation SGC',      description:'Super guarantee contribution',      itemType:'DEDUCTION', rateMultiplier:1.000,isActive:true, isSystem:true},
]

const BLANK: Omit<PayItem,'id'> = {
  code:'', name:'', description:'', itemType:'EARNINGS',
  rateMultiplier:1.000, isActive:true, isSystem:false,
}

export default function PayItemsPage() {
  const [items,    setItems]    = useState<PayItem[]>(SEED)
  const [filter,   setFilter]   = useState('all')
  const [editing,  setEditing]  = useState<string|null>(null)
  const [newItem,  setNewItem]  = useState(false)
  const [draft,    setDraft]    = useState<typeof BLANK>(BLANK)
  const [toast,    setToast]    = useState<string|null>(null)

  const toast_ = (m:string) => { setToast(m); setTimeout(()=>setToast(null),2800) }

  const filtered = filter==='all' ? items : items.filter(i=>i.itemType===filter)

  const handleSaveNew = () => {
    if (!draft.code || !draft.name) return
    setItems(prev => [...prev, {...draft, id:'new-'+Date.now()}])
    setNewItem(false)
    setDraft(BLANK)
    toast_('✓ Pay item created')
  }

  const toggleActive = (id: string) => {
    setItems(prev => prev.map(i => i.id===id&&!i.isSystem ? {...i, isActive:!i.isActive} : i))
  }

  return (
    <>
      <TopBar title="Pay items" subtitle="Earnings types, allowances and deductions"
        actions={<button onClick={()=>setNewItem(true)} className="btn btn-accent btn-sm" style={{padding:'8px 16px'}}>+ New pay item</button>}
      />
      <main style={{flex:1,padding:'28px 32px',background:B.bg}}>

        {/* Type filter */}
        <div style={{display:'flex',gap:6,marginBottom:18}}>
          {[['all','All types'],['EARNINGS','Earnings'],['ALLOWANCE','Allowances'],['LEAVE','Leave'],['DEDUCTION','Deductions']].map(([v,l])=>(
            <button key={v} onClick={()=>setFilter(v)} style={{
              padding:'7px 15px',borderRadius:100,border:'none',cursor:'pointer',
              fontFamily:"'DM Sans',sans-serif",fontSize:12.5,fontWeight:600,
              background:filter===v?B.accent:B.surface,color:filter===v?'#fff':B.dim,
              border:`1.5px solid ${filter===v?B.accent:B.border}`,transition:'all .12s',
            }}>{l}</button>
          ))}
        </div>

        <div className="card" style={{overflow:'hidden'}}>
          <table style={{width:'100%',borderCollapse:'collapse'}}>
            <thead>
              <tr style={{background:B.bg,borderBottom:`1px solid ${B.border}`}}>
                {['Code','Name','Type','Rate','ATO category','Active',''].map(h=>(
                  <th key={h} style={{padding:'11px 16px',textAlign:'left',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((item,i)=>{
                const ts = TYPE_STYLE[item.itemType]||{bg:B.faint,c:B.dim}
                const isEdit = editing===item.id
                return (
                  <tr key={item.id} style={{borderTop:i>0?`1px solid ${B.faint}`:'none',opacity:item.isActive?1:0.5}}>
                    <td style={{padding:'12px 16px',fontFamily:"'DM Mono',monospace",fontSize:13,color:B.accent,fontWeight:600}}>{item.code}</td>
                    <td style={{padding:'12px 16px'}}>
                      <div style={{fontSize:13.5,fontWeight:500,color:B.text}}>{item.name}</div>
                      <div style={{fontSize:12,color:B.dim}}>{item.description}</div>
                    </td>
                    <td style={{padding:'12px 16px'}}>
                      <span style={{fontSize:12,fontWeight:600,padding:'3px 9px',borderRadius:100,...ts}}>{item.itemType}</span>
                    </td>
                    <td style={{padding:'12px 16px',fontFamily:"'DM Mono',monospace",fontSize:13,color:item.rateMultiplier>1?B.amber:B.text,fontWeight:item.rateMultiplier>1?700:400}}>
                      {item.rateMultiplier.toFixed(3)}×
                    </td>
                    <td style={{padding:'12px 16px',fontSize:12.5,color:B.sub}}>{item.atpCategory||'—'}</td>
                    <td style={{padding:'12px 16px'}}>
                      <button onClick={()=>toggleActive(item.id)} disabled={item.isSystem} title={item.isSystem?'System items cannot be disabled':undefined} style={{
                        width:40,height:22,borderRadius:11,border:'none',cursor:item.isSystem?'not-allowed':'pointer',
                        background:item.isActive?B.green:B.border,position:'relative',transition:'background .18s',
                        opacity:item.isSystem?0.6:1,
                      }}>
                        <span style={{position:'absolute',top:2,left:item.isActive?20:2,width:18,height:18,borderRadius:'50%',background:'#fff',boxShadow:'0 1px 4px rgba(0,0,0,.2)',transition:'left .18s'}}/>
                      </button>
                    </td>
                    <td style={{padding:'12px 16px'}}>
                      {item.isSystem
                        ? <span style={{fontSize:11,padding:'2px 8px',borderRadius:4,background:B.faint,color:B.sub,fontWeight:600}}>System</span>
                        : <button onClick={()=>setEditing(isEdit?null:item.id)} style={{fontSize:12.5,color:B.accent,fontWeight:600,background:'none',border:'none',cursor:'pointer'}}>{isEdit?'Done':'Edit'}</button>
                      }
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {/* System items note */}
        <div style={{marginTop:12,fontSize:12.5,color:B.sub,padding:'0 4px'}}>
          System items are required for payroll processing and STP lodgement — they cannot be disabled or deleted. Custom items can be freely created and managed.
        </div>
      </main>

      {/* New item modal */}
      {newItem && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,.45)',zIndex:100,display:'flex',alignItems:'center',justifyContent:'center'}}>
          <div className="card" style={{width:480,padding:'24px 26px',margin:16}}>
            <h3 style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:16}}>New pay item</h3>
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
                <div>
                  <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:5}}>Code *</label>
                  <input value={draft.code} onChange={e=>setDraft(d=>({...d,code:e.target.value.toUpperCase().replace(/\s/g,'_')}))}
                    placeholder="e.g. WEEKEND_1_5"
                    style={{width:'100%',padding:'10px 12px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Mono',monospace",fontSize:13,color:B.text,background:B.surface,boxSizing:'border-box',outline:'none'}}
                    onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
                  />
                </div>
                <div>
                  <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:5}}>Rate multiplier</label>
                  <input type="number" step="0.001" min="0" value={draft.rateMultiplier} onChange={e=>setDraft(d=>({...d,rateMultiplier:Number(e.target.value)}))}
                    style={{width:'100%',padding:'10px 12px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Mono',monospace",fontSize:13,color:B.text,background:B.surface,boxSizing:'border-box',outline:'none'}}
                    onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
                  />
                </div>
              </div>
              <div>
                <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:5}}>Name *</label>
                <input value={draft.name} onChange={e=>setDraft(d=>({...d,name:e.target.value}))} placeholder="e.g. Weekend rate 1.5×"
                  style={{width:'100%',padding:'10px 12px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,background:B.surface,boxSizing:'border-box',outline:'none'}}
                  onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
                />
              </div>
              <div>
                <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:5}}>Type</label>
                <select value={draft.itemType} onChange={e=>setDraft(d=>({...d,itemType:e.target.value}))}
                  style={{width:'100%',padding:'10px 12px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,background:B.surface}}>
                  {['EARNINGS','ALLOWANCE','LEAVE','DEDUCTION'].map(t=><option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label style={{display:'block',fontSize:11,fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',color:B.dim,marginBottom:5}}>Description</label>
                <input value={draft.description} onChange={e=>setDraft(d=>({...d,description:e.target.value}))}
                  style={{width:'100%',padding:'10px 12px',borderRadius:9,border:`1.5px solid ${B.border}`,fontFamily:"'DM Sans',sans-serif",fontSize:14,color:B.text,background:B.surface,boxSizing:'border-box',outline:'none'}}
                  onFocus={e=>e.target.style.borderColor=B.accent} onBlur={e=>e.target.style.borderColor=B.border}
                />
              </div>
            </div>
            <div style={{display:'flex',gap:8,marginTop:18,justifyContent:'flex-end'}}>
              <button onClick={()=>{setNewItem(false);setDraft(BLANK)}} className="btn btn-ghost btn-sm">Cancel</button>
              <button onClick={handleSaveNew} disabled={!draft.code||!draft.name} className="btn btn-accent btn-sm" style={{opacity:(!draft.code||!draft.name)?0.4:1}}>
                Create pay item
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div style={{position:'fixed',bottom:24,right:24,zIndex:999,background:B.text,color:'#fff',padding:'12px 22px',borderRadius:10,fontWeight:600,fontSize:13,boxShadow:'0 4px 16px rgba(0,0,0,.18)'}}>{toast}</div>
      )}
    </>
  )
}
